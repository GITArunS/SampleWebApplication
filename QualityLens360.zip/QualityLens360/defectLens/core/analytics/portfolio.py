"""Portfolio hold-time analytics."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime


class CDEXPortfolioAnalyzer:
    """Calculate cumulative minutes spent with each application team."""

    def process_changelog(self, details: str) -> dict[str, float]:
        if not details:
            return {}

        events: list[dict[str, datetime | str]] = []
        current_time: datetime | None = None
        current_from: str | None = None

        for raw_line in details.splitlines():
            line = raw_line.strip()

            if line.startswith("Change on:"):
                value = line.replace("Change on:", "").strip()
                try:
                    current_time = datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%f%z")
                except ValueError:
                    current_time = None
            elif line.startswith("From:"):
                current_from = line.replace("From:", "").strip()
            elif line.startswith("To:") and current_time and current_from:
                events.append({"app": current_from, "time": current_time})
                current_from = line.replace("To:", "").strip()

        if len(events) < 2:
            return {}

        app_minutes: defaultdict[str, float] = defaultdict(float)
        for index in range(len(events) - 1):
            start = events[index]
            end = events[index + 1]
            app_name = str(start["app"])
            if "CQE" in app_name.upper():
                continue

            delta_minutes = (end["time"] - start["time"]).total_seconds() / 60.0
            if delta_minutes > 0:
                app_minutes[app_name] += delta_minutes

        return dict(app_minutes)
