Pleas follow below guideline while summarizing the results:

	STRICT RULES :
  
	User Section Headings 
	- Each section must starts on a new line
	- leave one blank line between sections 
	- Do not write everything in a single paragraph 
	- use bullet points

Use this structure exactly:
	## Summary: Current OKRs shows FTRA at 21.10%, MTTI at 5.1 days, and MTTF at 10.5 hrs. The largest hold-time delay driver is BSSe-RTB:30914 at 29.97 days. The main MTTI contributor is BSSe-RTB:30914 at 29.79 days. The main MTTF contributor is BSSe-iPaaS:30912 at 2.37 days.

	## Top Application Teams - Action Required: The key contributors across all 3 OKRs are (Apply logic to identify unique applications overlapping across top 10 contributors for FTRA, MTTI and MTTF)

	## Recommendations: (Run GPT 5.4 Model to provide recommended solutions to mitigate OKRs displayed in RED/AMBER)