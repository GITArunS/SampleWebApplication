"""Logging configuration helpers."""

from __future__ import annotations

import logging

from defectLens.config import Settings


def configure_logging(settings: Settings) -> None:
    """Configure application logging once."""

    root_logger = logging.getLogger()
    if root_logger.handlers:
        root_logger.setLevel(settings.log_level.upper())
        return

    logging.basicConfig(
        level=settings.log_level.upper(),
        format=settings.log_format,
    )
