"""Date parsing and time-based OKR helpers."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from defectLens.config import Settings, get_settings


def _resolve_settings(settings: Settings | None) -> Settings:
    return settings if settings is not None else get_settings()


def parse_jira_datetime(value: str) -> datetime | None:
    """Parse Jira timestamps across multiple timestamp shapes."""

    if not value or not isinstance(value, str):
        return None

    normalized = value.strip()
    if normalized.endswith("Z"):
        normalized = normalized[:-1] + "+0000"

    for fmt in ("%Y-%m-%dT%H:%M:%S.%f%z", "%Y-%m-%dT%H:%M:%S%z"):
        try:
            return datetime.strptime(normalized, fmt)
        except ValueError:
            continue

    for fmt in ("%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(normalized, fmt).replace(tzinfo=timezone.utc)
        except ValueError:
            continue

    return None


def is_excluded_team(team_name: str, settings: Settings | None = None) -> bool:
    """Return True when the target team should be ignored for metrics."""

    resolved = _resolve_settings(settings)
    normalized = (team_name or "").strip().lower()
    if not normalized:
        return True
    tokens = tuple(value.strip().lower() for value in resolved.excluded_values)
    return any(token in normalized for token in tokens)


def get_created_ts(issue_json: dict[str, Any]) -> datetime | None:
    """Return the issue creation timestamp."""

    created_str = issue_json.get("fields", {}).get("created") or issue_json.get("created")
    return parse_jira_datetime(created_str) if created_str else None


def get_resolved_ts(issue_json: dict[str, Any]) -> datetime | None:
    """Return the issue resolved timestamp."""

    resolved_str = (
        issue_json.get("fields", {}).get("resolutiondate")
        or issue_json.get("fields", {}).get("resolved")
        or issue_json.get("resolved")
    )
    return parse_jira_datetime(resolved_str) if resolved_str else None


def detect_itrack_display_tz(issue_json: dict[str, Any]) -> timezone | None:
    """Infer the timezone Jira used when displaying timestamps in the UI."""

    histories = (issue_json.get("changelog") or {}).get("histories", []) or []
    for history in histories:
        parsed = parse_jira_datetime(history.get("created", ""))
        if parsed and parsed.tzinfo:
            return parsed.tzinfo
    return None


def format_created_like_itrack_ui(issue_json: dict[str, Any]) -> str:
    """Render Created in the same format shown in iTrack."""

    created_dt = get_created_ts(issue_json)
    if not created_dt:
        return ""

    display_tz = detect_itrack_display_tz(issue_json)
    if display_tz:
        created_dt = created_dt.astimezone(display_tz)

    hour = created_dt.strftime("%I").lstrip("0") or "0"
    return f"{created_dt.strftime('%Y/%m/%d')} {hour}:{created_dt.strftime('%M')} {created_dt.strftime('%p')}"


def format_ts_like_column_c(value: datetime | None) -> str:
    """Format timestamps like the existing workbook output."""

    if not value:
        return ""
    milliseconds = int(value.microsecond / 1000)
    return value.strftime("%Y-%m-%dT%H:%M:%S.") + f"{milliseconds:03d}" + value.strftime("%z")


def find_last_valid_app_fixed_in(
    issue_json: dict[str, Any],
    settings: Settings | None = None,
) -> tuple[str | None, datetime | None]:
    """Return the last valid Application Fixed In team and timestamp."""

    resolved = _resolve_settings(settings)
    histories = (issue_json.get("changelog") or {}).get("histories", []) or []
    last_team: str | None = None
    last_ts: datetime | None = None
    field_check_lower = resolved.field_to_check.strip().lower()

    for history in histories:
        created = parse_jira_datetime(history.get("created", ""))
        if not created:
            continue

        for item in history.get("items", []) or []:
            raw_field = str(item.get("field") or "").strip()
            if raw_field:
                is_target_field = raw_field.lower() == field_check_lower
            else:
                raw_field_id = str(item.get("fieldId") or "").strip().lower()
                is_target_field = field_check_lower in raw_field_id

            if not is_target_field:
                continue

            team_name = str(item.get("toString") or "").strip()
            if is_excluded_team(team_name, resolved):
                continue

            if last_ts is None or created > last_ts:
                last_ts = created
                last_team = team_name

    return last_team, last_ts


def find_status_change_ts(issue_json: dict[str, Any], target_status: str = "Dev Complete") -> datetime | None:
    """Return the first time the issue transitioned to the target status."""

    histories = (issue_json.get("changelog") or {}).get("histories", []) or []
    target = (target_status or "").strip().lower()
    found: datetime | None = None

    for history in histories:
        created = parse_jira_datetime(history.get("created", ""))
        if not created:
            continue
        for item in history.get("items", []) or []:
            if str(item.get("field") or "").strip().lower() != "status":
                continue
            if str(item.get("toString") or "").strip().lower() != target:
                continue
            if found is None or created < found:
                found = created

    return found


def compute_mtti_minutes(issue_json: dict[str, Any], settings: Settings | None = None) -> float | None:
    """Return MTTI in minutes."""

    resolved = _resolve_settings(settings)
    created_ts = get_created_ts(issue_json)
    if not created_ts:
        return None

    _, last_app_ts = find_last_valid_app_fixed_in(issue_json, resolved)
    if not last_app_ts:
        last_app_ts = created_ts

    delta = (last_app_ts - created_ts).total_seconds() / 60.0
    return float(delta) if delta >= 0 else 0.0


def compute_mttf_minutes(issue_json: dict[str, Any], settings: Settings | None = None) -> float | None:
    """Return MTTF in minutes."""

    resolved = _resolve_settings(settings)
    _, last_app_ts = find_last_valid_app_fixed_in(issue_json, resolved)
    if not last_app_ts:
        last_app_ts = get_created_ts(issue_json)
    if not last_app_ts:
        return None

    end_ts = find_status_change_ts(issue_json, "Dev Complete")
    if not end_ts:
        end_ts = find_status_change_ts(issue_json, "Retest")
    if not end_ts:
        return None

    delta = (end_ts - last_app_ts).total_seconds() / 60.0
    return float(delta) if delta >= 0 else 0.0


def compute_mttr_minutes(issue_json: dict[str, Any]) -> float | None:
    """Return MTTR in minutes using resolved minus created timestamps."""

    created_ts = get_created_ts(issue_json)
    resolved_ts = get_resolved_ts(issue_json)
    if not created_ts or not resolved_ts:
        return None

    delta = (resolved_ts - created_ts).total_seconds() / 60.0
    return float(delta) if delta >= 0 else 0.0
