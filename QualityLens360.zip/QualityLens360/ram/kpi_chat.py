"""
RAM KPI Configuration Chat

Guided conversational interface for teams to add/manage KPIs
for their application without touching code.
"""

import json
import os
import re
from copy import deepcopy
from pathlib import Path

from ram.app_config import (
    RAM_APPLICATION_DEFINITIONS,
    RAM_APPLICATION_OPTIONS,
    RAM_KPI_TILES,
    get_ram_application_definition,
    get_ram_application_handler,
    get_custom_application_names,
    register_kpi_handler,
    remove_custom_application,
    save_custom_application,
)

# Persistent storage for user-defined KPI configurations
_KPI_CONFIG_DIR = Path(__file__).resolve().parent / '_kpi_configs'
_KPI_CONFIG_DIR.mkdir(exist_ok=True)


# ============================================================================
# CONFIG PERSISTENCE
# ============================================================================

def _config_path(application):
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', application)
    return _KPI_CONFIG_DIR / f'{safe_name}.json'


def load_custom_kpis(application):
    path = _config_path(application)
    if path.exists():
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    return []


def save_custom_kpis(application, kpis):
    path = _config_path(application)
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(kpis, fh, indent=2, ensure_ascii=False)


def _get_all_tile_ids():
    return {tile['id'] for tile in RAM_KPI_TILES}


def _generate_tile_id(title):
    slug = re.sub(r'[^a-z0-9]+', '-', title.lower()).strip('-')
    return slug or 'custom-kpi'


# ============================================================================
# CHAT STATE MACHINE
# ============================================================================

# Steps:
#   idle          -> user opens chat
#   pick_action   -> "add kpi" or "list kpis" or "remove kpi"
#   pick_app      -> select application
#   kpi_title     -> enter KPI title
#   kpi_jql       -> enter the JQL for the numerator
#   kpi_denom_jql -> enter the JQL for the denominator (optional)
#   kpi_formula   -> enter the formula / logic description
#   kpi_target    -> enter target (e.g. ">=80%")
#   confirm       -> review and confirm

GREETING = (
    "Hi! I can help you configure KPIs for any RAM application.\n\n"
    "What would you like to do?\n"
    "1. **Add a new application**\n"
    "2. **Update an existing application**\n"
    "3. **Remove an application**\n"
    "4. **List configured KPIs**\n"
    "5. **Add a new KPI**\n"
    "6. **Update an existing KPI**\n"
    "7. **Remove a KPI**"
)


def _app_list_text():
    apps = list(dict.fromkeys(RAM_APPLICATION_OPTIONS))  # preserves order, deduplicates
    if not apps:
        return "No applications are currently configured."
    return "Which application?\n" + "\n".join(f"- **{app}**" for app in apps)


def _build_combined_kpi_list(application):
    """Build a combined list of builtin tiles + custom KPIs for an application.

    Each entry is a dict with:
      kind:     'builtin' | 'custom'
      title:    display title
      tile_id:  tile id (builtin) or kpi id (custom)
      index:    index into custom_kpis list (custom only)
    """
    app_def = get_ram_application_definition(application)
    tile_ids = app_def.get('tile_ids', []) if app_def else []
    tile_overrides = app_def.get('tile_overrides', {}) if app_def else {}
    rag_targets = app_def.get('rag_targets', {}) if app_def else {}
    tile_lookup = {t['id']: t for t in RAM_KPI_TILES}
    combined = []
    for tid in tile_ids:
        tile = tile_lookup.get(tid, {})
        title = tile_overrides.get(tid, {}).get('title', tile.get('title', tid))
        target = rag_targets.get(tid, {}).get('label', '—')
        combined.append({
            'kind': 'builtin',
            'title': title,
            'tile_id': tid,
            'target_label': target,
        })
    custom = load_custom_kpis(application)
    for i, kpi in enumerate(custom):
        combined.append({
            'kind': 'custom',
            'title': kpi.get('title', ''),
            'tile_id': kpi.get('id', ''),
            'index': i,
            'target_label': kpi.get('target_label', '—'),
        })
    return combined


def handle_chat_message(session_state, user_message):
    """
    Process a chat message and return (reply_text, updated_session_state).

    session_state is a dict persisted in the Flask session.
    """
    state = dict(session_state or {})
    step = state.get('step', 'idle')
    msg = (user_message or '').strip()

    if msg.lower() in ('reset', 'start over', 'cancel', 'quit'):
        return GREETING, {'step': 'pick_action'}

    if not msg or step == 'idle':
        return GREETING, {'step': 'pick_action'}

    if step == 'pick_action':
        return _handle_pick_action(msg, state)

    if step == 'pick_app':
        return _handle_pick_app(msg, state)

    if step == 'pick_existing_kpi':
        return _handle_pick_existing_kpi(msg, state)

    if step == 'review_kpi':
        return _handle_review_kpi(msg, state)

    if step == 'review_edit_field':
        return _handle_review_edit_field(msg, state)

    if step == 'review_pick_base_jql':
        return _handle_review_pick_base_jql(msg, state)

    if step == 'pick_tile_scope':
        return _handle_pick_tile_scope(msg, state)

    if step == 'collect_missing_config':
        return _handle_collect_missing_config(msg, state)

    if step == 'builtin_kpi_target':
        return _handle_builtin_kpi_target(msg, state)

    if step == 'kpi_title':
        return _handle_kpi_title(msg, state)

    if step == 'kpi_formula_type':
        return _handle_kpi_formula_type(msg, state)

    if step == 'kpi_pick_base_jql':
        return _handle_kpi_pick_base_jql(msg, state)

    if step == 'kpi_jql':
        return _handle_kpi_jql(msg, state)

    if step == 'kpi_denom_jql':
        return _handle_kpi_denom_jql(msg, state)

    if step == 'kpi_formula':
        return _handle_kpi_formula(msg, state)

    if step == 'kpi_comparison_mode':
        return _handle_kpi_comparison_mode(msg, state)

    if step == 'kpi_second_jql':
        return _handle_kpi_second_jql(msg, state)

    if step == 'kpi_custom_formula':
        return _handle_kpi_custom_formula(msg, state)

    if step == 'kpi_statuses':
        return _handle_kpi_statuses(msg, state)

    if step == 'kpi_working_days':
        return _handle_kpi_working_days(msg, state)

    if step == 'kpi_target':
        return _handle_kpi_target(msg, state)

    if step == 'confirm':
        return _handle_confirm(msg, state)

    if step == 'pick_remove':
        return _handle_pick_remove(msg, state)

    if step == 'pick_update':
        return _handle_pick_update(msg, state)

    if step == 'pick_update_field':
        return _handle_pick_update_field(msg, state)

    if step == 'update_value':
        return _handle_update_value(msg, state)

    if step == 'new_app_name':
        return _handle_new_app_name(msg, state)

    if step == 'new_app_pick_groups':
        return _handle_new_app_pick_groups(msg, state)

    if step == 'new_app_base_jql':
        return _handle_new_app_base_jql(msg, state)

    if step == 'new_app_preprod_base_jql':
        return _handle_new_app_preprod_base_jql(msg, state)

    if step == 'new_app_functional_base_jql':
        return _handle_new_app_functional_base_jql(msg, state)

    if step == 'new_app_automation_base_jql':
        return _handle_new_app_automation_base_jql(msg, state)

    if step == 'new_app_working_days':
        return _handle_new_app_working_days(msg, state)

    if step == 'new_app_filters':
        return _handle_new_app_filters(msg, state)

    if step == 'new_app_confirm':
        return _handle_new_app_confirm(msg, state)

    if step == 'pick_remove_app':
        return _handle_pick_remove_app(msg, state)

    if step == 'update_app_pick_groups':
        return _handle_update_app_pick_groups(msg, state)

    if step == 'update_app_base_jql':
        return _handle_update_app_base_jql(msg, state)

    if step == 'update_app_review':
        return _handle_update_app_review(msg, state)

    if step == 'update_app_review_edit':
        return _handle_update_app_review_edit(msg, state)

    if step == 'quick_setup_pick_group':
        return _handle_quick_setup_pick_group(msg, state)

    if step == 'quick_setup_confirm':
        return _handle_quick_setup_confirm(msg, state)

    if step == 'needs_preprod_jql':
        return _handle_needs_preprod_jql(msg, state)

    return GREETING, {'step': 'pick_action'}


# ============================================================================
# STEP HANDLERS
# ============================================================================

def _handle_pick_action(msg, state):
    lower = msg.lower()
    # 1 — Add a new application
    if lower == '1' or ('add' in lower and 'app' in lower) or 'new app' in lower:
        state['step'] = 'new_app_name'
        return "Enter the **name** for the new application (e.g. \"MyTeam-Prod\"):", state
    # 2 — Update an existing application
    if lower == '2' or ('update' in lower and 'app' in lower):
        state['action'] = 'update_app'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    # 3 — Remove an application
    if lower == '3' or ('remove' in lower and 'app' in lower) or ('delete' in lower and 'app' in lower):
        custom_names = get_custom_application_names()
        if not custom_names:
            return "No custom applications to remove.\n\nType **reset** to start over.", {'step': 'idle'}
        lines = ["Which custom application do you want to remove?\n"]
        for i, name in enumerate(custom_names, 1):
            lines.append(f"{i}. **{name}**")
        state['step'] = 'pick_remove_app'
        state['_custom_app_names'] = custom_names
        return "\n".join(lines), state
    # 4 — List configured KPIs
    if lower == '4' or 'list' in lower:
        state['action'] = 'list'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    # 5 — Add a new KPI
    if lower == '5' or ('add' in lower and 'kpi' in lower) or lower == 'add':
        state['action'] = 'add'
        state['step'] = 'pick_app'
        # Clear leftover KPI fields from any previous add flow
        for k in list(state.keys()):
            if k.startswith('kpi_') or k.startswith('_'):
                state.pop(k, None)
        return _app_list_text(), state
    # 6 — Update an existing KPI
    if lower == '6' or ('update' in lower and 'kpi' in lower) or 'edit' in lower:
        state['action'] = 'update'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    # 7 — Remove a KPI
    if lower == '7' or ('remove' in lower and 'kpi' in lower) or ('delete' in lower and 'kpi' in lower):
        state['action'] = 'remove'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    # Keyword fallbacks for ambiguous input
    if 'quick' in lower or 'setup' in lower:
        state['action'] = 'quick_setup'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    if 'remove' in lower or 'delete' in lower:
        state['action'] = 'remove'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    if 'update' in lower:
        state['action'] = 'update'
        state['step'] = 'pick_app'
        return _app_list_text(), state
    if 'add' in lower:
        state['action'] = 'add'
        state['step'] = 'pick_app'
        for k in list(state.keys()):
            if k.startswith('kpi_') or k.startswith('_'):
                state.pop(k, None)
        return _app_list_text(), state
    return (
        "Please choose:\n"
        "1. Add a new application\n"
        "2. Update an existing application\n"
        "3. Remove an application\n"
        "4. List configured KPIs\n"
        "5. Add a new KPI\n"
        "6. Update an existing KPI\n"
        "7. Remove a KPI"
    ), state


def _handle_pick_app(msg, state):
    apps = {name.lower(): name for name in RAM_APPLICATION_OPTIONS}
    matched = apps.get(msg.lower())
    if not matched:
        for key, name in apps.items():
            if msg.lower() in key:
                matched = name
                break
    if not matched:
        return f"I didn't recognise that application. {_app_list_text()}", state

    state['application'] = matched
    action = state.get('action', 'add')

    if action == 'list':
        app_def = get_ram_application_definition(matched)
        tile_ids = app_def.get('tile_ids', []) if app_def else []
        rag_targets = app_def.get('rag_targets', {}) if app_def else {}
        tile_overrides = app_def.get('tile_overrides', {}) if app_def else {}
        tile_lookup = {t['id']: t for t in RAM_KPI_TILES}

        lines = [f"**KPIs configured for {matched}:**\n"]
        lines.append("**Built-in KPIs:**")
        for i, tid in enumerate(tile_ids, 1):
            tile = tile_lookup.get(tid, {})
            title = tile_overrides.get(tid, {}).get('title', tile.get('title', tid))
            target = rag_targets.get(tid, {}).get('label', '—')
            lines.append(f"{i}. **{title}** — Target: {target}")

        custom = load_custom_kpis(matched)
        if custom:
            lines.append("\n**Custom KPIs (added via chat):**")
            for j, kpi in enumerate(custom, 1):
                lines.append(f"{j}. **{kpi['title']}** — Target: {kpi.get('target_label', '—')}")
        else:
            lines.append("\n_No custom KPIs added yet._")

        lines.append("\nType **reset** to start over.")
        return "\n".join(lines), {'step': 'idle'}

    if action == 'remove':
        combined = _build_combined_kpi_list(matched)
        if not combined:
            return f"No KPIs configured for **{matched}**.\n\nType **reset** to start over.", {'step': 'idle'}
        lines = [f"Which KPI do you want to remove from **{matched}**?\n"]
        for i, entry in enumerate(combined, 1):
            lines.append(f"{i}. {entry['title']}")
        state['step'] = 'pick_remove'
        state['_combined_kpi_list'] = combined
        return "\n".join(lines), state

    if action == 'update':
        combined = _build_combined_kpi_list(matched)
        if not combined:
            return f"No KPIs configured for **{matched}**.\n\nType **reset** to start over.", {'step': 'idle'}
        lines = [f"Which KPI do you want to update in **{matched}**?\n"]
        for i, entry in enumerate(combined, 1):
            lines.append(f"{i}. {entry['title']}")
        state['step'] = 'pick_update'
        state['_combined_kpi_list'] = combined
        return "\n".join(lines), state

    if action == 'update_app':
        app_def = get_ram_application_definition(matched) or {}
        if matched not in get_custom_application_names():
            return f"**{matched}** is a built-in application and cannot be updated via chat.\n\nType **reset** to start over.", {'step': 'idle'}
        existing_groups = set(app_def.get('configured_kpi_groups', []))
        tile_lookup = {t['id']: t for t in RAM_KPI_TILES}
        lines = [
            f"**Update application: {matched}**\n",
            "Select additional **KPI categories** to enable:\n",
        ]
        has_new = False
        for i, (group_name, group_tile_ids) in enumerate(_QUICK_SETUP_GROUPS.items(), 1):
            titles = [tile_lookup[tid]['title'] for tid in group_tile_ids if tid in tile_lookup]
            if group_name in existing_groups:
                lines.append(f"[chk {i}|{group_name} ✓ (already configured)|{', '.join(titles)}]")
            else:
                lines.append(f"[chk {i}|{group_name}|{', '.join(titles)}]")
                has_new = True
        if not has_new:
            return (
                f"All KPI categories are already configured for **{matched}**.\n\n"
                "Type **reset** to start over."
            ), {'step': 'idle'}
        lines.append(f"\n[chk-confirm|Confirm Selection]")
        state['step'] = 'update_app_pick_groups'
        return "\n".join(lines), state

    if action == 'quick_setup':
        state['step'] = 'quick_setup_pick_group'
        app_def = get_ram_application_definition(matched) or {}
        configured_ids = set(app_def.get('tile_ids', []))
        lines = [
            f"**Quick Setup for {matched}**\n",
            "Pick a KPI group to add all its KPIs at once:\n",
        ]
        for i, (group_name, group_tile_ids) in enumerate(_QUICK_SETUP_GROUPS.items(), 1):
            already = sum(1 for tid in group_tile_ids if tid in configured_ids)
            total = len(group_tile_ids)
            lines.append(f"[opt {i}|{group_name} ({already}/{total} configured)]")
        return "\n".join(lines), state

    # action == 'add'
    # Clear any leftover KPI fields from a previous flow
    for k in list(state.keys()):
        if k.startswith('kpi_') or k.startswith('_'):
            state.pop(k, None)
    state['step'] = 'pick_existing_kpi'
    return _build_kpi_catalog_text(matched, state), state


def _handle_quick_setup_pick_group(msg, state):
    """User picks which KPI group to bulk-add."""
    lower = msg.strip().lower()
    group_names = list(_QUICK_SETUP_GROUPS.keys())

    picked = None
    for i, name in enumerate(group_names, 1):
        if str(i) in lower or name.lower().startswith(lower[:6]):
            picked = name
            break
    if not picked:
        return "Please pick a group number (1-3) or type its name.", state

    application = state['application']
    app_def = get_ram_application_definition(application) or {}
    configured_ids = set(app_def.get('tile_ids', []))
    group_tile_ids = _QUICK_SETUP_GROUPS[picked]

    new_ids = [tid for tid in group_tile_ids if tid not in configured_ids]
    if not new_ids:
        return (
            f"All **{picked}** KPIs are already configured for **{application}**.\n\n"
            "Type **reset** to start over."
        ), {'step': 'idle'}

    # Build preview of what will be added
    lines = [f"**Quick Setup: {picked}** for **{application}**\n"]
    lines.append(f"This will add **{len(new_ids)} KPI(s)** with default targets:\n")
    for tid in new_ids:
        tile = next((t for t in RAM_KPI_TILES if t['id'] == tid), None)
        if tile:
            logic = _BUILTIN_KPI_JQL_LOGIC.get(tid, {})
            default_target = logic.get('default_target', 80)
            lines.append(f"- {tile['title']} (target: {default_target}%)")
    lines.append(f"\nProceed? **yes** / **no**")

    state['step'] = 'quick_setup_confirm'
    state['_quick_setup_group'] = picked
    state['_quick_setup_ids'] = new_ids
    return "\n".join(lines), state


def _handle_quick_setup_confirm(msg, state):
    """Confirm and execute bulk KPI addition."""
    lower = msg.strip().lower()
    if lower in ('no', 'n', 'cancel'):
        return "Cancelled. Type **reset** to start over.", {'step': 'idle'}
    if lower not in ('yes', 'y', 'ok', 'proceed'):
        return "Please type **yes** to proceed or **no** to cancel.", state

    application = state['application']
    app_def = get_ram_application_definition(application)
    if not app_def:
        return f"Application **{application}** not found.\n\nType **reset** to start over.", {'step': 'idle'}

    new_ids = state.get('_quick_setup_ids', [])
    group_name = state.get('_quick_setup_group', '')
    existing_ids = list(app_def.get('tile_ids', []))

    # Add all new tile IDs
    for tid in new_ids:
        if tid not in existing_ids:
            existing_ids.append(tid)
    app_def['tile_ids'] = existing_ids

    if application in get_custom_application_names():
        save_custom_application(app_def)

    # Check for missing required config across all newly added tiles
    all_missing = []
    seen_keys = set()
    for tid in new_ids:
        logic = _BUILTIN_KPI_JQL_LOGIC.get(tid, {})
        for cfg_key in logic.get('requires_config', []):
            if cfg_key not in seen_keys and not app_def.get(cfg_key):
                all_missing.append(cfg_key)
                seen_keys.add(cfg_key)

    # Check if any newly added tile needs preprod_base_jql
    needs_preprod = any(
        _BUILTIN_KPI_JQL_LOGIC.get(tid, {}).get('needs_preprod')
        for tid in new_ids
    )
    if needs_preprod and not str(app_def.get('preprod_base_jql') or '').strip():
        if 'preprod_base_jql' not in seen_keys:
            all_missing.insert(0, 'preprod_base_jql')
            seen_keys.add('preprod_base_jql')

    added_titles = []
    for tid in new_ids:
        tile = next((t for t in RAM_KPI_TILES if t['id'] == tid), None)
        if tile:
            added_titles.append(tile['title'])

    summary = f"Added **{len(new_ids)} KPIs** from **{group_name}**:\n" + "\n".join(f"- {t}" for t in added_titles)

    if all_missing:
        state['_missing_config_keys'] = all_missing
        state['_missing_config_idx'] = 0
        resp, state = _prompt_next_missing_config(state)
        return summary + "\n\n" + resp, state

    return summary + "\n\nType **reset** to start over.", {'step': 'idle'}


def _collect_all_unique_kpis():
    """Gather all unique KPIs across built-in tiles and all custom configs."""
    seen_ids = set()
    kpis = []
    # Built-in tiles
    for tile in RAM_KPI_TILES:
        if tile['id'] not in seen_ids:
            seen_ids.add(tile['id'])
            kpis.append({
                'id': tile['id'],
                'title': tile.get('title', tile['id']),
                'source': 'built-in',
                'section': tile.get('section', 'Defect Triage & Management Metrics'),
            })
    # Custom KPIs from all applications
    for app_name in RAM_APPLICATION_OPTIONS:
        custom = load_custom_kpis(app_name)
        for kpi in custom:
            if kpi['id'] not in seen_ids:
                seen_ids.add(kpi['id'])
                kpis.append({
                    'id': kpi['id'],
                    'title': kpi.get('title', kpi['id']),
                    'source': f'custom ({app_name})',
                    'source_app': app_name,
                    'section': 'Custom KPIs',
                })
    return kpis


def _best_target_for_kpi(kpi_id):
    """Find the best RAG target across all app definitions and custom KPIs."""
    candidates = []
    # Scan all app definitions' rag_targets
    for app_def in RAM_APPLICATION_DEFINITIONS.values():
        rag = app_def.get('rag_targets', {}).get(kpi_id)
        if rag and 'direction' in rag and 'threshold' in rag:
            candidates.append(rag)
    # Scan custom KPIs across all apps
    for app_name in RAM_APPLICATION_OPTIONS:
        for kpi in load_custom_kpis(app_name):
            if kpi['id'] == kpi_id and kpi.get('rag_target'):
                rag = kpi['rag_target']
                if 'direction' in rag and 'threshold' in rag:
                    candidates.append(rag)
    if not candidates:
        return None
    # For 'min' (>=): pick the highest threshold (most ambitious)
    # For 'max' (<=): pick the lowest threshold (most strict)
    min_candidates = [c for c in candidates if c['direction'] == 'min']
    max_candidates = [c for c in candidates if c['direction'] == 'max']
    if min_candidates:
        return max(min_candidates, key=lambda c: c['threshold'])
    if max_candidates:
        return min(max_candidates, key=lambda c: c['threshold'])
    return candidates[0]


def _lookup_kpi_data(kpi_entry):
    """Look up the full data for a catalog entry at selection time."""
    if kpi_entry['source'] == 'built-in':
        for tile in RAM_KPI_TILES:
            if tile['id'] == kpi_entry['id']:
                return tile
        return {}
    # Custom KPI — load from the source app's config
    source_app = kpi_entry.get('source_app', '')
    if source_app:
        for kpi in load_custom_kpis(source_app):
            if kpi['id'] == kpi_entry['id']:
                return kpi
    return {}


def _build_kpi_catalog_text(application, state):
    """Build the selectable KPI catalog list, grouped by section, filtered."""
    all_kpis = _collect_all_unique_kpis()

    # Filter out already-configured KPIs for this application
    app_def = get_ram_application_definition(application)
    configured_tile_ids = set(app_def.get('tile_ids', [])) if app_def else set()
    configured_custom_ids = {k['id'] for k in load_custom_kpis(application)}
    configured_ids = configured_tile_ids | configured_custom_ids

    # Map group names to catalog section names
    _GROUP_TO_SECTION = {
        'Defect Triage Efficiency': 'Defect Triage & Management Metrics',
        'Functional Efficiency': 'Functional Efficiency Metrics',
        'Automation Efficiency': 'Automation Efficiency Metrics',
    }

    # Filter by configured groups if app has them
    configured_groups = (app_def.get('configured_kpi_groups') or []) if app_def else []
    allowed_sections = set()
    if configured_groups:
        for g in configured_groups:
            sec = _GROUP_TO_SECTION.get(g)
            if sec:
                allowed_sections.add(sec)
        # Always show custom KPIs from other apps
        allowed_sections.add('Custom KPIs')

    available = [k for k in all_kpis if k['id'] not in configured_ids]

    if allowed_sections:
        available = [
            k for k in available
            if k.get('section', 'Defect Triage & Management Metrics') in allowed_sections
        ]

    if not available:
        state['_catalog_flat'] = []
        return (
            f"All known KPIs are already configured for **{application}**.\n\n"
            "Choose the option below to create a brand-new KPI:\n\n"
            "1. **Create a new KPI**"
        )

    # Group by section in defined order
    from collections import OrderedDict
    section_order = ['Defect Triage & Management Metrics', 'Functional Efficiency Metrics', 'Automation Efficiency Metrics', 'Custom KPIs']
    grouped = OrderedDict()
    for sec in section_order:
        grouped[sec] = []
    for kpi in available:
        sec = kpi.get('section', 'Custom KPIs')
        if sec not in grouped:
            grouped[sec] = []
        grouped[sec].append(kpi)

    lines = [f"Adding a KPI for **{application}**.\n"]
    lines.append("Pick a KPI to add, or create a new one:\n")
    flat_list = []
    idx = 1
    for section_name, kpis_in_section in grouped.items():
        if not kpis_in_section:
            continue
        lines.append(f"\n**{section_name}:**")
        for kpi in kpis_in_section:
            lines.append(f"[opt {idx}|{kpi['title']}]")
            flat_list.append(kpi)
            idx += 1
    lines.append(f"\n[opt {idx}|Create a new KPI]")

    # Store flat list on state for index lookup
    state['_catalog_flat'] = flat_list
    return "\n".join(lines)


# ── Built-in KPI JQL logic descriptions (keyed by tile id) ─────────────
_BUILTIN_KPI_JQL_LOGIC = {
    'production-defect-leakage': {
        'calculation_type': 'leakage',
        'base_jql_group': 'defect',
        'numerator_desc': 'Production leakage defects (AOTS Ticket # not empty, Phase Found In = Production, Defect Type in Production Defect/Defect, status != Cancelled)',
        'denominator_desc': 'Production leakage defects + Overall PreProd defects for the selected period',
        'numerator_jql_hint': '({base_jql}) and "AOTS Ticket #" is not EMPTY and "AOTS Ticket #" !~ None and "Phase Found In" in (Production) and "Defect Type" in ("Production Defect", Defect) and status != Cancelled',
        'denominator_jql_hint': '{preprod_base_jql}',
        'denominator_note': 'Denominator = numerator count + PreProd count. The denominator JQL fetches PreProd defects; the dashboard adds the two counts.',
        'needs_preprod': True,
        'alt_numerator_config_key': 'prod_defect_leakage_base_jql',
        'alt_denominator_config_key': 'preprod_defect_leakage_base_jql',
    },
    'defect-leakage-alt': {
        'calculation_type': 'leakage',
        'base_jql_group': 'defect',
        'numerator_desc': 'Production leakage defects (using app-specific prod/preprod leakage JQLs)',
        'denominator_desc': 'Production leakage defects + Overall PreProd defects (cumulative for the year)',
        'alt_numerator_config_key': 'prod_defect_leakage_base_jql',
        'alt_denominator_config_key': 'preprod_defect_leakage_base_jql',
        'cumulative_year': True,
    },
    'triage-efficiency': {
        'calculation_type': 'percentage',
        'base_jql_group': 'defect',
        'numerator_desc': 'Defects where STATUS not in ("To Do")',
        'denominator_desc': 'Overall Defects',
        'numerator_jql_hint': '({base_jql}) AND status NOT IN ("To Do")',
        'denominator_jql_hint': '{base_jql}',
    },
    'cancellation-rate': {
        'calculation_type': 'percentage',
        'base_jql_group': 'defect',
        'numerator_desc': 'Defects where STATUS in (Cancelled)',
        'denominator_desc': 'Overall Defects',
        'numerator_jql_hint': '({base_jql}) AND status IN (Cancelled)',
        'denominator_jql_hint': '{base_jql}',
    },
    'cancellation-efficiency-by-triage': {
        'calculation_type': 'cancelled_non_dev',
        'base_jql_group': 'defect',
        'numerator_desc': 'Cancelled defects where Assigned to Team is not Development in the entire lifecycle',
        'denominator_desc': 'Defects where STATUS in (Cancelled)',
        'numerator_jql_hint': '({base_jql}) AND status IN (Cancelled)',
        'denominator_jql_hint': '({base_jql}) AND status IN (Cancelled)',
    },
    'defect-burndown-rate': {
        'calculation_type': 'burndown',
        'base_jql_group': 'defect',
        'numerator_desc': 'Defects resolved for the selected period',
        'denominator_desc': 'Resolved defects + Open defects (STATUS not in Accepted, Cancelled)',
        'numerator_jql_hint': 'Resolved period defects (uses build_resolved_period_ram_jql)',
        'denominator_jql_hint': 'Open defects (uses build_open_ram_jql)',
    },
    'retest-defects-ontime-action-rate': {
        'calculation_type': 'ontime_action',
        'base_jql_group': 'defect',
        'statuses': ['Retest'],
        'working_days': 3,
        'numerator_desc': 'Defects moved out of Retest within N working days',
        'denominator_desc': 'Total defects moved to Retest',
    },
    'return-rejected-defects-ontime-action-rate': {
        'calculation_type': 'ontime_action',
        'base_jql_group': 'defect',
        'statuses': ['Returned', 'Rejected', 'Returned/Rejected'],
        'working_days': 3,
        'numerator_desc': 'Defects moved out of Returned/Rejected within N working days',
        'denominator_desc': 'Total defects moved to Returned/Rejected',
    },
    'triage-productivity-improvement': {
        'calculation_type': 'period_comparison',
        'base_jql_group': 'defect',
        'numerator_desc': 'Current period triaged defects productivity rate',
        'denominator_desc': 'Prior year triaged defects productivity rate',
    },
    'defect-acceptance-rate': {
        'calculation_type': 'percentage',
        'base_jql_group': 'defect',
        'numerator_desc': 'Defects in Accepted status',
        'denominator_desc': 'Overall Defects',
        'numerator_jql_hint': '({base_jql}) AND status IN (Accepted)',
        'denominator_jql_hint': '{base_jql}',
    },
    'defect-density': {
        'calculation_type': 'defect_density',
        'base_jql_group': 'functional',
        'numerator_desc': 'Active defects (not Canceled/Cancelled)',
        'denominator_desc': 'Unique feature labels',
        'requires_config': ['defect_density_date_range_labels'],
    },
    'productivity-improvement': {
        'calculation_type': 'label_comparison',
        'base_jql_group': 'functional',
        'numerator_desc': 'Current period defect count',
        'denominator_desc': 'Prior period defect count',
        'requires_config': ['defect_density_date_range_labels'],
    },
    'automation-coverage-overall': {
        'calculation_type': 'percentage',
        'base_jql_group': 'automation',
        'numerator_desc': 'Test cases automated',
        'denominator_desc': 'Overall test cases',
        'numerator_jql_hint': '({automation_base_jql}) and "Automated Script?" = Yes and ("User 5" ~ Automated or "User 5" ~ Partial)',
        'denominator_jql_hint': '{automation_base_jql}',
        'requires_config': ['automation_base_jql'],
    },
    'automation-coverage-automatable': {
        'calculation_type': 'app_config_percentage',
        'base_jql_group': 'automation',
        'numerator_desc': 'Test cases automated',
        'denominator_desc': 'Automatable test cases + yet-to-analyze',
        'numerator_config_key': 'automation_coverage_automatable_numerator_jql',
        'denominator_config_key': 'automation_coverage_automatable_denominator_jql',
        'requires_config': ['automation_coverage_automatable_numerator_jql', 'automation_coverage_automatable_denominator_jql'],
    },
    'defect-discovery-rate': {
        'calculation_type': 'percentage',
        'base_jql_group': 'automation',
        'numerator_desc': 'Valid defects found by automated runs',
        'denominator_desc': 'Valid regression defects logged',
        'numerator_jql_hint': '({defect_discovery_base_jql}) and labels in (Automation)',
        'denominator_jql_hint': '{defect_discovery_base_jql}',
        'requires_config': ['defect_discovery_base_jql'],
    },
    'automation-utilization': {
        'calculation_type': 'zephyr_percentage',
        'base_jql_group': 'automation',
        'numerator_desc': 'Test cases executed by automation',
        'denominator_desc': 'Total test cases executed',
        'requires_config': ['automation_utilization_fix_versions'],
    },
}


# Mapping from base_jql_group to the app-config keys it uses
_BASE_JQL_GROUP_KEYS = {
    'defect': [
        ('Defect Efficiency Base JQL (Prod)', 'base_jql'),
        ('Defect Efficiency Base JQL (PreProd)', 'preprod_base_jql'),
    ],
    'functional': [
        ('Functional Efficiency Base JQL', 'functional_base_jql'),
    ],
    'automation': [
        ('Automation Efficiency Base JQL', 'automation_base_jql'),
    ],
}

# Groups of tile IDs for Quick Setup (option 7)
_QUICK_SETUP_GROUPS = {
    'Defect Triage Efficiency': [
        tid for tid, cfg in _BUILTIN_KPI_JQL_LOGIC.items()
        if cfg.get('base_jql_group') == 'defect'
    ],
    'Functional Efficiency': [
        tid for tid, cfg in _BUILTIN_KPI_JQL_LOGIC.items()
        if cfg.get('base_jql_group') == 'functional'
    ],
    'Automation Efficiency': [
        tid for tid, cfg in _BUILTIN_KPI_JQL_LOGIC.items()
        if cfg.get('base_jql_group') == 'automation'
    ],
}


def _handle_pick_tile_scope(msg, state):
    """Handle Prod/PreProd base JQL scope selection for a defect-group KPI."""
    lower = msg.strip().lower()
    if '2' in lower or 'preprod' in lower or 'pre-prod' in lower or 'pre prod' in lower:
        state['_tile_base_jql_scope'] = 'preprod'
    elif '1' in lower or 'prod' in lower:
        state['_tile_base_jql_scope'] = 'prod'
    else:
        return "Please choose **1** (Production) or **2** (Pre-Production).", state

    state['step'] = 'review_kpi'
    return _build_kpi_review_text(state), state


def _handle_needs_preprod_jql(msg, state):
    """Handle input of preprod_base_jql when a tile needs it and the app lacks it."""
    jql = msg.strip()
    if not jql:
        return "Please enter a valid JQL query.", state

    application = state.get('application', '')
    app_def = get_ram_application_definition(application)
    if app_def:
        app_def['preprod_base_jql'] = jql
        if application in get_custom_application_names():
            save_custom_application(app_def)

    state['step'] = 'review_kpi'
    return _build_kpi_review_text(state), state


def _esc_edit(val):
    """Escape ] in values embedded in [edit N|value] markers so the JS regex doesn't break."""
    return str(val).replace(']', '&#93;')


def _build_kpi_review_text(state):
    """Build a review summary of all KPI fields for user to review/edit."""
    application = state['application']
    app_def = get_ram_application_definition(application)

    title = state.get('kpi_title', '')
    formula = state.get('kpi_formula', '')
    formula_type = state.get('kpi_formula_type', 'percentage')
    numerator_jql = state.get('kpi_numerator_jql', '')
    denominator_jql = state.get('kpi_denominator_jql', '')
    target = state.get('kpi_target')
    target_display = target['label'] if target else 'None'
    source_type = state.get('_source_type', 'custom')

    type_labels = {
        'percentage': 'Percentage (numerator/denominator)',
        'count': 'Count (single JQL)',
        'period_comparison': 'Period Comparison',
        'ontime_action': 'OnTime Action Rate',
        'leakage': 'Leakage (numerator / (numerator + denominator))',
        'cancelled_non_dev': 'Cancelled Non-Dev (lifecycle check)',
        'builtin': 'Built-in (standard handler)',
    }

    lines = [
        "**Review KPI configuration:**\n",
        f"- **Application:** {application}",
        f"- **KPI Title:** {title}  ·  [edit 2|{_esc_edit(title)}]",
        f"- **Calculation Type:** {type_labels.get(formula_type, formula_type)}  ·  [edit 3|{_esc_edit(formula_type)}]",
        f"- **Formula/Logic:** {formula or '_(standard logic)_'}  ·  [edit 4|{_esc_edit(formula)}]",
    ]

    if source_type == 'builtin':
        jql_logic = _BUILTIN_KPI_JQL_LOGIC.get(state.get('_selected_builtin_tile_id', ''), {})
        lines.append(f"- **Numerator Logic:** {jql_logic.get('numerator_desc', '_(standard)_')}  ·  [edit 5|{_esc_edit(jql_logic.get('numerator_desc', ''))}]")
        lines.append(f"- **Denominator Logic:** {jql_logic.get('denominator_desc', '_(standard)_')}  ·  [edit 6|{_esc_edit(jql_logic.get('denominator_desc', ''))}]")
        # List base JQLs for this KPI's group — each selectable to review/edit
        group = jql_logic.get('base_jql_group', 'defect')
        group_keys = _BASE_JQL_GROUP_KEYS.get(group, _BASE_JQL_GROUP_KEYS['defect'])
        base_jql_edit_list = []
        base_jql_edit_map = {}
        edit_idx = 10
        for label, config_key in group_keys:
            jql_val = str((app_def or {}).get(config_key) or '').strip()
            display_val = f'`{jql_val}`' if jql_val else '_(not configured)_'
            lines.append(f"- **{label}:** {display_val}  ·  [edit {edit_idx}|{_esc_edit(jql_val)}]")
            base_jql_edit_list.append((label, config_key))
            base_jql_edit_map[str(edit_idx)] = config_key
            edit_idx += 1
        state['_base_jql_edit_list'] = base_jql_edit_list
        state['_base_jql_edit_map'] = base_jql_edit_map
        # Show per-tile scope for defect-group KPIs
        if group == 'defect' and state.get('_tile_base_jql_scope'):
            scope = state['_tile_base_jql_scope']
            scope_label = 'Pre-Production' if scope == 'preprod' else 'Production'
            lines.append(f"- **Base JQL Scope:** {scope_label}")
        if jql_logic.get('statuses'):
            statuses_str = ', '.join(jql_logic['statuses'])
            lines.append(f"- **Statuses:** {statuses_str}  ·  [edit 8|{_esc_edit(statuses_str)}]")
            lines.append(f"- **Working Days:** {jql_logic.get('working_days', 3)}  ·  [edit 9|{jql_logic.get('working_days', 3)}]")
        # Show required config fields and their status
        required_keys = jql_logic.get('requires_config') or []
        for rk in required_keys:
            rk_label = _REQUIRED_CONFIG_LABELS.get(rk, rk)
            rk_val = (app_def or {}).get(rk)
            if isinstance(rk_val, (list, tuple)) and rk_val:
                display = ', '.join(str(v) for v in rk_val)
                lines.append(f"- **{rk_label}:** {display}  ·  [edit rc_{rk}|Edit]")
            elif isinstance(rk_val, str) and rk_val.strip():
                lines.append(f"- **{rk_label}:** `{rk_val.strip()}`  ·  [edit rc_{rk}|Edit]")
            else:
                lines.append(f"- **{rk_label}:** ⚠ _(not configured — required)_  ·  [edit rc_{rk}|Configure]")
    else:
        if formula_type == 'ontime_action':
            lines.append(f"- **Base JQL:** `{numerator_jql or '_(not set)_'}`  ·  [edit 5|{_esc_edit(numerator_jql)}]")
            statuses_str = ', '.join(state.get('kpi_statuses', []))
            lines.append(f"- **Statuses:** {statuses_str}  ·  [edit 6|{_esc_edit(statuses_str)}]")
            lines.append(f"- **Working Days:** {state.get('kpi_action_working_days', 3)}  ·  [edit 7|{state.get('kpi_action_working_days', 3)}]")
        elif formula_type == 'count':
            lines.append(f"- **JQL:** `{numerator_jql or '_(not set)_'}`  ·  [edit 5|{_esc_edit(numerator_jql)}]")
        elif formula_type == 'period_comparison':
            lines.append(f"- **Query 1 JQL:** `{numerator_jql or '_(not set)_'}`  ·  [edit 5|{_esc_edit(numerator_jql)}]")
            comparison_mode = state.get('kpi_comparison_mode', 'date')
            mode_labels = {'date': 'Date-based (vs prior year)', 'release': 'Release-based', 'two_jql': 'Two JQLs'}
            lines.append(f"- **Comparison Mode:** {mode_labels.get(comparison_mode, comparison_mode)}  ·  [edit 6|{_esc_edit(comparison_mode)}]")
            if comparison_mode == 'two_jql':
                lines.append(f"- **Query 2 JQL:** `{denominator_jql or '_(not set)_'}`  ·  [edit 7|{_esc_edit(denominator_jql)}]")
        else:
            lines.append(f"- **Numerator JQL:** `{numerator_jql or '_(not set)_'}`  ·  [edit 5|{_esc_edit(numerator_jql)}]")
            lines.append(f"- **Denominator JQL:** `{denominator_jql or '_(none — uses overall count)_'}`  ·  [edit 6|{_esc_edit(denominator_jql)}]")

    lines.append(f"- **Target:** {target_display}  ·  [edit target|{_esc_edit(target_display)}]")
    lines.append("\nType **save** to confirm, or **cancel** to discard.")
    return "\n".join(lines)


def _handle_pick_existing_kpi(msg, state):
    """Handle selection from the KPI catalog — shows full review."""
    catalog = state.get('_catalog_flat', _collect_all_unique_kpis())
    total_options = len(catalog) + 1  # +1 for "Create new"

    # Try to match by number
    try:
        choice = int(msg.strip())
    except ValueError:
        choice = None

    if choice is not None and 1 <= choice <= total_options:
        if choice == total_options:
            # User chose "Create a new KPI"
            state['step'] = 'kpi_title'
            return "What is the **KPI title**? (e.g. \"Defect Reopen Rate\")", state
        else:
            selected = catalog[choice - 1]
            source_data = _lookup_kpi_data(selected)
            application = state['application']
            has_handler = get_ram_application_handler(application) is not None
            app_def = get_ram_application_definition(application)

            # Populate state with all known details
            state['kpi_title'] = source_data.get('title', '')
            state['kpi_formula'] = source_data.get('formula', '')

            # Pre-fill target: best across all apps for this KPI
            state['kpi_target'] = _best_target_for_kpi(selected['id'])

            if selected['source'] == 'built-in':
                jql_logic = _BUILTIN_KPI_JQL_LOGIC.get(selected['id'], {})
                state['_source_type'] = 'builtin'
                state['_selected_builtin_tile_id'] = selected['id']
                state['kpi_formula_type'] = jql_logic.get('calculation_type', 'percentage')

                # Always save as builtin tile — the generic framework computes
                # builtin tiles for apps without a dedicated handler too.
                state['_save_mode'] = 'builtin_tile'

                if jql_logic.get('statuses'):
                    state['kpi_statuses'] = jql_logic['statuses']
                if jql_logic.get('working_days'):
                    state['kpi_action_working_days'] = jql_logic['working_days']

                # For defect-group KPIs, ask which base JQL scope to use
                # (skip for tiles that inherently use both prod and preprod, e.g. leakage)
                if (jql_logic.get('base_jql_group') == 'defect'
                        and not jql_logic.get('needs_preprod')
                        and jql_logic.get('calculation_type') != 'leakage'):
                    preprod_val = str((app_def or {}).get('preprod_base_jql') or '').strip()
                    if preprod_val:
                        state['step'] = 'pick_tile_scope'
                        state.pop('_catalog_flat', None)
                        return (
                            f"KPI: **{state['kpi_title']}**\n\n"
                            "Which base JQL should this KPI run against?\n\n"
                            "[opt 1|Production (Prod)]"
                            "\n[opt 2|Pre-Production (PreProd)]"
                        ), state
                    else:
                        state['_tile_base_jql_scope'] = 'prod'

                # For tiles that need both prod + preprod (e.g. leakage),
                # prompt for preprod_base_jql if not configured on the app.
                if jql_logic.get('needs_preprod'):
                    preprod_val = str((app_def or {}).get('preprod_base_jql') or '').strip()
                    if not preprod_val:
                        state['step'] = 'needs_preprod_jql'
                        state.pop('_catalog_flat', None)
                        return (
                            f"KPI **{state['kpi_title']}** requires a **Pre-Production base JQL** but none is configured for **{application}**.\n\n"
                            "Enter the base JQL that scopes all **Pre-Production** defects "
                            "(e.g. IST, Scrum Testing) for this application:\n\n"
                            "_Note: Do **not** include date or release clauses — those are added automatically._"
                        ), state
            else:
                # Custom KPI from another app
                state['_source_type'] = 'custom'
                state['_save_mode'] = 'custom_kpi'
                state['kpi_formula_type'] = source_data.get('formula_type', 'percentage')
                state['kpi_numerator_jql'] = source_data.get('numerator_jql', '')
                state['kpi_denominator_jql'] = source_data.get('denominator_jql', '')
                if source_data.get('comparison_mode'):
                    state['kpi_comparison_mode'] = source_data['comparison_mode']
                if source_data.get('statuses'):
                    state['kpi_statuses'] = source_data['statuses']
                if source_data.get('action_working_days'):
                    state['kpi_action_working_days'] = source_data['action_working_days']

            state.pop('_catalog_flat', None)
            state['step'] = 'review_kpi'
            return _build_kpi_review_text(state), state

    # Try matching by title
    msg_lower = msg.lower()
    for i, kpi in enumerate(catalog):
        if msg_lower in kpi['title'].lower():
            return _handle_pick_existing_kpi(str(i + 1), state)

    return f"Please enter a number between 1 and {total_options}.", state


# ── Friendly labels for requires_config keys ────────────────────────────
_REQUIRED_CONFIG_LABELS = {
    'preprod_base_jql': 'Defect Efficiency Base JQL (PreProd)',
    'defect_density_date_range_labels': 'Date Range Labels',
    'automation_base_jql': 'Automation Base JQL',
    'automation_coverage_automatable_numerator_jql': 'Automatable Numerator JQL',
    'automation_coverage_automatable_denominator_jql': 'Automatable Denominator JQL',
    'defect_discovery_base_jql': 'Defect Discovery Base JQL',
    'automation_utilization_fix_versions': 'Automation Fix Versions',
}

_REQUIRED_CONFIG_PROMPTS = {
    'preprod_base_jql': (
        "Enter the base JQL that scopes all **Pre-Production** defects "
        "(e.g. IST, Scrum Testing) for this application.\n\n"
        "_Note: Do **not** include date or release clauses — those are added automatically._"
    ),
    'defect_density_date_range_labels': (
        "Enter the **date range labels** (comma-separated).\n\n"
        "These are the Jira label values used for defect density / productivity improvement calculations.\n"
        "⚠ Jira labels **cannot contain spaces** — use underscores instead.\n\n"
        "_Example: `2026_ACES_IST_PI26.3, 2026_ACES_IST_PI26.5, 2026_ACES_IST_PI27.3`_"
    ),
    'automation_utilization_fix_versions': (
        "Enter the **fix versions** (comma-separated).\n\n"
        "_Example: `BSSe PI 25.3, BSSe PI 26.3, BSSe PI 26.5`_"
    ),
}

# ── Editable field mapping for review ───────────────────────────────────
_REVIEW_EDITABLE_FIELDS = {
    '2': {'key': 'kpi_title', 'label': 'KPI Title', 'prompt': 'Enter the new **KPI title**:'},
    '3': {'key': 'kpi_formula_type', 'label': 'Calculation Type',
           'prompt': 'Choose calculation type:\n1. **Percentage**\n2. **Count**\n3. **Period Comparison**\n4. **OnTime Action Rate**'},
    '4': {'key': 'kpi_formula', 'label': 'Formula/Logic', 'prompt': 'Enter the new **formula/logic description**:'},
    '5': {'key': 'kpi_numerator_jql', 'label': 'Numerator/Base JQL', 'prompt': 'Enter the new **numerator/base JQL**:'},
    '6': {'key': 'kpi_denominator_jql', 'label': 'Denominator JQL / Statuses', 'prompt': 'Enter the new value for this field:'},
    '7': {'key': '_extra_field', 'label': 'Extra field / PreProd Base JQL', 'prompt': 'Enter the new **PreProd Base JQL**, or type **skip** to clear:'},
    '8': {'key': 'kpi_statuses', 'label': 'Statuses', 'prompt': 'Enter statuses (comma-separated, e.g. `Retest, Returned`):'},
    '9': {'key': 'kpi_action_working_days', 'label': 'Working Days', 'prompt': 'Enter the number of **working days**:'},
}


def _handle_review_kpi(msg, state):
    """Handle the review step — save, cancel, or pick a field to edit."""
    lower = msg.strip().lower()

    if lower in ('save', 'yes', 'confirm', 'y'):
        return _save_reviewed_kpi(state)

    if lower in ('cancel', 'no', 'n'):
        return "Cancelled. Type **reset** to start over.", {'step': 'idle'}

    # Check for target edit
    if lower.startswith('target'):
        state['step'] = 'review_edit_field'
        state['_editing_field'] = 'target'
        return "Enter a **target** (e.g. `>=80%`, `<=10%`), or type **skip** for no target.", state

    # Check for field number — base JQL select & edit
    base_jql_edit_map = state.get('_base_jql_edit_map', {})
    if lower in base_jql_edit_map:
        config_key = base_jql_edit_map[lower]
        # Find the label
        label = config_key
        for lbl, key in state.get('_base_jql_edit_list', []):
            if key == config_key:
                label = lbl
                break
        app_def = get_ram_application_definition(state.get('application', ''))
        current_val = str((app_def or {}).get(config_key) or '').strip()
        state['step'] = 'review_edit_field'
        state['_editing_field'] = '10'
        state['_editing_config_key'] = config_key
        return (
            f"**{label}**\n"
            f"Current: `{current_val or '_(not configured)_'}`\n\n"
            "Enter the new JQL, or type **skip** to clear:"
        ), state

    if lower in _REVIEW_EDITABLE_FIELDS:
        field_info = _REVIEW_EDITABLE_FIELDS[lower]
        state['step'] = 'review_edit_field'
        state['_editing_field'] = lower
        return field_info['prompt'], state

    # Check for required config field edits (rc_<key>)
    if lower.startswith('rc_'):
        config_key = lower[3:]
        label = _REQUIRED_CONFIG_LABELS.get(config_key, config_key)
        prompt = _REQUIRED_CONFIG_PROMPTS.get(config_key, f"Enter the new value for **{label}**:")
        state['step'] = 'review_edit_field'
        state['_editing_field'] = 'rc'
        state['_editing_config_key'] = config_key
        return prompt, state

    return "Type a **field number** to edit, **save** to confirm, or **cancel** to discard.", state


def _handle_review_edit_field(msg, state):
    """Handle editing a specific field from the review screen."""
    field_num = state.get('_editing_field', '')

    if field_num == 'target':
        lower = msg.strip().lower()
        if lower in ('skip', 'none', 'n/a'):
            state['kpi_target'] = None
        else:
            target_match = re.match(r'^([<>]=?)\s*(\d+(?:\.\d+)?)\s*%?$', msg.strip())
            if not target_match:
                return "Please use format like `>=80%`, `<=10%`, or type **skip**.", state
            direction_symbol = target_match.group(1)
            threshold = float(target_match.group(2))
            direction = 'min' if '>' in direction_symbol else 'max'
            state['kpi_target'] = {
                'direction': direction,
                'threshold': threshold,
                'label': f'{direction_symbol}{int(threshold) if threshold == int(threshold) else threshold}%',
            }
    elif field_num == '3':
        # Calculation type — parse 1-4
        ft_map = {'1': 'percentage', '2': 'count', '3': 'period_comparison', '4': 'ontime_action'}
        ft = ft_map.get(msg.strip())
        if not ft:
            return "Enter 1–4 for the calculation type.", state
        state['kpi_formula_type'] = ft
    elif field_num == '8':
        # Statuses — comma-separated
        state['kpi_statuses'] = [s.strip() for s in msg.split(',') if s.strip()]
    elif field_num == '9':
        # Working days — integer
        try:
            state['kpi_action_working_days'] = int(msg.strip())
        except ValueError:
            return "Enter a number for working days.", state
    elif field_num in ('10',):
        # Group base JQL — config key stored on state by the pick handler
        config_key = state.get('_editing_config_key', 'base_jql')
        application = state['application']
        app_def = get_ram_application_definition(application)
        if app_def:
            lower = msg.strip().lower()
            if lower in ('skip', 'none', 'clear', 'remove'):
                app_def.pop(config_key, None)
            else:
                if len(msg) < 10:
                    return "That doesn't look like valid JQL. Enter the full JQL, or type **skip** to clear.", state
                app_def[config_key] = msg.strip()
            save_custom_application(app_def)
        state.pop('_editing_config_key', None)
    elif field_num == 'rc':
        # Required config field — save as list (comma-separated) or string on app definition
        config_key = state.get('_editing_config_key', '')
        application = state['application']
        app_def = get_ram_application_definition(application)
        if app_def and config_key:
            lower = msg.strip().lower()
            if lower in ('skip', 'none', 'clear', 'remove'):
                app_def.pop(config_key, None)
            else:
                # Keys ending in _labels or _versions are stored as lists
                if config_key.endswith('_labels') or config_key.endswith('_versions'):
                    values = [v.strip() for v in msg.split(',') if v.strip()]
                    if not values:
                        return "Please enter at least one value, separated by commas.", state
                    app_def[config_key] = values
                else:
                    if len(msg) < 10:
                        return "That doesn't look like valid JQL. Enter the full value, or type **skip** to clear.", state
                    app_def[config_key] = msg.strip()
            save_custom_application(app_def)
        state.pop('_editing_config_key', None)
    elif field_num in _REVIEW_EDITABLE_FIELDS:
        field_key = _REVIEW_EDITABLE_FIELDS[field_num]['key']
        if field_key == '_extra_field':
            # Context-dependent — could be preprod base JQL, working days, denominator JQL
            source_type = state.get('_source_type', 'custom')
            formula_type = state.get('kpi_formula_type', 'percentage')
            if source_type == 'builtin':
                # field 7 for builtin with needs_preprod = PreProd Base JQL (saved on app definition)
                application = state['application']
                app_def = get_ram_application_definition(application)
                if app_def:
                    lower = msg.strip().lower()
                    if lower in ('skip', 'none', 'clear', 'remove'):
                        app_def.pop('preprod_base_jql', None)
                    else:
                        if len(msg) < 10:
                            return "That doesn't look like valid JQL. Enter the full PreProd base JQL, or type **skip**.", state
                        app_def['preprod_base_jql'] = msg.strip()
                    save_custom_application(app_def)
            elif formula_type == 'ontime_action':
                try:
                    state['kpi_action_working_days'] = int(msg.strip())
                except ValueError:
                    return "Enter a number for working days.", state
            elif formula_type == 'period_comparison':
                state['kpi_denominator_jql'] = msg.strip()
            else:
                state['kpi_denominator_jql'] = msg.strip()
        else:
            state[field_key] = msg.strip()

    state.pop('_editing_field', None)
    state['step'] = 'review_kpi'
    return _build_kpi_review_text(state), state


def _handle_review_pick_base_jql(msg, state):
    """Handle selection of which base JQL to edit from the numbered list."""
    base_jql_edit_list = state.get('_base_jql_edit_list', [])
    try:
        choice = int(msg.strip())
    except ValueError:
        choice = None

    if choice is not None and 1 <= choice <= len(base_jql_edit_list):
        label, config_key = base_jql_edit_list[choice - 1]
    else:
        # Try text match
        matched = None
        lower = msg.strip().lower()
        for label, config_key in base_jql_edit_list:
            if lower in label.lower():
                matched = (label, config_key)
                break
        if not matched:
            pick_lines = ["Please choose a number:\n"]
            for i, (lbl, _key) in enumerate(base_jql_edit_list, 1):
                pick_lines.append(f"{i}. **{lbl}**")
            return "\n".join(pick_lines), state
        label, config_key = matched

    app_def = get_ram_application_definition(state.get('application', ''))
    current_val = str((app_def or {}).get(config_key) or '').strip()
    state['step'] = 'review_edit_field'
    state['_editing_field'] = '10'
    state['_editing_config_key'] = config_key
    return (
        f"**{label}**\n"
        f"Current: `{current_val or '_(not configured)_'}`\n\n"
        "Enter the new JQL, or type **skip** to clear:"
    ), state


def _prompt_next_missing_config(state):
    """Prompt for the next missing required config field, or finish."""
    missing_keys = state.get('_missing_config_keys', [])
    idx = state.get('_missing_config_idx', 0)
    if idx >= len(missing_keys):
        # All collected — proceed with save
        state['_required_config_collected'] = True
        state['step'] = 'review_kpi'
        return (
            "All required configuration has been saved.\n\n"
            "Type **save** to add the KPI, or **cancel** to discard."
        ), state
    config_key = missing_keys[idx]
    label = _REQUIRED_CONFIG_LABELS.get(config_key, config_key)
    prompt = _REQUIRED_CONFIG_PROMPTS.get(
        config_key,
        f"Enter the **{label}** for this application.\n\nType **skip** to leave it empty."
    )
    state['step'] = 'collect_missing_config'
    state['_collecting_config_key'] = config_key
    return (
        f"⚠ **{label}** is required for this KPI but not configured yet.\n\n{prompt}"
    ), state


def _handle_collect_missing_config(msg, state):
    """Handle user input for a missing required config field."""
    config_key = state.get('_collecting_config_key', '')
    application = state['application']
    app_def = get_ram_application_definition(application)

    lower = msg.strip().lower()
    if lower in ('skip', 'none', 'n/a'):
        pass  # leave unconfigured
    elif app_def:
        if config_key.endswith('_labels') or config_key.endswith('_versions'):
            values = [v.strip() for v in msg.split(',') if v.strip()]
            if values:
                # Sanitize: Jira labels cannot contain spaces
                if config_key.endswith('_labels'):
                    values = [v.replace(' ', '_') if ' ' in v else v for v in values]
                app_def[config_key] = values
                if application in get_custom_application_names():
                    save_custom_application(app_def)
        else:
            if len(msg) >= 10:
                app_def[config_key] = msg.strip()
                if application in get_custom_application_names():
                    save_custom_application(app_def)

    # Move to next missing config
    state['_missing_config_idx'] = state.get('_missing_config_idx', 0) + 1
    return _prompt_next_missing_config(state)


def _save_reviewed_kpi(state):
    """Save the KPI from the review screen."""
    application = state['application']
    save_mode = state.get('_save_mode', 'custom_kpi')

    if save_mode == 'builtin_tile':
        tile_id = state.get('_selected_builtin_tile_id', '')
        app_def = get_ram_application_definition(application)
        rag_target = state.get('kpi_target')

        # Check for missing required config — prompt if any are missing
        jql_logic = _BUILTIN_KPI_JQL_LOGIC.get(tile_id, {})
        required_keys = jql_logic.get('requires_config') or []
        missing_keys = []
        for rk in required_keys:
            val = (app_def or {}).get(rk)
            if isinstance(val, (list, tuple)):
                if not val:
                    missing_keys.append(rk)
            elif not str(val or '').strip():
                missing_keys.append(rk)

        if missing_keys and not state.get('_required_config_collected'):
            # Chain into collecting missing config before saving
            state['_missing_config_keys'] = missing_keys
            state['_missing_config_idx'] = 0
            return _prompt_next_missing_config(state)

        if app_def:
            if tile_id not in app_def.get('tile_ids', []):
                app_def.setdefault('tile_ids', []).append(tile_id)
            if rag_target:
                app_def.setdefault('rag_targets', {})[tile_id] = rag_target
            # Save per-tile base JQL scope override
            scope = state.get('_tile_base_jql_scope', 'prod')
            if scope == 'preprod':
                app_def.setdefault('tile_base_jql_overrides', {})[tile_id] = 'preprod_base_jql'
            if application in get_custom_application_names():
                save_custom_application(app_def)

            scope_label = 'Pre-Production' if scope == 'preprod' else 'Production'
            target_display = rag_target['label'] if rag_target else 'No target'
            return (
                f"Built-in KPI **{state['kpi_title']}** added to **{application}** with target: **{target_display}**.\n"
                f"Scope: **{scope_label}** base JQL.\n\n"
                "Type **reset** to configure another KPI."
            ), {'step': 'idle'}

    # Save as custom KPI
    custom_kpis = load_custom_kpis(application)
    tile_id = _generate_tile_id(state.get('kpi_title', ''))
    existing_ids = _get_all_tile_ids() | {k['id'] for k in custom_kpis}
    base_id = tile_id
    counter = 2
    while tile_id in existing_ids:
        tile_id = f'{base_id}-{counter}'
        counter += 1

    formula_type = state.get('kpi_formula_type', 'percentage')
    new_kpi = {
        'id': tile_id,
        'title': state.get('kpi_title', ''),
        'formula_type': formula_type,
        'numerator_jql': state.get('kpi_numerator_jql', ''),
        'denominator_jql': state.get('kpi_denominator_jql', ''),
        'formula': state.get('kpi_formula', ''),
    }
    if formula_type == 'period_comparison':
        new_kpi['comparison_mode'] = state.get('kpi_comparison_mode', 'date')
    if formula_type == 'ontime_action':
        new_kpi['statuses'] = state.get('kpi_statuses', [])
        new_kpi['action_working_days'] = state.get('kpi_action_working_days', 3)
    if state.get('kpi_target'):
        new_kpi['rag_target'] = state['kpi_target']
        new_kpi['target_label'] = state['kpi_target']['label']

    custom_kpis.append(new_kpi)
    save_custom_kpis(application, custom_kpis)
    return (
        f"KPI **{state.get('kpi_title', '')}** saved for **{application}**.\n\n"
        "It will appear on the dashboard the next time you run RAM for this application.\n\n"
        "Type **reset** to configure another KPI."
    ), {'step': 'idle'}
    """Handle target entry for a built-in KPI being added to an application."""
    lower = msg.strip().lower()
    if lower in ('skip', 'none', 'n/a'):
        rag_target = None
    else:
        target_match = re.match(r'^([<>]=?)\s*(\d+(?:\.\d+)?)\s*%?$', msg.strip())
        if not target_match:
            return "Please use format like `>=80%`, `<=10%`, `>50%`, or type **skip**.", state
        direction_symbol = target_match.group(1)
        threshold = float(target_match.group(2))
        direction = 'min' if '>' in direction_symbol else 'max'
        rag_target = {
            'direction': direction,
            'threshold': threshold,
            'label': f'{direction_symbol}{int(threshold) if threshold == int(threshold) else threshold}%',
        }

    application = state['application']
    tile_id = state['_selected_builtin_tile_id']
    app_def = get_ram_application_definition(application)

    if app_def:
        # Add tile_id to the application's tile_ids if not already present
        if tile_id not in app_def.get('tile_ids', []):
            app_def.setdefault('tile_ids', []).append(tile_id)
        # Set RAG target
        if rag_target:
            app_def.setdefault('rag_targets', {})[tile_id] = rag_target
        # Persist if it's a custom application
        if application in get_custom_application_names():
            save_custom_application(app_def)

        target_display = rag_target['label'] if rag_target else 'No target'
        return (
            f"Built-in KPI **{state['kpi_title']}** added to **{application}** with target: **{target_display}**.\n\n"
            "It will use the application's base JQL with the standard calculation logic.\n\n"
            "Type **reset** to configure another KPI."
        ), {'step': 'idle'}
    else:
        # Application has no definition yet (display-only) — save as custom KPI instead
        custom_kpis = load_custom_kpis(application)
        new_kpi = {
            'id': tile_id,
            'title': state['kpi_title'],
            'formula_type': 'builtin',
            'builtin_tile_id': tile_id,
            'numerator_jql': '',
            'denominator_jql': '',
            'formula': '',
        }
        if rag_target:
            new_kpi['rag_target'] = rag_target
            new_kpi['target_label'] = rag_target['label']
        custom_kpis.append(new_kpi)
        save_custom_kpis(application, custom_kpis)

        target_display = rag_target['label'] if rag_target else 'No target'
        return (
            f"KPI **{state['kpi_title']}** added to **{application}** with target: **{target_display}**.\n\n"
            "Type **reset** to configure another KPI."
        ), {'step': 'idle'}


def _handle_kpi_title(msg, state):
    if len(msg) < 3:
        return "Title is too short. Please enter a descriptive KPI name (at least 3 characters).", state
    state['kpi_title'] = msg
    state['step'] = 'kpi_formula_type'
    return (
        f"KPI: **{msg}**\n\n"
        "Choose the **calculation pattern**:\n\n"
        "1. **Percentage** — Numerator JQL / Denominator JQL × 100\n"
        "   _e.g. Triage Efficiency, Cancellation Rate_\n\n"
        "2. **Count** — Raw count from a single JQL query\n"
        "   _e.g. Total Open Defects_\n\n"
        "3. **Period-over-Period Change** — Compares current period rate vs prior year rate\n"
        "   _e.g. Triage Productivity Improvement_\n\n"
        "4. **On-Time Action Rate** — % of defects that moved out of a status within N working days\n"
        "   _e.g. Retest On-Time, Return/Rejected On-Time_\n\n"
        "Enter the number (1–4)."
    ), state


_FORMULA_TYPES = {
    '1': 'percentage',
    '2': 'count',
    '3': 'period_comparison',
    '4': 'ontime_action',
}

_FORMULA_JQL_PROMPTS = {
    'percentage': (
        "Enter the **numerator JQL** — the query that counts the numerator defects.\n\n"
        "_Example: `project = CDEX AND status in (Accepted)`_\n\n"
    ),
    'count': (
        "Enter the **JQL query** to count.\n\n"
        "_Example: `project = CDEX AND status not in (Cancelled, Accepted)`_\n\n"
    ),
    'period_comparison': (
        "Enter the **base JQL** — the query for counting defects in the selected period.\n\n"
        "The system will:\n"
        "- Count matching defects for the **current** date range you select\n"
        "- Count matching defects for the **prior calendar year**\n"
        "- Calculate: `(current_rate - prior_rate) / prior_rate × 100`\n\n"
        "_Rate = defect count / working days in the period_\n\n"
    ),
    'ontime_action': (
        "Enter the **base JQL** — the query that scopes the defects to track.\n\n"
        "The system will fetch status history and calculate how many defects moved out of "
        "the tracked status within the working days threshold.\n\n"
    ),
}


def _build_filter_note(application_name):
    """Build a note about which filters the application supports so the user knows what to include in JQL."""
    app_def = get_ram_application_definition(application_name)
    if not app_def:
        return "_Note: Any date/release values you include are treated as samples — dashboard picker values are used at runtime._"
    supports_release = app_def.get('supports_release_filter', False)
    if supports_release:
        return (
            "This application supports **Created Date** and **Release** filters on the dashboard.\n\n"
            "_You may include `created >= ...` / `created <= ...` or release clauses (e.g. `cf[18971] in (...)`) in "
            "your JQL as samples — at runtime the actual dates or release selected on the dashboard will be injected automatically._"
        )
    return (
        "This application supports the **Created Date** filter on the dashboard.\n\n"
        "_You may include `created >= ...` / `created <= ...` in your JQL as samples — "
        "at runtime the actual dates selected on the dashboard will be injected automatically._"
    )


def _handle_kpi_formula_type(msg, state):
    lower = msg.strip().lower()
    matched_type = _FORMULA_TYPES.get(msg.strip())
    if not matched_type:
        if 'percent' in lower:
            matched_type = 'percentage'
        elif 'count' in lower:
            matched_type = 'count'
        elif 'period' in lower or 'comparison' in lower or 'productivity' in lower:
            matched_type = 'period_comparison'
        elif 'ontime' in lower or 'on-time' in lower or 'action' in lower or 'status' in lower:
            matched_type = 'ontime_action'
    if not matched_type:
        return "Please enter a number 1–4.", state

    state['kpi_formula_type'] = matched_type

    # Check if the application has multiple base JQLs — if so, ask which one to use
    app_def = get_ram_application_definition(state.get('application', ''))
    available_bases = _get_available_base_jqls(app_def)
    if len(available_bases) > 1:
        state['_available_bases'] = available_bases
        state['step'] = 'kpi_pick_base_jql'
        lines = ["This application has multiple base JQL scopes configured. Which one applies to this KPI?\n"]
        for i, (label, _key, _jql) in enumerate(available_bases, 1):
            lines.append(f"{i}. **{label}**")
        return "\n".join(lines), state

    # Single or no base JQL — proceed directly to JQL entry
    state['step'] = 'kpi_jql'
    filter_note = _build_filter_note(state.get('application', ''))
    prompt = _FORMULA_JQL_PROMPTS[matched_type] + filter_note
    return prompt, state


_BASE_JQL_GROUPS = [
    ('Defect Efficiency', 'base_jql'),
    ('Functional Efficiency', 'functional_base_jql'),
    ('Automation Efficiency', 'automation_base_jql'),
]


def _get_available_base_jqls(app_def):
    """Return list of (label, key, jql) for base JQLs that are configured on the app."""
    if not app_def:
        return []
    results = []
    for label, key in _BASE_JQL_GROUPS:
        jql = str(app_def.get(key) or '').strip()
        if jql:
            results.append((label, key, jql))
    return results


def _handle_kpi_pick_base_jql(msg, state):
    """Handle selection of which base JQL scope to use for the new custom KPI."""
    available_bases = state.get('_available_bases', [])
    try:
        choice = int(msg.strip())
    except ValueError:
        choice = None

    if choice is not None and 1 <= choice <= len(available_bases):
        label, key, jql = available_bases[choice - 1]
        state['_selected_base_jql_key'] = key
        state['_selected_base_jql_label'] = label
        state['_selected_base_jql'] = jql
    else:
        # Try text match
        lower = msg.strip().lower()
        matched = None
        for label, key, jql in available_bases:
            if lower in label.lower():
                matched = (label, key, jql)
                break
        if not matched:
            lines = ["Please choose a number:\n"]
            for i, (label, _key, _jql) in enumerate(available_bases, 1):
                lines.append(f"{i}. **{label}**")
            return "\n".join(lines), state
        state['_selected_base_jql_key'] = matched[1]
        state['_selected_base_jql_label'] = matched[0]
        state['_selected_base_jql'] = matched[2]

    state['step'] = 'kpi_jql'
    filter_note = _build_filter_note(state.get('application', ''))
    formula_type = state.get('kpi_formula_type', 'percentage')
    base_hint = (
        f"\n\n**Selected scope:** {state['_selected_base_jql_label']}\n"
        f"_Base JQL:_ `{state['_selected_base_jql'][:120]}{'...' if len(state['_selected_base_jql']) > 120 else ''}`\n\n"
        "_You can copy/extend the base JQL above as a starting point for your query._"
    )
    prompt = _FORMULA_JQL_PROMPTS[formula_type] + base_hint + "\n\n" + filter_note
    return prompt, state


def _handle_kpi_comparison_mode(msg, state):
    """Handle selection of comparison mode for period_comparison formula."""
    lower = msg.strip().lower()
    app_def = get_ram_application_definition(state.get('application', ''))
    supports_release = app_def.get('supports_release_filter', False) if app_def else False

    if lower in ('1', 'date', 'date-based'):
        state['kpi_comparison_mode'] = 'date'
        state['kpi_formula'] = '(Current period rate - Prior year rate) / Prior year rate × 100'
        state['step'] = 'kpi_custom_formula'
        return (
            "Comparison mode: **Date-based** (current date range vs prior calendar year, normalized by working days)\n\n"
            "Default formula: **(Current period rate - Prior year rate) / Prior year rate × 100**\n\n"
            "Would you like to describe your own **formula / logic** in plain text?\n\n"
            "Type **skip** to keep the default, or enter your formula."
        ), state

    if supports_release and lower in ('2', 'release', 'release-based'):
        state['kpi_comparison_mode'] = 'release'
        state['kpi_formula'] = '(Selected release count - Avg other releases count) / Avg other releases count × 100'
        state['step'] = 'kpi_custom_formula'
        return (
            "Comparison mode: **Release-based** (selected release vs average of other releases)\n\n"
            "Default formula: **(Selected release count - Avg other releases count) / Avg other releases count × 100**\n\n"
            "Would you like to describe your own **formula / logic** in plain text?\n\n"
            "Type **skip** to keep the default, or enter your formula."
        ), state

    two_jql_option = '3' if supports_release else '2'
    if lower in (two_jql_option, 'two', 'two jqls', 'custom'):
        state['kpi_comparison_mode'] = 'two_jql'
        state['step'] = 'kpi_second_jql'
        filter_note = _build_filter_note(state.get('application', ''))
        return (
            "Enter the **second JQL** — the comparison period query.\n\n"
            "This JQL will have the same date/release filters applied as the first query.\n\n"
            + filter_note
        ), state

    max_opt = '3' if supports_release else '2'
    return f"Please enter a number 1–{max_opt}.", state


def _handle_kpi_second_jql(msg, state):
    """Handle second JQL entry for two-JQL period comparison."""
    if len(msg) < 10:
        return "That doesn't look like a valid JQL query. Please enter the full comparison JQL.", state
    state['kpi_denominator_jql'] = msg
    state['kpi_formula'] = 'Query 1 result vs Query 2 result'
    state['step'] = 'kpi_custom_formula'
    return (
        "Default formula: **Query 1 result vs Query 2 result**\n\n"
        "Would you like to describe your own **formula / logic** in plain text?\n\n"
        "Type **skip** to keep the default, or enter your formula.\n\n"
        "_Example: \"(Current count / working days - Prior count / working days) / Prior rate × 100\"_"
    ), state


def _handle_kpi_custom_formula(msg, state):
    """Allow user to override the default formula description, or skip to keep it."""
    lower = msg.strip().lower()
    if lower not in ('skip', 'none', 'default', 'keep'):
        if len(msg) < 5:
            return "Please provide a more descriptive formula, or type **skip** to keep the default.", state
        state['kpi_formula'] = msg
    state['step'] = 'kpi_target'
    return (
        f"Formula: **{state['kpi_formula']}**\n\n"
        "What is the **target**? Provide direction and threshold.\n\n"
        "Format: `>=80%` or `<=10%` or `>65%`\n\n"
        "Type **skip** if no target."
    ), state


def _handle_kpi_statuses(msg, state):
    statuses = [s.strip() for s in msg.split(',') if s.strip()]
    if not statuses:
        return "Please enter at least one status name (e.g. `Retest` or `Returned, Rejected`).", state
    state['kpi_statuses'] = statuses
    state['kpi_formula'] = (
        f'No. of defects moved out of {"/".join(statuses)} within N working days '
        f'/ Total defects moved to {"/".join(statuses)}'
    )
    state['step'] = 'kpi_working_days'
    return (
        f"Tracking status(es): **{', '.join(statuses)}**\n\n"
        "How many **working days** is the on-time threshold?\n\n"
        "_Example: `3` means defects must move out within 3 working days_"
    ), state


def _handle_kpi_working_days(msg, state):
    try:
        days = int(msg.strip())
        if days < 1 or days > 30:
            return "Please enter a number between 1 and 30.", state
    except ValueError:
        return "Please enter a number (e.g. `3`).", state
    state['kpi_action_working_days'] = days
    statuses = state.get('kpi_statuses', [])
    state['kpi_formula'] = (
        f'No. of defects moved out of {"/".join(statuses)} within {days} working days '
        f'/ Total defects moved to {"/".join(statuses)}'
    )
    state['step'] = 'kpi_custom_formula'
    return (
        f"Default formula: **{state['kpi_formula']}**\n\n"
        "Would you like to describe your own **formula / logic** in plain text?\n\n"
        "Type **skip** to keep the default, or enter your formula."
    ), state


def _handle_kpi_jql(msg, state):
    if len(msg) < 10:
        return "That doesn't look like a valid JQL query. Please enter the full numerator JQL.", state
    state['kpi_numerator_jql'] = msg
    formula_type = state.get('kpi_formula_type', 'percentage')

    if formula_type == 'count':
        state['kpi_denominator_jql'] = ''
        state['kpi_formula'] = 'Raw count from JQL query'
        state['step'] = 'kpi_custom_formula'
        return (
            "Default formula: **Raw count from JQL query**\n\n"
            "Would you like to describe your own **formula / logic** in plain text?\n\n"
            "Type **skip** to keep the default, or enter your formula.\n\n"
            "_Example: \"Total open defects not in Cancelled status\"_"
        ), state

    if formula_type == 'period_comparison':
        state['kpi_denominator_jql'] = ''
        # Check what filters the application supports to determine comparison mode options
        app_def = get_ram_application_definition(state.get('application', ''))
        supports_release = app_def.get('supports_release_filter', False) if app_def else False
        if supports_release:
            state['step'] = 'kpi_comparison_mode'
            return (
                "How should the **period comparison** work?\n\n"
                "1. **Date-based** — compare current date range vs prior calendar year "
                "(normalized by working days)\n"
                "2. **Release-based** — compare selected release vs average of other releases\n"
                "3. **Two JQLs** — provide a second JQL for the comparison period yourself\n\n"
                "Enter 1, 2, or 3."
            ), state
        else:
            state['step'] = 'kpi_comparison_mode'
            return (
                "How should the **period comparison** work?\n\n"
                "1. **Date-based** — compare current date range vs prior calendar year "
                "(normalized by working days)\n"
                "2. **Two JQLs** — provide a second JQL for the comparison period yourself\n\n"
                "Enter 1 or 2."
            ), state

    if formula_type == 'ontime_action':
        state['kpi_denominator_jql'] = ''
        state['step'] = 'kpi_statuses'
        return (
            "Which **status(es)** should be tracked for on-time action?\n\n"
            "Enter one or more status names separated by commas.\n\n"
            "_Examples: `Retest` or `Returned, Rejected`_"
        ), state

    # percentage type — ask for denominator
    state['step'] = 'kpi_denom_jql'
    return (
        "Now enter the **denominator JQL** — the query for the total count.\n\n"
        "Type **same** to use the same JQL as the numerator, or **skip** if this KPI "
        "doesn't use a numerator/denominator pattern.\n\n"
        "_Note: Any date or release values you include are treated as **samples**. "
        "At runtime, the actual dates/release selected on the dashboard will be used instead._"
    ), state


def _handle_kpi_denom_jql(msg, state):
    lower = msg.lower()
    if lower == 'same':
        state['kpi_denominator_jql'] = state['kpi_numerator_jql']
    elif lower == 'skip' or lower == 'none':
        state['kpi_denominator_jql'] = ''
    else:
        if len(msg) < 10:
            return "That doesn't look like valid JQL. Enter the denominator JQL, **same**, or **skip**.", state
        state['kpi_denominator_jql'] = msg
    state['step'] = 'kpi_formula'
    return "Describe the **formula / logic** in plain text.\n\n_Example: \"No. of accepted defects / Total defects\"_", state


def _handle_kpi_formula(msg, state):
    if len(msg) < 5:
        return "Please provide a more descriptive formula.", state
    state['kpi_formula'] = msg
    state['step'] = 'kpi_target'
    return (
        "What is the **target**? Provide direction and threshold.\n\n"
        "Format: `>=80%` or `<=10%` or `>65%`\n\n"
        "Type **skip** if no target."
    ), state


def _handle_kpi_target(msg, state):
    lower = msg.strip().lower()
    if lower in ('skip', 'none', 'n/a'):
        state['kpi_target'] = None
    else:
        target_match = re.match(r'^([<>]=?)\s*(\d+(?:\.\d+)?)\s*%?$', msg.strip())
        if not target_match:
            return "Please use format like `>=80%`, `<=10%`, `>50%`, or type **skip**.", state
        direction_symbol = target_match.group(1)
        threshold = float(target_match.group(2))
        direction = 'min' if '>' in direction_symbol else 'max'
        state['kpi_target'] = {
            'direction': direction,
            'threshold': threshold,
            'label': f'{direction_symbol}{int(threshold) if threshold == int(threshold) else threshold}%',
        }

    # Build confirmation summary
    formula_type = state.get('kpi_formula_type', 'percentage')
    target_display = state['kpi_target']['label'] if state['kpi_target'] else 'None'
    lines = [
        "**Review your KPI configuration:**\n",
        f"- **Application:** {state['application']}",
        f"- **Title:** {state['kpi_title']}",
        f"- **Calculation Type:** {formula_type}",
    ]
    if formula_type == 'period_comparison':
        comparison_mode = state.get('kpi_comparison_mode', 'date')
        mode_labels = {'date': 'Date-based (vs prior year)', 'release': 'Release-based (vs avg other releases)', 'two_jql': 'Two JQLs (user-defined)'}
        lines.append(f"- **Comparison Mode:** {mode_labels.get(comparison_mode, comparison_mode)}")
        lines.append(f"- **Query 1 JQL:** `{state.get('kpi_numerator_jql', '')}`")
        if comparison_mode == 'two_jql':
            lines.append(f"- **Query 2 JQL:** `{state.get('kpi_denominator_jql', '')}`")
    elif formula_type == 'ontime_action':
        lines.append(f"- **Base JQL:** `{state.get('kpi_numerator_jql', '')}`")
        lines.append(f"- **Statuses:** {', '.join(state.get('kpi_statuses', []))}")
        lines.append(f"- **Working Days:** {state.get('kpi_action_working_days', 3)}")
    elif formula_type == 'count':
        lines.append(f"- **JQL:** `{state.get('kpi_numerator_jql', '')}`")
    else:
        lines.append(f"- **Numerator JQL:** `{state.get('kpi_numerator_jql', '')}`")
        denom_display = state.get('kpi_denominator_jql') or '_(none)_'
        lines.append(f"- **Denominator JQL:** `{denom_display}`")
    lines.append(f"- **Formula:** {state['kpi_formula']}")
    lines.append(f"- **Target:** {target_display}")
    lines.append("\nType **yes** to save or **no** to cancel.")
    summary = "\n".join(lines)
    state['step'] = 'confirm'
    return summary, state


def _handle_confirm(msg, state):
    lower = msg.lower()
    if lower in ('yes', 'y', 'confirm', 'save'):
        application = state['application']
        custom_kpis = load_custom_kpis(application)
        tile_id = _generate_tile_id(state['kpi_title'])

        # Ensure unique ID
        existing_ids = _get_all_tile_ids() | {k['id'] for k in custom_kpis}
        base_id = tile_id
        counter = 2
        while tile_id in existing_ids:
            tile_id = f'{base_id}-{counter}'
            counter += 1

        formula_type = state.get('kpi_formula_type', 'percentage')
        new_kpi = {
            'id': tile_id,
            'title': state['kpi_title'],
            'formula_type': formula_type,
            'numerator_jql': state.get('kpi_numerator_jql', ''),
            'denominator_jql': state.get('kpi_denominator_jql', ''),
            'formula': state.get('kpi_formula', ''),
        }
        if formula_type == 'period_comparison':
            new_kpi['comparison_mode'] = state.get('kpi_comparison_mode', 'date')
        if formula_type == 'ontime_action':
            new_kpi['statuses'] = state.get('kpi_statuses', [])
            new_kpi['action_working_days'] = state.get('kpi_action_working_days', 3)
        if state.get('kpi_target'):
            new_kpi['rag_target'] = state['kpi_target']
            new_kpi['target_label'] = state['kpi_target']['label']

        custom_kpis.append(new_kpi)
        save_custom_kpis(application, custom_kpis)
        return (
            f"KPI **{state['kpi_title']}** saved for **{application}**.\n\n"
            "It will appear on the dashboard the next time you run RAM for this application.\n\n"
            "Type **reset** to configure another KPI."
        ), {'step': 'idle'}

    return "Cancelled. Type **reset** to start over.", {'step': 'idle'}


def _handle_pick_remove(msg, state):
    application = state['application']
    combined = state.get('_combined_kpi_list') or _build_combined_kpi_list(application)
    try:
        index = int(msg.strip()) - 1
        if 0 <= index < len(combined):
            entry = combined[index]
            if entry['kind'] == 'builtin':
                # Remove tile_id from app definition
                app_def = get_ram_application_definition(application)
                if app_def:
                    tile_id = entry['tile_id']
                    if tile_id in app_def.get('tile_ids', []):
                        app_def['tile_ids'].remove(tile_id)
                    app_def.get('rag_targets', {}).pop(tile_id, None)
                    if application in get_custom_application_names():
                        save_custom_application(app_def)
                return f"Removed built-in KPI **{entry['title']}** from **{application}**.\n\nType **reset** to start over.", {'step': 'idle'}
            else:
                # Remove custom KPI
                custom_kpis = load_custom_kpis(application)
                ci = entry.get('index', -1)
                if 0 <= ci < len(custom_kpis):
                    removed = custom_kpis.pop(ci)
                    save_custom_kpis(application, custom_kpis)
                    return f"Removed **{removed['title']}** from **{application}**.\n\nType **reset** to start over.", {'step': 'idle'}
    except ValueError:
        pass
    return "Please enter the number of the KPI to remove.", state


def _handle_pick_update(msg, state):
    application = state['application']
    combined = state.get('_combined_kpi_list') or _build_combined_kpi_list(application)
    try:
        index = int(msg.strip()) - 1
        if 0 <= index < len(combined):
            entry = combined[index]
            if entry['kind'] == 'builtin':
                state['_update_kind'] = 'builtin'
                state['_update_tile_id'] = entry['tile_id']
                state['step'] = 'pick_update_field'
                return _build_builtin_update_review_text(application, entry['tile_id']), state
            else:
                state['_update_kind'] = 'custom'
                state['update_index'] = entry.get('index', 0)
                custom_kpis = load_custom_kpis(application)
                ci = entry.get('index', 0)
                if 0 <= ci < len(custom_kpis):
                    state['step'] = 'pick_update_field'
                    return _build_update_review_text(custom_kpis[ci]), state
    except ValueError:
        pass
    return "Please enter the number of the KPI to update.", state


def _build_builtin_update_review_text(application, tile_id):
    """Build the update review for a builtin tile with all editable fields."""
    app_def = get_ram_application_definition(application) or {}
    rag_targets = app_def.get('rag_targets', {})
    tile_overrides = app_def.get('tile_overrides', {})
    tile_lookup = {t['id']: t for t in RAM_KPI_TILES}
    tile = tile_lookup.get(tile_id, {})
    title = tile_overrides.get(tile_id, {}).get('title', tile.get('title', tile_id))
    formula = tile_overrides.get(tile_id, {}).get('formula', tile.get('formula', '_(standard logic)_'))
    target = rag_targets.get(tile_id, {})
    target_display = target.get('label', '—') if target else '—'
    jql_logic = _BUILTIN_KPI_JQL_LOGIC.get(tile_id, {})
    calc_type = jql_logic.get('calculation_type', '')
    working_days = app_def.get('working_days', 3)

    lines = [
        f"**Review — {title}:**\n",
        f"- **KPI Title:** {title}  ·  [edit 3|{_esc_edit(title)}]",
        f"- **Calculation Type:** {calc_type or 'standard'}  ·  [edit 4|{_esc_edit(calc_type)}]",
        f"- **Formula:** {formula}  ·  [edit 5|{_esc_edit(formula)}]",
        f"- **Target:** {target_display}  ·  [edit 1|{_esc_edit(target_display)}]",
    ]

    # Base JQL fields
    group = jql_logic.get('base_jql_group', 'defect')
    group_keys = _BASE_JQL_GROUP_KEYS.get(group, _BASE_JQL_GROUP_KEYS['defect'])
    edit_idx = 10
    for label, config_key in group_keys:
        jql_val = str(app_def.get(config_key) or '').strip()
        display_val = f'`{jql_val}`' if jql_val else '_(not configured)_'
        lines.append(f"- **{label}:** {display_val}  ·  [edit {edit_idx}|{_esc_edit(jql_val)}]")
        edit_idx += 1

    # Tile base JQL scope override
    tile_scope_overrides = app_def.get('tile_base_jql_overrides', {})
    current_scope = tile_scope_overrides.get(tile_id, '')
    scope_display = 'Pre-Production' if current_scope == 'preprod_base_jql' else 'Production'
    if group == 'defect':
        lines.append(f"- **Base JQL Scope:** {scope_display}  ·  [edit 20|{_esc_edit(scope_display)}]")

    if calc_type == 'ontime_action':
        statuses_str = ', '.join(jql_logic.get('statuses', []))
        lines.append(f"- **Working Days:** {working_days}  ·  [edit 2|{working_days}]")
        lines.append(f"- **Statuses:** {statuses_str}")

    # Required config fields
    required_keys = jql_logic.get('requires_config') or []
    rk_edit_idx = 30
    for rk in required_keys:
        rk_label = _REQUIRED_CONFIG_LABELS.get(rk, rk)
        rk_val = app_def.get(rk)
        if isinstance(rk_val, (list, tuple)) and rk_val:
            display = ', '.join(str(v) for v in rk_val)
            lines.append(f"- **{rk_label}:** {display}  ·  [edit {rk_edit_idx}|{_esc_edit(display)}]")
        elif isinstance(rk_val, str) and rk_val.strip():
            lines.append(f"- **{rk_label}:** `{rk_val.strip()}`  ·  [edit {rk_edit_idx}|{_esc_edit(rk_val.strip())}]")
        else:
            lines.append(f"- **{rk_label}:** ⚠ _(not configured — required)_  ·  [edit {rk_edit_idx}|Configure]")
        rk_edit_idx += 1

    lines.append("\nType **save** to confirm, or **cancel** to discard.")
    return "\n".join(lines)


def _build_update_review_text(kpi):
    """Build the update review with inline edit buttons."""
    target_display = kpi.get('target_label', '—')
    denom_display = kpi.get('denominator_jql') or '_(none)_'
    formula_type = kpi.get('formula_type', 'percentage')

    lines = [
        f"**Review — {kpi['title']}:**\n",
        f"- **Title:** {kpi['title']}  ·  [edit 1|{_esc_edit(kpi['title'])}]",
        f"- **Numerator JQL:** `{kpi.get('numerator_jql', '—')}`  ·  [edit 2|{_esc_edit(kpi.get('numerator_jql', ''))}]",
        f"- **Denominator JQL:** `{denom_display}`  ·  [edit 3|{_esc_edit(kpi.get('denominator_jql', ''))}]",
        f"- **Formula:** {kpi.get('formula', '—')}  ·  [edit 4|{_esc_edit(kpi.get('formula', ''))}]",
        f"- **Target:** {target_display}  ·  [edit 5|{_esc_edit(target_display)}]",
    ]
    if formula_type == 'ontime_action':
        statuses_str = ', '.join(kpi.get('statuses', []))
        lines.append(f"- **Statuses:** {statuses_str}  ·  [edit 6|{_esc_edit(statuses_str)}]")
        lines.append(f"- **Working Days:** {kpi.get('action_working_days', 3)}  ·  [edit 7|{kpi.get('action_working_days', 3)}]")

    lines.append("\nType **save** to save changes, or **cancel** to discard.")
    return "\n".join(lines)


_UPDATE_FIELD_MAP = {
    '1': ('title', 'Title'),
    '2': ('numerator_jql', 'Numerator JQL'),
    '3': ('denominator_jql', 'Denominator JQL'),
    '4': ('formula', 'Formula'),
    '5': ('target', 'Target'),
    '6': ('statuses', 'Statuses'),
    '7': ('action_working_days', 'Working Days'),
}


_BUILTIN_UPDATE_FIELD_MAP = {
    '1': ('target', 'Target'),
    '2': ('working_days', 'Working Days'),
    '3': ('title', 'Title'),
    '4': ('calculation_type', 'Calculation Type'),
    '5': ('formula', 'Formula'),
    '10': ('base_jql', 'Base JQL (Prod)'),
    '11': ('preprod_base_jql', 'Base JQL (PreProd)'),
    '12': ('functional_base_jql', 'Functional Base JQL'),
    '13': ('automation_base_jql', 'Automation Base JQL'),
    '20': ('tile_scope', 'Base JQL Scope'),
}


def _handle_pick_update_field(msg, state):
    lower = msg.strip().lower()
    update_kind = state.get('_update_kind', 'custom')

    if lower in ('save', 'done', 'finish', 'yes', 'confirm'):
        if update_kind == 'builtin':
            application = state['application']
            tile_id = state.get('_update_tile_id', '')
            tile_lookup = {t['id']: t for t in RAM_KPI_TILES}
            title = tile_lookup.get(tile_id, {}).get('title', tile_id)
            return f"Built-in KPI **{title}** configuration saved.\n\nType **reset** to start over.", {'step': 'idle'}
        application = state['application']
        custom_kpis = load_custom_kpis(application)
        index = state.get('update_index', -1)
        if 0 <= index < len(custom_kpis):
            save_custom_kpis(application, custom_kpis)
            kpi_title = custom_kpis[index].get('title', '')
            return f"KPI **{kpi_title}** saved.\n\nType **reset** to start over.", {'step': 'idle'}
        return "KPI not found. Type **reset** to start over.", {'step': 'idle'}

    if lower in ('cancel', 'no', 'n'):
        return "Cancelled. Type **reset** to start over.", {'step': 'idle'}

    if update_kind == 'builtin':
        # Also handle required-config edit numbers (30+)
        field_info = _BUILTIN_UPDATE_FIELD_MAP.get(msg.strip())
        is_required_config = False
        if not field_info and msg.strip().isdigit() and int(msg.strip()) >= 30:
            tile_id = state.get('_update_tile_id', '')
            jql_logic = _BUILTIN_KPI_JQL_LOGIC.get(tile_id, {})
            required_keys = jql_logic.get('requires_config') or []
            rc_idx = int(msg.strip()) - 30
            if 0 <= rc_idx < len(required_keys):
                rk = required_keys[rc_idx]
                rk_label = _REQUIRED_CONFIG_LABELS.get(rk, rk)
                field_info = (rk, rk_label)
                is_required_config = True
        if not field_info:
            return "Type a **field number** to edit, **save** to confirm, or **cancel** to discard.", state
        field_key, field_label = field_info
        state['update_field'] = field_key
        state['update_field_label'] = field_label
        state['_last_edit_field_num'] = msg.strip()
        state['_is_required_config'] = is_required_config
        state['step'] = 'update_value'
        if field_key == 'target':
            return (
                f"Enter the new **{field_label}**.\n\n"
                "Format: `>=80%` or `<=10%` or `>65%`\n\n"
                "Type **skip** to remove the target."
            ), state
        if field_key == 'working_days':
            return f"Enter the number of **working days**:", state
        if field_key == 'tile_scope':
            return (
                f"Which base JQL should this KPI run against?\n\n"
                "[opt 1|Production (Prod)]"
                "\n[opt 2|Pre-Production (PreProd)]"
            ), state
        if field_key in ('base_jql', 'preprod_base_jql', 'functional_base_jql', 'automation_base_jql') or is_required_config:
            return (
                f"Enter the new **{field_label}**:\n\n"
                "_Note: Date/release values in JQL are treated as samples — "
                "the dashboard picker values are used at runtime._"
            ), state
        return f"Enter the new **{field_label}**:", state

    field_info = _UPDATE_FIELD_MAP.get(msg.strip())
    if not field_info:
        return "Type a **field number** to edit, **save** to save, or **cancel** to discard.", state

    field_key, field_label = field_info
    state['update_field'] = field_key
    state['update_field_label'] = field_label
    state['_last_edit_field_num'] = msg.strip()
    state['step'] = 'update_value'

    if field_key == 'target':
        return (
            f"Enter the new **{field_label}**.\n\n"
            "Format: `>=80%` or `<=10%` or `>65%`\n\n"
            "Type **skip** to remove the target."
        ), state
    if field_key == 'denominator_jql':
        return (
            f"Enter the new **{field_label}**.\n\n"
            "Type **skip** to clear the denominator.\n\n"
            "_Note: Date/release values in JQL are treated as samples — "
            "the dashboard picker values are used at runtime._"
        ), state
    if field_key == 'numerator_jql':
        return (
            f"Enter the new **{field_label}**.\n\n"
            "_Note: Date/release values in JQL are treated as samples — "
            "the dashboard picker values are used at runtime._"
        ), state
    return f"Enter the new **{field_label}**:", state


def _handle_update_value(msg, state):
    application = state['application']
    field_key = state['update_field']
    field_label = state['update_field_label']
    update_kind = state.get('_update_kind', 'custom')

    # If user clicked a different edit button, redirect to field picker
    active_field_map = _BUILTIN_UPDATE_FIELD_MAP if update_kind == 'builtin' else _UPDATE_FIELD_MAP
    if msg.strip() in active_field_map and msg.strip() != state.get('_last_edit_field_num'):
        state['step'] = 'pick_update_field'
        return _handle_pick_update_field(msg, state)

    if update_kind == 'builtin':
        tile_id = state.get('_update_tile_id', '')
        app_def = get_ram_application_definition(application)
        if not app_def:
            return "Application not found. Type **reset** to start over.", {'step': 'idle'}

        if field_key == 'target':
            lower = msg.strip().lower()
            if lower in ('skip', 'none', 'n/a', 'remove'):
                app_def.get('rag_targets', {}).pop(tile_id, None)
            else:
                target_match = re.match(r'^([<>]=?)\s*(\d+(?:\.\d+)?)\s*%?$', msg.strip())
                if not target_match:
                    return "Please use format like `>=80%`, `<=10%`, or type **skip** to remove.", state
                direction_symbol = target_match.group(1)
                threshold = float(target_match.group(2))
                direction = 'min' if '>' in direction_symbol else 'max'
                app_def.setdefault('rag_targets', {})[tile_id] = {
                    'direction': direction,
                    'threshold': threshold,
                    'label': f'{direction_symbol}{int(threshold) if threshold == int(threshold) else threshold}%',
                }
        elif field_key == 'working_days':
            try:
                app_def['working_days'] = int(msg.strip())
            except ValueError:
                return "Enter a number for working days.", state
        elif field_key == 'title':
            if len(msg.strip()) < 3:
                return "Title is too short (at least 3 characters).", state
            app_def.setdefault('tile_overrides', {}).setdefault(tile_id, {})['title'] = msg.strip()
        elif field_key == 'calculation_type':
            valid_types = ('percentage', 'count', 'leakage', 'ontime_action', 'burndown',
                           'period_comparison', 'cancelled_non_dev', 'app_config_percentage',
                           'defect_density', 'label_comparison', 'zephyr_percentage')
            val = msg.strip().lower()
            if val not in valid_types:
                return f"Invalid type. Choose one of: {', '.join(valid_types)}", state
            app_def.setdefault('tile_overrides', {}).setdefault(tile_id, {})['calculation_type'] = val
        elif field_key == 'formula':
            if len(msg.strip()) < 5:
                return "Please provide a more descriptive formula.", state
            app_def.setdefault('tile_overrides', {}).setdefault(tile_id, {})['formula'] = msg.strip()
        elif field_key in ('base_jql', 'preprod_base_jql', 'functional_base_jql', 'automation_base_jql'):
            if len(msg.strip()) < 10:
                return "That doesn't look like valid JQL.", state
            app_def[field_key] = msg.strip()
        elif field_key == 'tile_scope':
            lower_val = msg.strip().lower()
            if '2' in lower_val or 'preprod' in lower_val or 'pre-prod' in lower_val:
                app_def.setdefault('tile_base_jql_overrides', {})[tile_id] = 'preprod_base_jql'
            elif '1' in lower_val or 'prod' in lower_val:
                app_def.get('tile_base_jql_overrides', {}).pop(tile_id, None)
            else:
                return "Please choose **1** (Production) or **2** (Pre-Production).", state
        elif state.get('_is_required_config'):
            # Required config field (e.g. defect_density_date_range_labels)
            if ',' in msg:
                app_def[field_key] = [s.strip() for s in msg.split(',') if s.strip()]
            else:
                app_def[field_key] = msg.strip()

        if application in get_custom_application_names():
            save_custom_application(app_def)
        state['step'] = 'pick_update_field'
        return f"**{field_label}** updated.\n\n" + _build_builtin_update_review_text(application, tile_id), state

    # Custom KPI update
    index = state['update_index']
    custom_kpis = load_custom_kpis(application)

    if index >= len(custom_kpis):
        return "That KPI no longer exists. Type **reset** to start over.", {'step': 'idle'}

    kpi = custom_kpis[index]

    if field_key == 'target':
        lower = msg.strip().lower()
        if lower in ('skip', 'none', 'n/a', 'remove'):
            kpi.pop('rag_target', None)
            kpi.pop('target_label', None)
        else:
            target_match = re.match(r'^([<>]=?)\s*(\d+(?:\.\d+)?)\s*%?$', msg.strip())
            if not target_match:
                return "Please use format like `>=80%`, `<=10%`, or type **skip** to remove.", state
            direction_symbol = target_match.group(1)
            threshold = float(target_match.group(2))
            direction = 'min' if '>' in direction_symbol else 'max'
            kpi['rag_target'] = {
                'direction': direction,
                'threshold': threshold,
                'label': f'{direction_symbol}{int(threshold) if threshold == int(threshold) else threshold}%',
            }
            kpi['target_label'] = kpi['rag_target']['label']
    elif field_key == 'denominator_jql':
        lower = msg.strip().lower()
        if lower in ('skip', 'none', 'clear', 'remove'):
            kpi['denominator_jql'] = ''
        else:
            if len(msg) < 10:
                return "That doesn't look like valid JQL. Enter the JQL or type **skip** to clear.", state
            kpi['denominator_jql'] = msg
    elif field_key == 'title':
        if len(msg) < 3:
            return "Title is too short (at least 3 characters).", state
        kpi['title'] = msg
    elif field_key == 'numerator_jql':
        if len(msg) < 10:
            return "That doesn't look like valid JQL.", state
        kpi['numerator_jql'] = msg
    elif field_key == 'formula':
        if len(msg) < 5:
            return "Please provide a more descriptive formula.", state
        kpi['formula'] = msg
    elif field_key == 'statuses':
        kpi['statuses'] = [s.strip() for s in msg.split(',') if s.strip()]
    elif field_key == 'action_working_days':
        try:
            kpi['action_working_days'] = int(msg.strip())
        except ValueError:
            return "Enter a number for working days.", state

    save_custom_kpis(application, custom_kpis)

    # Re-show the review with edit buttons
    state['step'] = 'pick_update_field'
    return f"**{field_label}** updated.\n\n" + _build_update_review_text(kpi), state


# ============================================================================
# NEW APPLICATION HANDLERS
# ============================================================================

_BUILTIN_APP_NAMES = {'ACC-Prod', 'ACC-PreProd', 'Digital-Prod', 'Digital-PreProd', 'ACES-IST'}


def _handle_new_app_name(msg, state):
    name = msg.strip()
    if len(name) < 2:
        return "Name is too short. Please enter at least 2 characters.", state
    if name in RAM_APPLICATION_DEFINITIONS or name in _BUILTIN_APP_NAMES:
        return f"**{name}** already exists. Please choose a different name.", state
    state['new_app_name'] = name
    state['step'] = 'new_app_pick_groups'

    tile_lookup = {t['id']: t for t in RAM_KPI_TILES}
    lines = [
        f"Application: **{name}**\n",
        "Select the **KPI groups** you want to configure base JQLs for:\n",
        "_The KPIs listed are samples that can be configured under each category._\n",
    ]
    for i, (group_name, group_tile_ids) in enumerate(_QUICK_SETUP_GROUPS.items(), 1):
        titles = [tile_lookup[tid]['title'] for tid in group_tile_ids if tid in tile_lookup]
        lines.append(f"[chk {i}|{group_name}|{', '.join(titles)}]")
    lines.append(f"\n[chk-confirm|Confirm Selection]")
    return "\n".join(lines), state


def _handle_new_app_pick_groups(msg, state):
    """Parse user's group selection and move to the first required base JQL step."""
    group_names = list(_QUICK_SETUP_GROUPS.keys())
    selected = set()
    lower = msg.strip().lower()

    # Parse comma-separated numbers or keywords
    for token in re.split(r'[,\s]+', lower):
        token = token.strip()
        if not token:
            continue
        if token in ('all', 'everything'):
            selected = {0, 1, 2}
            break
        try:
            idx = int(token) - 1
            if 0 <= idx < len(group_names):
                selected.add(idx)
        except ValueError:
            for i, name in enumerate(group_names):
                if token in name.lower():
                    selected.add(i)

    if not selected:
        return "Please select at least one group number (1-3), e.g. `1, 2`.", state

    selected_groups = [group_names[i] for i in sorted(selected)]
    state['_new_app_selected_groups'] = selected_groups

    # Determine which base JQL steps are needed
    needs_defect = any('Defect' in g for g in selected_groups)
    needs_functional = any('Functional' in g for g in selected_groups)
    needs_automation = any('Automation' in g for g in selected_groups)
    state['_new_app_needs_defect'] = needs_defect
    state['_new_app_needs_functional'] = needs_functional
    state['_new_app_needs_automation'] = needs_automation

    summary = "Selected: **" + "**, **".join(selected_groups) + "**\n\n"
    return _advance_new_app_base_jql(state, summary)


def _advance_new_app_base_jql(state, prefix=''):
    """Advance to the next required base JQL step based on selected groups."""
    needs_defect = state.get('_new_app_needs_defect', False)
    needs_functional = state.get('_new_app_needs_functional', False)
    needs_automation = state.get('_new_app_needs_automation', False)

    # Defect group needs base_jql and optionally preprod_base_jql
    if needs_defect and 'new_app_base_jql' not in state:
        state['step'] = 'new_app_base_jql'
        return (
            prefix +
            "**Defect Triage — Base JQL (Prod)**\n\n"
            "Enter the base JQL that scopes all **Production** defects for this application.\n\n"
            "_Example: `project = CDEX AND \"Application Fixed In\" ~ \"MyApp*\" "
            "AND status not in (Cancelled) AND \"Phase Found In\" in (Production) "
            "AND \"Defect Type\" in (Defect, \"Production Defect\")`_\n\n"
            "_Note: Do **not** include date or release clauses — those are added automatically._"
        ), state

    if needs_defect and '_new_app_preprod_asked' not in state:
        state['_new_app_preprod_asked'] = True
        state['step'] = 'new_app_preprod_base_jql'
        return (
            prefix +
            "**Defect Triage — Base JQL (Pre-Prod)**\n\n"
            "Enter the base JQL that scopes all **Pre-Production** defects (e.g. IST, Scrum Testing).\n\n"
            "Type **skip** if not applicable."
        ), state

    # Functional group needs functional_base_jql
    if needs_functional and 'new_app_functional_base_jql' not in state:
        state['step'] = 'new_app_functional_base_jql'
        return (
            prefix +
            "Enter the **Functional Efficiency base JQL** — scopes defects for "
            "functional KPIs (Defect Density, Productivity Improvement).\n\n"
            "_This is typically a labels-based query, e.g. `labels in (\"2026_ACES_IST_PI27.3\")`_\n\n"
            "Type **skip** if not applicable."
        ), state

    # Automation group needs automation_base_jql
    if needs_automation and 'new_app_automation_base_jql' not in state:
        state['step'] = 'new_app_automation_base_jql'
        return (
            prefix +
            "Enter the **Automation Efficiency base JQL** — scopes test cases for "
            "automation KPIs (Coverage, Discovery Rate, Utilization).\n\n"
            "Type **skip** if not applicable."
        ), state

    # All base JQLs collected — move to working days
    state['step'] = 'new_app_working_days'
    return (
        prefix +
        "How many **working days** for on-time action rate calculations?\n\n"
        "Enter a number (e.g. `3`) or type **skip** to use the default of 3."
    ), state


def _handle_new_app_base_jql(msg, state):
    if len(msg) < 10:
        return "That doesn't look like a valid JQL query. Please enter the full base JQL.", state
    state['new_app_base_jql'] = msg
    return _advance_new_app_base_jql(state)


def _handle_new_app_preprod_base_jql(msg, state):
    lower = msg.strip().lower()
    if lower in ('skip', 'none', 'n/a'):
        state['new_app_preprod_base_jql'] = ''
    else:
        if len(msg) < 10:
            return "That doesn't look like valid JQL. Enter the full PreProd base JQL, or type **skip**.", state
        state['new_app_preprod_base_jql'] = msg
    return _advance_new_app_base_jql(state)


def _handle_new_app_functional_base_jql(msg, state):
    lower = msg.strip().lower()
    if lower in ('skip', 'none', 'n/a'):
        state['new_app_functional_base_jql'] = ''
    else:
        if len(msg) < 10:
            return "That doesn't look like valid JQL. Enter the full Functional Efficiency base JQL, or type **skip**.", state
        state['new_app_functional_base_jql'] = msg
    return _advance_new_app_base_jql(state)


def _handle_new_app_automation_base_jql(msg, state):
    lower = msg.strip().lower()
    if lower in ('skip', 'none', 'n/a'):
        state['new_app_automation_base_jql'] = ''
    else:
        if len(msg) < 10:
            return "That doesn't look like valid JQL. Enter the full Automation Efficiency base JQL, or type **skip**.", state
        state['new_app_automation_base_jql'] = msg
    return _advance_new_app_base_jql(state)


def _handle_new_app_working_days(msg, state):
    lower = msg.strip().lower()
    if lower in ('skip', 'default'):
        state['new_app_working_days'] = 3
    else:
        try:
            days = int(msg.strip())
            if days < 1 or days > 30:
                return "Please enter a number between 1 and 30.", state
            state['new_app_working_days'] = days
        except ValueError:
            return "Please enter a number (e.g. `3`) or type **skip**.", state

    state['step'] = 'new_app_filters'
    return (
        "Which **filters** should be available on the dashboard for this application?\n\n"
        "1. **Created Date only** (date from/to picker)\n"
        "2. **Release only** (release dropdown)\n"
        "3. **Both** (Created Date and Release)\n\n"
        "_Select a number or type the filter name._"
    ), state


def _handle_new_app_filters(msg, state):
    lower = msg.strip().lower()
    if '1' in lower or 'date' in lower:
        state['new_app_supports_release'] = False
    elif '2' in lower or 'release' in lower:
        state['new_app_supports_release'] = True
    elif '3' in lower or 'both' in lower:
        state['new_app_supports_release'] = True
    else:
        return "Please choose 1 (Created Date), 2 (Release), or 3 (Both).", state

    name = state['new_app_name']
    selected_groups = state.get('_new_app_selected_groups', [])
    filters_display = 'Created Date + Release' if state['new_app_supports_release'] else 'Created Date only'
    lines = [
        "**Review your new application:**\n",
        f"- **Name:** {name}",
        f"- **KPI Groups:** {', '.join(selected_groups)}",
    ]
    if state.get('_new_app_needs_defect'):
        lines.append(f"- **Defect Efficiency Base JQL (Prod):** `{state.get('new_app_base_jql', '_(none)_')}`")
        lines.append(f"- **Defect Efficiency Base JQL (PreProd):** `{state.get('new_app_preprod_base_jql') or '_(none)_'}`")
    if state.get('_new_app_needs_functional'):
        lines.append(f"- **Functional Efficiency Base JQL:** `{state.get('new_app_functional_base_jql') or '_(none)_'}`")
    if state.get('_new_app_needs_automation'):
        lines.append(f"- **Automation Efficiency Base JQL:** `{state.get('new_app_automation_base_jql') or '_(none)_'}`")
    lines.append(f"- **Working days:** {state['new_app_working_days']}")
    lines.append(f"- **Filters:** {filters_display}")
    lines.append("\nType **yes** to create or **no** to cancel.")

    state['step'] = 'new_app_confirm'
    return "\n".join(lines), state


def _handle_new_app_confirm(msg, state):
    lower = msg.lower()
    if lower in ('yes', 'y', 'confirm', 'save'):
        app_definition = {
            'name': state['new_app_name'],
            'base_jql': state.get('new_app_base_jql', ''),
            'tile_ids': [],
            'rag_targets': {},
            'working_days': state['new_app_working_days'],
            'supports_release_filter': state.get('new_app_supports_release', False),
            '_custom': True,
        }
        preprod = state.get('new_app_preprod_base_jql', '')
        if preprod:
            app_definition['preprod_base_jql'] = preprod
        functional = state.get('new_app_functional_base_jql', '')
        if functional:
            app_definition['functional_base_jql'] = functional
        automation = state.get('new_app_automation_base_jql', '')
        if automation:
            app_definition['automation_base_jql'] = automation
        save_custom_application(app_definition)

        # Persist selected groups for catalog filtering
        selected_groups = state.get('_new_app_selected_groups', [])
        if selected_groups:
            app_definition['configured_kpi_groups'] = selected_groups
            save_custom_application(app_definition)

        return (
            f"Application **{state['new_app_name']}** created!\n\n"
            "It now appears in the application dropdown on the RAM dashboard.\n"
            "Use **option 1 (Add a new KPI)** or **option 7 (Quick Setup)** to wire KPIs for it.\n\n"
            "Type **reset** to continue."
        ), {'step': 'idle'}
    return "Cancelled. Type **reset** to start over.", {'step': 'idle'}


# ── Update Application: add new KPI categories ─────────────────────────

# Mapping: group name → base_jql_group value → config keys needed
_GROUP_TO_BASE_JQL_GROUP = {
    'Defect Triage Efficiency': 'defect',
    'Functional Efficiency': 'functional',
    'Automation Efficiency': 'automation',
}

# Mapping: base_jql_group → list of (step_label, config_key, prompt)
_GROUP_BASE_JQL_PROMPTS = {
    'defect': [
        ('Defect Triage — Base JQL (Prod)', 'base_jql',
         "Enter the base JQL that scopes all **Production** defects.\n\n"
         "Type **skip** if already configured."),
        ('Defect Triage — Base JQL (Pre-Prod)', 'preprod_base_jql',
         "Enter the base JQL that scopes all **Pre-Production** defects.\n\n"
         "Type **skip** if not applicable."),
    ],
    'functional': [
        ('Functional Efficiency Base JQL', 'functional_base_jql',
         "Enter the **Functional Efficiency base JQL** — scopes defects for "
         "functional KPIs (Defect Density, Productivity Improvement).\n\n"
         "Type **skip** if not applicable."),
    ],
    'automation': [
        ('Automation Efficiency Base JQL', 'automation_base_jql',
         "Enter the **Automation Efficiency base JQL** — scopes test cases for "
         "automation KPIs (Coverage, Discovery Rate, Utilization).\n\n"
         "Type **skip** if not applicable."),
    ],
}


def _handle_update_app_pick_groups(msg, state):
    """Parse checkbox selection of new KPI categories to add."""
    group_names = list(_QUICK_SETUP_GROUPS.keys())
    selected = set()
    lower = msg.strip().lower()

    for token in re.split(r'[,\s]+', lower):
        token = token.strip()
        if not token:
            continue
        try:
            idx = int(token) - 1
            if 0 <= idx < len(group_names):
                selected.add(idx)
        except ValueError:
            pass

    if not selected:
        return "Please select at least one category number.", state

    application = state['application']
    app_def = get_ram_application_definition(application) or {}
    existing_groups = set(app_def.get('configured_kpi_groups', []))

    chosen_groups = [group_names[i] for i in sorted(selected)]
    new_groups = [g for g in chosen_groups if g not in existing_groups]
    edit_groups = [g for g in chosen_groups if g in existing_groups]

    # If only editing already-configured groups, show editable review
    if edit_groups and not new_groups:
        state['step'] = 'update_app_review'
        state['_update_app_edit_groups'] = edit_groups
        return _build_update_app_review(application, edit_groups, state), state

    # For new groups, collect base JQLs via prompts
    jql_queue = []
    for group_name in new_groups:
        bjg = _GROUP_TO_BASE_JQL_GROUP.get(group_name)
        if bjg:
            for label, config_key, prompt in _GROUP_BASE_JQL_PROMPTS.get(bjg, []):
                current_val = str(app_def.get(config_key) or '').strip()
                if current_val:
                    continue
                jql_queue.append((label, config_key, prompt))

    if not jql_queue:
        # New groups but all JQLs already set from other groups
        for g in new_groups:
            if g not in existing_groups:
                existing_groups.add(g)
        app_def['configured_kpi_groups'] = list(existing_groups)
        if application in get_custom_application_names():
            save_custom_application(app_def)
        state['step'] = 'update_app_review'
        state['_update_app_edit_groups'] = new_groups + edit_groups
        return _build_update_app_review(application, new_groups + edit_groups, state), state

    state['_update_app_new_groups'] = new_groups
    state['_update_app_jql_queue'] = jql_queue
    state['_update_app_jql_idx'] = 0

    return _advance_update_app_jql(state,
        prefix="Adding categories: **" + "**, **".join(new_groups) + "**\n\n")


def _build_update_app_review(application, groups, state):
    """Build an editable review of all app config fields for the selected groups."""
    app_def = get_ram_application_definition(application) or {}

    lines = [
        f"**Review — {application} Configuration:**\n",
    ]

    # Collect all relevant config keys for the chosen groups
    edit_idx = 1
    edit_map = {}

    # Working days
    wd = app_def.get('working_days', 3)
    lines.append(f"- **Working Days:** {wd}  ·  [edit {edit_idx}|{wd}]")
    edit_map[str(edit_idx)] = ('working_days', 'Working Days')
    edit_idx += 1

    # Base JQLs for each group
    seen_keys = set()
    for group_name in groups:
        bjg = _GROUP_TO_BASE_JQL_GROUP.get(group_name)
        if bjg:
            for label, config_key, _ in _GROUP_BASE_JQL_PROMPTS.get(bjg, []):
                if config_key in seen_keys:
                    continue
                seen_keys.add(config_key)
                jql_val = str(app_def.get(config_key) or '').strip()
                display_val = f'`{jql_val}`' if jql_val else '_(not configured)_'
                lines.append(f"- **{label}:** {display_val}  ·  [edit {edit_idx}|{_esc_edit(jql_val)}]")
                edit_map[str(edit_idx)] = (config_key, label)
                edit_idx += 1

    # Show tile-specific overrides and other config
    # Defect Leakage specific JQLs — only show if already configured on the app
    if any(_GROUP_TO_BASE_JQL_GROUP.get(g) == 'defect' for g in groups):
        for lbl, key in [('Prod Defect Leakage Base JQL', 'prod_defect_leakage_base_jql'),
                         ('PreProd Defect Leakage Base JQL', 'preprod_defect_leakage_base_jql')]:
            if key in seen_keys:
                continue
            val = str(app_def.get(key) or '').strip()
            if val:
                seen_keys.add(key)
                lines.append(f"- **{lbl}:** `{val}`  ·  [edit {edit_idx}|{_esc_edit(val)}]")
                edit_map[str(edit_idx)] = (key, lbl)
                edit_idx += 1

    lines.append("\nClick **Edit** on any field to update it, type **save** to finish, or **cancel** to discard.")

    state['_update_app_edit_map'] = edit_map
    return "\n".join(lines)


def _advance_update_app_jql(state, prefix=''):
    """Advance to the next base JQL prompt or finish the update."""
    jql_queue = state.get('_update_app_jql_queue', [])
    idx = state.get('_update_app_jql_idx', 0)

    if idx < len(jql_queue):
        label, config_key, prompt = jql_queue[idx]
        state['step'] = 'update_app_base_jql'
        state['_update_app_current_key'] = config_key
        return prefix + f"**{label}**\n\n{prompt}", state

    # All JQLs collected — save the new groups and show editable review
    application = state['application']
    app_def = get_ram_application_definition(application) or {}
    existing_groups = list(app_def.get('configured_kpi_groups', []))
    new_groups = state.get('_update_app_new_groups', [])
    for g in new_groups:
        if g not in existing_groups:
            existing_groups.append(g)
    app_def['configured_kpi_groups'] = existing_groups
    if application in get_custom_application_names():
        save_custom_application(app_def)

    # Show editable review of all configured fields
    state['step'] = 'update_app_review'
    state['_update_app_edit_groups'] = new_groups
    review = _build_update_app_review(application, new_groups, state)
    return prefix + f"Categories saved!\n\n" + review, state


def _handle_update_app_base_jql(msg, state):
    """Handle base JQL input for update-app flow."""
    config_key = state.get('_update_app_current_key', '')
    lower = msg.strip().lower()

    if lower not in ('skip', 'none', 'n/a'):
        if len(msg) < 10:
            return "That doesn't look like valid JQL. Enter the full JQL, or type **skip**.", state
        application = state['application']
        app_def = get_ram_application_definition(application) or {}
        app_def[config_key] = msg.strip()
        if application in get_custom_application_names():
            save_custom_application(app_def)

    state['_update_app_jql_idx'] = state.get('_update_app_jql_idx', 0) + 1
    return _advance_update_app_jql(state)


def _handle_update_app_review(msg, state):
    """Handle the editable review screen for update application flow."""
    lower = msg.strip().lower()
    application = state['application']
    edit_map = state.get('_update_app_edit_map', {})

    if lower in ('save', 'done', 'finish', 'yes', 'confirm'):
        return (
            f"Application **{application}** configuration saved.\n\n"
            "Type **reset** to start over."
        ), {'step': 'idle'}

    if lower in ('cancel', 'no', 'n'):
        return "Cancelled. Type **reset** to start over.", {'step': 'idle'}

    # Check if user clicked an edit button
    field_num = msg.strip()
    if field_num in edit_map:
        config_key, field_label = edit_map[field_num]
        state['_update_app_review_field'] = config_key
        state['_update_app_review_label'] = field_label
        state['_update_app_review_num'] = field_num
        state['step'] = 'update_app_review_edit'
        if config_key == 'working_days':
            return f"Enter the number of **working days**:", state
        return (
            f"Enter the new **{field_label}**:\n\n"
            "_Note: Date/release values in JQL are treated as samples — "
            "the dashboard picker values are used at runtime._"
        ), state

    return "Click **Edit** on a field to update it, type **save** to finish, or **cancel** to discard.", state


def _handle_update_app_review_edit(msg, state):
    """Handle a field edit value in the app review flow."""
    application = state['application']
    config_key = state.get('_update_app_review_field', '')
    field_label = state.get('_update_app_review_label', '')
    edit_map = state.get('_update_app_edit_map', {})

    # If user clicked a different edit button, redirect
    if msg.strip() in edit_map and msg.strip() != state.get('_update_app_review_num'):
        state['step'] = 'update_app_review'
        return _handle_update_app_review(msg, state)

    app_def = get_ram_application_definition(application) or {}

    if config_key == 'working_days':
        try:
            app_def['working_days'] = int(msg.strip())
        except ValueError:
            return "Enter a number for working days.", state
    else:
        lower = msg.strip().lower()
        if lower in ('skip', 'none', 'n/a', 'clear'):
            app_def[config_key] = ''
        else:
            if len(msg.strip()) < 10:
                return "That doesn't look like valid JQL. Enter the full JQL, or type **skip** to clear.", state
            app_def[config_key] = msg.strip()

    if application in get_custom_application_names():
        save_custom_application(app_def)

    state['step'] = 'update_app_review'
    groups = state.get('_update_app_edit_groups', [])
    review = _build_update_app_review(application, groups, state)
    return f"**{field_label}** updated.\n\n" + review, state


def _handle_pick_remove_app(msg, state):
    custom_names = state.get('_custom_app_names', [])
    try:
        index = int(msg.strip()) - 1
        if 0 <= index < len(custom_names):
            name = custom_names[index]
            removed = remove_custom_application(name)
            if removed:
                # Also remove any custom KPIs for this application
                path = _config_path(name)
                if path.exists():
                    path.unlink()
                return f"Application **{name}** and its custom KPIs have been removed.\n\nType **reset** to start over.", {'step': 'idle'}
            return f"Could not remove **{name}**. It may not be a custom application.\n\nType **reset** to start over.", {'step': 'idle'}
    except ValueError:
        pass
    return "Please enter the number of the application to remove.", state
