from shared.shared_logic import summarize_jira_error_response


_SELF_HEAL_FIELD_UPDATE_TITLES = {
    'Progression/Regression',
    'Tribe-Label',
    'Assigned To Team: Testing > Assignee: Update to Reporter',
    'Status: Return/Rejected or Retest or Test Blocked > Assigned to Team: Update to Testing',
    'Status: Retest or Test Blocked > Assigned to Team: Update to Testing',
    'Status: Return/Rejected > Assigned to Team: Update to Triage',
    'Status: Application Fixed in : Root Cause App in Sync',
    'Assigned to Team: Business > Update Application Fixed In',
    'Assigned to Team: Production Support > Update Application Fixed In',
    'Application Fixed in: CQE & Status = Accepted/Cancelled > Update Application Fixed In',
    'Application Fixed in: CQE & Status != Accepted/Cancelled > Revert Assigned to Team to previous value',
    'Status: Accepted/Cancelled/Retest/Dev Complete/Test Blocked/Deferred/Test Failed > Application Fixed in = Root Cause App',
}


def format_http_error_message(operation_title, error):
    response = getattr(error, 'response', None)
    if response is None:
        return f'{operation_title} failed while pulling data from Jira/iTrack: {error}'

    response_text = summarize_jira_error_response(response)

    if response.status_code == 401:
        base_message = (
            f'{operation_title} authentication failed. Enter your Jira/iTrack username and password or API token, then retry.'
        )
        if operation_title in _SELF_HEAL_FIELD_UPDATE_TITLES:
            base_message += ' This run updates Jira/iTrack fields, so the account must have REST edit permission for issues in addition to read access.'
        if response_text:
            base_message += f' Jira response: {response_text}'
        return base_message

    if response_text:
        return f'{operation_title} failed while pulling data from Jira/iTrack: {error}. Jira response: {response_text}'

    return f'{operation_title} failed while pulling data from Jira/iTrack: {error}'
