"""Flask routes for the defect_lens web UI."""

from __future__ import annotations

from pathlib import Path
from typing import Any

from flask import Blueprint, current_app, jsonify, redirect, render_template, request, send_file, url_for
from werkzeug.utils import secure_filename

from defectLens.core.services.job_service import AnalysisJobService

web_blueprint = Blueprint("web", __name__)


def _job_service() -> AnalysisJobService:
    return current_app.extensions["job_service"]


@web_blueprint.app_context_processor
def inject_asset_version() -> dict[str, Any]:
    settings = current_app.config["settings"]

    def asset_version(filename: str) -> int:
        try:
            return int((settings.static_dir / filename).stat().st_mtime)
        except OSError:
            return 0

    return {"asset_version": asset_version}


@web_blueprint.after_app_request
def disable_cache(response):
    if request.path.startswith("/api/") or response.mimetype in {"text/html", "application/json"}:
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
        response.headers["Expires"] = "0"
    return response


@web_blueprint.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        return redirect(url_for("web.index"))
    return render_template("index.html")


@web_blueprint.post("/api/run")
def api_run():
    username = (request.form.get("username") or "").strip()
    password = (request.form.get("password") or "").strip()
    file = request.files.get("file")
    if not username or not password:
        return jsonify({"ok": False, "error": "Please provide username and API token/password."}), 400
    if not file or file.filename == "":
        return jsonify({"ok": False, "error": "Please upload an Excel .xlsx file."}), 400
    if not file.filename.lower().endswith(".xlsx"):
        return jsonify({"ok": False, "error": "Only .xlsx files are supported."}), 400

    service = _job_service()
    settings = current_app.config["settings"]
    job_id = service.create_job()
    input_path = Path(settings.upload_dir) / f"{job_id}_{secure_filename(file.filename)}"
    file.save(str(input_path))
    service.start_file_job(job_id, username, password, input_path)
    return jsonify({"ok": True, "jobId": job_id})


@web_blueprint.post("/api/run-jql")
def api_run_jql():
    username = (request.form.get("username") or "").strip()
    password = (request.form.get("password") or "").strip()
    jql = (request.form.get("jql") or "").strip()
    if not username or not password:
        return jsonify({"ok": False, "error": "Please provide username and password."}), 400
    if not jql:
        return jsonify({"ok": False, "error": "Please enter a JQL query."}), 400

    service = _job_service()
    job_id = service.create_job()
    service.start_jql_job(job_id, username, password, jql)
    return jsonify({"ok": True, "jobId": job_id})


@web_blueprint.get("/api/status/<job_id>")
def api_status(job_id: str):
    service = _job_service()
    current_prompt_signature = service.current_prompt_signature()
    job = service.store.get_snapshot(job_id)
    if job is None:
        return jsonify({"ok": False, "error": "Job not found"}), 404

    if service.should_refresh_ai_summary(job, current_prompt_signature):
        try:
            service.populate_ai_summary(job_id)
        except Exception:
            pass
        job = service.store.get_snapshot(job_id)
        if job is None:
            return jsonify({"ok": False, "error": "Job not found"}), 404

    return jsonify(
        {
            "ok": True,
            "status": job.status,
            "progress": job.progress,
            "message": job.message,
            "ai": job.ai,
            "aiTitle": job.aiTitle,
            "aiPromptSignature": job.aiPromptSignature,
            "currentPromptSignature": current_prompt_signature,
            "okrs": job.okrs,
            "summary": job.summary,
            "topContrib": job.topContrib,
            "topContribChart": job.topContribChart,
            "mttrContrib": job.mttrContrib,
            "mttrContribChart": job.mttrContribChart,
            "mttiContrib": job.mttiContrib,
            "mttiContribChart": job.mttiContribChart,
            "mttfContrib": job.mttfContrib,
            "mttfContribChart": job.mttfContribChart,
            "jql": getattr(job, "jql", ""),
        }
    )


@web_blueprint.get("/api/log/<job_id>")
def api_log(job_id: str):
    try:
        since = max(0, int(request.args.get("since", "0")))
    except (TypeError, ValueError):
        since = 0

    slice_result = _job_service().store.get_log_slice(job_id, since)
    if slice_result is None:
        return jsonify({"ok": False, "error": "Job not found"}), 404

    lines, next_index = slice_result
    return jsonify({"ok": True, "lines": lines, "next": next_index})


@web_blueprint.post("/api/insights/<job_id>")
def api_insights(job_id: str):
    service = _job_service()
    job = service.store.get_snapshot(job_id)
    if job is None:
        return jsonify({"ok": False, "error": "Job not found"}), 404
    if job.status != "completed":
        return jsonify({"ok": False, "error": "AI insights are available only after the run completes."}), 409

    service.store.append_log(job_id, "Provide AI Insights requested...")
    payload = service.populate_ai_summary(job_id)
    return jsonify({"ok": True, **payload, "source": "prompt-template"})


@web_blueprint.get("/download/<job_id>")
def download(job_id: str):
    job = _job_service().store.get_snapshot(job_id)
    if job is None or job.status != "completed" or not job.output_path:
        return "File not ready", 404
    path = job.output_path
    download_name = job.download_name or Path(path).name
    return send_file(path, as_attachment=True, download_name=download_name)
