from pathlib import Path
import re
import sys

from flask import current_app, jsonify, render_template, request, send_file, url_for
import requests
from werkzeug.utils import secure_filename

from shared.shared_config import JIRA_USER
from shared.shared_logic import fetch_issue_editmeta, fetch_open_defects
from ram.app_config import RAM_CORE_APPLICATION_OPTIONS


WORKSPACE_ROOT = Path(__file__).resolve().parents[1]
LOCAL_DEFECT_LENS_PACKAGE_ROOT = WORKSPACE_ROOT
LOCAL_DEFECT_LENS_PACKAGE = LOCAL_DEFECT_LENS_PACKAGE_ROOT / 'DefectLens'
DEFECT_LENS_APPLICATION_OPTIONS = list(RAM_CORE_APPLICATION_OPTIONS)
DEFECT_LENS_CONFIGURED_APPLICATIONS = {'ACC-Prod', 'ACES-IST'}
DEFECT_LENS_RELEASE_ENABLED_APPLICATION = 'ACES-IST'
DEFECT_LENS_RELEASE_FIELD_KEY = 'customfield_18971'
DEFECT_LENS_RELEASE_FIELD_NAME = 'Detected in Release'
DEFECT_LENS_RELEASE_SEED_FALLBACK = 'BSSe PI 27.5'
DEFECT_LENS_ACC_BASE_JQL = (
    'filter in (self-agent-filter) and "Defect Type" in ("Tracking Record", "Bug/Issue", "Production Defect", Defect) '
    'and "Phase Found In" in (Production, "Production Validation Testing (PVT)", "Business Validation Testing", '
    '"First Field Availability (FFA)", "Controlled Introduction (CI)", "Production Readiness (PR)", "User Acceptance Test (UAT)", Pilot) '
    'and filter in (Lynn_ask_ACC_app_filter) and status in (Accepted) and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2")'
)
DEFECT_LENS_ACES_IST_BASE_JQL = (
    'project = CDEX and ("Application Found In" ~ "GRP- CQE Org:24115" '
    'or "Application Found In" ~ BSSe-RTB:30914 '
    'or "Application Found In" ~ BSSe-OC:30909 '
    'or "Application Found In" ~ BSSe-MMap:31697 '
    'or "Application Found In" ~ BSSe-BB:31692 '
    'or "Application Found In" ~ BSSe-SkyFM:31452 '
    'or "Application Found In" ~ BSSe-C1:30911 '
    'or "Application Found In" ~ BSSe-NEO:31710 '
    'or "Application Found In" ~ BSSe-OH:30910 '
    'or "Application Found In" ~ BSSe-iPaaS:30912 '
    'or "Application Found In" ~ BSSe-ACF:32985 and "Phase Found In" in ("Integrated Solution Testing (IST)", "Smoke Testing", Development, "Scrum Testing", "Enterprise Certification Testing (ECT)", "Integrated Scrum to Scrum (ST)") '
    'or "Phase Found In" in (Production, "Production Validation Testing (PVT)") and "Application Fixed In" ~ "BSSe*") '
    'and "Defect Type" in (Defect, "Tracking Record", "Bug/Issue", "Production Defect") '
    'and (cf[16424] not in (PET, PET1, PET2, PET2Azure, PET3, PET3_EAST) or cf[16424] is EMPTY) '
    'and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
    'and labels not in (ACC, ACC_IST, ACC_Sales, ACCINT, ACCUAT, csa, CSA_Triage, CSATriage, IST_ACC_CLM, IST_ACC_SALES, IST_ACC_SERVICE, PET2, Digital_Bsse_API, ECT_Digital) '
    'and "Phase Found In" in ("Integrated Solution Testing (IST)") '
    'and "Application Found In" ~ "GRP- CQE Org:24115" '
    'and Severity in ("Severity 1", "Severity 2", "Severity 3", "Severity 4") '
    'and status in (Accepted)'
)
DEFECT_LENS_RELEASE_CLAUSE_PATTERN = re.compile(
    r'\(cf\[18971\]\s+in\s+\(".*?"\)\s+or\s+cf\[18972\]\s+in\s+\(".*?"\)\)',
    re.IGNORECASE,
)
DEFECT_LENS_RELEASE_CLAUSE_WITH_PREFIX_PATTERN = re.compile(
    r'\s+and\s+\(cf\[18971\]\s+in\s+\(".*?"\)\s+or\s+cf\[18972\]\s+in\s+\(".*?"\)\)',
    re.IGNORECASE,
)


class DefectLensFeature:
    def __init__(self, get_session_credentials):
        self.get_session_credentials = get_session_credentials

    @staticmethod
    def get_selected_defect_lens_application():
        return (request.form.get('application') or request.args.get('application') or '').strip()

    @staticmethod
    def get_selected_defect_lens_release():
        return (request.form.get('release_name') or request.args.get('release_name') or '').strip()

    @staticmethod
    def get_selected_defect_lens_resolved_from():
        return (request.form.get('resolved_from') or request.args.get('resolved_from') or '').strip()

    @staticmethod
    def get_selected_defect_lens_resolved_to():
        return (request.form.get('resolved_to') or request.args.get('resolved_to') or '').strip()

    @staticmethod
    def escape_defect_lens_jql_string(value):
        return str(value).replace('\\', '\\\\').replace('"', '\\"').strip()

    @staticmethod
    def stringify_select_value(value):
        if value is None:
            return ''
        if isinstance(value, dict):
            return (value.get('value') or value.get('name') or '').strip()
        return str(value).strip()

    def build_defect_lens_release_clause(self, release_name):
        escaped_release_name = self.escape_defect_lens_jql_string(release_name)
        return f'(cf[18971] in ("{escaped_release_name}") or cf[18972] in ("{escaped_release_name}"))'

    def build_defect_lens_release_scoped_jql(self, base_jql, release_name):
        if not release_name:
            return base_jql
        scoped_jql, replaced_count = DEFECT_LENS_RELEASE_CLAUSE_PATTERN.subn(
            self.build_defect_lens_release_clause(release_name),
            base_jql,
            count=1,
        )
        if replaced_count:
            return scoped_jql
        order_by_index = base_jql.casefold().find(' order by ')
        if order_by_index == -1:
            return f'({base_jql}) and {self.build_defect_lens_release_clause(release_name)}'
        return f'{base_jql[:order_by_index]} and {self.build_defect_lens_release_clause(release_name)}{base_jql[order_by_index:]}'

    def strip_defect_lens_release_clause(self, base_jql):
        stripped_jql, replaced_count = DEFECT_LENS_RELEASE_CLAUSE_WITH_PREFIX_PATTERN.subn('', base_jql, count=1)
        if replaced_count:
            return stripped_jql
        stripped_jql, replaced_count = DEFECT_LENS_RELEASE_CLAUSE_PATTERN.subn('', base_jql, count=1)
        if replaced_count:
            return stripped_jql.replace('  ', ' ').replace('( ) and ', '').strip()
        return base_jql

    def fetch_defect_lens_release_options(self, username=None, password=None, release_name=None):
        seed_release_name = (release_name or self.get_selected_defect_lens_release() or DEFECT_LENS_RELEASE_SEED_FALLBACK).strip()
        seed_jql = self.build_defect_lens_release_scoped_jql(DEFECT_LENS_ACES_IST_BASE_JQL, seed_release_name)
        seed_issues = fetch_open_defects(
            jql=seed_jql,
            max_results=1,
            username=username,
            password=password,
            fields=[DEFECT_LENS_RELEASE_FIELD_KEY],
            expand='names',
        )
        if not seed_issues:
            return []
        issue_key = (seed_issues[0] or {}).get('key')
        if not issue_key:
            return []
        editmeta = fetch_issue_editmeta(issue_key, username=username, password=password)
        field_meta = (editmeta.get('fields') or {}).get(DEFECT_LENS_RELEASE_FIELD_KEY) or {}
        allowed_values = field_meta.get('allowedValues') or []
        release_options = []
        for allowed_value in allowed_values:
            option_text = self.stringify_select_value(allowed_value.get('value') or allowed_value.get('name'))
            if option_text:
                release_options.append(option_text)
        return sorted(set(release_options), key=str.casefold)

    def build_defect_lens_generated_jql(self, application, release_name, resolved_from='', resolved_to=''):
        if application not in DEFECT_LENS_CONFIGURED_APPLICATIONS:
            raise ValueError('Select a configured Defect Lens application to build the JQL.')
        if (resolved_from and not resolved_to) or (resolved_to and not resolved_from):
            raise ValueError('Provide both Resolution Date From and Resolution Date To, or leave both blank.')
        if resolved_from and resolved_to and resolved_from > resolved_to:
            raise ValueError('Resolution Date From cannot be later than Resolution Date To.')

        if application == 'ACC-Prod':
            scoped_jql = DEFECT_LENS_ACC_BASE_JQL
        else:
            scoped_jql = DEFECT_LENS_ACES_IST_BASE_JQL
            if release_name:
                scoped_jql = self.build_defect_lens_release_scoped_jql(scoped_jql, release_name)
        jql_parts = [scoped_jql]
        if resolved_from:
            jql_parts.append(f'resolved >= "{resolved_from}"')
        if resolved_to:
            jql_parts.append(f'resolved <= "{resolved_to}"')
        return ' and '.join(jql_parts)

    @staticmethod
    def ensure_defect_lens_imports():
        if not LOCAL_DEFECT_LENS_PACKAGE.exists():
            raise ValueError(f'Local Defect Lens package was not found at {LOCAL_DEFECT_LENS_PACKAGE}.')
        local_package_root = str(LOCAL_DEFECT_LENS_PACKAGE_ROOT)
        if local_package_root not in sys.path:
            sys.path.insert(0, local_package_root)

    def get_defect_lens_service(self):
        service = current_app.extensions.get('defect_lens_job_service')
        if service is not None:
            return service

        self.ensure_defect_lens_imports()

        from defectLens.config import get_settings
        from defectLens.logging_conf import configure_logging
        from defectLens.core.services.job_service import AnalysisJobService, JobStore

        settings = get_settings()
        configure_logging(settings)
        store = JobStore()
        service = AnalysisJobService(settings, store)
        current_app.extensions['defect_lens_job_service'] = service
        return service

    @staticmethod
    def build_defect_lens_asset_version(asset_relative_path):
        asset_path = Path(current_app.static_folder) / asset_relative_path
        try:
            return int(asset_path.stat().st_mtime)
        except OSError:
            return 0

    def get_defect_lens_credentials(self):
        credentials = self.get_session_credentials()
        if credentials is None:
            raise ValueError('Log in with your Jira/iTrack credentials to use Defect Lens.')
        return credentials

    def register(self, app, login_required):
        from flask import Blueprint
        static_bp = Blueprint(
            'defect_lens_static',
            __name__,
            static_folder='.',
            static_url_path='/static/defect_lens',
        )
        app.register_blueprint(static_bp)

        @app.route('/defect-lens')
        @login_required
        def defect_lens_page():
            credentials = self.get_session_credentials() or {}
            selected_application = self.get_selected_defect_lens_application()
            selected_release = self.get_selected_defect_lens_release()
            resolved_from = self.get_selected_defect_lens_resolved_from()
            resolved_to = self.get_selected_defect_lens_resolved_to()
            release_options = []
            release_error = None
            generated_jql = ''
            filter_error = None

            if selected_application == DEFECT_LENS_RELEASE_ENABLED_APPLICATION:
                try:
                    release_options = self.fetch_defect_lens_release_options(
                        username=credentials.get('username'),
                        password=credentials.get('password'),
                        release_name=selected_release,
                    )
                except requests.RequestException as error:
                    release_error = f'Unable to load {DEFECT_LENS_RELEASE_FIELD_NAME} values from Jira/iTrack: {error}'
                except ValueError as error:
                    release_error = str(error)

            if selected_application:
                try:
                    generated_jql = self.build_defect_lens_generated_jql(
                        selected_application,
                        selected_release,
                        resolved_from=resolved_from,
                        resolved_to=resolved_to,
                    )
                except ValueError as error:
                    filter_error = str(error)

            return render_template(
                'defect_lens.html',
                page_title='Quality Lens 360 | Defect Lens',
                jira_user=credentials.get('username', JIRA_USER),
                static_asset_version=self.build_defect_lens_asset_version,
                application_options=DEFECT_LENS_APPLICATION_OPTIONS,
                selected_application=selected_application,
                resolved_from=resolved_from,
                resolved_to=resolved_to,
                release_options=release_options,
                selected_release=selected_release,
                release_error=release_error,
                filter_error=filter_error,
                release_field_name=DEFECT_LENS_RELEASE_FIELD_NAME,
                release_enabled_application=DEFECT_LENS_RELEASE_ENABLED_APPLICATION,
                generated_jql=generated_jql,
                defect_lens_config={
                    'runUrl': url_for('defect_lens_api_run'),
                    'runJqlUrl': url_for('defect_lens_api_run_jql'),
                    'statusBaseUrl': url_for('defect_lens_api_status', job_id='__JOB_ID__').replace('__JOB_ID__', ''),
                    'logBaseUrl': url_for('defect_lens_api_log', job_id='__JOB_ID__').replace('__JOB_ID__', ''),
                    'insightsBaseUrl': url_for('defect_lens_api_insights', job_id='__JOB_ID__').replace('__JOB_ID__', ''),
                    'downloadBaseUrl': url_for('defect_lens_download', job_id='__JOB_ID__').replace('__JOB_ID__', ''),
                    'generatedJql': generated_jql,
                },
            )

        @app.post('/defect-lens/api/run')
        @login_required
        def defect_lens_api_run():
            try:
                credentials = self.get_defect_lens_credentials()
                file = request.files.get('file')
                if not file or file.filename == '':
                    return jsonify({'ok': False, 'error': 'Please upload an Excel .xlsx file.'}), 400
                if not file.filename.lower().endswith('.xlsx'):
                    return jsonify({'ok': False, 'error': 'Only .xlsx files are supported.'}), 400

                service = self.get_defect_lens_service()
                settings = service.settings
                job_id = service.create_job()
                input_path = Path(settings.upload_dir) / f'{job_id}_{secure_filename(file.filename)}'
                file.save(str(input_path))
                service.start_file_job(job_id, credentials['username'], credentials['password'], input_path)
                return jsonify({'ok': True, 'jobId': job_id})
            except ValueError as error:
                return jsonify({'ok': False, 'error': str(error)}), 400

        @app.post('/defect-lens/api/run-jql')
        @login_required
        def defect_lens_api_run_jql():
            try:
                credentials = self.get_defect_lens_credentials()
                selected_application = self.get_selected_defect_lens_application()
                selected_release = self.get_selected_defect_lens_release()
                resolved_from = self.get_selected_defect_lens_resolved_from()
                resolved_to = self.get_selected_defect_lens_resolved_to()
                jql = (request.form.get('jql') or '').strip()
                if not jql:
                    jql = self.build_defect_lens_generated_jql(
                        selected_application,
                        selected_release,
                        resolved_from=resolved_from,
                        resolved_to=resolved_to,
                    )

                service = self.get_defect_lens_service()
                job_id = service.create_job()
                service.start_jql_job(job_id, credentials['username'], credentials['password'], jql)
                return jsonify({'ok': True, 'jobId': job_id})
            except ValueError as error:
                return jsonify({'ok': False, 'error': str(error)}), 400

        @app.get('/defect-lens/api/status/<job_id>')
        @login_required
        def defect_lens_api_status(job_id):
            service = self.get_defect_lens_service()
            current_prompt_signature = service.current_prompt_signature()
            job = service.store.get_snapshot(job_id)
            if job is None:
                return jsonify({'ok': False, 'error': 'Job not found'}), 404

            if service.should_refresh_ai_summary(job, current_prompt_signature):
                try:
                    service.populate_ai_summary(job_id)
                except Exception:
                    pass
                job = service.store.get_snapshot(job_id)
                if job is None:
                    return jsonify({'ok': False, 'error': 'Job not found'}), 404

            return jsonify(
                {
                    'ok': True,
                    'status': job.status,
                    'progress': job.progress,
                    'message': job.message,
                    'ai': job.ai,
                    'aiTitle': job.aiTitle,
                    'aiPromptSignature': job.aiPromptSignature,
                    'currentPromptSignature': current_prompt_signature,
                    'okrs': job.okrs,
                    'summary': job.summary,
                    'topContrib': job.topContrib,
                    'topContribChart': job.topContribChart,
                    'mttrContrib': job.mttrContrib,
                    'mttrContribChart': job.mttrContribChart,
                    'mttiContrib': job.mttiContrib,
                    'mttiContribChart': job.mttiContribChart,
                    'mttfContrib': job.mttfContrib,
                    'mttfContribChart': job.mttfContribChart,
                }
            )

        @app.get('/defect-lens/api/log/<job_id>')
        @login_required
        def defect_lens_api_log(job_id):
            try:
                since = max(0, int(request.args.get('since', '0')))
            except (TypeError, ValueError):
                since = 0

            slice_result = self.get_defect_lens_service().store.get_log_slice(job_id, since)
            if slice_result is None:
                return jsonify({'ok': False, 'error': 'Job not found'}), 404

            lines, next_index = slice_result
            return jsonify({'ok': True, 'lines': lines, 'next': next_index})

        @app.post('/defect-lens/api/insights/<job_id>')
        @login_required
        def defect_lens_api_insights(job_id):
            service = self.get_defect_lens_service()
            job = service.store.get_snapshot(job_id)
            if job is None:
                return jsonify({'ok': False, 'error': 'Job not found'}), 404
            if job.status != 'completed':
                return jsonify({'ok': False, 'error': 'AI insights are available only after the run completes.'}), 409

            service.store.append_log(job_id, 'Provide AI Insights requested...')
            payload = service.populate_ai_summary(job_id)
            return jsonify({'ok': True, **payload, 'source': 'prompt-template'})

        @app.get('/defect-lens/download/<job_id>')
        @login_required
        def defect_lens_download(job_id):
            job = self.get_defect_lens_service().store.get_snapshot(job_id)
            if job is None or job.status != 'completed' or not job.output_path:
                return 'File not ready', 404
            path = job.output_path
            download_name = job.download_name or Path(path).name
            return send_file(path, as_attachment=True, download_name=download_name)