"""
ACES-IST KPI Handler

Executes all KPI calculations for the ACES-IST application.
"""


def run_aces_ist_ram_kpis(context):
    execute_ram_query = context['execute_ram_query']
    fetch_issue_count = context['fetch_issue_count']
    fetch_zephyr_zql_total_count = context['fetch_zephyr_zql_total_count']
    calculate_triage_efficiency_kpi = context['calculate_triage_efficiency_kpi']
    calculate_production_defect_leakage_kpi = context['calculate_production_defect_leakage_kpi']
    calculate_defect_acceptance_rate_kpi = context['calculate_defect_acceptance_rate_kpi']
    calculate_defect_burndown_rate_kpi = context['calculate_defect_burndown_rate_kpi']
    count_unique_defect_density_labels = context['count_unique_defect_density_labels']
    build_triaged_ram_jql = context['build_triaged_ram_jql']
    build_cancelled_ram_jql = context['build_cancelled_ram_jql']
    build_active_defect_density_ram_jql = context['build_active_defect_density_ram_jql']
    build_accepted_ram_jql = context['build_accepted_ram_jql']
    build_ram_scope_jql = context['build_ram_scope_jql']
    build_resolved_burndown_ram_jql = context['build_resolved_burndown_ram_jql']
    build_open_ram_jql = context['build_open_ram_jql']
    extract_release_numeric_value = context['extract_release_numeric_value']
    build_defect_density_denominator_ram_jql = context['build_defect_density_denominator_ram_jql']
    build_defect_density_formula = context['build_defect_density_formula']
    build_productivity_improvement_label = context['build_productivity_improvement_label']
    build_productivity_improvement_denominator_labels = context['build_productivity_improvement_denominator_labels']
    build_labels_only_ram_jql = context['build_labels_only_ram_jql']
    calculate_percentage_change = context['calculate_percentage_change']
    build_productivity_improvement_formula = context['build_productivity_improvement_formula']

    executed_jql = context['executed_jql']
    base_ram_jql = context['base_ram_jql']
    created_from = context['created_from']
    created_to = context['created_to']
    selected_release = context['selected_release']
    selected_application_definition = context['selected_application_definition']
    username = context['username']
    password = context['password']

    from ram.feature import (
        build_aces_ist_defect_leakage_scope_jql,
        build_full_year_created_scope_jql,
        build_ram_release_scoped_jql,
        filter_release_labels_by_year_notation,
        strip_created_date_clauses,
    )

    overall_defects = execute_ram_query(
        'RAM overall defects',
        lambda: fetch_issue_count(
            jql=executed_jql,
            username=username,
            password=password,
        ),
    )
    triaged_defects = execute_ram_query(
        'RAM triaged defects',
        lambda: fetch_issue_count(
            jql=build_triaged_ram_jql(executed_jql),
            username=username,
            password=password,
        ),
    )
    cancelled_defects = execute_ram_query(
        'RAM cancelled defects',
        lambda: fetch_issue_count(
            jql=build_cancelled_ram_jql(executed_jql),
            username=username,
            password=password,
        ),
    )
    configured_defect_density_labels = list(selected_application_definition.get('defect_density_date_range_labels') or ())
    defect_density_labels = (
        filter_release_labels_by_year_notation(configured_defect_density_labels, created_from, created_to)
        if created_from and created_to and not selected_release
        else configured_defect_density_labels
    )
    release_label_value = extract_release_numeric_value(selected_release)
    defect_density_numerator_jql = (
        build_active_defect_density_ram_jql(executed_jql)
        if release_label_value
        else build_active_defect_density_ram_jql(
            build_full_year_created_scope_jql(base_ram_jql, created_from, created_to)
        )
    )
    defect_density_numerator = execute_ram_query(
        'RAM defect density numerator',
        lambda: fetch_issue_count(
            jql=defect_density_numerator_jql,
            username=username,
            password=password,
        ),
    )
    accepted_defects = execute_ram_query(
        'RAM accepted defects',
        lambda: fetch_issue_count(
            jql=build_accepted_ram_jql(executed_jql),
            username=username,
            password=password,
        ),
    )
    # Burndown rate queries
    burndown_base_jql = strip_created_date_clauses(base_ram_jql)
    if selected_release:
        burndown_release_jql = build_ram_release_scoped_jql(burndown_base_jql, selected_release)
        burndown_numerator_jql = f'({burndown_release_jql}) and status in (Accepted, Cancelled)'
        burndown_denominator_jql = burndown_release_jql
        resolved_period_defects = execute_ram_query(
            'RAM burndown numerator (Accepted/Cancelled for release)',
            lambda: fetch_issue_count(
                jql=burndown_numerator_jql,
                username=username,
                password=password,
            ),
        )
        overall_open_defects = execute_ram_query(
            'RAM burndown denominator (all defects for release)',
            lambda: fetch_issue_count(
                jql=burndown_denominator_jql,
                username=username,
                password=password,
            ),
        )
    else:
        resolved_period_defects = execute_ram_query(
            'RAM resolved defects for selected criteria',
            lambda: fetch_issue_count(
                jql=build_resolved_burndown_ram_jql(burndown_base_jql, created_from, created_to),
                username=username,
                password=password,
            ),
        )
        overall_open_defects = execute_ram_query(
            'RAM overall open defects',
            lambda: fetch_issue_count(
                jql=build_open_ram_jql(burndown_base_jql),
                username=username,
                password=password,
            ),
        )

    triage_efficiency = None
    production_defect_leakage = None
    cancellation_rate = None
    defect_acceptance_rate = None
    defect_burndown_rate = None
    defect_density = None
    productivity_improvement = None
    automation_coverage_overall = None
    automation_coverage_automatable = None
    defect_discovery_rate = None
    automation_utilization = None

    production_defect_leakage_base_jql = str(selected_application_definition.get('prod_defect_leakage_base_jql') or '').strip()
    preprod_defect_leakage_base_jql = str(selected_application_definition.get('preprod_defect_leakage_base_jql') or '').strip()
    if production_defect_leakage_base_jql and preprod_defect_leakage_base_jql:
        production_defect_leakage_jql = build_aces_ist_defect_leakage_scope_jql(
            production_defect_leakage_base_jql,
            created_from,
            created_to,
            selected_release,
        )
        # Always exclude Cancelled defects from the production numerator
        if 'cancelled' not in production_defect_leakage_jql.lower():
            production_defect_leakage_jql = f'({production_defect_leakage_jql}) and status not in (Cancelled)'
        preprod_defects_jql = build_aces_ist_defect_leakage_scope_jql(
            preprod_defect_leakage_base_jql,
            created_from,
            created_to,
            selected_release,
        )
        production_defect_leakage_defects = execute_ram_query(
            'RAM defect leakage numerator',
            lambda: fetch_issue_count(
                jql=production_defect_leakage_jql,
                username=username,
                password=password,
            ),
        )
        overall_preprod_defects = execute_ram_query(
            'RAM pre-prod defects',
            lambda: fetch_issue_count(
                jql=preprod_defects_jql,
                username=username,
                password=password,
            ),
        )
        if production_defect_leakage_defects is not None and overall_preprod_defects is not None:
            production_defect_leakage = calculate_production_defect_leakage_kpi(
                production_defect_leakage_defects,
                overall_preprod_defects,
            )
            if production_defect_leakage:
                production_defect_leakage['queries'] = (
                    f'Query 1 (Production Leakage): {production_defect_leakage_jql}\n\n'
                    f'Query 2 (Pre-Prod): {preprod_defects_jql}'
                )

    if overall_defects is not None and triaged_defects is not None:
        triage_efficiency = calculate_triage_efficiency_kpi(overall_defects, triaged_defects)
        if triage_efficiency:
            triaged_jql = build_triaged_ram_jql(executed_jql)
            triage_efficiency['queries'] = f'Query 1 (Overall): {executed_jql}\n\nQuery 2 (Triaged): {triaged_jql}'
    if overall_defects is not None and cancelled_defects is not None:
        cancelled_jql = build_cancelled_ram_jql(executed_jql)
        cancellation_rate = {
            'percentage': f'{round((cancelled_defects / overall_defects) * 100) if overall_defects else 0}%',
            'numerator': cancelled_defects,
            'denominator': overall_defects,
            'logic': 'No. of defects where STATUS in (Cancelled) / Overall Defects',
            'queries': f'Query 1 (Overall): {executed_jql}\n\nQuery 2 (Cancelled): {cancelled_jql}',
        }
    if overall_defects is not None and accepted_defects is not None and cancelled_defects is not None:
        defect_acceptance_rate = calculate_defect_acceptance_rate_kpi(
            overall_defects,
            accepted_defects,
            cancelled_defects=cancelled_defects,
        )
        if defect_acceptance_rate:
            accepted_jql = build_accepted_ram_jql(executed_jql)
            cancelled_jql = build_cancelled_ram_jql(executed_jql)
            defect_acceptance_rate['queries'] = f'Query 1 (Overall): {executed_jql}\n\nQuery 2 (Accepted): {accepted_jql}\n\nQuery 3 (Cancelled): {cancelled_jql}'
    if resolved_period_defects is not None and overall_open_defects is not None:
        if selected_release:
            denominator_val = overall_open_defects
            defect_burndown_rate = {
                'percentage': f'{round((resolved_period_defects / denominator_val) * 100) if denominator_val else 0}%',
                'numerator': resolved_period_defects,
                'denominator': denominator_val,
                'logic': 'No. of defects where STATUS in (Accepted, Cancelled) for selected release / Total defects for selected release',
                'queries': f'Query 1 (Numerator - Accepted/Cancelled): {burndown_numerator_jql}\n\nQuery 2 (Denominator - All Defects): {burndown_denominator_jql}',
            }
        else:
            defect_burndown_rate = calculate_defect_burndown_rate_kpi(resolved_period_defects, overall_open_defects)
            if defect_burndown_rate:
                resolved_burndown_jql = build_resolved_burndown_ram_jql(burndown_base_jql, created_from, created_to)
                open_jql = build_open_ram_jql(burndown_base_jql)
                defect_burndown_rate['queries'] = f'Query 1 (Resolved in Period): {resolved_burndown_jql}\n\nQuery 2 (Overall Open): {open_jql}'

    defect_density_denominator = None
    denominator_jql = ''
    if release_label_value:
        denominator_jql = build_defect_density_denominator_ram_jql(
            selected_release=selected_release,
            label_values=configured_defect_density_labels,
        )
        defect_density_denominator = execute_ram_query(
            'RAM defect density denominator',
            lambda: fetch_issue_count(
                jql=denominator_jql,
                username=username,
                password=password,
            ),
        )
    elif defect_density_labels:
        denominator_jql = build_defect_density_denominator_ram_jql(dynamic_labels=defect_density_labels)
        defect_density_denominator = execute_ram_query(
            'RAM defect density denominator labels',
            lambda: fetch_issue_count(
                jql=denominator_jql,
                username=username,
                password=password,
            ),
        )
    else:
        defect_density_denominator = 0

    if defect_density_numerator is not None and defect_density_denominator is not None:
        defect_density_logic = build_defect_density_formula(
            selected_release,
            defect_density_labels if not release_label_value else None,
            label_values=configured_defect_density_labels,
        )
        if defect_density_denominator:
            defect_density = {
                'percentage': f'{round(defect_density_numerator / defect_density_denominator, 2)}',
                'numerator': defect_density_numerator,
                'denominator': defect_density_denominator,
                'logic': defect_density_logic,
                'queries': f'Query 1 (Defect Vs Feature Ratio - Numerator): {defect_density_numerator_jql}\n\nQuery 2 (Denominator): {denominator_jql}',
            }
        else:
            defect_density = {
                'percentage': 'N/A',
                'numerator': defect_density_numerator,
                'denominator': defect_density_denominator,
                'logic': defect_density_logic,
                'queries': f'Query 1 (Defect Vs Feature Ratio - Numerator): {defect_density_numerator_jql}\n\nQuery 2 (Denominator): {denominator_jql}',
                'status_note': 'No matching ACES_IST_PI labels were found for the current selection.',
            }

    productivity_all_labels = (
        defect_density_labels
        if created_from and created_to and not selected_release
        else configured_defect_density_labels
    )
    productivity_denominator_labels = build_productivity_improvement_denominator_labels(
        selected_release,
        productivity_all_labels,
    )
    productivity_denominator_jql = ''
    productivity_denominator_issue_count = None
    if productivity_denominator_labels:
        productivity_denominator_jql = build_defect_density_denominator_ram_jql(dynamic_labels=productivity_denominator_labels)
        productivity_denominator_issue_count = execute_ram_query(
            'RAM productivity improvement denominator labels',
            lambda: fetch_issue_count(
                jql=productivity_denominator_jql,
                username=username,
                password=password,
            ),
        )
    productivity_denominator_unique_label_count = count_unique_defect_density_labels(productivity_all_labels)
    productivity_denominator_divisor = max(0, productivity_denominator_unique_label_count - 1)
    productivity_denominator = None
    if productivity_denominator_issue_count is not None and productivity_denominator_divisor:
        productivity_denominator = round(
            productivity_denominator_issue_count / productivity_denominator_divisor,
            2,
        )
    elif productivity_denominator_issue_count is not None:
        productivity_denominator = 0

    productivity_label = build_productivity_improvement_label(
        selected_release,
        label_values=productivity_all_labels,
    )
    if productivity_label and productivity_denominator is not None:
        productivity_numerator_jql = build_labels_only_ram_jql([productivity_label])
        productivity_numerator = execute_ram_query(
            'RAM productivity improvement numerator',
            lambda: fetch_issue_count(
                jql=productivity_numerator_jql,
                username=username,
                password=password,
            ),
        )
        if productivity_numerator is not None:
            productivity_difference = abs(round(productivity_numerator - productivity_denominator, 2))
            productivity_improvement = {
                'percentage': f'{abs(calculate_percentage_change(productivity_numerator, productivity_denominator))}%',
                'numerator': productivity_difference,
                'denominator': productivity_denominator,
                'logic': build_productivity_improvement_formula(productivity_label, productivity_denominator_labels),
                'queries': f'Query 1 (Numerator - {productivity_label}): {productivity_numerator_jql}\n\nQuery 2 (Denominator): {productivity_denominator_jql}',
            }

    automation_base_jql = str(selected_application_definition.get('automation_base_jql') or '').strip()
    if automation_base_jql:
        automated_coverage_clause = '"Automated Script?" = Yes and ("User 5" ~ Automated or "User 5" ~ Partial)'

        automation_overall_denominator = execute_ram_query(
            'RAM automation coverage overall denominator',
            lambda: fetch_issue_count(
                jql=automation_base_jql,
                username=username,
                password=password,
            ),
        )
        automation_coverage_numerator = execute_ram_query(
            'RAM automation coverage numerator',
            lambda: fetch_issue_count(
                jql=f'({automation_base_jql}) and {automated_coverage_clause}',
                username=username,
                password=password,
            ),
        )

        if automation_coverage_numerator is not None and automation_overall_denominator is not None:
            automation_coverage_overall = {
                'percentage': f'{round((automation_coverage_numerator / automation_overall_denominator) * 100) if automation_overall_denominator else 0}%',
                'numerator': automation_coverage_numerator,
                'denominator': automation_overall_denominator,
                'logic': 'No. of test cases automated/Overall test cases',
                'queries': f'Query 1 (Overall): {automation_base_jql}\n\nQuery 2 (Automated): ({automation_base_jql}) and "Automated Script?" = Yes and ("User 5" ~ Automated or "User 5" ~ Partial)',
            }

    automation_automatable_numerator_jql = str(
        selected_application_definition.get('automation_coverage_automatable_numerator_jql') or ''
    ).strip()
    automation_automatable_denominator_jql = str(
        selected_application_definition.get('automation_coverage_automatable_denominator_jql') or ''
    ).strip()
    if automation_automatable_numerator_jql and automation_automatable_denominator_jql:
        automation_automatable_numerator = execute_ram_query(
            'RAM automation coverage automatable numerator',
            lambda: fetch_issue_count(
                jql=automation_automatable_numerator_jql,
                username=username,
                password=password,
            ),
        )
        automation_automatable_denominator = execute_ram_query(
            'RAM automation coverage automatable denominator',
            lambda: fetch_issue_count(
                jql=automation_automatable_denominator_jql,
                username=username,
                password=password,
            ),
        )
        if automation_automatable_numerator is not None and automation_automatable_denominator is not None:
            automation_coverage_automatable = {
                'percentage': f'{round((automation_automatable_numerator / automation_automatable_denominator) * 100) if automation_automatable_denominator else 0}%',
                'numerator': automation_automatable_numerator,
                'denominator': automation_automatable_denominator,
                'logic': 'No. of test cases automated/(No. of Automatable test cases + No. of test cases yet to analyze)',
                'queries': f'Query 1 (Numerator - Automated Automatable): {automation_automatable_numerator_jql}\n\nQuery 2 (Denominator - All Automatable): {automation_automatable_denominator_jql}',
            }

    defect_discovery_base_jql = str(selected_application_definition.get('defect_discovery_base_jql') or '').strip()
    if defect_discovery_base_jql:
        defect_discovery_denominator = execute_ram_query(
            'RAM defect discovery denominator',
            lambda: fetch_issue_count(
                jql=defect_discovery_base_jql,
                username=username,
                password=password,
            ),
        )
        defect_discovery_numerator = execute_ram_query(
            'RAM defect discovery numerator',
            lambda: fetch_issue_count(
                jql=f'({defect_discovery_base_jql}) and labels in (Automation)',
                username=username,
                password=password,
            ),
        )
        if defect_discovery_numerator is not None and defect_discovery_denominator is not None:
            defect_discovery_rate = {
                'percentage': f'{round((defect_discovery_numerator / defect_discovery_denominator) * 100) if defect_discovery_denominator else 0}%',
                'numerator': defect_discovery_numerator,
                'denominator': defect_discovery_denominator,
                'logic': 'No. of valid defects found by Automated Runs/No. of valid regression defects loggged)',
                'queries': f'Query 1 (Denominator): {defect_discovery_base_jql}\n\nQuery 2 (Numerator - Automation Label): ({defect_discovery_base_jql}) and labels in (Automation)',
            }

    automation_utilization_fix_versions = [
        str(value).strip() for value in (selected_application_definition.get('automation_utilization_fix_versions') or ()) if str(value).strip()
    ]
    automation_utilization_executed_by = [
        str(value).strip() for value in (selected_application_definition.get('automation_utilization_executed_by') or ()) if str(value).strip()
    ]
    if automation_utilization_fix_versions:
        quoted_fix_versions = ', '.join(f'"{value}"' for value in automation_utilization_fix_versions)
        automation_utilization_base_jql = f'project = "BTEST" AND fixVersion in ({quoted_fix_versions})'
        automation_utilization_denominator = execute_ram_query(
            'RAM automation utilization denominator',
            lambda: fetch_zephyr_zql_total_count(
                zql_query=automation_utilization_base_jql,
                username=username,
                password=password,
            ),
        )
        automation_utilization_numerator = None
        if automation_utilization_executed_by:
            executed_by_clause = ', '.join(automation_utilization_executed_by)
            automation_utilization_numerator = execute_ram_query(
                'RAM automation utilization numerator',
                lambda: fetch_zephyr_zql_total_count(
                    zql_query=f'{automation_utilization_base_jql} AND executedBy in ({executed_by_clause})',
                    username=username,
                    password=password,
                ),
            )
        if automation_utilization_numerator is not None and automation_utilization_denominator is not None:
            automation_utilization = {
                'percentage': f'{round((automation_utilization_numerator / automation_utilization_denominator) * 100) if automation_utilization_denominator else 0}%',
                'numerator': automation_utilization_numerator,
                'denominator': automation_utilization_denominator,
                'logic': 'No. of test cases executed by Automation/Total No. of test cases executed',
                'queries': f'Query 1 (Denominator - ZQL): {automation_utilization_base_jql}\n\nQuery 2 (Numerator - ZQL): {automation_utilization_base_jql} AND executedBy in ({", ".join(automation_utilization_executed_by)})' if automation_utilization_executed_by else f'Query 1 (Denominator - ZQL): {automation_utilization_base_jql}',
            }

    return {
        'triaged_defects': triaged_defects,
        'defect_leakage_alt': production_defect_leakage,
        'triage_efficiency': triage_efficiency,
        'cancellation_rate': cancellation_rate,
        'defect_acceptance_rate': defect_acceptance_rate,
        'defect_burndown_rate': defect_burndown_rate,
        'defect_density': defect_density,
        'productivity_improvement': productivity_improvement,
        'automation_coverage_overall': automation_coverage_overall,
        'automation_coverage_automatable': automation_coverage_automatable,
        'defect_discovery_rate': defect_discovery_rate,
        'automation_utilization': automation_utilization,
    }
