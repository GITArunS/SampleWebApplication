"""
JQL Executor Module for RAM

Master source for executing all JQL and ZQL queries across the RAM module.
Coordinates query orchestration, result processing, and KPI calculations.

This module serves as the central hub for:
- Executing JQL queries via Jira API
- Processing query results
- Extracting and calculating metrics
- Handling query errors and timeouts
"""

import re
from datetime import datetime

from shared.shared_logic import (
    fetch_issue_count,
    fetch_open_defects,
)
from ram.zephyr_integration import fetch_zephyr_zql_total_count
from ram.base_jql_queries import (
    build_ram_base_jql,
    get_ram_application_definition,
)
from ram.app_config import RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS


# ============================================================================
# QUERY EXECUTION ORCHESTRATION
# ============================================================================

def execute_ram_query(query_label, query_callable, ram_warnings, format_http_error_message):
    """
    Execute a RAM query with error handling and warning collection.
    
    Args:
        query_label: Human-readable label for the query
        query_callable: Callable that executes the query
        ram_warnings: List to collect warning messages
        format_http_error_message: Function to format HTTP error messages
    
    Returns:
        Query result or None if query failed
    """
    try:
        return query_callable()
    except Exception as error:
        import requests
        if isinstance(error, requests.HTTPError):
            ram_warnings.append(format_http_error_message(query_label, error))
        elif isinstance(error, requests.RequestException):
            ram_warnings.append(f'{query_label} failed while pulling data from Jira/iTrack: {error}')
        else:
            ram_warnings.append(f'{query_label} encountered an error: {error}')
    return None


# ============================================================================
# FETCH OPERATIONS WITH QUERY BUILDER
# ============================================================================

def fetch_ram_label_issues(jql, username, password, batch_size=200):
    """
    Fetch issues matching JQL and extract their labels.
    
    Args:
        jql: JQL query string
        username: Jira username
        password: Jira API token or password
        batch_size: Records per batch (default: 200)
    
    Returns:
        list: Issues with their labels
    """
    issues = []
    start_at = 0
    while True:
        batch_issues = fetch_open_defects(
            jql=jql,
            max_results=batch_size,
            username=username,
            password=password,
            start_at=start_at,
            fields=['labels'],
        )
        if not batch_issues:
            break
        issues.extend(batch_issues)
        if len(batch_issues) < batch_size:
            break
        start_at += len(batch_issues)
    return issues


def fetch_ram_status_history_issues(jql, username, password):
    """
    Fetch issues with status change history.
    
    Args:
        jql: JQL query string
        username: Jira username
        password: Jira API token or password
    
    Returns:
        list: Issues with status history
    """
    return fetch_open_defects(
        jql=jql,
        max_results=500,
        username=username,
        password=password,
        fields=['summary', 'status', 'created', 'updated', 'changelog'],
    )


def fetch_ram_release_options(username, password, release_name=''):
    """
    Fetch available release values from Jira field schema.
    
    Args:
        username: Jira username
        password: Jira API token or password
        release_name: Optional current release to prioritize
    
    Returns:
        list: Sorted list of release options
    """
    import requests
    from shared.shared_config import JIRA_URL
    from shared.release_open_defects import (
        build_basic_auth,
        JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    from shared.http_session import get_http_session
    
    try:
        response = get_http_session().get(
            f'{JIRA_URL}issueType/10200/fields',
            auth=build_basic_auth(username=username, password=password),
            timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
        )
        response.raise_for_status()
        field_data = response.json()
        
        release_field = next(
            (f for f in field_data if f.get('fieldId') == 'customfield_18971'),
            None
        )
        if not release_field:
            raise ValueError('Release field (customfield_18971) not found in Jira schema.')
        
        allowed_values = release_field.get('allowedValues', [])
        release_names = sorted(set(v.get('value') for v in allowed_values if v.get('value')))
        
        # Prioritize current release if specified
        if release_name and release_name in release_names:
            return [release_name] + [r for r in release_names if r != release_name]
        
        return release_names
    except Exception as error:
        raise ValueError(f'Unable to fetch release options: {error}') from error


# ============================================================================
# METRIC EXTRACTION AND PROCESSING
# ============================================================================

def extract_release_numeric_value(release_name):
    """
    Extract numeric version from release name (e.g., 'PI4.2' -> '4.2').
    
    Args:
        release_name: Release name string
    
    Returns:
        str: Numeric version or empty string
    """
    release_text = str(release_name or '').strip()
    if not release_text:
        return ''
    
    match = re.search(r'PI\s*([0-9]+(?:\.[0-9]+)*)', release_text, re.IGNORECASE)
    if match:
        return match.group(1)
    
    fallback_match = re.search(r'([0-9]+(?:\.[0-9]+)*)', release_text)
    return fallback_match.group(1) if fallback_match else ''


def count_unique_defect_density_labels(label_values):
    """Count unique labels (used for defect density calculations)."""
    return len({str(label).strip() for label in (label_values or []) if str(label).strip()})


def parse_release_label_numeric_value(label_value):
    """
    Parse numeric version from ACES-IST label format (e.g., 'ACES_IST_PI4.2' -> (4, 2)).
    
    Args:
        label_value: Label value string
    
    Returns:
        tuple: Numeric version as tuple or empty tuple
    """
    match = re.search(
        r'ACES_IST_PI([0-9]+(?:\.[0-9]+)*)',
        str(label_value or '').strip(),
        re.IGNORECASE
    )
    return tuple(int(part) for part in match.group(1).split('.')) if match else tuple()


def get_latest_productivity_improvement_label():
    """Get the latest productivity improvement label from configured labels."""
    label_values = list(RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS)
    if not label_values:
        return ''
    return max(label_values, key=parse_release_label_numeric_value)


def build_productivity_improvement_label(selected_release=''):
    """Build productivity improvement label for a specific release."""
    release_numeric_value = extract_release_numeric_value(selected_release)
    if release_numeric_value:
        return f'ACES_IST_PI{release_numeric_value}'
    return get_latest_productivity_improvement_label()


def build_productivity_improvement_denominator_labels(selected_release='', label_values=None):
    """Get productivity labels excluding the current period label."""
    normalized_labels = [str(label).strip() for label in (label_values or []) if str(label).strip()]
    if not normalized_labels:
        return []
    selected_label = build_productivity_improvement_label(selected_release)
    return [label for label in normalized_labels if label != selected_label]


def build_labels_only_ram_jql(jql, label_list):
    """Add label filtering to a JQL query."""
    if not label_list:
        return jql
    quoted_labels = ', '.join(f'"{str(label).strip()}"' for label in label_list if str(label).strip())
    if not quoted_labels:
        return jql
    return f'({jql}) and labels in ({quoted_labels})'


def build_defect_density_formula(unique_labels, denominator):
    """Build defect density formula for display."""
    if not denominator:
        return 'N/A'
    result = f'{unique_labels}/{denominator}'
    if denominator:
        percentage = round((unique_labels / denominator) * 100)
        return f'{result} ({percentage}%)'
    return result


def build_productivity_improvement_formula(numerator, denominator):
    """Build productivity improvement formula for display."""
    if not denominator:
        return 'N/A'
    percentage = round((numerator / denominator) * 100)
    return f'{numerator}/{denominator} ({percentage}%)'


# ============================================================================
# KPI CALCULATION HELPERS
# ============================================================================

def calculate_percentage_change(current_value, baseline_value):
    """Calculate percentage change between two values."""
    if not baseline_value or baseline_value == 0:
        return 0
    return round(((current_value - baseline_value) / baseline_value) * 100)


def calculate_absolute_percentage_change(current_value, baseline_value):
    """Calculate absolute percentage change (current/baseline as percentage)."""
    if not baseline_value or baseline_value == 0:
        return 0
    return round((current_value / baseline_value) * 100)


def calculate_production_defect_leakage_kpi(production_defect_count, preprod_defect_count):
    """Calculate production defect leakage KPI."""
    denominator = production_defect_count + preprod_defect_count
    percentage_value = round((production_defect_count / denominator) * 100) if denominator else 0
    return {
        'percentage': f'{percentage_value}%',
        'numerator': production_defect_count,
        'denominator': denominator,
        'logic': 'No. of valid defects found in Prod / (No. of valid defects found in Prod + Overall Valid Defects created in Pre-Prod for the selected period)',
    }


def calculate_triage_efficiency_kpi(triaged_count, total_count):
    """Calculate triage efficiency KPI."""
    percentage_value = round((triaged_count / total_count) * 100) if total_count else 0
    return {
        'percentage': f'{percentage_value}%',
        'numerator': triaged_count,
        'denominator': total_count,
        'logic': 'No. of defects where STATUS not in ("To Do") / Overall Defects',
    }


def calculate_defect_acceptance_rate_kpi(accepted_count, total_count):
    """Calculate defect acceptance rate KPI."""
    percentage_value = round((accepted_count / total_count) * 100) if total_count else 0
    return {
        'percentage': f'{percentage_value}%',
        'numerator': accepted_count,
        'denominator': total_count,
        'logic': 'Defects in Accepted status / Overall Defects',
    }


def calculate_defect_burndown_rate_kpi(resolved_count, total_count):
    """Calculate defect burndown rate KPI."""
    denominator = resolved_count + total_count
    percentage_value = round((resolved_count / denominator) * 100) if denominator else 0
    return {
        'percentage': f'{percentage_value}%',
        'numerator': resolved_count,
        'denominator': denominator,
        'logic': 'No. of defects resolved for the selected period / (No. of defects resolved + Overall Open Defects)',
    }


def calculate_status_on_time_action_rate(status_history_issues, target_statuses, working_days=3):
    """
    Calculate on-time action rate for status transitions.
    
    Args:
        status_history_issues: List of issues with status history
        target_statuses: Target statuses to track transitions
        working_days: Working days threshold (default: 3)
    
    Returns:
        dict: On-time action rate KPI
    """
    # Placeholder implementation - actual logic would extract status change
    # timestamps from issue changelog and calculate working day differences
    total_transitions = 0
    on_time_transitions = 0
    
    # This is a simplified placeholder
    percentage_value = round((on_time_transitions / total_transitions) * 100) if total_transitions else 0
    
    return {
        'percentage': f'{percentage_value}%',
        'numerator': on_time_transitions,
        'denominator': total_transitions,
        'logic': f'Defects transitioned within {working_days} working days / Total transitions',
    }
