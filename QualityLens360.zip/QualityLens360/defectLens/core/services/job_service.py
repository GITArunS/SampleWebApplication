"""Background job coordination for the Flask UI."""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime
from pathlib import Path
import hashlib
import logging
import shutil
import threading
import traceback
import uuid

import openpyxl

from defectLens.core.clients.jira_client import JiraClient
from defectLens.config import Settings
from defectLens.core.models.job import JobRecord
from defectLens.core.services.ai_summary_service import generate_prompt_file_insights
from defectLens.core.services.analysis_service import run_analysis_workbook

LOGGER = logging.getLogger(__name__)


class JobStore:
    """Thread-safe in-memory job store."""

    def __init__(self) -> None:
        self._jobs: dict[str, JobRecord] = {}
        self._lock = threading.RLock()

    def create_job(self) -> str:
        job_id = str(uuid.uuid4())
        with self._lock:
            self._jobs[job_id] = JobRecord()
        return job_id

    def exists(self, job_id: str) -> bool:
        with self._lock:
            return job_id in self._jobs

    def get_snapshot(self, job_id: str) -> JobRecord | None:
        with self._lock:
            job = self._jobs.get(job_id)
            return deepcopy(job) if job is not None else None

    def update(self, job_id: str, **fields) -> None:
        with self._lock:
            job = self._jobs[job_id]
            for key, value in fields.items():
                setattr(job, key, value)

    def append_log(self, job_id: str, message: str) -> None:
        with self._lock:
            job = self._jobs[job_id]
            job.log.append(message)
            job.log = job.log[-500:]

    def set_progress(self, job_id: str, progress: float, message: str) -> None:
        bounded = max(0.0, min(100.0, float(progress)))
        self.update(job_id, progress=bounded, message=message)

    def get_log_slice(self, job_id: str, since: int) -> tuple[list[str], int] | None:
        with self._lock:
            job = self._jobs.get(job_id)
            if job is None:
                return None
            return deepcopy(job.log[since:]), len(job.log)


class AnalysisJobService:
    """Start, monitor, and enrich workbook analysis jobs."""

    def __init__(self, settings: Settings, store: JobStore):
        self.settings = settings
        self.store = store

    def create_job(self) -> str:
        return self.store.create_job()

    def start_file_job(self, job_id: str, username: str, password: str, input_path: Path) -> None:
        self.store.append_log(job_id, f"Job created: {job_id}")
        self.store.set_progress(job_id, 0, "Queued...")
        worker = threading.Thread(
            target=self._run_analysis_job,
            args=(job_id, username, password, input_path),
            daemon=True,
        )
        worker.start()

    def start_jql_job(self, job_id: str, username: str, password: str, jql: str) -> None:
        self.store.append_log(job_id, f"JQL job created: {job_id}")
        self.store.set_progress(job_id, 0, "Queued...")
        self.store.update(job_id, jql=jql)
        worker = threading.Thread(
            target=self._run_analysis_job_jql,
            args=(job_id, username, password, jql),
            daemon=True,
        )
        worker.start()

    def current_prompt_signature(self) -> str:
        return self.build_ai_prompt_signature(self.load_ai_prompt_template())

    def load_ai_prompt_template(self) -> str:
        try:
            text = self.settings.prompt_file.read_text(encoding="utf-8").strip()
            if text:
                return text
        except OSError:
            LOGGER.exception("Failed to read AI prompt template from %s", self.settings.prompt_file)
        return "Summarize the completed Defect Lens analysis for an executive audience in plain text."

    @staticmethod
    def build_ai_prompt_signature(prompt_text: str) -> str:
        return hashlib.sha256((prompt_text or "").encode("utf-8")).hexdigest()

    def should_refresh_ai_summary(self, job: JobRecord, current_prompt_signature: str) -> bool:
        if job.status != "completed":
            return False
        if not job.ai:
            return True
        if job.aiPromptSignature != current_prompt_signature:
            return True
        return "## Section Headings" in job.ai or "Section Headings 1" in job.ai

    def populate_ai_summary(self, job_id: str) -> dict[str, str]:
        job = self.store.get_snapshot(job_id)
        if job is None:
            raise KeyError(job_id)
        if job.status != "completed":
            raise RuntimeError("AI insights are available only after the run completes.")

        prompt_template = self.load_ai_prompt_template()
        insight_text = generate_prompt_file_insights(
            prompt_template=prompt_template,
            summary=dict(job.summary or {}),
            okrs=dict(job.okrs or {}),
            top_contrib_rows=[dict(row) for row in job.topContrib],
            mtti_rows=[dict(row) for row in job.mttiContrib],
            mttf_rows=[dict(row) for row in job.mttfContrib],
            mttr_rows=[dict(row) for row in job.mttrContrib],
        )
        prompt_signature = self.build_ai_prompt_signature(prompt_template)
        self.store.update(
            job_id,
            ai=insight_text,
            aiTitle="AI Insights",
            aiPromptSignature=prompt_signature,
        )
        self.store.append_log(job_id, "AI assisted summary generated ✅")
        return {"title": "AI Insights", "text": insight_text}

    def _create_temp_excel_from_keys(self, keys: list[str]) -> Path:
        workbook = openpyxl.Workbook()
        worksheet = workbook.active
        worksheet.title = self.settings.sheet_name
        worksheet.cell(1, 1).value = "CDEX#"
        for row_index, key in enumerate(keys, start=2):
            worksheet.cell(row_index, 1).value = str(key)
        temp_path = self.settings.upload_dir / f"jql_{uuid.uuid4()}.xlsx"
        workbook.save(str(temp_path))
        return temp_path

    def _run_analysis_job(self, job_id: str, username: str, password: str, input_path: Path) -> None:
        try:
            self.store.update(job_id, status="running")
            artifacts = run_analysis_workbook(
                input_path=input_path,
                username=username,
                password=password,
                settings=self.settings,
                progress_callback=lambda progress, message: self.store.set_progress(job_id, progress, message),
                log_callback=lambda message: self.store.append_log(job_id, message),
            )

            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_filename = f"DefectLens_{timestamp}.xlsx"
            output_path = self.settings.upload_dir / output_filename
            shutil.copy2(str(input_path), str(output_path))

            self.store.update(
                job_id,
                status="completed",
                progress=100.0,
                message="✅ Completed",
                okrs=artifacts.okrs,
                summary=artifacts.summary,
                topContrib=artifacts.top_contrib_rows,
                topContribChart=artifacts.top_contrib_chart,
                mttrContrib=artifacts.mttr_contrib_rows,
                mttrContribChart=artifacts.mttr_contrib_chart,
                mttiContrib=artifacts.mtti_contrib_rows,
                mttiContribChart=artifacts.mtti_contrib_chart,
                mttfContrib=artifacts.mttf_contrib_rows,
                mttfContribChart=artifacts.mttf_contrib_chart,
                output_path=str(output_path),
                download_name=output_filename,
            )
        except Exception as exc:
            LOGGER.exception("Analysis job %s failed", job_id)
            self.store.update(
                job_id,
                status="failed",
                message=str(exc),
                error=traceback.format_exc(),
            )
            self.store.append_log(job_id, f"Run failed ❌ : {exc}")

    def _run_analysis_job_jql(self, job_id: str, username: str, password: str, jql: str) -> None:
        try:
            self.store.update(job_id, status="running")
            self.store.set_progress(job_id, 1, "Authenticating to Jira...")
            self.store.append_log(job_id, f"JQL: {jql}")
            jira = JiraClient(username, password, self.settings)
            self.store.set_progress(job_id, 3, "Running JQL search...")
            keys = jira.search_issues_jql(jql)
            if not keys:
                self.store.update(job_id, status="failed", message="No issues found for the given JQL query.")
                self.store.append_log(job_id, "❌ No issues returned by JQL.")
                return

            self.store.append_log(job_id, f"JQL returned {len(keys)} issue(s).")
            self.store.set_progress(job_id, 5, f"Found {len(keys)} CDEXes — building workbook...")
            temp_path = self._create_temp_excel_from_keys(keys)
            self.store.append_log(job_id, f"Workbook ready ({temp_path.name}). Starting analysis...")
            self._run_analysis_job(job_id, username, password, temp_path)
        except Exception as exc:
            LOGGER.exception("JQL analysis job %s failed", job_id)
            self.store.update(
                job_id,
                status="failed",
                message=str(exc),
                error=traceback.format_exc(),
            )
            self.store.append_log(job_id, f"JQL run failed ❌: {exc}")
