from flask import render_template

from shared.shared_config import JIRA_USER


class LearningFeature:
    def __init__(self, get_session_credentials):
        self.get_session_credentials = get_session_credentials

    def register(self, app, login_required):
        @app.route('/advanced-reporting/acc-prod/defect-management-framework')
        @login_required
        def acc_prod_defect_management_framework_page():
            credentials = self.get_session_credentials() or {}
            return render_template(
                'advanced_reporting_acc_prod_defect_management_framework.html',
                page_title='Quality Lens 360 | Defect Management & Framework',
                jira_user=credentials.get('username', JIRA_USER),
            )

        @app.route('/advanced-reporting/acc-prod/triaging-tools')
        @login_required
        def acc_prod_triaging_tools_page():
            credentials = self.get_session_credentials() or {}
            return render_template(
                'advanced_reporting_acc_prod_triaging_tools.html',
                page_title='Quality Lens 360 | Triaging Tools',
                jira_user=credentials.get('username', JIRA_USER),
            )

        @app.route('/advanced-reporting/acc-prod/functional-overview')
        @login_required
        def acc_prod_functional_overview_page():
            credentials = self.get_session_credentials() or {}
            return render_template(
                'advanced_reporting_acc_prod_functional_overview.html',
                page_title='Quality Lens 360 | Functional Overview',
                jira_user=credentials.get('username', JIRA_USER),
            )

        @app.route('/advanced-reporting/acc-prod/ai-tap')
        @login_required
        def acc_prod_ai_tap_page():
            credentials = self.get_session_credentials() or {}
            return render_template(
                'advanced_reporting_acc_prod_ai_tap.html',
                page_title='Quality Lens 360 | AI-Tap',
                jira_user=credentials.get('username', JIRA_USER),
            )
