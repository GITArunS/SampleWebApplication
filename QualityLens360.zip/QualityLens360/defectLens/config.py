"""Application configuration."""

from __future__ import annotations

from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
import os


def _csv_to_tuple(value: str | None, default: tuple[str, ...]) -> tuple[str, ...]:
    if not value:
        return default
    parts = [part.strip() for part in value.split(",") if part.strip()]
    return tuple(parts) if parts else default


def _env(name: str, default: str = "") -> str:
    """Read DEFECT_LENS_* vars with fallback to legacy names."""

    return os.getenv(
        f"DEFECT_LENS_{name}",
        os.getenv(f"HOPFINDER_{name}", os.getenv(f"defect_lens_{name}", default)),
    )


@dataclass(frozen=True)
class Settings:
    """Typed settings loaded from environment variables."""

    package_name: str
    base_dir: Path
    package_dir: Path
    template_dir: Path
    static_dir: Path
    upload_dir: Path
    prompt_file: Path
    jira_url: str
    sheet_name: str
    field_to_check: str
    excluded_values: tuple[str, ...]
    severity_field_id: str
    flask_host: str
    flask_port: int
    flask_debug: bool
    external_host: str
    preferred_scheme: str
    trust_proxy: bool
    max_content_length: int
    log_level: str
    log_format: str


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    """Return cached application settings."""

    package_dir = Path(__file__).resolve().parent
    base_dir = package_dir.parent
    prompt_override = _env("PROMPT_FILE", "").strip()
    prompt_file = Path(prompt_override) if prompt_override else base_dir / "prompt.md"
    if not prompt_file.exists():
        prompt_file = package_dir / "prompt.md"

    upload_dir = Path(_env("UPLOAD_DIR", str(base_dir / "_uploads")))
    upload_dir.mkdir(parents=True, exist_ok=True)

    return Settings(
        package_name="defect_lens",
        base_dir=base_dir,
        package_dir=package_dir,
        template_dir=package_dir / "ui" / "templates",
        static_dir=package_dir / "ui" / "static",
        upload_dir=upload_dir,
        prompt_file=prompt_file,
        jira_url=_env("JIRA_URL", "https://itrack.web.att.com/rest/api/2/issue/"),
        sheet_name=_env("SHEET_NAME", "CDEX"),
        field_to_check=_env("FIELD_TO_CHECK", "Application Fixed In"),
        excluded_values=_csv_to_tuple(
            _env("EXCLUDED_VALUES"),
            ("CQE", "TBD", "Not An Application"),
        ),
        severity_field_id=_env("SEVERITY_FIELD_ID", "customfield_10552"),
        flask_host=_env("HOST", "127.0.0.1"),
        flask_port=int(_env("PORT", "5000")),
        flask_debug=_env("DEBUG", "false").strip().lower() == "true",
        external_host=_env("EXTERNAL_HOST", "").strip(),
        preferred_scheme=_env("PREFERRED_SCHEME", "https").strip().lower() or "https",
        trust_proxy=_env("TRUST_PROXY", "true").strip().lower() == "true",
        max_content_length=int(_env("MAX_CONTENT_LENGTH", str(50 * 1024 * 1024))),
        log_level=_env("LOG_LEVEL", "INFO"),
        log_format=_env(
            "LOG_FORMAT",
            "%(asctime)s | %(levelname)s | %(name)s | %(message)s",
        ),
    )
