"""Production WSGI server entry point."""

from __future__ import annotations

from waitress import serve

from defectLens.app import create_app
from defectLens.config import get_settings


def main() -> None:
    """Run the Flask app with Waitress for production use."""

    settings = get_settings()
    app = create_app(settings)
    serve(app, host=settings.flask_host, port=settings.flask_port)