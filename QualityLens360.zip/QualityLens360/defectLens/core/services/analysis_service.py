"""Shared analysis workflow for workbook processing."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import timedelta
from pathlib import Path
import logging
import time

from defectLens.core.analytics.cdex_processor import (
    compute_final_hop_adjustment,
    count_field_changes,
    count_unique_hops,
    parse_field_changes,
)
from defectLens.core.analytics.portfolio import CDEXPortfolioAnalyzer
from defectLens.core.analytics.time_metrics import (
    compute_mttr_minutes,
    compute_mttf_minutes,
    compute_mtti_minutes,
    find_last_valid_app_fixed_in,
    find_status_change_ts,
    format_created_like_itrack_ui,
    format_ts_like_column_c,
    get_created_ts,
    get_resolved_ts,
)
from defectLens.core.clients.jira_client import JiraClient
from defectLens.config import Settings, get_settings
from defectLens.core.reporting.excel_service import ExcelService
from defectLens.core.reporting.summary_workbook import (
    apply_cdex_table_borders_and_alignment,
    build_mttr_contributors_payload,
    build_mtti_contributors_payload,
    build_mttf_contributors_payload,
    build_top_contributors_payload,
    compute_okrs_from_cdex_sheet,
    ensure_summary_view_and_formulas,
    format_cdex_sheet,
    write_mttr_delay_drivers_to_summary,
    write_mtti_delay_drivers_to_summary,
    write_mttf_delay_drivers_to_summary,
    write_okrs_to_summary,
    write_summary_tab,
)

LOGGER = logging.getLogger(__name__)
ProgressCallback = Callable[[float, str], None]
LogCallback = Callable[[str], None]
SEVERITY_LABELS = ("Sev 1", "Sev 2", "Sev 3", "Sev 4")


@dataclass
class AnalysisArtifacts:
    """Result object returned after workbook processing finishes."""

    okrs: dict
    summary: dict
    top_contrib_rows: list[dict]
    top_contrib_chart: dict
    mtti_contrib_rows: list[dict]
    mtti_contrib_chart: dict
    mttf_contrib_rows: list[dict]
    mttf_contrib_chart: dict
    mttr_contrib_rows: list[dict]
    mttr_contrib_chart: dict


def format_duration(minutes: float) -> str:
    """Return a human-readable duration string."""

    if minutes < 60:
        return f"{minutes:.1f} mins"
    if minutes < 1440:
        return f"{minutes / 60:.1f} hrs"
    return f"{minutes / 1440:.1f} days"


def normalize_severity_bucket(severity: str) -> str | None:
    """Normalize severity names into Sev 1-4 buckets for UI drill-downs."""

    normalized = (severity or "").strip().lower()
    if not normalized:
        return None

    for number in ("1", "2", "3", "4"):
        if f"sev-{number}" in normalized or f"sev {number}" in normalized or f"severity {number}" in normalized:
            return f"Sev {number}"
    return None


def _empty_severity_aggregates() -> dict[str, dict[str, float]]:
    return {label: {"sum": 0.0, "count": 0.0} for label in SEVERITY_LABELS}


def _format_severity_breakdown(
    severity_totals: dict[str, int],
    severity_no_hops: dict[str, int],
    severity_mtti: dict[str, dict[str, float]],
    severity_mttf: dict[str, dict[str, float]],
    severity_mttr: dict[str, dict[str, float]],
) -> dict[str, dict[str, str]]:
    def format_average(metric_map: dict[str, dict[str, float]]) -> dict[str, str]:
        values: dict[str, str] = {}
        for label in SEVERITY_LABELS:
            count = int(metric_map[label]["count"] or 0)
            values[label] = format_duration(metric_map[label]["sum"] / count) if count else "TBD"
        return values

    ftra_values: dict[str, str] = {}
    for label in SEVERITY_LABELS:
        total = int(severity_totals[label] or 0)
        if total:
            ftra_values[label] = f"{(severity_no_hops[label] / total) * 100.0:.1f}%"
        else:
            ftra_values[label] = "TBD"

    return {
        "ftra": ftra_values,
        "mtti": format_average(severity_mtti),
        "mttf": format_average(severity_mttf),
        "mttr": format_average(severity_mttr),
    }


def extract_severity(issue_json: dict, settings: Settings | None = None) -> str:
    """Extract the configured severity field from the issue payload."""

    resolved = settings if settings is not None else get_settings()
    try:
        field = issue_json.get("fields", {}).get(resolved.severity_field_id)
        if isinstance(field, dict):
            return field.get("value", "Sev-3")
        if isinstance(field, str):
            return field
    except Exception:
        LOGGER.exception("Failed to extract severity")
    return "Sev-3"


def severity_to_sla_days(severity: str) -> float:
    """Map severity to the SLA used for workbook highlighting."""

    normalized = (severity or "").strip().lower()
    if "severity 1" in normalized or "sev-1" in normalized or "sev 1" in normalized:
        return 1.0
    if "severity 2" in normalized or "sev-2" in normalized or "sev 2" in normalized:
        return 3.0
    if "severity 3" in normalized or "sev-3" in normalized or "sev 3" in normalized:
        return 7.0
    return 7.0


def minutes_to_days(minutes: float) -> float:
    """Convert minutes to day units."""

    return float(minutes) / 1440.0


def build_timing_rich_runs(hold_summary: dict[str, float], sla_days: float) -> list[tuple[str, bool]]:
    """Return workbook rich-text runs, coloring only SLA breaches red."""

    runs: list[tuple[str, bool]] = []
    first = True
    if not hold_summary:
        return [("", False)]

    for app_name, minutes in hold_summary.items():
        if minutes is None:
            continue
        if not first:
            runs.append((", ", False))
        first = False
        runs.append((f"{app_name}: ", False))
        duration = format_duration(float(minutes))
        runs.append((duration, minutes_to_days(float(minutes)) > sla_days))

    return runs if runs else [("", False)]


def accumulate_app_minutes(app_totals: dict[str, float], hold_summary: dict[str, float]) -> None:
    """Roll up per-application hold minutes across all processed rows."""

    if not hold_summary:
        return
    for app_name, minutes in hold_summary.items():
        if minutes is None:
            continue
        app_totals[app_name] = app_totals.get(app_name, 0.0) + float(minutes)


def _emit_progress(callback: ProgressCallback | None, progress: float, message: str) -> None:
    if callback is not None:
        callback(progress, message)


def _emit_log(callback: LogCallback | None, message: str) -> None:
    if callback is not None:
        callback(message)


def run_analysis_workbook(
    input_path: Path,
    username: str,
    password: str,
    settings: Settings | None = None,
    progress_callback: ProgressCallback | None = None,
    log_callback: LogCallback | None = None,
) -> AnalysisArtifacts:
    """Run the full web analysis pipeline against a workbook."""

    resolved = settings if settings is not None else get_settings()
    start = time.perf_counter()
    processed = 0
    skipped_blank = 0
    skipped_no_data = 0
    mttr_minutes_values: list[float] = []
    mtti_minutes_values: list[float] = []
    mttf_minutes_values: list[float] = []
    team_mttr_minutes: dict[str, float] = {}
    team_mtti_minutes: dict[str, float] = {}
    team_mttf_minutes: dict[str, float] = {}
    severity_totals = {label: 0 for label in SEVERITY_LABELS}
    severity_no_hops = {label: 0 for label in SEVERITY_LABELS}
    severity_mtti = _empty_severity_aggregates()
    severity_mttf = _empty_severity_aggregates()
    severity_mttr = _empty_severity_aggregates()

    _emit_progress(progress_callback, 2, "Authenticating to Jira...")
    _emit_log(log_callback, "Run started...")

    jira = JiraClient(username, password, resolved)
    excel = ExcelService(str(input_path), sheet_name=resolved.sheet_name)
    portfolio = CDEXPortfolioAnalyzer()

    format_cdex_sheet(excel, resolved.sheet_name)
    ws_cdex = excel.wb[resolved.sheet_name]
    last_row = ws_cdex.max_row
    total = max(1, last_row - 1)
    app_totals_minutes: dict[str, float] = {}

    for index, row in enumerate(range(2, last_row + 1), start=1):
        cdex_id = excel.get_cell(row, 1)
        if not cdex_id:
            skipped_blank += 1
            continue

        issue_data = jira.get_issue_changelog(str(cdex_id))
        if not issue_data:
            skipped_no_data += 1
            continue

        severity = extract_severity(issue_data, resolved)
        severity_bucket = normalize_severity_bucket(severity)
        details = parse_field_changes(issue_data, resolved.field_to_check)
        hops = count_field_changes(issue_data, resolved.field_to_check)
        unique_apps = count_unique_hops(details, resolved.excluded_values)
        final_adjustment = compute_final_hop_adjustment(details, unique_apps)
        if final_adjustment is None:
            final_adjustment = 0
        if severity_bucket:
            severity_totals[severity_bucket] += 1
            if float(final_adjustment) == 0.0:
                severity_no_hops[severity_bucket] += 1

        hold_summary = portfolio.process_changelog(details)
        runs = build_timing_rich_runs(hold_summary, severity_to_sla_days(severity))
        accumulate_app_minutes(app_totals_minutes, hold_summary)

        excel.set_cell(row, 1, str(cdex_id))
        excel.set_cell(row, 2, severity)
        excel.set_cell(row, 3, details)
        excel.set_cell(row, 4, hops)
        excel.set_cell(row, 5, unique_apps)
        excel.set_cell(row, 6, final_adjustment)
        excel.set_rich_text(row, 7, runs)

        last_team, last_app_ts = find_last_valid_app_fixed_in(issue_data, resolved)
        if last_app_ts is None:
            last_app_ts = get_created_ts(issue_data)

        excel.set_cell(row, 8, last_team or "")
        excel.set_cell(row, 9, format_ts_like_column_c(get_created_ts(issue_data)))
        excel.set_cell(row, 10, format_ts_like_column_c(last_app_ts))

        dev_complete_ts = find_status_change_ts(issue_data, "Dev Complete")
        if not dev_complete_ts:
            dev_complete_ts = find_status_change_ts(issue_data, "Retest")
        excel.set_cell(row, 11, format_ts_like_column_c(dev_complete_ts))

        resolved_ts = get_resolved_ts(issue_data)
        excel.set_cell(row, 12, format_ts_like_column_c(resolved_ts))

        mtti_minutes = compute_mtti_minutes(issue_data, resolved)
        if mtti_minutes is not None:
            mtti_minutes_values.append(mtti_minutes)
            excel.set_cell(row, 13, format_duration(mtti_minutes))
            if severity_bucket:
                severity_mtti[severity_bucket]["sum"] += float(mtti_minutes)
                severity_mtti[severity_bucket]["count"] += 1
            if last_team:
                team_mtti_minutes[last_team] = team_mtti_minutes.get(last_team, 0.0) + float(mtti_minutes)
        else:
            excel.set_cell(row, 13, "")

        mttf_minutes = compute_mttf_minutes(issue_data, resolved)
        if mttf_minutes is not None:
            mttf_minutes_values.append(mttf_minutes)
            excel.set_cell(row, 14, format_duration(mttf_minutes))
            if severity_bucket:
                severity_mttf[severity_bucket]["sum"] += float(mttf_minutes)
                severity_mttf[severity_bucket]["count"] += 1
            if last_team:
                team_mttf_minutes[last_team] = team_mttf_minutes.get(last_team, 0.0) + float(mttf_minutes)
        else:
            excel.set_cell(row, 14, "")

        mttr_minutes = compute_mttr_minutes(issue_data)
        if mttr_minutes is not None:
            mttr_minutes_values.append(mttr_minutes)
            excel.set_cell(row, 15, format_duration(mttr_minutes))
            if severity_bucket:
                severity_mttr[severity_bucket]["sum"] += float(mttr_minutes)
                severity_mttr[severity_bucket]["count"] += 1
            if last_team:
                team_mttr_minutes[last_team] = team_mttr_minutes.get(last_team, 0.0) + float(mttr_minutes)
        else:
            excel.set_cell(row, 15, "")

        processed += 1
        _emit_progress(progress_callback, (index / total) * 88.0, f"Processing {cdex_id} ({index}/{total})")
        if processed % 25 == 0:
            _emit_log(log_callback, f"Processed {processed} CDEXes so far...")

    apply_cdex_table_borders_and_alignment(excel, resolved.sheet_name)
    _emit_progress(progress_callback, 92, "Updating Summary tab...")
    ensure_summary_view_and_formulas(excel)

    okrs = compute_okrs_from_cdex_sheet(ws_cdex)
    okrs["mttr"] = format_duration(sum(mttr_minutes_values) / len(mttr_minutes_values)) if mttr_minutes_values else "TBD"
    okrs["mtti"] = format_duration(sum(mtti_minutes_values) / len(mtti_minutes_values)) if mtti_minutes_values else "TBD"
    okrs["mttf"] = format_duration(sum(mttf_minutes_values) / len(mttf_minutes_values)) if mttf_minutes_values else "TBD"
    okrs["severityBreakdown"] = _format_severity_breakdown(
        severity_totals,
        severity_no_hops,
        severity_mtti,
        severity_mttf,
        severity_mttr,
    )
    write_okrs_to_summary(excel, okrs)

    top_payload = build_top_contributors_payload(app_totals_minutes, top_n=5)
    mttr_payload = build_mttr_contributors_payload(team_mttr_minutes, top_n=5)
    mtti_payload = build_mtti_contributors_payload(team_mtti_minutes, top_n=5)
    mttf_payload = build_mttf_contributors_payload(team_mttf_minutes, top_n=5)

    _emit_progress(progress_callback, 95, "Refreshing table/chart...")
    write_summary_tab(excel, app_totals_minutes, start_row=15, start_col=1, top_n_chart=5)
    write_mtti_delay_drivers_to_summary(excel, team_mtti_minutes, top_n=5)
    write_mttf_delay_drivers_to_summary(excel, team_mttf_minutes, top_n=5)
    write_mttr_delay_drivers_to_summary(excel, team_mttr_minutes, top_n=5)
    excel.save()

    elapsed = time.perf_counter() - start
    elapsed_hms = str(timedelta(seconds=int(elapsed)))
    summary = {
        "processed": processed,
        "skipped_blank": skipped_blank,
        "skipped_no_data": skipped_no_data,
        "elapsed_seconds": round(elapsed, 2),
        "elapsed_hms": elapsed_hms,
    }

    _emit_log(log_callback, "Run completed ✅")
    _emit_log(log_callback, f"CDEXes processed: {processed}")
    _emit_log(log_callback, f"MTTR samples used: {len(mttr_minutes_values)}")
    _emit_log(log_callback, f"MTTI samples used: {len(mtti_minutes_values)}")
    _emit_log(log_callback, f"MTTF samples used: {len(mttf_minutes_values)}")
    _emit_log(log_callback, f"Time taken: {elapsed:.2f}s ({elapsed_hms})")

    return AnalysisArtifacts(
        okrs=okrs,
        summary=summary,
        top_contrib_rows=top_payload.get("rows", []),
        top_contrib_chart=top_payload.get("chart", {}),
        mttr_contrib_rows=mttr_payload.get("rows", []),
        mttr_contrib_chart=mttr_payload.get("chart", {}),
        mtti_contrib_rows=mtti_payload.get("rows", []),
        mtti_contrib_chart=mtti_payload.get("chart", {}),
        mttf_contrib_rows=mttf_payload.get("rows", []),
        mttf_contrib_chart=mttf_payload.get("chart", {}),
    )
