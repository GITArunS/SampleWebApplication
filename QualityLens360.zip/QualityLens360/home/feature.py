from flask import redirect, render_template, url_for

from home.config import DASHBOARD_TILES
from shared.shared_config import JIRA_USER


class HomeFeature:
    def __init__(self, get_session_credentials, get_hub_metrics_summary, record_dashboard_tile_click):
        self.get_session_credentials = get_session_credentials
        self.get_hub_metrics_summary = get_hub_metrics_summary
        self.record_dashboard_tile_click = record_dashboard_tile_click

    @staticmethod
    def build_dashboard_tiles():
        return DASHBOARD_TILES

    @staticmethod
    def get_dashboard_tile(tile_id):
        return next((tile for tile in DASHBOARD_TILES if tile['id'] == tile_id), None)

    def register(self, app, login_required):
        @app.route('/home')
        @login_required
        def home():
            credentials = self.get_session_credentials() or {}
            hub_metrics = self.get_hub_metrics_summary()
            return render_template(
                'home_dashboard.html',
                page_title='Quality Lens 360',
                dashboard_tiles=self.build_dashboard_tiles(),
                hub_metrics=hub_metrics,
                jira_user=credentials.get('username', JIRA_USER),
            )

        @app.get('/home/tile/<tile_id>')
        @login_required
        def open_dashboard_tile(tile_id):
            tile = self.get_dashboard_tile(tile_id)
            if tile is None:
                return redirect(url_for('home'))

            self.record_dashboard_tile_click(tile_id)
            return redirect(url_for(tile['route']))
