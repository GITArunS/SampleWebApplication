from functools import wraps

from flask import redirect, url_for


class SessionCredentialStore:
    def get_session_credentials(self, session):
        username = session.get('jira_username')
        password = session.get('jira_password')
        if not username or not password:
            return None
        return {
            'username': username,
            'password': password,
        }

    def store_session_credentials(
        self, session, username, password, key_factory=None
    ):
        session['jira_username'] = username
        session['jira_password'] = password

    def clear_session_credentials(self, session):
        session.pop('jira_username', None)
        session.pop('jira_password', None)


def build_login_required(get_session_credentials):
    def login_required(view_function):
        @wraps(view_function)
        def wrapped_view(*args, **kwargs):
            if get_session_credentials() is None:
                return redirect(
                    url_for(
                        'login_page',
                        status='error',
                        message='Log in with your Jira/iTrack credentials to continue.',
                    )
                )
            return view_function(*args, **kwargs)

        return wrapped_view

    return login_required
