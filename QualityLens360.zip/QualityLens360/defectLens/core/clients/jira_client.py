"""Client for the Jira and iTrack APIs."""

from __future__ import annotations

import base64
import logging
import re

import requests

from defectLens.config import Settings, get_settings

LOGGER = logging.getLogger(__name__)


class JiraClient:
    """Minimal Jira REST client used by the analysis pipeline."""

    def __init__(self, username: str, password: str, settings: Settings | None = None):
        self.settings = settings if settings is not None else get_settings()
        auth = base64.b64encode(f"{username}:{password}".encode()).decode()
        self.headers = {
            "Authorization": f"Basic {auth}",
            "Accept": "application/json",
            "Content-Type": "application/json",
        }

    def get_issue_changelog(self, issue_id: str) -> dict | None:
        """Return the issue payload with changelog expansion."""

        url = f"{self.settings.jira_url}{issue_id}?expand=changelog"
        try:
            response = requests.get(url, headers=self.headers, timeout=30)
            response.raise_for_status()
        except requests.RequestException:
            LOGGER.exception("Failed to fetch changelog for %s", issue_id)
            return None
        return response.json()

    def search_issues_jql(self, jql: str) -> list[str]:
        """Return all issue keys that match a JQL query."""

        base_url = re.sub(r"/issue/?$", "", self.settings.jira_url.rstrip("/"))
        search_url = f"{base_url}/search"
        issue_keys: list[str] = []
        start_at = 0
        page_size = 100

        while True:
            params = {
                "jql": jql,
                "fields": "key",
                "maxResults": page_size,
                "startAt": start_at,
            }
            try:
                response = requests.get(search_url, headers=self.headers, params=params, timeout=60)
                response.raise_for_status()
            except requests.RequestException:
                LOGGER.exception("Failed to run JQL search")
                break

            payload = response.json()
            issues = payload.get("issues", [])
            if not issues:
                break

            for issue in issues:
                issue_key = issue.get("key") or ""
                if issue_key:
                    issue_keys.append(issue_key)

            total = int(payload.get("total", 0) or 0)
            start_at += len(issues)
            if start_at >= total:
                break

        return issue_keys
