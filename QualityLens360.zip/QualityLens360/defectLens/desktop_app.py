"""Desktop Tkinter entry point retained for compatibility."""

from __future__ import annotations

from datetime import timedelta
import threading
import time
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from defectLens.core.analytics.cdex_processor import (
    compute_final_hop_adjustment,
    count_field_changes,
    count_unique_hops,
    parse_field_changes,
)
from defectLens.core.analytics.portfolio import CDEXPortfolioAnalyzer
from defectLens.core.clients.jira_client import JiraClient
from defectLens.core.reporting.excel_service import ExcelService
from defectLens.core.reporting.summary_workbook import write_summary_tab
from defectLens.core.services.analysis_service import (
    accumulate_app_minutes,
    build_timing_rich_runs,
    extract_severity,
    severity_to_sla_days,
)


class CDEXApp(tk.Tk):
    """Legacy desktop UI for running the workbook analysis locally."""

    def __init__(self):
        super().__init__()
        self.title("Defect Hop & First Time Right Analyzer")
        self.geometry("1000x900")
        self.resizable(False, False)

        self.file_path = tk.StringVar()
        self.username = tk.StringVar()
        self.password = tk.StringVar()
        self.status = tk.StringVar(value="Ready")
        self._build_ui()

    def _build_ui(self) -> None:
        pad = {"padx": 10, "pady": 6}
        tk.Label(self, text="iTrack Username").pack(**pad)
        tk.Entry(self, textvariable=self.username, width=50).pack()
        tk.Label(self, text="iTrack Password").pack(**pad)
        tk.Entry(self, textvariable=self.password, show="*", width=50).pack()
        tk.Label(self, text="Excel File").pack(**pad)

        frame = tk.Frame(self)
        frame.pack()
        tk.Entry(frame, textvariable=self.file_path, width=50).pack(side=tk.LEFT)
        tk.Button(frame, text="Browse", command=self._browse).pack(side=tk.LEFT)

        tk.Button(
            self,
            text="Run Analysis",
            command=self._run,
            bg="#0078D4",
            fg="white",
            width=25,
        ).pack(pady=15)

        self.progress = ttk.Progressbar(self, orient="horizontal", length=620, mode="determinate")
        self.progress.pack(pady=10)
        tk.Label(self, textvariable=self.status, fg="green").pack(pady=5)

        tk.Label(self, text="AI Assisted Summary", font=("Segoe UI", 10, "bold")).pack(pady=(10, 0))
        self.ai_text = tk.Text(self, height=12, width=100, wrap="word", state="disabled", bg="#F7F7F7")
        self.ai_text.pack(padx=10, pady=5)
        tk.Label(self, text="Run Log", font=("Segoe UI", 10, "bold")).pack(pady=(10, 0))
        self.log_text = tk.Text(self, height=8, width=100, wrap="word", state="disabled", bg="#F7F7F7")
        self.log_text.pack(padx=10, pady=5)

    def _browse(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("Excel Files", "*.xlsx")])
        if path:
            self.file_path.set(path)

    def _run(self) -> None:
        if not self.file_path.get():
            messagebox.showerror("Error", "Please select an Excel file")
            return
        threading.Thread(target=self._process, daemon=True).start()

    def _update_progress(self, percent: float, text: str) -> None:
        self.after(0, lambda: (self.progress.configure(value=percent), self.status.set(text)))

    def _append_log(self, message: str) -> None:
        def update() -> None:
            self.log_text.configure(state="normal")
            self.log_text.insert("end", message + "\n")
            self.log_text.see("end")
            self.log_text.configure(state="disabled")

        self.after(0, update)

    def _clear_log(self) -> None:
        def update() -> None:
            self.log_text.configure(state="normal")
            self.log_text.delete("1.0", "end")
            self.log_text.configure(state="disabled")

        self.after(0, update)

    def _set_ai_text(self, text: str) -> None:
        def update() -> None:
            self.ai_text.configure(state="normal")
            self.ai_text.delete("1.0", "end")
            self.ai_text.insert("1.0", text)
            self.ai_text.configure(state="disabled")

        self.after(0, update)

    def _process(self) -> None:
        start_time = time.perf_counter()
        processed = 0
        skipped_blank = 0
        skipped_no_data = 0

        try:
            self._clear_log()
            self._append_log("Run started...")
            self._update_progress(0, "Authenticating...")

            jira = JiraClient(self.username.get(), self.password.get())
            excel = ExcelService(self.file_path.get())
            portfolio = CDEXPortfolioAnalyzer()
            last_row = excel.last_row()
            total = max(1, last_row - 1)
            app_totals_minutes: dict[str, float] = {}
            done = 0

            for row in range(2, last_row + 1):
                issue_id = excel.get_cell(row, 1)
                if not issue_id:
                    skipped_blank += 1
                    continue

                issue_data = jira.get_issue_changelog(str(issue_id))
                if not issue_data:
                    skipped_no_data += 1
                    continue

                severity = extract_severity(issue_data)
                details = parse_field_changes(issue_data)
                hops = count_field_changes(issue_data)
                unique_apps = count_unique_hops(details)
                final_adjustment = compute_final_hop_adjustment(details, unique_apps)

                excel.set_cell(row, 2, severity)
                excel.set_cell(row, 3, details)
                excel.set_cell(row, 4, hops)
                excel.set_cell(row, 5, unique_apps)
                excel.set_cell(row, 6, final_adjustment)

                hold_summary = portfolio.process_changelog(details)
                runs = build_timing_rich_runs(hold_summary, severity_to_sla_days(severity))
                excel.set_rich_text(row, 7, runs)
                accumulate_app_minutes(app_totals_minutes, hold_summary)

                processed += 1
                done += 1
                self._update_progress((done / total) * 100, f"Processing {issue_id}...")
                if processed % 25 == 0:
                    self._append_log(f"Processed {processed} CDEXes so far...")

            self._update_progress(98, "Refreshing Summary tab...")
            self._append_log("Writing Summary tab (table + Top 5 chart)...")
            write_summary_tab(excel, app_totals_minutes, start_row=15, start_col=1, top_n_chart=5)
            self._set_ai_text("")
            excel.save()

            elapsed = time.perf_counter() - start_time
            elapsed_str = str(timedelta(seconds=int(elapsed)))
            self._append_log("Run completed ✅")
            self._append_log(f"CDEXes considered (processed): {processed}")
            self._append_log(f"Skipped blank rows: {skipped_blank}")
            self._append_log(f"Skipped missing Jira data: {skipped_no_data}")
            self._append_log(f"Time taken: {elapsed:.2f} seconds ({elapsed_str})")
            self._update_progress(100, "✅ Completed")
            messagebox.showinfo(
                "Success",
                f"CDEX analysis completed.\n\nProcessed: {processed}\nTime taken: {elapsed:.2f} seconds",
            )
        except Exception as exc:
            elapsed = time.perf_counter() - start_time
            self._append_log(f"Run failed ❌ after {elapsed:.2f} seconds")
            self._append_log(f"Error: {exc}")
            messagebox.showerror("Error", str(exc))


def main() -> None:
    """Run the desktop application."""

    CDEXApp().mainloop()
