"""
Base JQL Queries Module for RAM

Contains all base JQL query definitions and helper functions for building
JQL queries grouped by application and use case.

This module serves as the master source for all foundational JQL queries
that are combined in different ways to create derived metrics.
"""

from ram.app_config import (
    RAM_RELEASE_CLAUSE_PATTERN,
    get_ram_application_definition,
)
from shared.shared_logic import IST_TIMEZONE


# ============================================================================
# JQL ESCAPING AND FORMATTING HELPERS
# ============================================================================

def escape_ram_jql_string(value):
    """
    Escape special characters in JQL string values.
    
    Args:
        value: String value to escape
    
    Returns:
        str: Escaped JQL string
    """
    return str(value).replace('\\', '\\\\').replace('"', '\\"').strip()


# ============================================================================
# BASE JQL BUILDERS BY APPLICATION
# ============================================================================

def is_acc_ram_application(application):
    """Check if application is ACC-Prod with pre-prod support."""
    application_definition = get_ram_application_definition(application)
    return bool(application_definition and application_definition.get('preprod_base_jql'))


def is_ram_display_only_application(application):
    """Check if application is display-only (no KPI logic configured)."""
    from ram.app_config import RAM_DISPLAY_ONLY_APPLICATIONS
    return application in RAM_DISPLAY_ONLY_APPLICATIONS


def build_ram_base_jql(application):
    """
    Get the base JQL for an application.
    
    Args:
        application: Application name (e.g., 'ACC-Prod', 'ACES-IST')
    
    Returns:
        str: Base JQL query
    
    Raises:
        ValueError: If application is not configured
    """
    application_definition = get_ram_application_definition(application)
    if application_definition is None:
        from ram.app_config import RAM_APPLICATION_DEFINITIONS
        configured_applications = ', '.join(sorted(RAM_APPLICATION_DEFINITIONS))
        raise ValueError(f'RAM KPI logic is currently configured only for: {configured_applications}.')
    return application_definition['base_jql']


def build_preprod_defects_ram_jql(application, created_from, created_to):
    """
    Build JQL for pre-prod defects within date range.
    
    Args:
        application: Application name
        created_from: Start date (YYYY-MM-DD)
        created_to: End date (YYYY-MM-DD)
    
    Returns:
        str: Pre-prod defects JQL with date filtering
    """
    application_definition = get_ram_application_definition(application)
    preprod_base_jql = (application_definition or {}).get('preprod_base_jql')
    if not preprod_base_jql:
        raise ValueError(f'RAM pre-prod defect logic is not configured for {application}.')
    
    jql_parts = [preprod_base_jql]
    if created_from:
        jql_parts.append(f'created >= "{created_from}"')
    if created_to:
        jql_parts.append(f'created <= "{created_to}"')
    return ' and '.join(jql_parts)


# ============================================================================
# RELEASE FILTERING
# ============================================================================

def build_ram_release_clause(release_name):
    """
    Build release filter clause for JQL.
    
    Args:
        release_name: Release name to filter by
    
    Returns:
        str: JQL release clause
    """
    escaped_release_name = escape_ram_jql_string(release_name)
    return f'(cf[18971] in ("{escaped_release_name}") or cf[18972] in ("{escaped_release_name}"))'


def build_ram_release_scoped_jql(base_jql, release_name):
    """
    Apply release filtering to a base JQL query.
    
    Args:
        base_jql: Base JQL query
        release_name: Release name to filter by
    
    Returns:
        str: JQL with release filtering applied
    """
    if not release_name:
        return base_jql
    
    scoped_jql, replaced_count = RAM_RELEASE_CLAUSE_PATTERN.subn(
        build_ram_release_clause(release_name), base_jql, count=1
    )
    if replaced_count:
        return scoped_jql
    
    order_by_index = base_jql.casefold().find(' order by ')
    if order_by_index == -1:
        return f'({base_jql}) and {build_ram_release_clause(release_name)}'
    return f'{base_jql[:order_by_index]} and {build_ram_release_clause(release_name)}{base_jql[order_by_index:]}'


# ============================================================================
# DATE-BASED SCOPE FILTERING
# ============================================================================

def build_ram_scope_jql(base_jql, created_from, created_to, release_name=''):
    """
    Apply date and release filtering to a base JQL query.
    
    Args:
        base_jql: Base JQL query
        created_from: Start date (YYYY-MM-DD)
        created_to: End date (YYYY-MM-DD)
        release_name: Optional release name for filtering
    
    Returns:
        str: JQL with date and release scoping applied
    """
    scoped_jql = build_ram_release_scoped_jql(base_jql, release_name)
    jql_parts = [scoped_jql]
    if created_from:
        jql_parts.append(f'created >= "{created_from}"')
    if created_to:
        jql_parts.append(f'created <= "{created_to}"')
    return ' and '.join(jql_parts)


def build_resolved_period_ram_jql(base_jql, created_from, created_to):
    """
    Build JQL for issues resolved within a specific period.
    
    Args:
        base_jql: Base JQL query
        created_from: Period start date
        created_to: Period end date
    
    Returns:
        str: JQL filtering for resolved issues in date period
    """
    jql_parts = [f'({base_jql})']
    if created_from:
        jql_parts.append(f'resolved >= "{created_from}"')
    if created_to:
        jql_parts.append(f'resolved <= "{created_to}"')
    return ' and '.join(jql_parts)


# ============================================================================
# STATUS-BASED FILTERS
# ============================================================================

def build_open_ram_jql(base_jql):
    """Get open defects (not Accepted or Cancelled), without creation date filter."""
    import re
    jql = re.sub(r'and created >= ".*?"', '', base_jql)
    jql = re.sub(r'and created <= ".*?"', '', jql)
    jql = re.sub(r'created >= ".*?" and ', '', jql)
    jql = re.sub(r'created <= ".*?" and ', '', jql)
    jql = re.sub(r'created >= ".*?"', '', jql)
    jql = re.sub(r'created <= ".*?"', '', jql)
    jql = re.sub(r'\s+', ' ', jql).strip()
    return f'({jql}) and status not in (Accepted, Cancelled)'


def build_accepted_ram_jql(jql):
    """Filter for Accepted status defects."""
    return f'({jql}) and status in (Accepted)'


def build_triaged_ram_jql(jql):
    """Filter for triaged defects (not in To Do status)."""
    return f'({jql}) and status not in ("To Do")'


def build_cancelled_ram_jql(jql):
    """Filter for Cancelled status defects."""
    return f'({jql}) and status in (Cancelled)'


def build_active_defect_density_ram_jql(jql):
    """Filter for active defects (not Canceled or Cancelled)."""
    return f'({jql}) and status not in (Canceled, Cancelled)'


# ============================================================================
# LIFECYCLE AND TRANSITION FILTERS
# ============================================================================

def build_ram_status_history_jql(jql):
    """
    Build JQL for issues with specific lifecycle history transitions.
    
    Args:
        jql: Base JQL query
    
    Returns:
        str: JQL for issues with lifecycle transitions
    """
    return (
        f'({jql}) and ('
        'status in (Cancelled) '
        'or status changed to Retest '
        'or status changed to Returned '
        'or status changed to Rejected '
        'or status changed to "returned/rejected" '
        'or status changed to "Returned/Rejected"'
        ')'
    )


def build_ram_status_changed_during_jql(jql, target_statuses, created_from, created_to):
    """
    Build JQL for issues transitioning to specific statuses during a period.
    
    Args:
        jql: Base JQL query
        target_statuses: Target status values
        created_from: Period start date
        created_to: Period end date
    
    Returns:
        str: JQL for status transitions during date period
    
    Raises:
        ValueError: If no valid status clauses
    """
    status_clauses = [
        f'status changed to "{str(target_status).strip()}" DURING ("{created_from}", "{created_to}")'
        for target_status in target_statuses
        if str(target_status).strip()
    ]
    if not status_clauses:
        raise ValueError('At least one RAM lifecycle status is required.')
    return f'({jql}) and ({" or ".join(status_clauses)})'


def build_ram_status_changed_jql(jql, target_statuses):
    """
    Build JQL for issues that have transitioned to specific statuses.
    
    Args:
        jql: Base JQL query
        target_statuses: Target status values
    
    Returns:
        str: JQL for status transitions
    
    Raises:
        ValueError: If no valid status clauses
    """
    status_clauses = [
        f'status changed to "{str(target_status).strip()}"'
        for target_status in target_statuses
        if str(target_status).strip()
    ]
    if not status_clauses:
        raise ValueError('At least one RAM lifecycle status is required.')
    return f'({jql}) and ({" or ".join(status_clauses)})'


def build_ram_status_scope_jql(jql, target_statuses, created_from, created_to):
    """
    Build JQL for status transitions with optional date filtering.
    
    Args:
        jql: Base JQL query
        target_statuses: Target status values
        created_from: Optional period start date
        created_to: Optional period end date
    
    Returns:
        str: JQL for status transitions
    """
    if created_from and created_to:
        return build_ram_status_changed_during_jql(jql, target_statuses, created_from, created_to)
    return build_ram_status_changed_jql(jql, target_statuses)


# ============================================================================
# SPECIAL METRIC FILTERS
# ============================================================================

def build_production_defect_leakage_jql(jql):
    """
    Build JQL for production defect leakage metrics.
    
    Filters for valid defects found in production with AOTS tracking.
    """
    return (
        f'({jql}) and "AOTS Ticket #" is not EMPTY and "AOTS Ticket #" !~ None '
        'and "Phase Found In" in (Production) and "Defect Type" in ("Production Defect", Defect) and status != Cancelled'
    )


def build_resolved_burndown_ram_jql(base_jql, created_from, created_to):
    """
    Build JQL for defect burndown rate (resolved defects).
    
    Args:
        base_jql: Base JQL query
        created_from: Period start date
        created_to: Period end date
    
    Returns:
        str: JQL for resolved defects
    """
    # Remove any 'created >=' or 'created <=' clauses from base_jql for burndown
    import re
    jql = re.sub(r'and created >= ".*?"', '', base_jql)
    jql = re.sub(r'and created <= ".*?"', '', jql)
    jql = re.sub(r'created >= ".*?" and ', '', jql)
    jql = re.sub(r'created <= ".*?" and ', '', jql)
    jql = re.sub(r'created >= ".*?"', '', jql)
    jql = re.sub(r'created <= ".*?"', '', jql)
    jql = re.sub(r'\s+', ' ', jql).strip()
    if created_from or created_to:
        return build_resolved_period_ram_jql(jql, created_from, created_to)
    return f'({jql}) and resolved is not EMPTY'


# ============================================================================
# COMPLETE JQL BUILDERS (WITH ALL SCOPING)
# ============================================================================

def build_ram_jql(application, created_from, created_to, release_name=''):
    """
    Build complete JQL for an application with all scoping.
    
    Args:
        application: Application name
        created_from: Period start date
        created_to: Period end date
        release_name: Optional release name for filtering
    
    Returns:
        str: Complete JQL with all filters applied
    """
    base_jql = build_ram_base_jql(application)
    application_definition = get_ram_application_definition(application)
    
    if application_definition and application_definition.get('supports_release_filter'):
        return build_ram_scope_jql(base_jql, created_from, created_to, release_name)
    
    jql_parts = [base_jql]
    if created_from:
        jql_parts.append(f'created >= "{created_from}"')
    if created_to:
        jql_parts.append(f'created <= "{created_to}"')
    return ' and '.join(jql_parts)


# ============================================================================
# HISTORICAL QUERIES (PREVIOUS YEAR)
# ============================================================================

def shift_ram_period_to_last_year(created_from, created_to):
    """
    Shift a date range backward by one year for historical comparison.
    
    Args:
        created_from: Start date (YYYY-MM-DD format)
        created_to: End date (YYYY-MM-DD format)
    
    Returns:
        tuple: (prior_year_from, prior_year_to)
    """
    from datetime import datetime, timedelta
    
    if not created_from or not created_to:
        return None, None
    
    try:
        from_dt = datetime.strptime(created_from, '%Y-%m-%d')
        to_dt = datetime.strptime(created_to, '%Y-%m-%d')
        
        one_year = timedelta(days=365)
        prior_from = from_dt - one_year
        prior_to = to_dt - one_year
        
        return prior_from.strftime('%Y-%m-%d'), prior_to.strftime('%Y-%m-%d')
    except ValueError:
        return None, None


def build_triaged_last_year_ram_jql(application, created_from, created_to, release_name=''):
    """Build JQL for triaged defects from the prior year (for comparison)."""
    prior_year_from, prior_year_to = shift_ram_period_to_last_year(created_from, created_to)
    return build_triaged_ram_jql(build_ram_jql(application, prior_year_from, prior_year_to, release_name))


def get_last_calendar_year_bounds(reference_datetime=None):
    """
    Get calendar year bounds (Jan 1 - Dec 31) for the prior year.
    
    Args:
        reference_datetime: Reference datetime (default: current time)
    
    Returns:
        tuple: (start_date, end_date) in YYYY-MM-DD format
    """
    from datetime import datetime
    
    if reference_datetime is None:
        current_datetime = datetime.now(IST_TIMEZONE)
    elif getattr(reference_datetime, 'tzinfo', None) is None:
        current_datetime = reference_datetime
    else:
        current_datetime = reference_datetime.astimezone(IST_TIMEZONE)
    
    previous_year = current_datetime.year - 1
    return f'{previous_year}-01-01', f'{previous_year + 1}-01-01'


def build_triaged_last_calendar_year_ram_jql(application):
    """Build JQL for triaged defects from the prior calendar year."""
    created_from, created_before = get_last_calendar_year_bounds()
    base_jql = build_ram_base_jql(application)
    return f'({base_jql}) and created >= "{created_from}" and created < "{created_before}" and status not in ("To Do")'
