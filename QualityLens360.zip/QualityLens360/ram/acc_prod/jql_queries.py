"""
ACC-Prod — JQL Queries & Data Fetch

Application-specific JQL builders and data retrieval for ACC-Prod.
Owned by the ACC-Prod team. Changes here do not affect ACES-IST.
"""

from ram.app_config import get_ram_application_definition
from shared.shared_logic import (
    ASSIGNED_TO_TEAM_FIELD_KEY,
    ASSIGNED_TO_TEAM_FIELD_NAME,
    fetch_open_defects,
    get_select_field_transitions,
)
from ram.core.kpi_calculations import stringify_select_value


def build_production_defect_leakage_jql(jql):
    return (
        f'({jql}) and "AOTS Ticket #" is not EMPTY and "AOTS Ticket #" !~ None '
        'and "Phase Found In" in (Production) and "Defect Type" in ("Production Defect", Defect) and status != Cancelled'
    )


def build_preprod_defects_ram_jql(application, created_from, created_to):
    application_definition = get_ram_application_definition(application)
    preprod_base_jql = (application_definition or {}).get('preprod_base_jql')
    if not preprod_base_jql:
        raise ValueError(f'RAM pre-prod defect logic is not configured for {application}.')
    jql_parts = [preprod_base_jql]
    if created_from:
        jql_parts.append(f'created >= "{created_from}"')
    if created_to:
        jql_parts.append(f'created <= "{created_to}"')
    return ' and '.join(jql_parts)


def fetch_ram_cancelled_issues(jql, username, password, batch_size=50):
    issues = []
    start_at = 0
    while True:
        batch_issues = fetch_open_defects(
            jql=jql,
            max_results=batch_size,
            username=username,
            password=password,
            start_at=start_at,
            fields=['status', ASSIGNED_TO_TEAM_FIELD_KEY],
            expand='changelog',
        )
        if not batch_issues:
            break
        issues.extend(batch_issues)
        if len(batch_issues) < batch_size:
            break
        start_at += len(batch_issues)
    return issues


def issue_has_non_development_assigned_team_entire_lifecycle(issue):
    current_assigned_team = stringify_select_value((issue.get('fields') or {}).get(ASSIGNED_TO_TEAM_FIELD_KEY))
    assigned_team_values = []
    if current_assigned_team:
        assigned_team_values.append(current_assigned_team)
    for transition in get_select_field_transitions(issue, ASSIGNED_TO_TEAM_FIELD_KEY, ASSIGNED_TO_TEAM_FIELD_NAME):
        from_value = stringify_select_value(transition.get('from_value'))
        to_value = stringify_select_value(transition.get('to_value'))
        if from_value:
            assigned_team_values.append(from_value)
        if to_value:
            assigned_team_values.append(to_value)
    normalized_values = {value.casefold() for value in assigned_team_values if value}
    return 'development' not in normalized_values
