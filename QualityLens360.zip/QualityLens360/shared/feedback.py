from flask import request, session


def set_home_feedback(status, message):
    session['home_feedback'] = {
        'status': status,
        'message': message,
    }


def get_home_feedback():
    message = request.args.get('message')
    if message:
        return request.args.get('status'), message

    pending_feedback = session.pop('home_feedback', None)
    if pending_feedback is None:
        return None, None

    return pending_feedback.get('status'), pending_feedback.get('message')
