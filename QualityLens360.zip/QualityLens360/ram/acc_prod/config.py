"""
ACC-Prod Application Configuration

Contains all JQL queries, RAG targets, KPI tile IDs, and application-specific
metadata for the ACC-Prod application within the RAM module.
"""

ACC_PROD_APPLICATION = {
    'name': 'ACC-Prod',
    'base_jql': (
        'filter in (self-agent-filter) and "Defect Type" in ("Tracking Record", "Bug/Issue", Defect, "Production Defect") '
        'AND "Phase Found In" in (Production, "Production Validation Testing (PVT)", "Business Validation Testing", '
        '"First Field Availability (FFA)", "Controlled Introduction (CI)", "Production Readiness (PR)", '
        '"User Acceptance Test (UAT)", Pilot) and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
        'and filter in (Lynn_ask_ACC_app_filter)'
    ),
    'preprod_base_jql': (
        'project = "Central Defect EXchange" AND '
        '(("Defect Type" in (Defect, "Bug/Issue", "Tracking Record", "Production Defect")) or "Defect Type" is EMPTY) and '
        '"Phase Found In" in (Development, "Scrum Testing", "Integrated Scrum to Scrum (ST)", "Integrated Systems Test (IST)", '
        '"Performance/Load", "Enterprise Certification Testing (ECT)", "Smoke Testing", "Sanity/Shakeout") AND status != Cancelled AND '
        '("Application Found In" ~ CCSF:30685 OR "Application Found In" ~ CCMULE:30686 OR "Application Found In" ~ BWSFMC:30687 '
        'OR "Application Found In" ~ CCMule-CLM:33686 OR "Application Found In" ~ 36108 OR "Application Found In" ~ CCMule-SLS:33687 '
        'OR "Application Found In" ~ CCMule-SRV:33688 OR "Application Fixed In" ~ CCSF:30685 OR "Application Fixed In" ~ CCMULE:30686 '
        'OR "Application Fixed In" ~ BWSFMC:30687 OR "Application Fixed In" ~ CCMule-CLM:33686 OR "Application Fixed In" ~ 36108 '
        'OR "Application Fixed In" ~ CCMule-SLS:33687 OR "Application Fixed In" ~ CCMule-SRV:33688)'
    ),
    'tile_ids': [
        'production-defect-leakage',
        'triage-efficiency',
        'cancellation-rate',
        'cancellation-efficiency-by-triage',
        'defect-burndown-rate',
        'retest-defects-ontime-action-rate',
        'return-rejected-defects-ontime-action-rate',
        'triage-productivity-improvement',
    ],
    'rag_targets': {
        'production-defect-leakage': {'direction': 'max', 'threshold': 10, 'label': '<=10%'},
        'triage-efficiency': {'direction': 'min', 'threshold': 95, 'label': '>=95%'},
        'cancellation-rate': {'direction': 'max', 'threshold': 10, 'label': '<=10%'},
        'cancellation-efficiency-by-triage': {'direction': 'min', 'threshold': 50, 'label': '>=50%'},
        'defect-burndown-rate': {'direction': 'min', 'threshold': 80, 'label': '>=80%'},
        'retest-defects-ontime-action-rate': {'direction': 'min', 'threshold': 80, 'label': '>=80%'},
        'return-rejected-defects-ontime-action-rate': {'direction': 'min', 'threshold': 80, 'label': '>=80%'},
        'triage-productivity-improvement': {'direction': 'min', 'threshold': 10, 'label': '>=10%'},
    },
    'tile_overrides': {
        'production-defect-leakage': {'section': 'Defect Triage & Management Metrics'},
        'triage-efficiency': {'section': 'Defect Triage & Management Metrics'},
        'cancellation-rate': {'section': 'Defect Triage & Management Metrics'},
        'cancellation-efficiency-by-triage': {'section': 'Defect Triage & Management Metrics'},
        'defect-burndown-rate': {'section': 'Defect Triage & Management Metrics'},
        'retest-defects-ontime-action-rate': {'section': 'Defect Triage & Management Metrics'},
        'return-rejected-defects-ontime-action-rate': {'section': 'Defect Triage & Management Metrics'},
        'triage-productivity-improvement': {'section': 'Defect Triage & Management Metrics'},
    },
    'working_days': 3,
    'supports_release_filter': False,
}
