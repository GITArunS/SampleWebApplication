"""defect_lens package."""

from defectLens.app import create_app

__all__ = ["create_app"]
