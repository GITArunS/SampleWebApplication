"""
Zephyr Integration Module for RAM

Handles all Zephyr Test Management integration including:
- URL construction for Zephyr endpoints
- Authentication and request headers
- ZQL (Zephyr Query Language) execution
"""

import re
from urllib.parse import urlsplit, urlunsplit

import requests

from shared.shared_config import JIRA_URL
from shared.release_open_defects import (
    JIRA_REQUEST_TIMEOUT_SECONDS,
    build_basic_auth,
)


# ============================================================================
# ZEPHYR URL BUILDERS
# ============================================================================

def build_zephyr_execute_search_url():
    """Generate the URL for Zephyr ZQL executeSearch endpoint."""
    base_url = str(JIRA_URL or '').strip()
    if '/rest/' in base_url:
        base_url = base_url.split('/rest/', 1)[0]
    parsed_url = urlsplit(base_url)
    normalized_path = parsed_url.path.rstrip('/')
    return urlunsplit(parsed_url._replace(
        path=f'{normalized_path}/rest/zephyr/latest/zql/executeSearch/',
        query='',
        fragment=''
    ))


def build_zephyr_execution_navigator_url():
    """Generate the URL for Zephyr execution navigator."""
    base_url = str(JIRA_URL or '').strip()
    if '/rest/' in base_url:
        base_url = base_url.split('/rest/', 1)[0]
    parsed_url = urlsplit(base_url)
    normalized_path = parsed_url.path.rstrip('/')
    return urlunsplit(parsed_url._replace(
        path=f'{normalized_path}/secure/enav/',
        query='',
        fragment=''
    ))


# ============================================================================
# ZEPHYR AUTHENTICATION AND HEADERS
# ============================================================================

def fetch_zephyr_request_headers(session, username=None, password=None):
    """
    Fetch Zephyr authentication headers required for ZQL queries.
    
    Extracts encryption key information from the Zephyr navigator page
    and constructs headers for Zephyr API requests.
    
    Args:
        session: requests.Session object
        username: Jira username
        password: Jira API token or password
    
    Returns:
        dict: Headers including Zephyr encryption keys
    """
    response = session.get(
        build_zephyr_execution_navigator_url(),
        headers={
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        },
        auth=build_basic_auth(username=username, password=password),
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    response_text = response.text or ''
    
    field_match = re.search(r'var\s+zEncKeyFld\s*=\s*"([^"]+)"', response_text)
    value_match = re.search(r'var\s+zEncKeyVal\s*=\s*"([^"]+)"', response_text)
    
    headers = {
        'Accept': 'application/json, text/javascript, */*; q=0.01',
        'Content-Type': 'application/json',
        'Referer': build_zephyr_execution_navigator_url(),
        'X-Requested-With': 'XMLHttpRequest',
    }
    
    if field_match and value_match:
        headers[field_match.group(1).lower()] = value_match.group(1)
    
    return headers


# ============================================================================
# ZQL EXECUTION
# ============================================================================

def fetch_zephyr_zql_total_count(zql_query, username=None, password=None, max_records=1):
    """
    Execute a ZQL (Zephyr Query Language) query and return total count.
    
    Args:
        zql_query: ZQL query string
        username: Jira username
        password: Jira API token or password
        max_records: Maximum records to fetch (default: 1 for count-only queries)
    
    Returns:
        int: Total count of records matching the ZQL query
    
    Raises:
        requests.HTTPError: If the Zephyr API request fails
    """
    session = requests.Session()
    headers = fetch_zephyr_request_headers(session, username=username, password=password)
    
    response = session.get(
        build_zephyr_execute_search_url(),
        headers=headers,
        auth=build_basic_auth(username=username, password=password),
        params={
            'zqlQuery': zql_query,
            'offset': 0,
            'maxRecords': max(1, int(max_records)),
            'expand': 'executionStatus',
        },
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    payload = response.json()
    
    try:
        return max(0, int(payload.get('totalCount', 0)))
    except (TypeError, ValueError):
        return 0
