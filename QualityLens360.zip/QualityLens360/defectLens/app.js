function setJql(jql) {
  const box = $('jqlBox');
  if (!box) return;
  if (jql && jql.trim()) {
    box.textContent = `JQL used for this run:` + '\n' + jql;
    box.style.display = '';
  } else {
    box.textContent = '';
    box.style.display = 'none';
  }
}
let currentJobId = null;
let logIndex = 0;
let timer = null;
let insightsRequested = false;
let insightsInFlight = false;

let topChart = null;
let mttiChart = null;
let mttfChart = null;
let mttrChart = null;
const OKR_SEVERITY_KEYS = ['Sev 1', 'Sev 2', 'Sev 3', 'Sev 4'];
const OKR_SEVERITY_DISPLAY = {
  'Sev 1': 'Severity 1',
  'Sev 2': 'Severity 2',
  'Sev 3': 'Severity 3',
  'Sev 4': 'Severity 4'
};
const routes = window.defectLensConfig || {};

function $(id) { return document.getElementById(id); }
function withJobId(baseUrl, jobId) { return `${baseUrl}${jobId}`; }

function activateGeneratedJqlMode() {
  const generatedJql = String(routes.generatedJql || '').trim();
  const jqlInput = $('jqlInput');
  const jqlModeButton = $('jqlModeBtn');
  if (!generatedJql || !jqlInput || !jqlModeButton) return;
  jqlInput.value = generatedJql;
  if (typeof bootstrap !== 'undefined' && bootstrap.Tab) {
    bootstrap.Tab.getOrCreateInstance(jqlModeButton).show();
  }
}

function appendDefectLensFilters(formData) {
  const application = $('defectLensApplication')?.value || '';
  const releaseName = $('defectLensReleaseName')?.value || '';
  const resolvedFrom = $('defectLensResolvedFrom')?.value || '';
  const resolvedTo = $('defectLensResolvedTo')?.value || '';
  formData.append('application', application);
  formData.append('release_name', releaseName);
  formData.append('resolved_from', resolvedFrom);
  formData.append('resolved_to', resolvedTo);
}

function setBadge(state) {
  const badge = $('statusBadge');
  if (!badge) return;
  badge.className = 'badge';
  if (state === 'running' || state === 'queued') badge.classList.add('text-bg-primary');
  else if (state === 'completed') badge.classList.add('text-bg-success');
  else if (state === 'failed') badge.classList.add('text-bg-danger');
  else badge.classList.add('text-bg-secondary');
  const value = String(state || 'ready');
  const label = value.charAt(0).toUpperCase() + value.slice(1);
  if (state === 'running' || state === 'queued') {
    badge.innerHTML = '<span class="ql-spinner"></span>' + label;
  } else {
    badge.textContent = label;
  }
}

function setProgress(pct) {
  const bar = $('progressBar');
  if (!bar) return;
  const value = Math.max(0, Math.min(100, Number(pct || 0)));
  bar.style.width = `${value.toFixed(1)}%`;
  bar.textContent = `${value.toFixed(0)}%`;
  if (bar.parentElement) {
    bar.parentElement.setAttribute('aria-valuenow', value.toFixed(0));
  }
}

function setStatusText(text) { const element = $('statusText'); if (element) element.textContent = text || ''; }
function setAI(text) { const element = $('aiText'); if (element) element.textContent = text || ''; }
function setAITitle(text) { const element = $('aiTitle'); if (element) element.textContent = text || 'AI Insights'; }

function appendLog(lines) {
  const box = $('logText');
  if (!box || !lines || !lines.length) return;
  box.textContent += `${lines.join('\n')}\n`;
  box.scrollTop = box.scrollHeight;
}

function setSummary(summary) {
  const element = $('summaryBox');
  if (!element) return;
  if (!summary) {
    element.innerHTML = '';
    return;
  }
  element.innerHTML = `
    <div><b>Processed:</b> ${summary.processed ?? 0}</div>
    <div><b>Skipped blank:</b> ${summary.skipped_blank ?? 0}</div>
    <div><b>Skipped no data:</b> ${summary.skipped_no_data ?? 0}</div>
    <div><b>Time:</b> ${summary.elapsed_seconds ?? 0}s (${summary.elapsed_hms ?? ''})</div>
  `;
}

function parseToDays(value) {
  if (!value || value === 'TBD' || value === 'NA') return null;
  const normalized = String(value).toLowerCase().trim();
  const numeric = parseFloat(normalized);
  if (Number.isNaN(numeric)) return null;
  if (normalized.includes('day')) return numeric;
  if (normalized.includes('hr')) return numeric / 24;
  if (normalized.includes('min')) return numeric / 1440;
  return numeric;
}

function applyRag(elementId, status) {
  const element = $(elementId);
  if (!element) return;
  element.className = 'okr-rag-badge';
  const map = {
    GREEN: ['okr-rag-green', '● GREEN'],
    AMBER: ['okr-rag-amber', '● AMBER'],
    RED: ['okr-rag-red', '● RED']
  };
  const [cssClass, text] = map[status] || ['okr-rag-grey', '● --'];
  element.classList.add(cssClass);
  element.textContent = text;
}

function displayMetricValue(value, fallback = 'NA') {
  if (value === null || value === undefined || value === '' || value === 'TBD') return fallback;
  return String(value);
}

function breakdownStatus(metricKey, severityKey, rawValue) {
  if (!rawValue || rawValue === 'TBD' || rawValue === 'NA') return null;
  if (metricKey === 'ftra') {
    const pct = parseFloat(String(rawValue).replace('%', ''));
    if (Number.isNaN(pct)) return null;
    if (pct > 90) return 'green';
    if (pct >= 85) return 'amber';
    return 'red';
  }
  const slaDays = { 'Sev 1': 0.5, 'Sev 2': 3, 'Sev 3': 5, 'Sev 4': 10 }[severityKey];
  const multiplier = { mtti: 0.2, mttf: 0.6, mttr: 1.0 }[metricKey];
  if (!slaDays || !multiplier) return null;
  const targetDays = slaDays * multiplier;
  const valueDays = parseToDays(rawValue);
  if (valueDays === null) return null;
  if (valueDays <= targetDays) return 'green';
  if (valueDays <= targetDays * 1.2) return 'amber';
  return 'red';
}

function renderSeverityBreakdown(containerId, valuesBySeverity, metricKey) {
  const container = $(containerId);
  if (!container) return;
  const values = valuesBySeverity || {};
  container.innerHTML = '';
  const fragment = document.createDocumentFragment();
  for (const severityKey of OKR_SEVERITY_KEYS) {
    const row = document.createElement('div');
    row.className = 'okr-breakdown-row';
    const name = document.createElement('span');
    name.className = 'okr-breakdown-severity';
    name.textContent = OKR_SEVERITY_DISPLAY[severityKey] || severityKey;
    const value = document.createElement('span');
    value.className = 'okr-breakdown-value';
    const renderedValue = displayMetricValue(values[severityKey]);
    value.textContent = renderedValue;
    const status = breakdownStatus(metricKey, severityKey, renderedValue);
    if (status) value.classList.add(`okr-breakdown-${status}`);
    row.appendChild(name);
    row.appendChild(value);
    fragment.appendChild(row);
  }
  container.appendChild(fragment);
}

function setOKRs(okrs) {
  if (!okrs) return;
  const total = okrs.total || 0;
  const ftra = Number(okrs.ftra || 0);
  if ($('okrFtra')) $('okrFtra').textContent = `${(ftra * 100).toFixed(0)}%`;
  if ($('okrMtti')) $('okrMtti').textContent = displayMetricValue(okrs.mtti);
  if ($('okrMttf')) $('okrMttf').textContent = displayMetricValue(okrs.mttf);
  if ($('okrMttr')) $('okrMttr').textContent = displayMetricValue(okrs.mttr);
  const severityBreakdown = okrs.severityBreakdown || {};
  renderSeverityBreakdown('okrFtraBreakdown', severityBreakdown.ftra, 'ftra');
  renderSeverityBreakdown('okrMttiBreakdown', severityBreakdown.mtti, 'mtti');
  renderSeverityBreakdown('okrMttfBreakdown', severityBreakdown.mttf, 'mttf');
  renderSeverityBreakdown('okrMttrBreakdown', severityBreakdown.mttr, 'mttr');

  const tbody = $('okrNohTable');
  if (!tbody) return;
  const buckets = ['No Hops', '1 Hop', '2 Hops', '3-5 Hops', '6-10 Hops', '>10 Hops'];
  const counts = okrs.counts || {};
  const pct = okrs.pct || {};
  tbody.innerHTML = '';
  buckets.forEach((bucket, index) => {
    const count = counts[bucket] || 0;
    const percent = Number(pct[bucket] || 0);
    const row = document.createElement('tr');
    row.innerHTML = `<td>${bucket}</td><td class="text-center">${count}</td><td class="text-center ${index <= 1 ? 'pct-green' : 'pct-red'}">${(percent * 100).toFixed(0)}%</td>`;
    tbody.appendChild(row);
  });
  const totalRow = document.createElement('tr');
  totalRow.innerHTML = `<td><b>Total</b></td><td class="text-center"><b>${total}</b></td><td class="text-center"><b>${total ? '100%' : '0%'}</b></td>`;
  tbody.appendChild(totalRow);
  applyRag('okrFtraRag', (ftra * 100) > 90 ? 'GREEN' : (ftra * 100) >= 85 ? 'AMBER' : 'RED');
  const mttiDays = parseToDays(displayMetricValue(okrs.mtti));
  applyRag('okrMttiRag', mttiDays === null ? null : (mttiDays <= 4 ? 'GREEN' : mttiDays <= 5 ? 'AMBER' : 'RED'));
  const mttfDays = parseToDays(displayMetricValue(okrs.mttf));
  applyRag('okrMttfRag', mttfDays === null ? null : (mttfDays <= 11 ? 'GREEN' : mttfDays <= 13 ? 'AMBER' : 'RED'));
  const mttrDays = parseToDays(displayMetricValue(okrs.mttr));
  applyRag('okrMttrRag', mttrDays === null ? null : (mttrDays <= 4.6 ? 'GREEN' : mttrDays <= 5.6 ? 'AMBER' : 'RED'));
}

function setSimpleTable(elementId, rows, columns, emptyCols) {
  const tbody = $(elementId);
  if (!tbody) return;
  if (!rows || !rows.length) {
    tbody.innerHTML = `<tr><td colspan="${emptyCols}" class="text-muted p-3">No data.</td></tr>`;
    return;
  }
  tbody.innerHTML = '';
  for (const rowData of rows) {
    const row = document.createElement('tr');
    row.innerHTML = columns(rowData);
    tbody.appendChild(row);
  }
}

function buildDonutChart(canvasId, existingChart, payload) {
  const canvas = $(canvasId);
  if (!canvas) return null;
  const labels = payload?.labels || [];
  const values = payload?.values || [];
  if (!labels.length || !values.length || typeof Chart === 'undefined') {
    if (existingChart) existingChart.destroy();
    return null;
  }
  if (existingChart) existingChart.destroy();
  return new Chart(canvas.getContext('2d'), {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: ['#5B9BD5','#ED7D31','#A5A5A5','#FFC000','#4472C4','#70AD47','#264478','#9E480E','#636363','#987300'],
        borderWidth: 0,
        hoverOffset: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: { display: true, position: 'bottom', labels: { boxWidth: 10, boxHeight: 10 } },
        tooltip: { callbacks: { label: (context) => `${context.label}: ${Number(context.raw ?? 0).toFixed(1)}%` } }
      }
    }
  });
}

function bindOkrExpandButtons() {
  document.querySelectorAll('[data-okr-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      const targetId = button.getAttribute('data-okr-toggle');
      const panel = targetId ? $(targetId) : null;
      if (!panel) return;
      const isExpanded = button.getAttribute('aria-expanded') === 'true';
      const nextExpanded = !isExpanded;
      button.setAttribute('aria-expanded', String(nextExpanded));
      const label = button.querySelector('.okr-expand-label');
      const icon = button.querySelector('.okr-expand-icon');
      if (label) label.textContent = nextExpanded ? 'Hide Details' : 'Show Details';
      if (icon) icon.innerHTML = nextExpanded ? '&#9652;' : '&#9662;';
      panel.hidden = !nextExpanded;
    });
  });
}

async function poll() {
  if (!currentJobId) return;
  const statusRes = await fetch(withJobId(routes.statusBaseUrl, currentJobId));
  const statusJson = await statusRes.json();
  if (!statusJson.ok) return;
  setBadge(statusJson.status);
  setProgress(statusJson.progress);
  setStatusText(statusJson.message);
  if (statusJson.aiTitle) setAITitle(statusJson.aiTitle);
  if (statusJson.ai) setAI(statusJson.ai);
  if (statusJson.summary) setSummary(statusJson.summary);
  if (statusJson.okrs) setOKRs(statusJson.okrs);
  setSimpleTable('topContribTable', statusJson.topContrib, (row) => `<td>${row.application || ''}</td><td class="text-center">${Number(row.hours ?? 0).toFixed(2)}</td><td class="text-center">${Number(row.days ?? 0).toFixed(2)}</td><td class="text-center">${Number(row.pct ?? 0).toFixed(1)}%</td>`, 4);
  setSimpleTable('mttiContribTable', statusJson.mttiContrib, (row) => `<td>${row.application || ''}</td><td class="text-center">${Number(row.days ?? 0).toFixed(2)}</td><td class="text-center">${Number(row.pct ?? 0).toFixed(1)}%</td>`, 3);
  setSimpleTable('mttfContribTable', statusJson.mttfContrib, (row) => `<td>${row.application || ''}</td><td class="text-center">${Number(row.days ?? 0).toFixed(2)}</td><td class="text-center">${Number(row.pct ?? 0).toFixed(1)}%</td>`, 3);
  setSimpleTable('mttrContribTable', statusJson.mttrContrib, (row) => `<td>${row.application || ''}</td><td class="text-center">${Number(row.days ?? 0).toFixed(2)}</td><td class="text-center">${Number(row.pct ?? 0).toFixed(1)}%</td>`, 3);
  topChart = buildDonutChart('topContribChart', topChart, statusJson.topContribChart);
  mttiChart = buildDonutChart('mttiContribChart', mttiChart, statusJson.mttiContribChart);
  mttfChart = buildDonutChart('mttfContribChart', mttfChart, statusJson.mttfContribChart);
  mttrChart = buildDonutChart('mttrContribChart', mttrChart, statusJson.mttrContribChart);

  const logRes = await fetch(`${withJobId(routes.logBaseUrl, currentJobId)}?since=${logIndex}`);
  const logJson = await logRes.json();
  if (logJson.ok) {
    appendLog(logJson.lines);
    logIndex = logJson.next;
  }

  const downloadBtn = $('downloadBtn');
  if (statusJson.status === 'completed' && downloadBtn) {
    downloadBtn.classList.remove('disabled');
    downloadBtn.href = withJobId(routes.downloadBaseUrl, currentJobId);
    downloadBtn.removeAttribute('aria-disabled');
    downloadBtn.removeAttribute('tabindex');
    setStatusText('');
    clearInterval(timer);
    const promptIsStale = Boolean(statusJson.currentPromptSignature) && statusJson.aiPromptSignature !== statusJson.currentPromptSignature;
    if ((!statusJson.ai || promptIsStale) && !insightsRequested) {
      provideAIInsights(true);
    }
  }
  if (statusJson.status === 'failed') clearInterval(timer);
}

async function provideAIInsights(autoTriggered = false) {
  if (!currentJobId || insightsInFlight) return;
  insightsRequested = true;
  insightsInFlight = true;
  try {
    const response = await fetch(withJobId(routes.insightsBaseUrl, currentJobId), { method: 'POST' });
    const payload = await response.json();
    if (!payload.ok) {
      appendLog([`Error: ${payload.error || 'Failed to generate AI insights.'}`]);
      insightsRequested = false;
      return;
    }
    setAI(payload.text || '');
    setAITitle(payload.title || 'AI Insights');
    if (!autoTriggered) appendLog(['AI Insights generated successfully.']);
  } catch (error) {
    insightsRequested = false;
    appendLog([String(error)]);
  } finally {
    insightsInFlight = false;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  activateGeneratedJqlMode();
  bindOkrExpandButtons();
  const form = $('runForm');
  const runBtn = $('runBtn');
  if (!form) return;
  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (runBtn) runBtn.disabled = true;
    currentJobId = null;
    logIndex = 0;
    insightsRequested = false;
    insightsInFlight = false;
    if ($('logText')) $('logText').textContent = '';
    setAITitle('AI Insights');
    if ($('aiText')) $('aiText').textContent = '';
    applyRag('okrFtraRag', null);
    applyRag('okrMttiRag', null);
    applyRag('okrMttfRag', null);
    applyRag('okrMttrRag', null);
    const downloadBtn = $('downloadBtn');
    if (downloadBtn) {
      downloadBtn.classList.add('disabled');
      downloadBtn.href = '#';
    }
    setBadge('queued');
    setProgress(0);
    setStatusText('Starting...');
    try {
      const isJql = document.querySelector('#inputModeTabs .nav-link.active')?.id === 'jqlModeBtn';
      let runRes;
      if (isJql) {
        const jql = ($('jqlInput')?.value || '').trim();
        if (!jql) {
          setBadge('failed');
          setStatusText('Please enter a JQL query.');
          appendLog(['Error: JQL query is required.']);
          if (runBtn) runBtn.disabled = false;
          return;
        }
        const data = new FormData();
        appendDefectLensFilters(data);
        data.append('jql', jql);
        runRes = await fetch(routes.runJqlUrl, { method: 'POST', body: data });
      } else {
        const fileInput = $('fileInput');
        if (!fileInput || !fileInput.files || !fileInput.files.length) {
          setBadge('failed');
          setStatusText('Please upload an Excel .xlsx file.');
          appendLog(['Error: No file selected.']);
          if (runBtn) runBtn.disabled = false;
          return;
        }
        const data = new FormData();
        data.append('file', fileInput.files[0]);
        runRes = await fetch(routes.runUrl, { method: 'POST', body: data });
      }
      const runJson = await runRes.json();
      if (!runJson.ok) {
        setBadge('failed');
        setStatusText(runJson.error || 'Failed to start job.');
        appendLog([`Error: ${runJson.error || 'Unknown error'}`]);
        setJql(runJson.jql);
        return;
      }
      currentJobId = runJson.jobId;
      appendLog([`Job started: ${currentJobId}`]);
      setBadge('running');
      setStatusText('Running...');
      setJql(runJson.jql);
      if (timer) clearInterval(timer);
      timer = setInterval(poll, 900);
    } catch (error) {
      setBadge('failed');
      setStatusText('Failed to start (see log).');
      appendLog([String(error)]);
    } finally {
      if (runBtn) setTimeout(() => { runBtn.disabled = false; }, 600);
    }
  });
  const clearBtn = $('clearLog');
  const filterForm = $('defectLensFilterForm');
  const applicationField = $('defectLensApplication');
  const releaseField = $('defectLensReleaseName');
  if (filterForm && applicationField) {
    applicationField.addEventListener('change', () => {
      if (releaseField) {
        releaseField.value = '';
      }
      const resolvedFromField = $('defectLensResolvedFrom');
      const resolvedToField = $('defectLensResolvedTo');
      if (resolvedFromField) {
        resolvedFromField.value = '';
      }
      if (resolvedToField) {
        resolvedToField.value = '';
      }
      filterForm.requestSubmit();
    });
  }
  if (filterForm && releaseField) {
    releaseField.addEventListener('change', () => {
      filterForm.requestSubmit();
    });
  }
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if ($('logText')) $('logText').textContent = '';
      logIndex = 0;
    });
  }
});