"""
ACC-Prod KPI Handler

Executes all KPI calculations for the ACC-Prod application.
"""


def run_acc_prod_ram_kpis(context):
    execute_ram_query_fn = context['execute_ram_query']
    fetch_issue_count_fn = context['fetch_issue_count']
    fetch_ram_cancelled_issues_fn = context['fetch_ram_cancelled_issues']
    issue_has_non_development_assigned_team_entire_lifecycle_fn = context['issue_has_non_development_assigned_team_entire_lifecycle']
    calculate_triage_efficiency_kpi_fn = context['calculate_triage_efficiency_kpi']
    calculate_production_defect_leakage_kpi_fn = context['calculate_production_defect_leakage_kpi']
    calculate_defect_burndown_rate_kpi_fn = context['calculate_defect_burndown_rate_kpi']
    build_production_defect_leakage_jql_fn = context['build_production_defect_leakage_jql']
    build_preprod_defects_ram_jql_fn = context['build_preprod_defects_ram_jql']
    build_triaged_ram_jql_fn = context['build_triaged_ram_jql']
    build_cancelled_ram_jql_fn = context['build_cancelled_ram_jql']
    build_resolved_period_ram_jql_fn = context['build_resolved_period_ram_jql']
    build_open_ram_jql_fn = context['build_open_ram_jql']

    executed_jql = context['executed_jql']
    base_ram_jql = context['base_ram_jql']
    selected_application = context['selected_application']
    created_from = context['created_from']
    created_to = context['created_to']
    username = context['username']
    password = context['password']

    production_defect_leakage_jql = build_production_defect_leakage_jql_fn(executed_jql)
    preprod_defects_jql = build_preprod_defects_ram_jql_fn(selected_application, created_from, created_to)
    overall_defects = execute_ram_query_fn(
        'RAM overall defects',
        lambda: fetch_issue_count_fn(
            jql=executed_jql,
            username=username,
            password=password,
        ),
    )
    production_defect_leakage_defects = execute_ram_query_fn(
        'RAM defect leakage numerator',
        lambda: fetch_issue_count_fn(
            jql=production_defect_leakage_jql,
            username=username,
            password=password,
        ),
    )
    overall_preprod_defects = execute_ram_query_fn(
        'RAM pre-prod defects',
        lambda: fetch_issue_count_fn(
            jql=preprod_defects_jql,
            username=username,
            password=password,
        ),
    )
    triaged_defects = execute_ram_query_fn(
        'RAM triaged defects',
        lambda: fetch_issue_count_fn(
            jql=build_triaged_ram_jql_fn(executed_jql),
            username=username,
            password=password,
        ),
    )
    cancelled_jql = build_cancelled_ram_jql_fn(executed_jql)
    cancelled_defects = execute_ram_query_fn(
        'RAM cancelled defects',
        lambda: fetch_issue_count_fn(
            jql=cancelled_jql,
            username=username,
            password=password,
        ),
    )

    triage_efficiency = None
    cancellation_rate = None
    cancellation_efficiency_by_triage = None
    production_defect_leakage = None
    defect_burndown_rate = None

    if overall_defects is not None and triaged_defects is not None:
        triage_efficiency = calculate_triage_efficiency_kpi_fn(overall_defects, triaged_defects)
        if triage_efficiency:
            triaged_jql = build_triaged_ram_jql_fn(executed_jql)
            triage_efficiency['queries'] = f'Query 1 (Overall): {executed_jql}\n\nQuery 2 (Triaged): {triaged_jql}'
    if overall_defects is not None and cancelled_defects is not None:
        cancellation_rate = {
            'percentage': f'{round((cancelled_defects / overall_defects) * 100) if overall_defects else 0}%',
            'numerator': cancelled_defects,
            'denominator': overall_defects,
            'logic': 'No. of defects where STATUS in (Cancelled) / Overall Defects',
            'queries': f'Query 1 (Overall): {executed_jql}\n\nQuery 2 (Cancelled): {cancelled_jql}',
        }

    cancelled_issues = execute_ram_query_fn(
        'RAM cancelled issue lifecycle data',
        lambda: fetch_ram_cancelled_issues_fn(
            jql=cancelled_jql,
            username=username,
            password=password,
        ),
    )
    if cancelled_issues is not None and cancelled_defects is not None:
        cancelled_non_development_defects = sum(
            1 for issue in cancelled_issues if issue_has_non_development_assigned_team_entire_lifecycle_fn(issue)
        )
        cancellation_efficiency_by_triage = {
            'percentage': f'{round((cancelled_non_development_defects / cancelled_defects) * 100) if cancelled_defects else 0}%',
            'numerator': cancelled_non_development_defects,
            'denominator': cancelled_defects,
            'logic': 'No. of cancelled defects where Assigned to Team is not Development in the entire lifecycle / No. of defects where STATUS in (Cancelled)',
            'queries': f'Query (Cancelled): {cancelled_jql}',
        }

    if production_defect_leakage_defects is not None and overall_preprod_defects is not None:
        production_defect_leakage = calculate_production_defect_leakage_kpi_fn(
            production_defect_leakage_defects,
            overall_preprod_defects,
        )
        if production_defect_leakage:
            production_defect_leakage['queries'] = f'Query 1 (Production Leakage): {production_defect_leakage_jql}\n\nQuery 2 (Preprod): {preprod_defects_jql}'

    # Strip created date filters from base_ram_jql for burndown rate queries
    from ram.feature import strip_created_date_clauses
    burndown_base_jql = strip_created_date_clauses(base_ram_jql)
    resolved_period_defects = execute_ram_query_fn(
        'RAM resolved defects for selected period',
        lambda: fetch_issue_count_fn(
            jql=build_resolved_period_ram_jql_fn(burndown_base_jql, created_from, created_to),
            username=username,
            password=password,
        ),
    )
    overall_open_defects = execute_ram_query_fn(
        'RAM overall open defects',
        lambda: fetch_issue_count_fn(
            jql=build_open_ram_jql_fn(burndown_base_jql),
            username=username,
            password=password,
        ),
    )
    if resolved_period_defects is not None and overall_open_defects is not None:
        defect_burndown_rate = calculate_defect_burndown_rate_kpi_fn(resolved_period_defects, overall_open_defects)
        if defect_burndown_rate:
            resolved_period_jql = build_resolved_period_ram_jql_fn(burndown_base_jql, created_from, created_to)
            open_jql = build_open_ram_jql_fn(burndown_base_jql)
            defect_burndown_rate['queries'] = f'Query 1 (Resolved in Period): {resolved_period_jql}\n\nQuery 2 (Overall Open): {open_jql}'

    return {
        'triaged_defects': triaged_defects,
        'production_defect_leakage': production_defect_leakage,
        'triage_efficiency': triage_efficiency,
        'cancellation_rate': cancellation_rate,
        'cancellation_efficiency_by_triage': cancellation_efficiency_by_triage,
        'defect_burndown_rate': defect_burndown_rate,
    }
