"""Pre-configured ``requests.Session`` with proxy and CA settings.

Every module that makes outbound HTTP calls (Jira / iTrack, Graph API,
SharePoint, etc.) should use the session returned by
:func:`get_http_session` instead of bare ``requests.get / .post`` so
that proxy and TLS settings are applied consistently.

Environment variables honoured
------------------------------
``HTTPS_PROXY`` / ``HTTP_PROXY``
    Corporate forward-proxy URL, e.g. ``http://proxy.corp:8080``.
``NO_PROXY``
    Comma-separated hostnames/CIDRs to bypass the proxy.
``REQUESTS_CA_BUNDLE``
    Path to a PEM CA bundle for TLS-inspecting proxies.
"""

from __future__ import annotations

from functools import lru_cache

import requests

from shared.shared_config import (
    HTTP_PROXY,
    HTTPS_PROXY,
    NO_PROXY,
    REQUESTS_CA_BUNDLE,
)


def _build_proxies() -> dict[str, str]:
    """Build the proxies dict from config, skipping empty values."""
    proxies: dict[str, str] = {}
    if HTTPS_PROXY:
        proxies['https'] = HTTPS_PROXY
    if HTTP_PROXY:
        proxies['http'] = HTTP_PROXY
    if NO_PROXY:
        proxies['no'] = NO_PROXY
    return proxies


@lru_cache(maxsize=1)
def get_http_session() -> requests.Session:
    """Return a reusable ``requests.Session`` with proxy & CA config.

    The session is cached so all callers share the same connection pool.
    """
    session = requests.Session()

    proxies = _build_proxies()
    if proxies:
        session.proxies.update(proxies)

    if REQUESTS_CA_BUNDLE:
        session.verify = REQUESTS_CA_BUNDLE

    return session
