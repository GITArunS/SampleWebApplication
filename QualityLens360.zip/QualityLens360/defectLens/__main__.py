"""Module entry point for python -m defectLens."""

from defectLens.main import main


if __name__ == "__main__":
    main()
