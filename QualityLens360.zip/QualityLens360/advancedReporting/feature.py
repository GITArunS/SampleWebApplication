import logging
import time
import re
from collections import defaultdict
from io import BytesIO

from flask import jsonify, render_template, request, send_file
from openpyxl import Workbook

from shared.shared_config import JIRA_USER
from shared.shared_logic import fetch_open_defects, fetch_issue_editmeta
from ram.app_config import RAM_CORE_APPLICATION_OPTIONS

LOGGER = logging.getLogger(__name__)

CANCELLATION_BASE_JQL = (
    'project = CDEX and ('
    '"Application Found In" ~ "GRP- CQE Org:24115" '
    'or "Application Found In" ~ BSSe-RTB:30914 '
    'or "Application Found In" ~ BSSe-OC:30909 '
    'or "Application Found In" ~ BSSe-MMap:31697 '
    'or "Application Found In" ~ BSSe-BB:31692 '
    'or "Application Found In" ~ BSSe-SkyFM:31452 '
    'or "Application Found In" ~ BSSe-C1:30911 '
    'or "Application Found In" ~ BSSe-NEO:31710 '
    'or "Application Found In" ~ BSSe-OH:30910 '
    'or "Application Found In" ~ BSSe-iPaaS:30912 '
    'or "Application Found In" ~ BSSe-ACF:32985 '
    'and "Phase Found In" in ("Integrated Solution Testing (IST)", "Smoke Testing", Development, '
    '"Scrum Testing", "Enterprise Certification Testing (ECT)", "Integrated Scrum to Scrum (ST)") '
    'or "Phase Found In" in (Production, "Production Validation Testing (PVT)") '
    'and "Application Fixed In" ~ "BSSe*") '
    'and "Defect Type" in (Defect, "Tracking Record", "Bug/Issue", "Production Defect") '
    'and (cf[16424] not in (PET, PET1, PET2, PET2Azure, PET3, PET3_EAST) or cf[16424] is EMPTY) '
    'and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
    'and labels not in (ACC, ACC_IST, ACC_Sales, ACCINT, ACCUAT, csa, CSA_Triage, CSATriage, '
    'IST_ACC_CLM, IST_ACC_SALES, IST_ACC_SERVICE, PET2, Digital_Bsse_API, ECT_Digital) '
    'and "Phase Found In" in ("Integrated Solution Testing (IST)") '
    'and "Application Found In" ~ "GRP- CQE Org:24115" '
    'and Status in (Cancelled)'
)

ACCEPTED_DEFECT_RCA_BASE_JQL = (
    'project = CDEX and ('
    '"Application Found In" ~ "GRP- CQE Org:24115" '
    'or "Application Found In" ~ BSSe-RTB:30914 '
    'or "Application Found In" ~ BSSe-OC:30909 '
    'or "Application Found In" ~ BSSe-MMap:31697 '
    'or "Application Found In" ~ BSSe-BB:31692 '
    'or "Application Found In" ~ BSSe-SkyFM:31452 '
    'or "Application Found In" ~ BSSe-C1:30911 '
    'or "Application Found In" ~ BSSe-NEO:31710 '
    'or "Application Found In" ~ BSSe-OH:30910 '
    'or "Application Found In" ~ BSSe-iPaaS:30912 '
    'or "Application Found In" ~ BSSe-ACF:32985 '
    'and "Phase Found In" in ("Integrated Solution Testing (IST)", "Smoke Testing", Development, '
    '"Scrum Testing", "Enterprise Certification Testing (ECT)", "Integrated Scrum to Scrum (ST)") '
    'or "Phase Found In" in (Production, "Production Validation Testing (PVT)") '
    'and "Application Fixed In" ~ "BSSe*") '
    'and "Defect Type" in (Defect, "Tracking Record", "Bug/Issue", "Production Defect") '
    'and (cf[16424] not in (PET, PET1, PET2, PET2Azure, PET3, PET3_EAST) or cf[16424] is EMPTY) '
    'and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
    'and labels not in (ACC, ACC_IST, ACC_Sales, ACCINT, ACCUAT, csa, CSA_Triage, CSATriage, '
    'IST_ACC_CLM, IST_ACC_SALES, IST_ACC_SERVICE, PET2, Digital_Bsse_API, ECT_Digital) '
    'and "Phase Found In" in ("Integrated Solution Testing (IST)") '
    'and "Application Found In" ~ "GRP- CQE Org:24115" '
    'and Status in (Accepted)'
)

CANCELLATION_ROOT_CAUSE_REASON_FIELD_KEY = 'customfield_18871:1'
ACCEPTED_ROOT_CAUSE_REASON_FIELD_KEY = 'customfield_18871'
CANCELLATION_ROOT_CAUSE_REASON_VALUE_KEY = 'customfield_18871-val'

CANCELLATION_FIELDS = [
    'labels', 'customfield_18971', 'customfield_18972', ACCEPTED_ROOT_CAUSE_REASON_FIELD_KEY,
    CANCELLATION_ROOT_CAUSE_REASON_FIELD_KEY,
    'status', 'summary', 'severity', 'created',
]

ACCEPTED_DEFECT_FIELDS = [
    'labels', 'customfield_18971', 'customfield_18972', ACCEPTED_ROOT_CAUSE_REASON_FIELD_KEY,
    'status', 'summary', 'severity', 'created',
]

RELEASE_FIELD_KEY = 'customfield_18971'
RELEASE_SEED_FALLBACK = 'BSSe PI 27.5'
DATE_PATTERN = re.compile(r'^\d{4}-\d{2}-\d{2}$')


def _escape_jql(value):
    return str(value).replace('\\', '\\\\').replace('"', '\\"').strip()


def _build_cancellation_jql(created_from=None, created_to=None, release_name=None):
    jql = CANCELLATION_BASE_JQL
    if created_from and DATE_PATTERN.match(created_from):
        jql += f' and created >= "{_escape_jql(created_from)}"'
    if created_to and DATE_PATTERN.match(created_to):
        jql += f' and created <= "{_escape_jql(created_to)}"'
    if release_name:
        escaped = _escape_jql(release_name)
        jql += f' and (cf[18971] in ("{escaped}") or cf[18972] in ("{escaped}"))'
    jql += ' ORDER BY created DESC'
    return jql


def _build_accepted_defect_rca_jql(created_from=None, created_to=None, release_name=None):
    jql = ACCEPTED_DEFECT_RCA_BASE_JQL
    if created_from and DATE_PATTERN.match(created_from):
        jql += f' and created >= "{_escape_jql(created_from)}"'
    if created_to and DATE_PATTERN.match(created_to):
        jql += f' and created <= "{_escape_jql(created_to)}"'
    if release_name:
        escaped = _escape_jql(release_name)
        jql += f' and (cf[18971] in ("{escaped}") or cf[18972] in ("{escaped}"))'
    jql += ' ORDER BY created DESC'
    return jql


def _extract_tribe_from_labels(labels):
    for label in (labels or []):
        if isinstance(label, str) and label.lower().startswith('tribe'):
            return label
    return 'Unknown'


def _normalize_tribe_label(label):
    normalized = str(label or '').strip()
    if not normalized:
        return 'Unknown'

    numbered_match = re.match(r'^tribe\s*(\d+)$', normalized, re.IGNORECASE)
    if numbered_match:
        return f'Tribe{int(numbered_match.group(1))}'

    if re.match(r'^tribe[-_ ]?aut$', normalized, re.IGNORECASE):
        return 'Tribe-Aut'

    if re.match(r'^tribe[-_ ]?generic$', normalized, re.IGNORECASE):
        return 'Tribe_Generic'

    if normalized.lower().startswith('tribe'):
        return 'Tribe' + normalized[5:]

    return normalized


def _extract_release(fields):
    for key in ('customfield_18971', 'customfield_18972'):
        val = fields.get(key)
        if val:
            if isinstance(val, dict):
                return val.get('value') or val.get('name') or ''
            if isinstance(val, list):
                for item in val:
                    if isinstance(item, dict):
                        text = item.get('value') or item.get('name') or ''
                        if text:
                            return text
            if isinstance(val, str) and val.strip():
                return val.strip()
    return 'Unknown'


def _normalize_report_release(release):
    normalized = str(release or '').strip()
    if not normalized:
        return 'Others'

    match = re.match(r'^BSSe\s+PI\s+(\d+)\.(\d+)$', normalized, re.IGNORECASE)
    if not match:
        return 'Others'

    major_release = int(match.group(1))
    minor_release = int(match.group(2))
    if minor_release <= 0:
        return 'Others'

    release_bucket = ((minor_release - 1) // 3) + 1
    return f'BSSe PI {major_release} R{release_bucket}'


def _extract_rca_category(fields):
    val = fields.get('customfield_18871')
    if not val:
        return 'Not Specified'
    text = ''
    if isinstance(val, dict):
        text = val.get('value') or val.get('name') or ''
    elif isinstance(val, str):
        text = val.strip()
    if not text:
        return 'Not Specified'
    return text.split('-')[0].strip() or 'Not Specified'


def _extract_rca_reason_text(fields, field_key=ACCEPTED_ROOT_CAUSE_REASON_FIELD_KEY):
    val = fields.get(field_key)
    if not val:
        return 'Not Specified'

    text = ''
    if isinstance(val, dict):
        text = val.get('value') or val.get('name') or ''
    elif isinstance(val, str):
        text = val.strip()

    return text.strip() or 'Not Specified'


def _extract_cancellation_rca_reason_text(fields):
    direct_value = _extract_rca_reason_text(fields, CANCELLATION_ROOT_CAUSE_REASON_VALUE_KEY)
    if direct_value and direct_value != 'Not Specified':
        return direct_value

    cascading_value = fields.get(ACCEPTED_ROOT_CAUSE_REASON_FIELD_KEY)
    if isinstance(cascading_value, dict):
        parent_value = str(
            cascading_value.get('value')
            or cascading_value.get('name')
            or cascading_value.get('displayName')
            or ''
        ).strip()
        child_value = ''
        child = cascading_value.get('child')
        if isinstance(child, dict):
            child_value = str(child.get('value') or child.get('name') or child.get('displayName') or '').strip()
        elif child not in (None, ''):
            child_value = str(child).strip()

        if parent_value and child_value:
            return f'{parent_value} - {child_value}'
        if parent_value:
            return parent_value
        if child_value:
            return child_value

    fallback_value = _extract_rca_reason_text(fields, CANCELLATION_ROOT_CAUSE_REASON_FIELD_KEY)
    if fallback_value and fallback_value != 'Not Specified':
        return fallback_value
    return 'Not Specified'


def _extract_status(fields):
    status = fields.get('status')
    if isinstance(status, dict):
        return status.get('name') or status.get('value') or ''
    return str(status or '').strip()


def _extract_severity(fields):
    severity = fields.get('severity')
    if isinstance(severity, dict):
        return severity.get('value') or severity.get('name') or ''
    return str(severity or '').strip()


def _extract_created(fields):
    created = str(fields.get('created') or '').strip()
    if not created:
        return ''
    if 'T' in created:
        return created.split('T', 1)[0]
    return created


def _extract_label_text(labels):
    return ', '.join(label for label in (labels or []) if isinstance(label, str))


def _normalize_report_rca_category(category):
    normalized = str(category or '').strip()
    if not normalized:
        return 'Not Specified'

    lowered = normalized.casefold()
    if lowered in {'requirements', 'design specification', 'business'}:
        return 'Requirements'
    if lowered in {'environment', 'anomaly', 'application availability'}:
        return 'Environment Instability'
    if lowered in {'testing', 'other'}:
        return 'Others'
    return normalized


def _normalize_cancellation_rca_category(category):
    normalized = str(category or '').strip()
    if not normalized:
        return 'Others'

    lowered = normalized.casefold()
    if 'testing - incorrect test case' in lowered:
        return 'Incorrect Test Case'
    if 'testing - duplicate' in lowered:
        return 'Duplicate'
    if 'testing - vendor documentation' in lowered:
        return 'Vendor Documentation'
    return 'Others'


def _normalize_accepted_defect_rca_category(category):
    return _normalize_report_rca_category(category)


def _generate_recommendations(total, by_tribe, by_rca, by_release, defect_label='defects', report_label='report'):
    recs = []
    if total == 0:
        recs.append(f'No {defect_label} found for the selected criteria. This indicates strong process stability for this {report_label}.')
        return recs

    if by_tribe:
        top_tribe = max(by_tribe, key=by_tribe.get)
        recs.append(
            f'{top_tribe} has the highest {defect_label} count ({by_tribe[top_tribe]}). '
            'Review recurring patterns from this tribe first to identify the most impactful process and quality gaps.'
        )

    if by_rca:
        top_rca = max(by_rca, key=by_rca.get)
        recs.append(
            f'The leading RCA category is "{top_rca}" ({by_rca[top_rca]} defects). '
            'Conduct a focused review of this category to identify repeatable root causes and corrective actions.'
        )

    if len(by_release) >= 2:
        releases = list(by_release.items())
        recent = releases[-1]
        prev = releases[-2]
        if recent[1] > prev[1]:
            recs.append(
                f'{defect_label.capitalize()} increased from {prev[1]} ({prev[0]}) to {recent[1]} ({recent[0]}). '
                'Investigate release-specific process or code changes that may have contributed to the increase.'
            )
        elif recent[1] < prev[1]:
            recs.append(
                f'{defect_label.capitalize()} decreased from {prev[1]} ({prev[0]}) to {recent[1]} ({recent[0]}). '
                'Capture the practices or fixes behind this improvement and standardize them across teams.'
            )

    if by_rca.get('Data', 0) > total * 0.3:
        recs.append(
            f'Data-related {defect_label} account for over 30% of total. '
            'Recommend a targeted data quality and environment readiness review before the next cycle.'
        )

    if by_rca.get('Duplicate', 0) > total * 0.2:
        recs.append(
            f'Duplicate-related {defect_label} represent a significant share. '
            'Consider strengthening duplicate review and classification guidance before final acceptance.'
        )

    if len(by_tribe) > 3:
        low_tribes = [t for t, c in by_tribe.items() if c <= 2 and t != 'Unknown']
        if low_tribes:
            recs.append(
                f'{len(low_tribes)} tribe(s) have minimal {defect_label} (≤2). '
                'Use them as comparison points to identify practices worth replicating in higher-volume tribes.'
            )

    recs.append(
        f'Schedule a periodic {report_label} review with tribe leads to track recurring patterns and drive corrective actions.'
    )
    return recs


def _build_export_rows(issues, rca_normalizer=None, rca_extractor=None):
    rows = []
    for issue in issues:
        fields = issue.get('fields') or {}
        raw_tribe = _extract_tribe_from_labels(fields.get('labels'))
        mapped_tribe = _normalize_tribe_label(raw_tribe)
        raw_release = _extract_release(fields)
        mapped_release = _normalize_report_release(raw_release)
        raw_rca = rca_extractor(fields) if rca_extractor is not None else _extract_rca_category(fields)
        mapped_rca = rca_normalizer(raw_rca) if rca_normalizer is not None else raw_rca
        rows.append({
            'Issue Key': issue.get('key', ''),
            'Summary': str(fields.get('summary') or '').strip(),
            'Status': _extract_status(fields),
            'Severity': _extract_severity(fields),
            'Created Date': _extract_created(fields),
            'Labels': _extract_label_text(fields.get('labels')),
            'Raw Tribe Label': raw_tribe,
            'Mapped Tribe': mapped_tribe,
            'Raw Release': raw_release,
            'Mapped Release': mapped_release,
            'Raw RCA Category': raw_rca,
            'Mapped RCA Category': mapped_rca,
        })
    return rows


def _build_export_filename(report_slug):
    timestamp = time.strftime('%Y%m%d_%H%M%S')
    return f'{report_slug}_{timestamp}.xlsx'


def _build_export_workbook_stream(sheet_title, rows):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_title

    headers = [
        'Issue Key', 'Summary', 'Status', 'Severity', 'Created Date', 'Labels',
        'Raw Tribe Label', 'Mapped Tribe', 'Raw Release', 'Mapped Release',
        'Raw RCA Category', 'Mapped RCA Category',
    ]
    worksheet.append(headers)
    for row in rows:
        worksheet.append([row.get(header, '') for header in headers])

    worksheet.freeze_panes = 'A2'
    for column_cells in worksheet.columns:
        max_length = max(len(str(cell.value or '')) for cell in column_cells)
        worksheet.column_dimensions[column_cells[0].column_letter].width = min(max(max_length + 2, 14), 48)

    file_bytes = BytesIO()
    workbook.save(file_bytes)
    file_bytes.seek(0)
    return file_bytes


def _build_report_payload(issues, total_key, recommendation_defect_label, recommendation_report_label, rca_normalizer=None, rca_extractor=None):
    by_tribe = defaultdict(int)
    by_release = defaultdict(int)
    by_rca_category = defaultdict(int)
    rca_by_release = defaultdict(lambda: defaultdict(int))

    for issue in issues:
        fields = issue.get('fields') or {}
        tribe = _normalize_tribe_label(_extract_tribe_from_labels(fields.get('labels')))
        release = _normalize_report_release(_extract_release(fields))
        rca = rca_extractor(fields) if rca_extractor is not None else _extract_rca_category(fields)
        if rca_normalizer is not None:
            rca = rca_normalizer(rca)

        by_tribe[tribe] += 1
        by_release[release] += 1
        by_rca_category[rca] += 1
        rca_by_release[rca][release] += 1

    by_tribe = dict(sorted(by_tribe.items(), key=lambda item: item[1], reverse=True))
    by_release = dict(sorted(by_release.items(), key=lambda item: (item[0] == 'Others', item[0].casefold())))
    by_rca_category = dict(sorted(by_rca_category.items(), key=lambda item: item[1], reverse=True))
    rca_by_release_plain = {category: dict(releases) for category, releases in rca_by_release.items()}

    return {
        total_key: len(issues),
        'by_tribe': by_tribe,
        'by_release': by_release,
        'by_rca_category': by_rca_category,
        'rca_by_release': rca_by_release_plain,
        'recommendations': _generate_recommendations(
            len(issues),
            by_tribe,
            by_rca_category,
            by_release,
            defect_label=recommendation_defect_label,
            report_label=recommendation_report_label,
        ),
    }


def _attach_run_duration(payload, started_at):
    payload['run_time_seconds'] = round(time.perf_counter() - started_at, 2)
    return payload


class AdvancedReportingFeature:
    def __init__(self, get_session_credentials):
        self.get_session_credentials = get_session_credentials

    def register(self, app, login_required):
        @app.route('/advanced-reporting')
        @login_required
        def advanced_reporting_page():
            credentials = self.get_session_credentials() or {}
            selected_application = (request.args.get('application') or '').strip()
            return render_template(
                'advanced_reporting.html',
                page_title='Quality Lens 360 | Advanced Reporting',
                jira_user=credentials.get('username', JIRA_USER),
                application_options=RAM_CORE_APPLICATION_OPTIONS,
                selected_application=selected_application,
            )

        @app.route('/advanced-reporting/cancellation-report')
        @login_required
        def cancellation_report_page():
            credentials = self.get_session_credentials() or {}
            selected_application = (request.args.get('application') or '').strip() or 'ACES-IST'
            selected_release = (request.args.get('release_name') or '').strip()
            release_options = self._fetch_release_options(
                username=credentials.get('username'),
                password=credentials.get('password'),
            )
            return render_template(
                'cancellation_report.html',
                page_title='Quality Lens 360 | Cancellation Report',
                jira_user=credentials.get('username', JIRA_USER),
                application_options=RAM_CORE_APPLICATION_OPTIONS,
                selected_application=selected_application,
                selected_release=selected_release,
                release_options=release_options,
            )

        @app.route('/advanced-reporting/accepted-defects-root-cause-analysis')
        @login_required
        def accepted_defects_root_cause_analysis_page():
            credentials = self.get_session_credentials() or {}
            selected_application = (request.args.get('application') or '').strip() or 'ACES-IST'
            selected_release = (request.args.get('release_name') or '').strip()
            release_options = self._fetch_release_options(
                username=credentials.get('username'),
                password=credentials.get('password'),
            )
            return render_template(
                'accepted_defects_root_cause_analysis.html',
                page_title='Quality Lens 360 | Accepted Defects: Root Cause Analysis',
                jira_user=credentials.get('username', JIRA_USER),
                application_options=RAM_CORE_APPLICATION_OPTIONS,
                selected_application=selected_application,
                selected_release=selected_release,
                release_options=release_options,
            )

        @app.route('/advanced-reporting/cancellation-report/run')
        @login_required
        def cancellation_report_run():
            credentials = self.get_session_credentials()
            if not credentials:
                return jsonify({'error': 'Log in with your Jira/iTrack credentials to run this report.'}), 401

            created_from = (request.args.get('created_from') or '').strip()
            created_to = (request.args.get('created_to') or '').strip()
            release_name = (request.args.get('release_name') or '').strip()
            started_at = time.perf_counter()

            jql = _build_cancellation_jql(created_from, created_to, release_name)
            LOGGER.info("Cancellation report JQL: %s", jql)

            try:
                issues = self._fetch_all_issues(
                    jql=jql,
                    username=credentials['username'],
                    password=credentials['password'],
                    fields=CANCELLATION_FIELDS,
                )
            except Exception as error:
                LOGGER.exception("Cancellation report JQL fetch failed.")
                return jsonify({'error': f'Jira query failed: {error}'}), 500

            return jsonify(
                _attach_run_duration(
                    _build_report_payload(
                        issues,
                        'total_cancelled',
                        'cancelled defects',
                        'cancellation report',
                        rca_normalizer=_normalize_cancellation_rca_category,
                        rca_extractor=_extract_cancellation_rca_reason_text,
                    ),
                    started_at,
                )
            )

        @app.route('/advanced-reporting/cancellation-report/download')
        @login_required
        def cancellation_report_download():
            credentials = self.get_session_credentials()
            if not credentials:
                return jsonify({'error': 'Log in with your Jira/iTrack credentials to download this report.'}), 401

            created_from = (request.args.get('created_from') or '').strip()
            created_to = (request.args.get('created_to') or '').strip()
            release_name = (request.args.get('release_name') or '').strip()

            jql = _build_cancellation_jql(created_from, created_to, release_name)
            LOGGER.info('Cancellation report download JQL: %s', jql)

            try:
                issues = self._fetch_all_issues(
                    jql=jql,
                    username=credentials['username'],
                    password=credentials['password'],
                    fields=CANCELLATION_FIELDS,
                )
            except Exception as error:
                LOGGER.exception('Cancellation report download fetch failed.')
                return jsonify({'error': f'Jira query failed: {error}'}), 500

            file_bytes = _build_export_workbook_stream(
                'Cancelled Defects',
                _build_export_rows(
                    issues,
                    rca_normalizer=_normalize_cancellation_rca_category,
                    rca_extractor=_extract_cancellation_rca_reason_text,
                ),
            )
            return send_file(
                file_bytes,
                as_attachment=True,
                download_name=_build_export_filename('cancelled_defects_analysis_report'),
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

        @app.route('/advanced-reporting/accepted-defects-root-cause-analysis/run')
        @login_required
        def accepted_defects_root_cause_analysis_run():
            credentials = self.get_session_credentials()
            if not credentials:
                return jsonify({'error': 'Log in with your Jira/iTrack credentials to run this report.'}), 401

            created_from = (request.args.get('created_from') or '').strip()
            created_to = (request.args.get('created_to') or '').strip()
            release_name = (request.args.get('release_name') or '').strip()
            started_at = time.perf_counter()

            jql = _build_accepted_defect_rca_jql(created_from, created_to, release_name)
            LOGGER.info('Accepted defect RCA JQL: %s', jql)

            try:
                issues = self._fetch_all_issues(
                    jql=jql,
                    username=credentials['username'],
                    password=credentials['password'],
                    fields=ACCEPTED_DEFECT_FIELDS,
                )
            except Exception as error:
                LOGGER.exception('Accepted defect RCA JQL fetch failed.')
                return jsonify({'error': f'Jira query failed: {error}'}), 500

            return jsonify(
                _attach_run_duration(
                    _build_report_payload(
                        issues,
                        'total_accepted',
                        'accepted defects',
                        'accepted defect RCA report',
                        rca_normalizer=_normalize_accepted_defect_rca_category,
                    ),
                    started_at,
                )
            )

        @app.route('/advanced-reporting/accepted-defects-root-cause-analysis/download')
        @login_required
        def accepted_defects_root_cause_analysis_download():
            credentials = self.get_session_credentials()
            if not credentials:
                return jsonify({'error': 'Log in with your Jira/iTrack credentials to download this report.'}), 401

            created_from = (request.args.get('created_from') or '').strip()
            created_to = (request.args.get('created_to') or '').strip()
            release_name = (request.args.get('release_name') or '').strip()

            jql = _build_accepted_defect_rca_jql(created_from, created_to, release_name)
            LOGGER.info('Accepted defect RCA download JQL: %s', jql)

            try:
                issues = self._fetch_all_issues(
                    jql=jql,
                    username=credentials['username'],
                    password=credentials['password'],
                    fields=ACCEPTED_DEFECT_FIELDS,
                )
            except Exception as error:
                LOGGER.exception('Accepted defect RCA download fetch failed.')
                return jsonify({'error': f'Jira query failed: {error}'}), 500

            file_bytes = _build_export_workbook_stream(
                'Accepted Defects',
                _build_export_rows(issues, rca_normalizer=_normalize_accepted_defect_rca_category),
            )
            return send_file(
                file_bytes,
                as_attachment=True,
                download_name=_build_export_filename('accepted_defects_rca_report'),
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

    @staticmethod
    def _fetch_all_issues(jql, username, password, fields, max_per_page=100):
        all_issues = []
        start_at = 0
        while True:
            batch = fetch_open_defects(
                jql=jql, max_results=max_per_page, username=username, password=password,
                start_at=start_at, fields=fields, expand='names',
            )
            if not batch:
                break
            all_issues.extend(batch)
            start_at += len(batch)
            if len(batch) < max_per_page:
                break
        return all_issues

    @staticmethod
    def _fetch_release_options(username=None, password=None):
        seed_jql = (
            CANCELLATION_BASE_JQL.replace('and Status in (Cancelled)', '')
            + f' and (cf[18971] in ("{_escape_jql(RELEASE_SEED_FALLBACK)}") '
            f'or cf[18972] in ("{_escape_jql(RELEASE_SEED_FALLBACK)}"))'
            + ' ORDER BY created DESC'
        )
        try:
            issues = fetch_open_defects(
                jql=seed_jql, max_results=1, username=username, password=password,
                fields=[RELEASE_FIELD_KEY], expand='names',
            )
            if not issues:
                return []
            issue_key = (issues[0] or {}).get('key')
            if not issue_key:
                return []
            editmeta = fetch_issue_editmeta(issue_key, username=username, password=password)
            field_meta = (editmeta.get('fields') or {}).get(RELEASE_FIELD_KEY) or {}
            allowed_values = field_meta.get('allowedValues') or []
            options = []
            for av in allowed_values:
                text = (av.get('value') or av.get('name') or '').strip()
                if text:
                    options.append(text)
            return sorted(set(options), key=str.casefold)
        except Exception:
            LOGGER.exception("Failed to fetch release options for cancellation report.")
            return []
