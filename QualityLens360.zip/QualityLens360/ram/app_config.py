"""
RAM Application Configuration Module (Consolidated)

Consolidates all application configuration, KPI tile definitions,
and application-specific metadata for the RAM module.

This module is self-contained and does not depend on external application definition files.
"""

import json
import re
from pathlib import Path

from ram.acc_prod.config import ACC_PROD_APPLICATION
from ram.aces_ist.config import ACES_IST_APPLICATION


# ============================================================================
# APPLICATION REGISTRY
# ============================================================================

RAM_APPLICATION_DEFINITIONS = {
    ACC_PROD_APPLICATION['name']: ACC_PROD_APPLICATION,
    ACES_IST_APPLICATION['name']: ACES_IST_APPLICATION,
}

RAM_APPLICATION_OPTIONS = [
    'ACC-Prod',
    'ACC-PreProd',
    'Digital-Prod',
    'Digital-PreProd',
    'ACES-IST',
]

# Frozen copy of the base application list — used by other modules (Operations,
# Advanced Reporting, DefectLens) so that custom apps added via the RAM chatbot
# do NOT leak into those modules.
RAM_CORE_APPLICATION_OPTIONS = list(RAM_APPLICATION_OPTIONS)

RAM_DISPLAY_ONLY_APPLICATIONS = set(RAM_APPLICATION_OPTIONS) - set(RAM_APPLICATION_DEFINITIONS)


# ============================================================================
# CUSTOM APPLICATION PERSISTENCE
# ============================================================================

_CUSTOM_APPS_PATH = Path(__file__).resolve().parent / '_kpi_configs' / '_applications.json'


def _load_custom_applications():
    """Load user-defined applications from JSON and merge into the registry."""
    if not _CUSTOM_APPS_PATH.exists():
        return
    try:
        with open(_CUSTOM_APPS_PATH, 'r', encoding='utf-8') as fh:
            custom_apps = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return
    for app in custom_apps:
        name = app.get('name', '').strip()
        if not name:
            continue
        RAM_APPLICATION_DEFINITIONS[name] = app
        if name not in RAM_APPLICATION_OPTIONS:
            RAM_APPLICATION_OPTIONS.append(name)
    RAM_DISPLAY_ONLY_APPLICATIONS.clear()
    RAM_DISPLAY_ONLY_APPLICATIONS.update(set(RAM_APPLICATION_OPTIONS) - set(RAM_APPLICATION_DEFINITIONS))


def save_custom_application(app_definition):
    """Save a new custom application to persistent storage and register it."""
    _CUSTOM_APPS_PATH.parent.mkdir(exist_ok=True)
    existing = []
    if _CUSTOM_APPS_PATH.exists():
        try:
            with open(_CUSTOM_APPS_PATH, 'r', encoding='utf-8') as fh:
                existing = json.load(fh)
        except (json.JSONDecodeError, OSError):
            existing = []
    existing = [a for a in existing if a.get('name') != app_definition['name']]
    existing.append(app_definition)
    with open(_CUSTOM_APPS_PATH, 'w', encoding='utf-8') as fh:
        json.dump(existing, fh, indent=2, ensure_ascii=False)
    name = app_definition['name']
    RAM_APPLICATION_DEFINITIONS[name] = app_definition
    if name not in RAM_APPLICATION_OPTIONS:
        RAM_APPLICATION_OPTIONS.append(name)
    RAM_DISPLAY_ONLY_APPLICATIONS.discard(name)


def remove_custom_application(app_name):
    """Remove a custom application from persistent storage and the registry."""
    if not _CUSTOM_APPS_PATH.exists():
        return False
    try:
        with open(_CUSTOM_APPS_PATH, 'r', encoding='utf-8') as fh:
            existing = json.load(fh)
    except (json.JSONDecodeError, OSError):
        return False
    original_count = len(existing)
    existing = [a for a in existing if a.get('name') != app_name]
    if len(existing) == original_count:
        return False
    with open(_CUSTOM_APPS_PATH, 'w', encoding='utf-8') as fh:
        json.dump(existing, fh, indent=2, ensure_ascii=False)
    RAM_APPLICATION_DEFINITIONS.pop(app_name, None)
    if app_name in RAM_APPLICATION_OPTIONS:
        RAM_APPLICATION_OPTIONS.remove(app_name)
    RAM_DISPLAY_ONLY_APPLICATIONS.discard(app_name)
    return True


def get_custom_application_names():
    """Return names of user-created applications."""
    if not _CUSTOM_APPS_PATH.exists():
        return []
    try:
        with open(_CUSTOM_APPS_PATH, 'r', encoding='utf-8') as fh:
            return [a.get('name', '') for a in json.load(fh) if a.get('name')]
    except (json.JSONDecodeError, OSError):
        return []


_load_custom_applications()


# ============================================================================
# KPI TILE DEFINITIONS
# ============================================================================

RAM_KPI_TILES = [
    {
        'id': 'production-defect-leakage',
        'title': 'Defect Leakage (AOTs=Y | PhaseFoundIn = Production | Sev1-4)',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of valid defects found in Prod / (No. of valid defects found in Prod + Overall Valid Defects created in Pre-Prod for the selected period)',
    },
    {
        'id': 'defect-leakage-alt',
        'title': 'Defect Leakage*',
        'section': 'Functional Efficiency Metrics',
        'formula': 'No. of valid defects found in Prod / (No. of valid defects found in Prod + Overall Valid Defects created in Pre-Prod for the selected period)',
    },
    {
        'id': 'triage-efficiency',
        'title': 'Triage Efficiency',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of defects where STATUS not in ("To Do") / Overall Defects',
    },
    {
        'id': 'cancellation-rate',
        'title': 'Cancellation Rate',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of defects where STATUS in (Cancelled) / Overall Defects',
    },
    {
        'id': 'cancellation-efficiency-by-triage',
        'title': 'Cancellation Efficiency by Triage',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of cancelled defects where Assigned to Team is not Development in the entire lifecycle / No. of defects where STATUS in (Cancelled)',
    },
    {
        'id': 'defect-burndown-rate',
        'title': 'Defect Burndown Rate',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of defects resolved for the selected period / (No. of defects resolved for the selected period + Overall Open Defects where STATUS not in (Accepted, Cancelled))',
    },
    {
        'id': 'retest-defects-ontime-action-rate',
        'title': 'Retest Defects: OnTime Action Rate',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of defects moved out of Retest within 3 working days of moving to Retest / Total number of defects moved to Retest',
    },
    {
        'id': 'return-rejected-defects-ontime-action-rate',
        'title': 'Return/Rejected Defects: OnTime Action Rate',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'No. of defects moved out of Returned/Rejected within 3 working days of moving to Returned/Rejected / Total number of defects moved to Returned/Rejected',
    },
    {
        'id': 'triage-productivity-improvement',
        'title': 'Triage Productivity Improvement',
        'section': 'Defect Triage & Management Metrics',
        'formula': '(Current year productivity - previous year productivity for selected period)/Previous year productivity *100',
    },
    {
        'id': 'defect-acceptance-rate',
        'title': 'Defect Acceptance Rate',
        'section': 'Defect Triage & Management Metrics',
        'formula': 'Defects in Accepted status / Overall Defects',
    },
    {
        'id': 'defect-density',
        'title': 'Defect Vs Feature Ratio*',
        'section': 'Functional Efficiency Metrics',
    },
    {
        'id': 'productivity-improvement',
        'title': 'Productivity Improvement*',
        'section': 'Functional Efficiency Metrics',
    },
    {
        'id': 'automation-coverage-overall',
        'title': 'Automation Coverage (Against Overall)*',
        'section': 'Automation Efficiency Metrics',
        'formula': 'No. of test cases automated/Overall test cases',
    },
    {
        'id': 'automation-coverage-automatable',
        'title': 'Automation Coverage (Against Automatable)*',
        'section': 'Automation Efficiency Metrics',
        'formula': 'No. of test cases automated/(No. of Automatable test cases + No. of test cases yet to analyze)',
    },
    {
        'id': 'defect-discovery-rate',
        'title': 'Defect Discovery Rate*',
        'section': 'Automation Efficiency Metrics',
        'formula': 'No. of valid defects found by Automated Runs/No. of valid regression defects logged',
    },
    {
        'id': 'automation-utilization',
        'title': 'Automation Utilization*',
        'section': 'Automation Efficiency Metrics',
        'formula': 'No. of test cases executed by Automation/Total No. of test cases executed',
    },
]


# ============================================================================
# RAG TARGETS AND KPI TILE IDS BY APPLICATION
# ============================================================================

RAM_ACC_PROD_RAG_TARGETS = ACC_PROD_APPLICATION['rag_targets']
RAM_ACES_IST_RAG_TARGETS = ACES_IST_APPLICATION['rag_targets']
RAM_ACC_PROD_KPI_TILE_IDS = ACC_PROD_APPLICATION['tile_ids']
RAM_ACES_IST_KPI_TILE_IDS = ACES_IST_APPLICATION['tile_ids']

RAM_ACES_IST_KPI_SECTIONS = {
    tile_id: overrides['section']
    for tile_id, overrides in ACES_IST_APPLICATION['tile_overrides'].items()
    if 'section' in overrides
}

RAM_APPLICATION_KPI_TILE_IDS = {
    application_name: application_definition['tile_ids']
    for application_name, application_definition in RAM_APPLICATION_DEFINITIONS.items()
}


# ============================================================================
# RELEASE AND FIELD CONFIGURATION
# ============================================================================

RAM_RELEASED_APPLICATION = ACES_IST_APPLICATION['name']
RAM_RELEASE_FIELD_KEY = 'customfield_18971'
RAM_RELEASE_FIELD_NAME = 'Detected in Release'
RAM_RELEASE_SEED_FALLBACK = ACES_IST_APPLICATION['release_seed_fallback']

RAM_RELEASE_CLAUSE_PATTERN = re.compile(
    r'\(cf\[18971\]\s+in\s+\(".*?"\)\s+or\s+cf\[18972\]\s+in\s+\(".*?"\)\)',
    re.IGNORECASE,
)


# ============================================================================
# BASE JQL QUERIES BY APPLICATION
# ============================================================================

RAM_ACC_BASE_JQL = ACC_PROD_APPLICATION['base_jql']
RAM_ACC_PREPROD_BASE_JQL = ACC_PROD_APPLICATION['preprod_base_jql']
RAM_ACES_IST_BASE_JQL = ACES_IST_APPLICATION['base_jql']
RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS = ACES_IST_APPLICATION['defect_density_date_range_labels']


# ============================================================================
# PLACEHOLDER KPI HANDLER REGISTRY (To be populated at runtime)
# ============================================================================

RAM_APPLICATION_KPI_HANDLERS = {}


def register_kpi_handler(application_name, handler_function):
    """Register a KPI handler function for an application."""
    RAM_APPLICATION_KPI_HANDLERS[application_name] = handler_function


def get_ram_application_handler(application):
    """Get the KPI execution handler for a specific application."""
    return RAM_APPLICATION_KPI_HANDLERS.get(application)


def get_ram_application_definition(application):
    """Get the application definition for a specific application."""
    return RAM_APPLICATION_DEFINITIONS.get(application)


def get_ram_kpi_tile_ids(application):
    """Get KPI tile IDs for a specific application."""
    return RAM_APPLICATION_KPI_TILE_IDS.get(application, [])
