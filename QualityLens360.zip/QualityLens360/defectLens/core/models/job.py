"""Job record model used by the web application."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class JobRecord:
    """Mutable in-memory job state."""

    status: str = "queued"
    progress: float = 0.0
    message: str = "Queued"
    log: list[str] = field(default_factory=list)
    ai: str = ""
    aiTitle: str = ""
    aiPromptSignature: str = ""
    okrs: dict[str, Any] | None = None
    summary: dict[str, Any] | None = None
    topContrib: list[dict[str, Any]] = field(default_factory=list)
    topContribChart: dict[str, Any] = field(default_factory=dict)
    mttiContrib: list[dict[str, Any]] = field(default_factory=list)
    mttiContribChart: dict[str, Any] = field(default_factory=dict)
    mttfContrib: list[dict[str, Any]] = field(default_factory=list)
    mttfContribChart: dict[str, Any] = field(default_factory=dict)
    mttrContrib: list[dict[str, Any]] = field(default_factory=list)
    mttrContribChart: dict[str, Any] = field(default_factory=dict)
    output_path: str | None = None
    download_name: str | None = None
    error: str | None = None
    jql: str = ""
