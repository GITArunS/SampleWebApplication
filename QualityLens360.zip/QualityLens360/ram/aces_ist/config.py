"""
ACES-IST Application Configuration

Contains all JQL queries, RAG targets, KPI tile IDs, and application-specific
metadata for the ACES-IST application within the RAM module.
"""

ACES_IST_APPLICATION = {
    'name': 'ACES-IST',
    'base_jql': (
        'project = CDEX and '
        '(("Application Found In" ~ "GRP- CQE Org:24115" '
        'or "Application Found In" ~ BSSe-RTB:30914 '
        'or "Application Found In" ~ BSSe-OC:30909 '
        'or "Application Found In" ~ BSSe-MMap:31697 '
        'or "Application Found In" ~ BSSe-BB:31692 '
        'or "Application Found In" ~ BSSe-SkyFM:31452 '
        'or "Application Found In" ~ BSSe-C1:30911 '
        'or "Application Found In" ~ BSSe-NEO:31710 '
        'or "Application Found In" ~ BSSe-OH:30910 '
        'or "Application Found In" ~ BSSe-iPaaS:30912 '
        'or "Application Found In" ~ BSSe-ACF:32985) '
        'and "Phase Found In" in ("Integrated Solution Testing (IST)", "Smoke Testing", Development, "Scrum Testing", "Enterprise Certification Testing (ECT)", "Integrated Scrum to Scrum (ST)") '
        'or ("Phase Found In" in (Production, "Production Validation Testing (PVT)") and "Application Fixed In" ~ "BSSe*")) '
        'and "Defect Type" in (Defect, "Tracking Record", "Bug/Issue", "Production Defect") '
        'and (cf[16424] not in (PET, PET1, PET2, PET2Azure, PET3, PET3_EAST, PET3_West,NFT03) or cf[16424] is EMPTY) '
        'and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
        'and labels not in (ACC, ACC_IST, ACC_Sales, ACCINT, ACCUAT, csa, CSA_Triage, CSATriage, IST_ACC_CLM, IST_ACC_SALES, IST_ACC_SERVICE, PET2, Digital_Bsse_API, ECT_Digital) '
        'and "Phase Found In" in ("Integrated Solution Testing (IST)") '
        'and "Application Found In" ~ "GRP- CQE Org:24115"'
    ),
    'prod_defect_leakage_base_jql': (
        'project = CDEX and '
        '("Application Fixed In" ~ "BSSe*") and status not in (Cancelled) '
        'and "Phase Found In" in (Production) '
        'and "Defect Type" in (Defect, "Production Defect")'
    ),
    'preprod_defect_leakage_base_jql': (
        'project = CDEX and '
        '("Application Found In" ~ "GRP- CQE Org:24115" '
        'or "Application Found In" ~ BSSe-RTB:30914 '
        'or "Application Found In" ~ BSSe-OC:30909 '
        'or "Application Found In" ~ BSSe-MMap:31697 '
        'or "Application Found In" ~ BSSe-BB:31692 '
        'or "Application Found In" ~ BSSe-SkyFM:31452 '
        'or "Application Found In" ~ BSSe-C1:30911 '
        'or "Application Found In" ~ BSSe-NEO:31710 '
        'or "Application Found In" ~ BSSe-OH:30910 '
        'or "Application Found In" ~ BSSe-iPaaS:30912 '
        'or "Application Found In" ~ BSSe-ACF:32985 '
        'or "Application Fixed In" ~ "BSSe*") '
        'and "Phase Found In" in ("Integrated Solution Testing (IST)", "Smoke Testing", Development, '
        '"Scrum Testing", "Enterprise Certification Testing (ECT)", "Integrated Scrum to Scrum (ST)", "Performance/Load") '
        'and "Defect Type" in (Defect, "Tracking Record", "Bug/Issue", "Production Defect") '
        'and (cf[16424] not in (PET, PET1, PET2, PET2Azure, PET3, PET3_EAST, PET3_West,NFT03) or cf[16424] is EMPTY) '
        'and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
        'and labels not in (ACC, ACC_IST, ACC_Sales, ACCINT, ACCUAT, csa, CSA_Triage, CSATriage, '
        'IST_ACC_CLM, IST_ACC_SALES, IST_ACC_SERVICE, PET2, Digital_Bsse_API, ECT_Digital) '
    ),
    'automation_base_jql': (
        'project = BTEST and issuetype = Test and "Progression/Regression" = Regression '
        'and Status != Cancelled'
    ),
    'automation_coverage_automatable_numerator_jql': (
        'project = BTEST and issuetype = Test and "Progression/Regression" in (Regression) '
        'and Status != Cancelled '
        'and "Automated Script?" = Yes and ("User 5" ~ Automated or "User 5" ~ Partial)'
    ),
    'automation_coverage_automatable_denominator_jql': (
        'project = BTEST and issuetype = Test and "Progression/Regression" in (Regression) '
        'and Status != Cancelled '
        'and ("User 5" ~ Automated or "User 5" ~ Partial or "User 5" ~ "Automation in progress" '
        'or "User 5" is EMPTY or "User 5" ~ "Yet to analyze")'
    ),
    'defect_discovery_base_jql': (
        'project = CDEX and "Application Found In" ~ "GRP- CQE Org:24115" '
        'and "Defect Type" in (Defect) '
        'and cf[16424] not in (ACCINT, PET2, PET3_EAST, TEST3, TEST5, TMPAA, TMPAA-EAST, TMPAA-WEST, PET3_West, NFT03) '
        'and createdDate >= startOfYear() '
        'and "Progression/Regression" in (Regression)'
    ),
    'automation_utilization_fix_versions': (
        'BSSe PI 25.3',
        'BSSe PI 26.3',
        'BSSe PI 26.5',
        'BSSe PI 27.3',
        'BSSe PI 27.5'
    ),
    'automation_utilization_executed_by': (
        'sv8671',
        'sc589d',
        'sm664v',
        'sx0305',
        'ua9049',
        'pz517m',
        'kt4205',
        'nk295a',
        'sk2777',
        'tt475e',
        'pm9898',
    ),
    'tile_ids': [
        'triage-efficiency',
        'defect-burndown-rate',
        'defect-acceptance-rate',
        'retest-defects-ontime-action-rate',
        'return-rejected-defects-ontime-action-rate',
        'triage-productivity-improvement',
        'cancellation-rate',
        'defect-leakage-alt',
        'defect-density',
        'productivity-improvement',
        'automation-coverage-overall',
        'automation-coverage-automatable',
        'defect-discovery-rate',
        'automation-utilization',
    ],
    'rag_targets': {
        'defect-leakage-alt': {'direction': 'max', 'threshold': 10, 'label': '<=10%'},
        'triage-efficiency': {'direction': 'min', 'threshold': 95, 'label': '>=95%'},
        'defect-burndown-rate': {'direction': 'min', 'threshold': 80, 'label': '>=80%'},
        'defect-acceptance-rate': {'direction': 'min', 'threshold': 90, 'label': '>=90%'},
        'cancellation-rate': {'direction': 'min', 'threshold': 10, 'label': '>=10%'},
        'retest-defects-ontime-action-rate': {'direction': 'min', 'threshold': 80, 'label': '>=80%'},
        'return-rejected-defects-ontime-action-rate': {'direction': 'min', 'threshold': 80, 'label': '>=80%'},
        'triage-productivity-improvement': {'direction': 'min', 'threshold': 10, 'label': '>=10%'},
        'defect-density': {'direction': 'max', 'threshold': 1, 'label': '<1%'},
        'productivity-improvement': {'direction': 'min', 'threshold': 10, 'label': '>10%'},
        'automation-coverage-overall': {'direction': 'min', 'threshold': 65, 'label': '>65%'},
        'automation-coverage-automatable': {'direction': 'min', 'threshold': 90, 'label': '>90%'},
        'defect-discovery-rate': {'direction': 'min', 'threshold': 50, 'label': '>50%'},
        'automation-utilization': {'direction': 'min', 'threshold': 65, 'label': '>65%'},
    },
    'tile_overrides': {
        'triage-efficiency': {'section': 'Defect Triage & Management Metrics'},
        'defect-burndown-rate': {'section': 'Defect Triage & Management Metrics'},
        'defect-acceptance-rate': {'section': 'Defect Triage & Management Metrics'},
        'retest-defects-ontime-action-rate': {'section': 'Defect Triage & Management Metrics'},
        'return-rejected-defects-ontime-action-rate': {'section': 'Defect Triage & Management Metrics'},
        'triage-productivity-improvement': {'section': 'Defect Triage & Management Metrics'},
        'cancellation-rate': {'section': 'Defect Triage & Management Metrics'},
        'defect-leakage-alt': {},
        'defect-density': {},
        'productivity-improvement': {},
        'automation-coverage-overall': {},
        'automation-coverage-automatable': {},
        'defect-discovery-rate': {},
        'automation-utilization': {},
    },
    'release_seed_fallback': 'BSSe PI 27.5',
    'defect_density_date_range_labels': [
        '2026_ACES_IST_PI26.3',
        '2026_ACES_IST_PI26.5',
        '2026_ACES_IST_PI27.3',
        '2026_ACES_IST_PI27.5'
    ],
    'working_days': 3,
    'supports_release_filter': True,
}
