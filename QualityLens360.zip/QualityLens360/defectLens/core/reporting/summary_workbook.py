"""Workbook formatting and summary rendering helpers."""

from __future__ import annotations

from typing import Any

from openpyxl.chart import DoughnutChart, Reference
from openpyxl.chart.label import DataLabelList
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.views import Selection

from defectLens.core.reporting.excel_service import ExcelService

NOH_BUCKETS = [
    ("No Hops", lambda value: value == 0),
    ("1 Hop", lambda value: 0 < value <= 1),
    ("2 Hops", lambda value: 1 < value <= 2),
    ("3-5 Hops", lambda value: 3 <= value <= 5),
    ("6-10 Hops", lambda value: 6 <= value <= 10),
    (">10 Hops", lambda value: value >= 11),
]


def _find_last_data_row(ws, col: int = 1, min_row: int = 2) -> int:
    row_index = ws.max_row
    while row_index >= min_row:
        if ws.cell(row=row_index, column=col).value not in (None, ""):
            return row_index
        row_index -= 1
    return min_row - 1


def _find_last_used_row(ws) -> int:
    last = 1
    for row_index in range(1, ws.max_row + 1):
        has_value = False
        for column_index in range(1, ws.max_column + 1):
            if ws.cell(row=row_index, column=column_index).value not in (None, ""):
                has_value = True
                break
        if has_value:
            last = row_index
    return last


def set_sheet_open_at_top(ws, cell: str = "A1") -> None:
    """Ensure the workbook opens with the summary sheet scrolled to the top."""

    try:
        ws.sheet_view.topLeftCell = cell
        if ws.sheet_view.selection:
            ws.sheet_view.selection[0].activeCell = cell
            ws.sheet_view.selection[0].sqref = cell
        else:
            ws.sheet_view.selection = [Selection(activeCell=cell, sqref=cell)]
    except Exception:
        return


def auto_adjust_row_heights(
    ws,
    start_row: int = 2,
    end_row: int | None = None,
    base_height: int = 18,
    max_height: int = 240,
) -> None:
    """Size rows based on wrapped text across columns A through O."""

    final_row = ws.max_row if end_row is None else end_row
    for row_index in range(start_row, final_row + 1):
        max_lines = 1
        for column_index in range(1, 16):
            cell = ws.cell(row=row_index, column=column_index)
            if not cell.value:
                continue
            text = str(cell.value)
            approx = max(1, len(text) // 60)
            lines = text.count("\n") + approx
            max_lines = max(max_lines, lines)
        ws.row_dimensions[row_index].height = min(max_height, base_height * max_lines)


def clear_summary_from_row(ws, start_row: int = 15, clear_cols: int = 60, clear_rows: int = 1500) -> None:
    """Clear summary rows and embedded charts from the given starting row."""

    try:
        ws._charts = []
    except Exception:
        pass

    try:
        ws._images = []
    except Exception:
        pass

    default_font = Font()
    default_fill = PatternFill()
    default_border = Border()
    default_alignment = Alignment()
    end_row = start_row + clear_rows

    for row_index in range(start_row, end_row + 1):
        for column_index in range(1, clear_cols + 1):
            cell = ws.cell(row=row_index, column=column_index)
            cell.value = None
            cell.font = default_font
            cell.fill = default_fill
            cell.border = default_border
            cell.alignment = default_alignment
            cell.number_format = "General"


def style_summary_table(ws, start_row: int, start_col: int, last_row: int) -> None:
    """Apply the legacy summary table styling."""

    widths = {
        start_col + 0: 28,
        start_col + 1: 16,
        start_col + 2: 16,
        start_col + 3: 16,
    }
    for col_index, width in widths.items():
        ws.column_dimensions[get_column_letter(col_index)].width = width

    header_fill = PatternFill("solid", fgColor="BFBFBF")
    header_font = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left = Alignment(horizontal="left", vertical="center", wrap_text=False)
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for column_index in range(start_col, start_col + 4):
        cell = ws.cell(row=start_row, column=column_index)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = center
        cell.border = border

    for row_index in range(start_row + 1, last_row + 1):
        for column_index in range(start_col, start_col + 4):
            cell = ws.cell(row=row_index, column=column_index)
            cell.border = border
            cell.alignment = left if column_index == start_col else center


def write_summary_tab(
    excel: ExcelService,
    app_totals_minutes: dict[str, float],
    start_row: int = 15,
    start_col: int = 1,
    top_n_chart: int = 5,
) -> None:
    """Write the legacy hold-time summary table and doughnut chart."""

    ws = excel.get_or_create_sheet("Summary")
    try:
        excel.wb.calculation.fullCalcOnLoad = True
    except Exception:
        pass

    clear_summary_from_row(ws, start_row=start_row, clear_cols=60, clear_rows=1500)

    items = [(app_name, minutes) for app_name, minutes in app_totals_minutes.items() if minutes and minutes > 0]
    items.sort(key=lambda item: item[1], reverse=True)
    if not items:
        return

    col_app = start_col
    col_hours = start_col + 1
    col_days = start_col + 2
    col_pct = start_col + 3
    headers = ["Application", "Total Hours (cum)", "Total Days (cum)", "% Contribution"]
    for offset, value in enumerate(headers):
        ws.cell(row=start_row, column=start_col + offset).value = value

    first_data_row = start_row + 1
    last_data_row = start_row + len(items)
    days_letter = get_column_letter(col_days)

    for row_index, (app_name, minutes) in enumerate(items, start=first_data_row):
        ws.cell(row=row_index, column=col_app).value = app_name
        ws.cell(row=row_index, column=col_hours).value = round(minutes / 60.0, 2)
        ws.cell(row=row_index, column=col_days).value = round(minutes / 1440.0, 2)
        ws.cell(row=row_index, column=col_pct).value = (
            f"={days_letter}{row_index}/SUM(${days_letter}${first_data_row}:${days_letter}${last_data_row})"
        )
        ws.cell(row=row_index, column=col_pct).number_format = "0.0%"

    style_summary_table(ws, start_row=start_row, start_col=start_col, last_row=last_data_row)

    chart_rows = min(top_n_chart, len(items))
    chart_end_row = first_data_row + chart_rows - 1
    categories = Reference(ws, min_col=col_app, min_row=first_data_row, max_row=chart_end_row)
    values = Reference(ws, min_col=col_pct, min_row=first_data_row, max_row=chart_end_row)
    chart = DoughnutChart()
    chart.title = "Top 5 Contributors"
    chart.holeSize = 60
    chart.add_data(values, titles_from_data=False)
    chart.set_categories(categories)
    chart.dataLabels = DataLabelList()
    chart.dataLabels.showVal = True
    chart.dataLabels.showPercent = False
    chart.dataLabels.showCatName = False
    chart.dataLabels.showSerName = False
    chart.dataLabels.showLegendKey = False
    try:
        chart.legend.position = "b"
    except Exception:
        pass
    chart.height = 10
    chart.width = 18
    ws.add_chart(chart, "G15")


def compute_okrs_from_cdex_sheet(ws_cdex) -> dict[str, Any]:
    """Compute NOH distribution and FTRA from the formatted CDEX sheet."""

    counts = {label: 0 for label, _ in NOH_BUCKETS}
    total = 0
    for row_index in range(2, ws_cdex.max_row + 1):
        value = ws_cdex.cell(row=row_index, column=6).value
        if value in (None, ""):
            continue
        try:
            hops = float(value)
        except (TypeError, ValueError):
            continue

        total += 1
        for label, predicate in NOH_BUCKETS:
            if predicate(hops):
                counts[label] += 1
                break

    pct = {label: (counts[label] / total if total else 0.0) for label in counts}
    return {
        "total": total,
        "counts": counts,
        "pct": pct,
        "ftra": pct.get("No Hops", 0.0),
        "mttr": "TBD",
        "mtti": "TBD",
        "mttf": "TBD",
    }


def write_okrs_to_summary(excel: ExcelService, okrs: dict[str, Any]) -> None:
    """Write the executive OKR tiles into the workbook summary sheet."""

    ws = excel.get_or_create_sheet("Summary")
    blue = PatternFill("solid", fgColor="00B0F0")
    grey = PatternFill("solid", fgColor="BFBFBF")
    bold_white = Font(bold=True, color="FFFFFF")
    bold = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left = Alignment(horizontal="left", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    ws.merge_cells("A2:C2")
    ws["A2"].value = "NOH (No. of Hops)"
    ws["A2"].fill = blue
    ws["A2"].font = bold_white
    ws["A2"].alignment = center

    ws.merge_cells("E2:F2")
    ws["E2"].value = "FTRA (First Time Right Assignment)"
    ws["E2"].fill = blue
    ws["E2"].font = bold_white
    ws["E2"].alignment = center

    for address, value in (("A4", "No. of Hops"), ("B4", "CDEX#"), ("C4", "%")):
        ws[address].value = value
        ws[address].fill = grey
        ws[address].font = bold
        ws[address].alignment = center
        ws[address].border = border

    row_map = {
        "No Hops": 5,
        "1 Hop": 6,
        "2 Hops": 7,
        "3-5 Hops": 8,
        "6-10 Hops": 9,
        ">10 Hops": 10,
    }

    counts = okrs.get("counts", {})
    pct = okrs.get("pct", {})
    total = int(okrs.get("total", 0) or 0)
    for label, row_index in row_map.items():
        ws[f"A{row_index}"].value = label
        ws[f"A{row_index}"].alignment = left
        ws[f"A{row_index}"].border = border
        ws[f"B{row_index}"].value = int(counts.get(label, 0) or 0)
        ws[f"B{row_index}"].alignment = center
        ws[f"B{row_index}"].border = border
        ws[f"C{row_index}"].value = float(pct.get(label, 0.0) or 0.0)
        ws[f"C{row_index}"].number_format = "0%"
        ws[f"C{row_index}"].alignment = center
        ws[f"C{row_index}"].border = border

    ws["B11"].value = total
    ws["B11"].alignment = center
    ws["B11"].border = border
    ws["E5"].value = float(okrs.get("ftra", 0.0) or 0.0)
    ws["E5"].number_format = "0%"
    ws["E5"].alignment = center
    ws["E5"].border = border
    ws["E7"].value = "MTTR"
    ws["F7"].value = okrs.get("mttr", "TBD")
    ws["E8"].value = "MTTI"
    ws["F8"].value = okrs.get("mtti", "TBD")
    ws["E9"].value = "MTTF"
    ws["F9"].value = okrs.get("mttf", "TBD")
    for address in ("E7", "F7", "E8", "F8", "E9", "F9"):
        ws[address].border = border
        ws[address].alignment = left if address.startswith("F") else center

    set_sheet_open_at_top(ws, "A1")


def _build_metric_payload(metric_minutes: dict[str, float], top_n: int, title: str, include_hours: bool = False) -> dict[str, Any]:
    pairs: list[tuple[str, float]] = []
    for key, value in (metric_minutes or {}).items():
        try:
            minutes = float(value or 0.0)
        except (TypeError, ValueError):
            minutes = 0.0
        if minutes > 0:
            pairs.append((str(key), minutes))

    pairs.sort(key=lambda item: item[1], reverse=True)
    total_minutes = sum(value for _, value in pairs)
    rows: list[dict[str, Any]] = []
    for name, minutes in pairs:
        row = {
            "application": name,
            "days": round(minutes / 1440.0, 2),
            "pct": round(((minutes / total_minutes) if total_minutes else 0.0) * 100.0, 1),
        }
        if include_hours:
            row["hours"] = round(minutes / 60.0, 2)
        rows.append(row)

    top_rows = rows[:top_n]
    return {
        "rows": rows,
        "chart": {
            "title": title.format(count=min(top_n, len(top_rows))),
            "labels": [row["application"] for row in top_rows],
            "values": [row["pct"] for row in top_rows],
        },
        "totalCount": len(rows),
        "topN": top_n,
    }


def build_top_contributors_payload(app_totals_minutes: dict[str, float], top_n: int = 5) -> dict[str, Any]:
    return _build_metric_payload(app_totals_minutes, top_n, "Top {count} Contributors", include_hours=True)


def build_mtti_contributors_payload(team_mtti_minutes: dict[str, float], top_n: int = 5) -> dict[str, Any]:
    return _build_metric_payload(team_mtti_minutes, top_n, "Top {count} Contributors (MTTI)")


def build_mttf_contributors_payload(team_mttf_minutes: dict[str, float], top_n: int = 5) -> dict[str, Any]:
    return _build_metric_payload(team_mttf_minutes, top_n, "Top {count} Contributors (MTTF)")


def build_mttr_contributors_payload(team_mttr_minutes: dict[str, float], top_n: int = 5) -> dict[str, Any]:
    return _build_metric_payload(team_mttr_minutes, top_n, "Top {count} Contributors (MTTR)")


def _write_delay_driver_section(excel: ExcelService, title: str, metric_label: str, metric_minutes: dict[str, float], top_n: int) -> None:
    ws = excel.get_or_create_sheet("Summary")
    start_row = _find_last_used_row(ws) + 2
    start_col = 1
    chart_start_col = 5
    blue = PatternFill("solid", fgColor="00B0F0")
    grey = PatternFill("solid", fgColor="BFBFBF")
    bold_white = Font(bold=True, color="FFFFFF")
    bold = Font(bold=True)
    center = Alignment(horizontal="center", vertical="center", wrap_text=True)
    left = Alignment(horizontal="left", vertical="center", wrap_text=True)
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    pairs = [(str(key), float(value or 0.0)) for key, value in (metric_minutes or {}).items() if float(value or 0.0) > 0]
    pairs.sort(key=lambda item: item[1], reverse=True)
    total_minutes = sum(value for _, value in pairs)

    ws.merge_cells(start_row=start_row, start_column=start_col, end_row=start_row, end_column=start_col + 2)
    ws.cell(start_row, start_col).value = title
    ws.cell(start_row, start_col).fill = blue
    ws.cell(start_row, start_col).font = bold_white
    ws.cell(start_row, start_col).alignment = center

    header_row = start_row + 2
    headers = ("Last Assigned Team", metric_label, "% Contribution")
    for offset, header in enumerate(headers):
        cell = ws.cell(header_row, start_col + offset)
        cell.value = header
        cell.fill = grey
        cell.font = bold
        cell.alignment = center
        cell.border = border

    data_start_row = header_row + 1
    for offset, (team_name, minutes) in enumerate(pairs):
        row_index = data_start_row + offset
        days = minutes / 1440.0
        contribution = (minutes / total_minutes) if total_minutes else 0.0
        ws.cell(row_index, start_col).value = team_name
        ws.cell(row_index, start_col).alignment = left
        ws.cell(row_index, start_col).border = border
        ws.cell(row_index, start_col + 1).value = float(days)
        ws.cell(row_index, start_col + 1).number_format = "0.00"
        ws.cell(row_index, start_col + 1).alignment = center
        ws.cell(row_index, start_col + 1).border = border
        ws.cell(row_index, start_col + 2).value = float(contribution)
        ws.cell(row_index, start_col + 2).number_format = "0.0%"
        ws.cell(row_index, start_col + 2).alignment = center
        ws.cell(row_index, start_col + 2).border = border

    ws.merge_cells(start_row=start_row, start_column=chart_start_col, end_row=start_row, end_column=chart_start_col + 2)
    ws.cell(start_row, chart_start_col).value = f"Top 5 Contributors ({metric_label.split()[0]})"
    ws.cell(start_row, chart_start_col).fill = blue
    ws.cell(start_row, chart_start_col).font = bold_white
    ws.cell(start_row, chart_start_col).alignment = center

    top_count = min(top_n, len(pairs))
    if top_count > 0:
        values_ref = Reference(ws, min_col=start_col + 1, min_row=data_start_row, max_row=data_start_row + top_count - 1)
        labels_ref = Reference(ws, min_col=start_col, min_row=data_start_row, max_row=data_start_row + top_count - 1)
        chart = DoughnutChart()
        chart.add_data(values_ref, titles_from_data=False)
        chart.set_categories(labels_ref)
        chart.title = None
        chart.dataLabels = DataLabelList()
        chart.dataLabels.showPercent = True
        chart.dataLabels.showLeaderLines = True
        chart.dataLabels.showSerName = False
        chart.dataLabels.showCategoryName = False
        chart.dataLabels.showVal = False
        chart.dataLabels.showLegendKey = False
        anchor = f"{get_column_letter(chart_start_col)}{start_row + 1}"
        ws.add_chart(chart, anchor)

    set_sheet_open_at_top(ws, "A1")


def write_mtti_delay_drivers_to_summary(excel: ExcelService, team_mtti_minutes: dict[str, float], top_n: int = 5) -> None:
    _write_delay_driver_section(excel, "Defect Delay Drivers - MTTI", "MTTI (Days)", team_mtti_minutes, top_n)


def write_mttf_delay_drivers_to_summary(excel: ExcelService, team_mttf_minutes: dict[str, float], top_n: int = 5) -> None:
    _write_delay_driver_section(excel, "Defect Delay Drivers - MTTF", "MTTF (Days)", team_mttf_minutes, top_n)


def write_mttr_delay_drivers_to_summary(excel: ExcelService, team_mttr_minutes: dict[str, float], top_n: int = 5) -> None:
    _write_delay_driver_section(excel, "Defect Delay Drivers - MTTR", "MTTR (Days)", team_mttr_minutes, top_n)


def format_cdex_sheet(excel: ExcelService, sheet_name: str) -> None:
    """Apply header styling to the CDEX worksheet."""

    ws = excel.wb[sheet_name] if sheet_name in excel.wb.sheetnames else excel.ws
    headers = [
        "CDEX#",
        "Severity",
        "Application Fixed In - Details on Hops",
        "# Hops",
        "No. of Unique Application Teams Involved",
        "Actual Hops",
        "Time Taken by Each Application",
        "Last Assigned Team Name",
        "Created",
        "Last App Fixed In Timestamp",
        "Dev Complete / Retest Timestamp",
        "Resolved Timestamp",
        "MTTI",
        "MTTF",
        "MTTR",
    ]
    for col_index, name in enumerate(headers, start=1):
        ws.cell(1, col_index).value = name

    header_fill = PatternFill("solid", fgColor="00B0F0")
    header_font = Font(bold=True, color="FFFFFF")
    top_left_wrap = Alignment(horizontal="left", vertical="top", wrap_text=True)
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for col_index in range(1, 16):
        cell = ws.cell(1, col_index)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = top_left_wrap
        cell.border = border

    ws.auto_filter.ref = "A1:O1"
    ws.freeze_panes = "A2"
    set_sheet_open_at_top(ws, "A1")


def apply_cdex_table_borders_and_alignment(excel: ExcelService, sheet_name: str) -> None:
    """Apply borders, alignment, and row sizing to the CDEX worksheet."""

    ws = excel.wb[sheet_name] if sheet_name in excel.wb.sheetnames else excel.ws
    last_row = _find_last_data_row(ws, col=1, min_row=2)
    if last_row < 2:
        last_row = 2

    top_left_wrap = Alignment(horizontal="left", vertical="top", wrap_text=True)
    thin = Side(style="thin", color="000000")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for row_index in range(1, last_row + 1):
        for col_index in range(1, 16):
            cell = ws.cell(row=row_index, column=col_index)
            cell.alignment = top_left_wrap
            cell.border = border

    auto_adjust_row_heights(ws, start_row=2, end_row=last_row, base_height=18, max_height=240)


def ensure_summary_view_and_formulas(excel: ExcelService) -> None:
    """Force formula recalculation and open the summary sheet at the top."""

    ws = excel.get_or_create_sheet("Summary")
    try:
        excel.wb.calculation.fullCalcOnLoad = True
    except Exception:
        pass
    set_sheet_open_at_top(ws, "A1")
