"""
RAM Core — KPI Calculations & Query Execution

Stable shared KPI formulas, query executor, and data-fetch utilities.
Changes here are infrequent and should be coordinated across teams.
"""

from datetime import datetime, timedelta

import requests

from shared.shared_logic import (
    ASSIGNED_TO_TEAM_FIELD_KEY,
    IST_TIMEZONE,
    fetch_issue_count,
    fetch_open_defects,
    fetch_issue_editmeta,
    parse_jira_datetime,
)
from ram.core.jql_helpers import (
    build_ram_base_jql,
    build_ram_release_scoped_jql,
)


# ============================================================================
# QUERY EXECUTOR
# ============================================================================

def execute_ram_query(query_label, query_callable, ram_warnings, format_http_error_message):
    try:
        return query_callable()
    except requests.HTTPError as error:
        ram_warnings.append(format_http_error_message(query_label, error))
    except requests.RequestException as error:
        ram_warnings.append(f'{query_label} failed while pulling data from Jira/iTrack: {error}')
    return None


# ============================================================================
# SHARED KPI FORMULAS
# ============================================================================

def calculate_production_defect_leakage_kpi(production_defect_count, preprod_defect_count):
    denominator = production_defect_count + preprod_defect_count
    percentage_value = round((production_defect_count / denominator) * 100) if denominator else 0
    return {
        'percentage': f'{percentage_value}%',
        'numerator': production_defect_count,
        'denominator': denominator,
        'logic': 'No. of valid defects found in Prod / (No. of valid defects found in Prod + Overall Valid Defects created in Pre-Prod for the selected period)',
    }


def calculate_triage_efficiency_kpi(overall_defects, triaged_defects):
    percentage_value = round((triaged_defects / overall_defects) * 100) if overall_defects else 0
    return {
        'percentage': f'{percentage_value}%',
        'numerator': triaged_defects,
        'denominator': overall_defects,
        'logic': 'No. of defects where STATUS not in ("To Do") / Overall Defects',
    }


def calculate_defect_burndown_rate_kpi(resolved_period_defects, overall_open_defects):
    denominator = resolved_period_defects + overall_open_defects
    return {
        'percentage': f'{round((resolved_period_defects / denominator) * 100) if denominator else 0}%',
        'numerator': resolved_period_defects,
        'denominator': denominator,
        'logic': 'No. of defects resolved for the selected period / (No. of defects resolved for the selected period + Overall Open Defects where STATUS not in (Accepted, Cancelled))',
    }


def calculate_defect_acceptance_rate_kpi(overall_defects, accepted_defects, cancelled_defects=0):
    denominator = max(0, overall_defects - (cancelled_defects or 0))
    return {
        'percentage': f'{round((accepted_defects / denominator) * 100) if denominator else 0}%',
        'numerator': accepted_defects,
        'denominator': denominator,
        'logic': 'Defects in Accepted status / (Overall Defects - Defects in STATUS in (Cancelled))',
    }


# ============================================================================
# ON-TIME ACTION RATE (STATUS LIFECYCLE TRACKING)
# ============================================================================

def stringify_select_value(value):
    if value is None:
        return ''
    if isinstance(value, dict):
        return (value.get('value') or value.get('name') or '').strip()
    return str(value).strip()


def build_status_transitions(issue):
    transitions = []
    for history in ((issue.get('changelog') or {}).get('histories') or []):
        history_created = parse_jira_datetime(history.get('created'))
        if history_created is None:
            continue
        for item in history.get('items') or []:
            if stringify_select_value(item.get('field')).casefold() != 'status':
                continue
            transitions.append(
                {
                    'changed_at': history_created.astimezone(IST_TIMEZONE),
                    'from_value': stringify_select_value(item.get('fromString')),
                    'to_value': stringify_select_value(item.get('toString')),
                }
            )
    transitions.sort(key=lambda entry: entry['changed_at'])
    return transitions


def add_working_days(start_datetime, working_days):
    current_datetime = start_datetime
    remaining_days = max(0, int(working_days))
    while remaining_days > 0:
        current_datetime += timedelta(days=1)
        if current_datetime.weekday() < 5:
            remaining_days -= 1
    return current_datetime


def calculate_status_on_time_action_rate(issue_collection, target_statuses, working_days=3):
    normalized_targets = {status.casefold() for status in target_statuses}
    total_entered = 0
    moved_out_on_time = 0
    for issue in issue_collection:
        transitions = build_status_transitions(issue)
        qualifying_exit_found = False
        entered_target = False
        for index, transition in enumerate(transitions):
            to_status = transition['to_value'].casefold()
            if to_status not in normalized_targets:
                continue
            entered_target = True
            total_entered += 1
            deadline = add_working_days(transition['changed_at'], working_days)
            for later_transition in transitions[index + 1:]:
                later_to_status = later_transition['to_value'].casefold()
                if later_to_status in normalized_targets:
                    continue
                if later_transition['changed_at'] <= deadline:
                    qualifying_exit_found = True
                break
            if qualifying_exit_found:
                moved_out_on_time += 1
                break
        if not entered_target:
            continue
    percentage = round((moved_out_on_time / total_entered) * 100) if total_entered else 0
    return {
        'percentage': f'{percentage}%',
        'numerator': moved_out_on_time,
        'denominator': total_entered,
    }


# ============================================================================
# SHARED DATA FETCH HELPERS
# ============================================================================

def fetch_ram_label_issues(jql, username, password, batch_size=200):
    issues = []
    start_at = 0
    while True:
        batch_issues = fetch_open_defects(
            jql=jql,
            max_results=batch_size,
            username=username,
            password=password,
            start_at=start_at,
            fields=['labels'],
        )
        if not batch_issues:
            break
        issues.extend(batch_issues)
        if len(batch_issues) < batch_size:
            break
        start_at += len(batch_issues)
    return issues


def fetch_ram_status_history_issues(jql, username, password, batch_size=25):
    issues = []
    start_at = 0
    while True:
        batch_issues = fetch_open_defects(
            jql=jql,
            max_results=batch_size,
            username=username,
            password=password,
            start_at=start_at,
            fields=['status', ASSIGNED_TO_TEAM_FIELD_KEY],
            expand='changelog',
        )
        if not batch_issues:
            break
        issues.extend(batch_issues)
        if len(batch_issues) < batch_size:
            break
        start_at += len(batch_issues)
    return issues


def fetch_ram_created_date_issues(jql, username, password, batch_size=200):
    issues = []
    start_at = 0
    while True:
        batch_issues = fetch_open_defects(
            jql=jql,
            max_results=batch_size,
            username=username,
            password=password,
            start_at=start_at,
            fields=['created'],
        )
        if not batch_issues:
            break
        issues.extend(batch_issues)
        if len(batch_issues) < batch_size:
            break
        start_at += len(batch_issues)
    return issues


def resolve_ram_created_date_bounds(issue_collection):
    created_dates = []
    for issue in issue_collection or []:
        created_value = ((issue.get('fields') or {}).get('created'))
        created_at = parse_jira_datetime(created_value)
        if created_at is not None:
            created_dates.append(created_at.astimezone(IST_TIMEZONE).date())
    if not created_dates:
        return None, None
    return min(created_dates).isoformat(), max(created_dates).isoformat()


def fetch_ram_release_options(username=None, password=None, release_name=None):
    from ram.app_config import RAM_RELEASE_FIELD_KEY, RAM_RELEASE_SEED_FALLBACK, RAM_RELEASED_APPLICATION

    seed_release_name = (release_name or RAM_RELEASE_SEED_FALLBACK).strip()
    seed_jql = build_ram_release_scoped_jql(build_ram_base_jql(RAM_RELEASED_APPLICATION), seed_release_name)
    seed_issues = fetch_open_defects(
        jql=seed_jql,
        max_results=1,
        username=username,
        password=password,
        fields=[RAM_RELEASE_FIELD_KEY],
        expand='names',
    )
    if not seed_issues:
        return []
    issue_key = (seed_issues[0] or {}).get('key')
    if not issue_key:
        return []
    editmeta = fetch_issue_editmeta(issue_key, username=username, password=password)
    field_meta = (editmeta.get('fields') or {}).get(RAM_RELEASE_FIELD_KEY) or {}
    allowed_values = field_meta.get('allowedValues') or []
    release_options = []
    for allowed_value in allowed_values:
        option_text = stringify_select_value(allowed_value.get('value') or allowed_value.get('name'))
        if option_text:
            release_options.append(option_text)
    return sorted(set(release_options), key=str.casefold)


# ============================================================================
# PERIOD UTILITIES
# ============================================================================

def count_days_in_selected_period(created_from, created_to):
    start_date = datetime.strptime(created_from, '%Y-%m-%d').date()
    end_date = datetime.strptime(created_to, '%Y-%m-%d').date()
    return max(1, (end_date - start_date).days + 1)


def count_months_in_selected_period(created_from, created_to):
    start_date = datetime.strptime(created_from, '%Y-%m-%d').date()
    end_date = datetime.strptime(created_to, '%Y-%m-%d').date()
    return max(1, (end_date.year - start_date.year) * 12 + (end_date.month - start_date.month) + 1)


def count_working_days_in_period(date_from, date_to):
    """Count Mon-Fri weekdays in the inclusive range [date_from, date_to]."""
    start = datetime.strptime(date_from, '%Y-%m-%d').date()
    end = datetime.strptime(date_to, '%Y-%m-%d').date()
    if start > end:
        return 1
    total = 0
    current = start
    while current <= end:
        if current.weekday() < 5:
            total += 1
        current += timedelta(days=1)
    return max(1, total)
