import re
from datetime import datetime, timedelta
import io
import math
from time import perf_counter

from flask import redirect, render_template, request, send_file, session, url_for, jsonify
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
import requests

from ram.app_config import (
    RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS,
    RAM_APPLICATION_DEFINITIONS,
    RAM_DISPLAY_ONLY_APPLICATIONS,
    RAM_APPLICATION_OPTIONS,
    RAM_KPI_TILES,
    RAM_RELEASE_CLAUSE_PATTERN,
    RAM_RELEASE_FIELD_KEY,
    RAM_RELEASE_FIELD_NAME,
    RAM_RELEASE_SEED_FALLBACK,
    RAM_RELEASED_APPLICATION,
    get_ram_application_handler,
    get_ram_application_definition,
    register_kpi_handler,
)
from shared.shared_config import JIRA_USER
from shared.shared_logic import (
    ASSIGNED_TO_TEAM_FIELD_KEY,
    ASSIGNED_TO_TEAM_FIELD_NAME,
    IST_TIMEZONE,
    fetch_issue_count,
    fetch_open_defects,
    fetch_issue_editmeta,
    get_select_field_transitions,
    parse_jira_datetime,
)

# --- Shared core infrastructure ---
from ram.core.jql_helpers import (
    build_cancelled_ram_jql,
    build_open_ram_jql,
    build_ram_base_jql,
    build_ram_jql,
    build_ram_release_clause,
    build_ram_release_clause_for_values,
    build_ram_release_scoped_jql,
    build_ram_scope_jql,
    build_ram_status_changed_during_jql,
    build_ram_status_changed_jql,
    build_ram_status_history_jql,
    build_ram_status_scope_jql,
    build_resolved_period_ram_jql,
    build_triaged_last_calendar_year_ram_jql,
    build_triaged_last_year_ram_jql,
    build_triaged_ram_jql,
    escape_ram_jql_string,
    get_last_calendar_year_bounds,
    is_acc_ram_application,
    is_ram_display_only_application,
    shift_ram_period_to_last_year,
    strip_created_date_clauses,
)
from ram.core.kpi_calculations import (
    calculate_defect_acceptance_rate_kpi,
    calculate_defect_burndown_rate_kpi,
    calculate_production_defect_leakage_kpi,
    calculate_status_on_time_action_rate,
    calculate_triage_efficiency_kpi,
    count_days_in_selected_period,
    count_months_in_selected_period,
    count_working_days_in_period,
    execute_ram_query,
    fetch_ram_created_date_issues,
    fetch_ram_label_issues,
    fetch_ram_release_options,
    fetch_ram_status_history_issues,
    resolve_ram_created_date_bounds,
    stringify_select_value,
)

# --- ACC-Prod specific ---
from ram.acc_prod.jql_queries import (
    build_preprod_defects_ram_jql,
    build_production_defect_leakage_jql,
    fetch_ram_cancelled_issues,
    issue_has_non_development_assigned_team_entire_lifecycle,
)

# --- ACES-IST specific ---
from ram.aces_ist.jql_queries import (
    build_accepted_ram_jql,
    build_active_defect_density_ram_jql,
    build_aces_ist_defect_leakage_scope_jql,
    build_defect_density_denominator_ram_jql,
    build_defect_density_formula,
    build_full_year_created_scope_jql,
    build_labels_only_ram_jql,
    build_productivity_improvement_denominator_labels,
    build_productivity_improvement_formula,
    build_productivity_improvement_label,
    build_release_names_from_configured_labels,
    build_resolved_burndown_ram_jql,
    calculate_absolute_percentage_change,
    calculate_percentage_change,
    count_unique_defect_density_labels,
    extract_release_numeric_from_label,
    extract_release_numeric_value,
    filter_release_labels_by_year_notation,
    get_current_year_bounds,
    get_latest_productivity_improvement_label,
    get_selected_year_notations,
    parse_release_label_numeric_value,
    resolve_release_label_for_selected_release,
)
from ram.aces_ist.zephyr import fetch_zephyr_zql_total_count
from ram.kpi_chat import load_custom_kpis

class RamFeature:
    def __init__(self, get_session_credentials, format_http_error_message):
        self.get_session_credentials = get_session_credentials
        self.format_http_error_message = format_http_error_message

    def register(self, app, login_required):
        @app.route('/ram')
        @login_required
        def ram_page():
            credentials = self.get_session_credentials() or {}
            selected_application = (request.args.get('application') or '').strip()
            selected_application_definition = get_ram_application_definition(selected_application)
            created_from = (request.args.get('created_from') or '').strip()
            created_to = (request.args.get('created_to') or '').strip()
            selected_release = (request.args.get('release_name') or '').strip()
            effective_selected_release = '' if created_from and created_to else selected_release
            run_requested = (request.args.get('run_requested') or '').strip() == '1'
            ram_error = None
            ram_warnings = []
            executed_jql = None
            kpi_tiles = build_ram_kpi_tiles(
                selected_application,
                created_from=created_from,
                created_to=created_to,
                release_name=effective_selected_release,
            )
            custom_kpis = load_custom_kpis(selected_application) if selected_application else []
            for ckpi in custom_kpis:
                kpi_tiles.append({
                    'id': ckpi['id'],
                    'title': ckpi['title'],
                    'formula': ckpi.get('formula', ''),
                    'section': 'Custom KPIs',
                    'rag_status': 'neutral',
                    '_custom': True,
                    '_formula_type': ckpi.get('formula_type', 'percentage'),
                    '_numerator_jql': ckpi.get('numerator_jql', ''),
                    '_denominator_jql': ckpi.get('denominator_jql', ''),
                    '_comparison_mode': ckpi.get('comparison_mode', 'date'),
                    '_statuses': ckpi.get('statuses', []),
                    '_action_working_days': ckpi.get('action_working_days', 3),
                    '_rag_target': ckpi.get('rag_target'),
                })
            kpi_sections = build_ram_kpi_sections(kpi_tiles)
            ram_run_duration = None
            ram_export_ready = False
            release_options = []
            release_error = None

            if selected_application_definition and selected_application_definition.get('supports_release_filter'):
                try:
                    release_options = fetch_ram_release_options(
                        username=credentials.get('username'),
                        password=credentials.get('password'),
                        release_name=selected_release,
                    )
                except requests.RequestException as error:
                    release_error = f'Unable to load {RAM_RELEASE_FIELD_NAME} values from Jira/iTrack: {error}'
                except ValueError as error:
                    release_error = str(error)

            session.pop('ram_kpi_export', None)

            if run_requested:
                has_complete_date_range = bool(created_from and created_to)
                has_release_filter = bool(selected_release)
                if not selected_application:
                    ram_error = 'Select Application before running RAM.'
                elif not (has_complete_date_range or has_release_filter):
                    ram_error = 'Select either Defect Creation Date From and To, or choose a Release, before running RAM.'
                elif created_from and created_to and created_from > created_to:
                    ram_error = 'Defect Creation Date From cannot be later than Defect Creation Date To.'
                elif (created_from and not created_to) or (created_to and not created_from):
                    ram_error = 'Provide both Defect Creation Date From and Defect Creation Date To, or use Release instead.'
                elif is_ram_display_only_application(selected_application):
                    ram_error = f'RAM KPI calculations for {selected_application} are not wired yet. The planned KPI layout is displayed below.'
                    mark_ram_tiles_unavailable(
                        kpi_tiles,
                        f'{selected_application} KPI calculation logic is not wired yet.',
                    )
                else:
                    run_started_at = perf_counter()
                    try:
                        base_ram_jql = build_ram_base_jql(selected_application)
                        executed_jql = build_ram_jql(selected_application, created_from, created_to, effective_selected_release)
                        triage_efficiency = None
                        cancellation_rate = None
                        cancellation_efficiency_by_triage = None
                        production_defect_leakage = None
                        defect_leakage_alt = None
                        defect_burndown_rate = None
                        defect_density = None
                        productivity_improvement = None
                        automation_coverage_overall = None
                        automation_coverage_automatable = None
                        defect_discovery_rate = None
                        automation_utilization = None
                        retest_on_time_action_rate = None
                        returned_rejected_on_time_action_rate = None
                        triage_productivity_improvement = None
                        defect_acceptance_rate = None

                        application_handler = get_ram_application_handler(selected_application)

                        if application_handler is not None:
                            application_results = application_handler(
                                {
                                    'base_ram_jql': base_ram_jql,
                                    'created_from': created_from,
                                    'created_to': created_to,
                                    'executed_jql': executed_jql,
                                    'password': credentials.get('password'),
                                    'selected_application': selected_application,
                                    'selected_application_definition': selected_application_definition,
                                    'selected_release': effective_selected_release,
                                    'username': credentials.get('username'),
                                    'build_accepted_ram_jql': build_accepted_ram_jql,
                                    'build_active_defect_density_ram_jql': build_active_defect_density_ram_jql,
                                    'build_cancelled_ram_jql': build_cancelled_ram_jql,
                                    'build_defect_density_denominator_ram_jql': build_defect_density_denominator_ram_jql,
                                    'build_defect_density_formula': build_defect_density_formula,
                                    'build_labels_only_ram_jql': build_labels_only_ram_jql,
                                    'build_open_ram_jql': build_open_ram_jql,
                                    'build_preprod_defects_ram_jql': build_preprod_defects_ram_jql,
                                    'build_productivity_improvement_denominator_labels': build_productivity_improvement_denominator_labels,
                                    'build_productivity_improvement_formula': build_productivity_improvement_formula,
                                    'build_productivity_improvement_label': build_productivity_improvement_label,
                                    'build_production_defect_leakage_jql': build_production_defect_leakage_jql,
                                    'build_ram_scope_jql': build_ram_scope_jql,
                                    'build_resolved_burndown_ram_jql': build_resolved_burndown_ram_jql,
                                    'build_resolved_period_ram_jql': build_resolved_period_ram_jql,
                                    'build_triaged_ram_jql': build_triaged_ram_jql,
                                    'calculate_absolute_percentage_change': calculate_absolute_percentage_change,
                                    'calculate_percentage_change': calculate_percentage_change,
                                    'calculate_defect_acceptance_rate_kpi': calculate_defect_acceptance_rate_kpi,
                                    'calculate_defect_burndown_rate_kpi': calculate_defect_burndown_rate_kpi,
                                    'calculate_production_defect_leakage_kpi': calculate_production_defect_leakage_kpi,
                                    'calculate_triage_efficiency_kpi': calculate_triage_efficiency_kpi,
                                    'count_unique_defect_density_labels': count_unique_defect_density_labels,
                                    'fetch_zephyr_zql_total_count': fetch_zephyr_zql_total_count,
                                    'execute_ram_query': lambda label, query: execute_ram_query(
                                        label,
                                        query,
                                        ram_warnings,
                                        self.format_http_error_message,
                                    ),
                                    'extract_release_numeric_value': extract_release_numeric_value,
                                    'fetch_issue_count': fetch_issue_count,
                                    'fetch_ram_cancelled_issues': fetch_ram_cancelled_issues,
                                    'issue_has_non_development_assigned_team_entire_lifecycle': issue_has_non_development_assigned_team_entire_lifecycle,
                                }
                            )
                            triaged_defects = application_results.get('triaged_defects')
                            production_defect_leakage = application_results.get('production_defect_leakage')
                            triage_efficiency = application_results.get('triage_efficiency')
                            cancellation_rate = application_results.get('cancellation_rate')
                            cancellation_efficiency_by_triage = application_results.get('cancellation_efficiency_by_triage')
                            defect_burndown_rate = application_results.get('defect_burndown_rate')
                            defect_density = application_results.get('defect_density')
                            productivity_improvement = application_results.get('productivity_improvement')
                            automation_coverage_overall = application_results.get('automation_coverage_overall')
                            automation_coverage_automatable = application_results.get('automation_coverage_automatable')
                            defect_discovery_rate = application_results.get('defect_discovery_rate')
                            automation_utilization = application_results.get('automation_utilization')
                            defect_acceptance_rate = application_results.get('defect_acceptance_rate')
                            defect_leakage_alt = application_results.get('defect_leakage_alt')

                        if application_handler is not None:
                            action_rate_working_days = (selected_application_definition or {}).get('working_days', 3)
                            retest_status_scope_jql = build_ram_status_scope_jql(executed_jql, {'Retest'}, created_from, created_to)
                            retest_status_history_issues = execute_ram_query(
                                'RAM retest lifecycle data',
                                lambda: fetch_ram_status_history_issues(
                                    jql=retest_status_scope_jql,
                                    username=credentials.get('username'),
                                    password=credentials.get('password'),
                                ),
                                ram_warnings,
                                self.format_http_error_message,
                            )
                            if retest_status_history_issues is not None:
                                retest_on_time_action_rate = calculate_status_on_time_action_rate(
                                    retest_status_history_issues,
                                    {'Retest'},
                                    working_days=action_rate_working_days,
                                )
                                retest_on_time_action_rate['logic'] = (
                                    f'No. of defects moved out of Retest within {action_rate_working_days} working days of moving to Retest '
                                    '/ Total number of defects moved to Retest'
                                )
                                retest_on_time_action_rate['queries'] = f'Query 1 (Retest Lifecycle Scope): {retest_status_scope_jql}'

                            returned_rejected_status_scope_jql = build_ram_status_scope_jql(
                                executed_jql,
                                {'Returned', 'Rejected', 'returned/rejected', 'Returned/Rejected'},
                                created_from,
                                created_to,
                            )
                            returned_rejected_status_history_issues = execute_ram_query(
                                'RAM returned/rejected lifecycle data',
                                lambda: fetch_ram_status_history_issues(
                                    jql=returned_rejected_status_scope_jql,
                                    username=credentials.get('username'),
                                    password=credentials.get('password'),
                                ),
                                ram_warnings,
                                self.format_http_error_message,
                            )
                            if returned_rejected_status_history_issues is not None:
                                returned_rejected_on_time_action_rate = calculate_status_on_time_action_rate(
                                    returned_rejected_status_history_issues,
                                    {'Returned', 'Rejected', 'returned/rejected', 'Returned/Rejected'},
                                    working_days=action_rate_working_days,
                                )
                                returned_rejected_on_time_action_rate['logic'] = (
                                    f'No. of defects moved out of Returned/Rejected within {action_rate_working_days} working days of moving to Returned/Rejected '
                                    '/ Total number of defects moved to Returned/Rejected'
                                )
                                returned_rejected_on_time_action_rate['queries'] = f'Query 1 (Returned/Rejected Lifecycle Scope): {returned_rejected_status_scope_jql}'

                            if created_from and created_to:
                                prior_year_triaged_jql = build_triaged_last_calendar_year_ram_jql(selected_application)
                                prior_year_triaged_defects = execute_ram_query(
                                    'RAM prior-year triaged defects',
                                    lambda: fetch_issue_count(
                                        jql=prior_year_triaged_jql,
                                        username=credentials.get('username'),
                                        password=credentials.get('password'),
                                    ),
                                    ram_warnings,
                                    self.format_http_error_message,
                                )
                                working_days_selected = count_working_days_in_period(created_from, created_to)
                                prior_year_from, prior_year_exclusive_to = get_last_calendar_year_bounds()
                                prior_year_to = (datetime.strptime(prior_year_exclusive_to, '%Y-%m-%d').date() - timedelta(days=1)).isoformat()
                                working_days_prior_year = count_working_days_in_period(prior_year_from, prior_year_to)
                                if triaged_defects is not None and prior_year_triaged_defects is not None:
                                    current_productivity = triaged_defects / working_days_selected
                                    prior_productivity = (prior_year_triaged_defects / working_days_prior_year) if working_days_prior_year else 0
                                    productivity_delta = round(current_productivity - prior_productivity, 2)
                                    triage_productivity_improvement = {
                                        'percentage': f'{abs(calculate_percentage_change(current_productivity, prior_productivity))}%',
                                        'numerator': abs(productivity_delta),
                                        'denominator': round(prior_productivity, 2),
                                        'logic': '(Current year productivity - previous year productivity for selected period)/Previous year productivity *100',
                                        'queries': f'Query 1 (Current Triaged): {build_triaged_ram_jql(executed_jql)}\n\nQuery 2 (Prior-Year Triaged Jan–Dec): {prior_year_triaged_jql}',
                                    }
                            elif selected_application_definition and selected_application_definition.get('supports_release_filter') and effective_selected_release:
                                configured_release_labels = list(selected_application_definition.get('defect_density_date_range_labels') or ())
                                all_release_values = build_release_names_from_configured_labels(configured_release_labels)
                                if not all_release_values:
                                    all_release_values = [
                                        str(value).strip()
                                        for value in (release_options or [])
                                        if str(value).strip() and str(value).strip().lower().startswith('bsse pi ')
                                    ]
                                other_release_values = [value for value in all_release_values if value != effective_selected_release]
                                if triaged_defects is not None and other_release_values:
                                    avg_release_scope_jql = f'({base_ram_jql}) and {build_ram_release_clause_for_values(other_release_values)}'
                                    avg_release_triaged_jql = build_triaged_ram_jql(avg_release_scope_jql)
                                    avg_release_triaged_total = execute_ram_query(
                                        'RAM comparison releases triaged defects',
                                        lambda: fetch_issue_count(
                                            jql=avg_release_triaged_jql,
                                            username=credentials.get('username'),
                                            password=credentials.get('password'),
                                        ),
                                        ram_warnings,
                                        self.format_http_error_message,
                                    )
                                    if avg_release_triaged_total is not None:
                                        release_selected_productivity = triaged_defects
                                        avg_release_productivity = round(avg_release_triaged_total / len(other_release_values), 2)
                                        productivity_delta = round(release_selected_productivity - avg_release_productivity, 2)
                                        triage_productivity_improvement = {
                                            'percentage': f'{abs(calculate_percentage_change(release_selected_productivity, avg_release_productivity))}%',
                                            'numerator': abs(productivity_delta),
                                            'denominator': round(avg_release_productivity, 2),
                                            'logic': '(ReleaseSelectedProductivity - AvgReleaseProductivity)/AvgReleaseProductivity * 100',
                                            'queries': f'Query 1 (ReleaseSelectedProductivity): {build_triaged_ram_jql(executed_jql)}\n\nQuery 2 (AvgReleaseProductivity Scope): {avg_release_triaged_jql}\n\nAvgReleaseProductivity = Query 2 result / {len(other_release_values)} release(s)',
                                        }

                            populate_ram_tiles(
                                kpi_tiles,
                                production_defect_leakage,
                                triage_efficiency,
                                cancellation_rate,
                                cancellation_efficiency_by_triage,
                                defect_burndown_rate,
                                defect_density,
                                productivity_improvement,
                                automation_coverage_overall,
                                automation_coverage_automatable,
                                defect_discovery_rate,
                                automation_utilization,
                                retest_on_time_action_rate,
                                returned_rejected_on_time_action_rate,
                                triage_productivity_improvement,
                                defect_acceptance_rate,
                                defect_leakage_alt=defect_leakage_alt,
                            )
                            if selected_application_definition and selected_application_definition.get('supports_release_filter') and not (created_from and created_to) and triage_productivity_improvement is None:
                                for tile in kpi_tiles:
                                    if tile.get('id') == 'triage-productivity-improvement':
                                        set_ram_tile_unavailable(
                                            tile,
                                            'Triage Productivity Improvement baseline is unavailable because no comparison releases were found.',
                                        )
                            apply_ram_tile_targets(kpi_tiles, selected_application)

                        else:
                            # --- Generic KPI framework: compute all builtin tiles ---
                            if selected_application_definition:
                                _execute_generic_builtin_tiles(
                                    kpi_tiles, selected_application_definition,
                                    executed_jql, base_ram_jql,
                                    created_from, created_to, effective_selected_release,
                                    credentials, ram_warnings, self.format_http_error_message,
                                    release_options=release_options,
                                )
                                # Show the base JQL most used by configured tiles
                                tile_overrides_map = selected_application_definition.get('tile_base_jql_overrides', {})
                                configured_tile_ids = selected_application_definition.get('tile_ids', [])
                                if tile_overrides_map and configured_tile_ids:
                                    preprod_count = sum(1 for tid in configured_tile_ids if tile_overrides_map.get(tid) == 'preprod_base_jql')
                                    prod_count = len(configured_tile_ids) - preprod_count
                                    if preprod_count > prod_count:
                                        dominant_jql = selected_application_definition.get('preprod_base_jql', '')
                                        jql_parts = [dominant_jql]
                                        if created_from:
                                            jql_parts.append(f'created >= "{created_from}"')
                                        if created_to:
                                            jql_parts.append(f'created <= "{created_to}"')
                                        executed_jql = ' and '.join(jql_parts)
                            apply_ram_tile_targets(kpi_tiles, selected_application)

                        # Execute custom KPI queries
                        for tile in kpi_tiles:
                            if not tile.get('_custom'):
                                continue
                            formula_type = tile.get('_formula_type', 'percentage')
                            num_jql = _apply_runtime_filters(tile.get('_numerator_jql', ''), created_from, created_to, effective_selected_release)
                            if not num_jql:
                                set_ram_tile_unavailable(tile, 'No JQL configured for this custom KPI.')
                                continue

                            if formula_type == 'ontime_action':
                                _execute_custom_ontime_action(tile, num_jql, credentials, created_from, created_to, ram_warnings, self.format_http_error_message)
                            elif formula_type == 'period_comparison':
                                _execute_custom_period_comparison(
                                    tile, num_jql, credentials, created_from, created_to,
                                    effective_selected_release, selected_application_definition,
                                    release_options, ram_warnings, self.format_http_error_message,
                                )
                            elif formula_type == 'count':
                                _execute_custom_count(tile, num_jql, credentials, ram_warnings, self.format_http_error_message)
                            elif formula_type == 'leakage':
                                # Leakage is cumulative for the year: when release is
                                # selected without dates, use current year bounds instead
                                # of the release clause (mirrors build_aces_ist_defect_leakage_scope_jql).
                                leakage_from, leakage_to = created_from, created_to
                                if effective_selected_release and not (created_from and created_to):
                                    leakage_from, leakage_to = get_current_year_bounds()
                                leakage_num_jql = _apply_runtime_filters(tile.get('_numerator_jql', ''), leakage_from, leakage_to, '')
                                leakage_denom_jql = _apply_runtime_filters(tile.get('_denominator_jql', ''), leakage_from, leakage_to, '')
                                _execute_custom_leakage(tile, leakage_num_jql, leakage_denom_jql, credentials, ram_warnings, self.format_http_error_message)
                            elif formula_type == 'cancelled_non_dev':
                                _execute_custom_cancelled_non_dev(tile, num_jql, credentials, ram_warnings, self.format_http_error_message)
                            elif formula_type == 'burndown':
                                # Burndown requires special two-query logic; fall back
                                # to generic burndown using the app's base_jql
                                _generic_burndown(
                                    tile,
                                    (selected_application_definition or {}).get('base_jql', ''),
                                    created_from, created_to,
                                    effective_selected_release, selected_application_definition or {},
                                    credentials, ram_warnings, self.format_http_error_message,
                                )
                            else:
                                denom_jql = _apply_runtime_filters(tile.get('_denominator_jql', ''), created_from, created_to, effective_selected_release)
                                _execute_custom_percentage(tile, num_jql, denom_jql, credentials, ram_warnings, self.format_http_error_message)

                            # Apply custom RAG target if tile was populated
                            if tile.get('value') and tile.get('value') != 'N/A':
                                tile['logic'] = tile.get('formula', '')
                                tile.pop('status_note', None)
                                rag = tile.get('_rag_target')
                                if rag:
                                    tile['target_label'] = rag.get('label', '')
                                    tile['rag_status'] = evaluate_ram_rag_status(
                                        parse_ram_percentage_value(tile.get('value')),
                                        rag['direction'],
                                        rag['threshold'],
                                    )
                    except ValueError as error:
                        ram_error = str(error)
                    finally:
                        ram_run_duration = format_ram_run_duration(perf_counter() - run_started_at)

                    if ram_warnings and ram_error is None:
                        ram_error = 'RAM loaded partial KPI results. Some KPI queries timed out or were rejected by Jira/iTrack.'

                    if kpi_tiles:
                        session['ram_kpi_export'] = build_ram_export_payload(
                            selected_application,
                            created_from,
                            created_to,
                            executed_jql,
                            ram_run_duration,
                            kpi_tiles,
                            ram_warnings,
                            selected_release=effective_selected_release,
                        )
                        ram_export_ready = True

            kpi_sections = build_ram_kpi_sections(kpi_tiles)

            return render_template(
                'ram_dashboard.html',
                page_title='Quality Lens 360 | RAM',
                jira_user=credentials.get('username', JIRA_USER),
                application_options=RAM_APPLICATION_OPTIONS,
                selected_application=selected_application,
                created_from=created_from,
                created_to=created_to,
                release_options=release_options,
                selected_release=effective_selected_release,
                release_error=release_error,
                release_field_name=RAM_RELEASE_FIELD_NAME,
                release_enabled_application=selected_application if (selected_application_definition or {}).get('supports_release_filter') else RAM_RELEASED_APPLICATION,
                executed_jql=executed_jql,
                ram_error=ram_error,
                ram_warnings=ram_warnings,
                kpi_tiles=kpi_tiles,
                kpi_sections=kpi_sections,
                ram_run_duration=ram_run_duration,
                ram_export_ready=ram_export_ready,
            )

        @app.get('/ram/download-kpis')
        @login_required
        def download_ram_kpis():
            payload = session.get('ram_kpi_export')
            if not payload:
                return redirect(url_for('ram_page'))
            return stream_ram_export(payload)

        @app.get('/ram/download-slides')
        @login_required
        def download_ram_slides():
            from ram.slides import build_ram_slides, build_ram_slides_filename
            payload = session.get('ram_kpi_export')
            if not payload:
                return redirect(url_for('ram_page'))
            buf = build_ram_slides(payload)
            filename = build_ram_slides_filename(
                payload.get('application', ''),
                payload.get('export_timestamp', ''),
            )
            return send_file(
                buf,
                mimetype='application/vnd.openxmlformats-officedocument.presentationml.presentation',
                as_attachment=True,
                download_name=filename,
            )

        @app.post('/ram/send-email')
        @login_required
        def ram_send_email():
            from ram.slides import build_ram_slides, build_ram_slides_filename
            from operations.release_open_defects import is_graph_configured, send_email_via_graph
            payload = session.get('ram_kpi_export')
            if not payload:
                return jsonify({'error': 'No RAM results to send. Please run RAM first.'}), 400
            body = request.get_json(silent=True) or {}
            recipients_raw = (body.get('recipients') or '').strip()
            if not recipients_raw:
                return jsonify({'error': 'Please enter at least one recipient email address.'}), 400
            if not is_graph_configured():
                return jsonify({'error': 'Email delivery is not configured on this server.'}), 500

            recipients = [r.strip() for r in recipients_raw.replace(',', ';').split(';') if r.strip()]
            application = payload.get('application', 'RAM')
            date_from = payload.get('created_from', '')
            date_to = payload.get('created_to', '')
            selected_release = payload.get('selected_release', '')
            if date_from and date_to:
                period = f'{date_from} to {date_to}'
            elif selected_release:
                period = f'Release: {selected_release}'
            else:
                period = 'All dates'
            subject = f'Real-Time Analysis & Metrics Report — {application} ({period})'

            # Build slide deck attachment
            slide_buf = build_ram_slides(payload)
            slide_filename = build_ram_slides_filename(
                application,
                payload.get('export_timestamp', ''),
            )

            # Build HTML body summary
            tiles = payload.get('kpi_tiles', [])
            kpi_rows = ''.join(
                f'<tr>'
                f'<td style="padding:6px 10px;border:1px solid #d7dee7">{t.get("title","")}</td>'
                f'<td style="padding:6px 10px;border:1px solid #d7dee7;font-weight:700">{t.get("value","")}</td>'
                f'<td style="padding:6px 10px;border:1px solid #d7dee7">{t.get("target_label","")}</td>'
                f'</tr>'
                for t in tiles if t.get('value')
            )
            html_body = (
                f'<div style="font-family:Arial,sans-serif;color:#0f172a">'
                f'<h2 style="color:#0f4c81">Real-Time Analysis & Metrics Report — {application}</h2>'
                f'<p><strong>Period:</strong> {period}</p>'
                f'<table style="border-collapse:collapse;margin:16px 0">'
                f'<tr style="background:#009FDB;color:#fff">'
                f'<th style="padding:8px 10px;text-align:left">KPI</th>'
                f'<th style="padding:8px 10px;text-align:left">Value</th>'
                f'<th style="padding:8px 10px;text-align:left">Target</th></tr>'
                f'{kpi_rows}</table>'
                f'<p style="color:#888;font-size:12px">Full slide deck attached.  •  Generated by QualityLens 360</p>'
                f'</div>'
            )

            try:
                send_email_via_graph(
                    subject=subject,
                    html_body=html_body,
                    to_recipients=recipients,
                    attachment_bytes=slide_buf.read(),
                    attachment_filename=slide_filename,
                )
            except Exception as exc:
                return jsonify({'error': f'Failed to send email: {exc}'}), 500

            return jsonify({'message': f'Email sent to {", ".join(recipients)}'})

        # In-memory chat state store (avoids cookie size limits)
        _chat_states = {}

        @app.post('/ram/kpi-chat')
        @login_required
        def ram_kpi_chat():
            from ram.kpi_chat import handle_chat_message
            body = request.get_json(silent=True) or {}
            user_message = str(body.get('message', '')).strip()
            chat_key = session.get('credentials_key', 'default')
            chat_state = _chat_states.get(chat_key, {})
            try:
                reply, new_state = handle_chat_message(chat_state, user_message)
            except Exception as exc:
                import logging
                logging.getLogger(__name__).exception('RAM chat error')
                return jsonify({'reply': f'Something went wrong: {exc}'})
            _chat_states[chat_key] = new_state
            return jsonify({'reply': reply})


# ============================================================================
# GENERIC KPI COMPUTATION FRAMEWORK
# ============================================================================

def _execute_generic_builtin_tiles(kpi_tiles, app_def, executed_jql, base_ram_jql,
                                    created_from, created_to, effective_selected_release,
                                    credentials, ram_warnings, format_http_error_message,
                                    release_options=None):
    """Compute builtin KPI tiles for any application using _BUILTIN_KPI_JQL_LOGIC.

    This is the generic framework that replaces the need for per-app handler functions.
    Each tile's calculation_type drives the execution path.
    """
    from ram.kpi_chat import _BUILTIN_KPI_JQL_LOGIC

    base_jql = app_def.get('base_jql', '')
    preprod_base_jql = app_def.get('preprod_base_jql', '')
    action_rate_working_days = app_def.get('working_days', 3)
    fmt_vars = {
        'base_jql': base_jql,
        'preprod_base_jql': preprod_base_jql,
        'functional_base_jql': str(app_def.get('functional_base_jql') or '').strip(),
        'automation_base_jql': str(app_def.get('automation_base_jql') or '').strip(),
        'defect_discovery_base_jql': str(app_def.get('defect_discovery_base_jql') or '').strip(),
        'from': '',
        'to': '',
    }

    # Track values needed for cross-tile computations
    triaged_defects = None

    # Per-tile base JQL overrides (e.g. to run a defect KPI against PreProd)
    tile_overrides = app_def.get('tile_base_jql_overrides', {})

    for tile in kpi_tiles:
        if tile.get('_custom'):
            continue  # custom KPIs handled separately
        tile_id = tile.get('id', '')
        jql_logic = _BUILTIN_KPI_JQL_LOGIC.get(tile_id, {})
        calc_type = jql_logic.get('calculation_type', '')

        if not calc_type:
            continue  # no logic defined, skip

        # Apply per-tile base JQL override if configured
        tile_fmt_vars = fmt_vars
        tile_base_jql = base_jql
        tile_executed_jql = executed_jql
        tile_base_ram_jql = base_ram_jql
        override_key = tile_overrides.get(tile_id)
        if override_key and override_key in fmt_vars:
            tile_fmt_vars = dict(fmt_vars)
            tile_fmt_vars['base_jql'] = fmt_vars[override_key]
            tile_base_jql = fmt_vars[override_key]
            # Rebuild executed_jql and base_ram_jql for the overridden base,
            # including the release filter when the application supports it
            if app_def.get('supports_release_filter'):
                tile_executed_jql = build_ram_scope_jql(tile_base_jql, created_from, created_to, effective_selected_release)
            else:
                tile_jql_parts = [tile_base_jql]
                if created_from:
                    tile_jql_parts.append(f'created >= "{created_from}"')
                if created_to:
                    tile_jql_parts.append(f'created <= "{created_to}"')
                tile_executed_jql = ' and '.join(tile_jql_parts)
            tile_base_ram_jql = tile_base_jql

        # Skip tiles whose required app-config fields are not present
        required_keys = jql_logic.get('requires_config') or []
        if required_keys and not all(str(app_def.get(k) or '').strip() for k in required_keys):
            continue

        try:
            if calc_type == 'percentage':
                _generic_percentage(tile, jql_logic, executed_jql, tile_fmt_vars,
                                     created_from, created_to, effective_selected_release,
                                     credentials, ram_warnings, format_http_error_message)
                # Track triaged defects for triage productivity improvement
                if tile_id == 'triage-efficiency' and tile.get('fraction_numerator') is not None:
                    triaged_defects = tile.get('fraction_numerator')

            elif calc_type == 'leakage':
                _generic_leakage(tile, jql_logic, app_def, tile_fmt_vars,
                                  created_from, created_to, effective_selected_release,
                                  credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'cancelled_non_dev':
                _generic_cancelled_non_dev(tile, jql_logic, tile_fmt_vars,
                                            created_from, created_to, effective_selected_release,
                                            credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'ontime_action':
                _generic_ontime_action(tile, jql_logic, tile_executed_jql,
                                        created_from, created_to, action_rate_working_days,
                                        credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'burndown':
                _generic_burndown(tile, tile_base_jql, created_from, created_to,
                                   effective_selected_release, app_def,
                                   credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'period_comparison':
                _generic_period_comparison(tile, jql_logic, tile_executed_jql, tile_base_ram_jql,
                                            created_from, created_to, effective_selected_release,
                                            app_def, triaged_defects, release_options,
                                            credentials, ram_warnings, format_http_error_message,
                                            tile_base_jql=tile_base_jql)

            elif calc_type == 'app_config_percentage':
                _generic_app_config_percentage(tile, jql_logic, app_def,
                                                credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'defect_density':
                _generic_defect_density(tile, app_def, executed_jql, base_ram_jql,
                                         created_from, created_to, effective_selected_release,
                                         credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'label_comparison':
                _generic_label_comparison(tile, app_def, executed_jql,
                                           created_from, created_to, effective_selected_release,
                                           credentials, ram_warnings, format_http_error_message)

            elif calc_type == 'zephyr_percentage':
                _generic_zephyr_percentage(tile, app_def,
                                            credentials, ram_warnings, format_http_error_message)

        except Exception:
            import logging
            logging.getLogger(__name__).exception(f'Generic KPI computation failed for {tile_id}')
            set_ram_tile_unavailable(tile, f'{tile.get("title", tile_id)} computation failed.')


def _generic_percentage(tile, jql_logic, executed_jql, fmt_vars,
                         created_from, created_to, effective_selected_release,
                         credentials, ram_warnings, format_http_error_message):
    """Generic percentage: numerator_jql_hint / denominator_jql_hint * 100."""
    num_hint = jql_logic.get('numerator_jql_hint', '')
    denom_hint = jql_logic.get('denominator_jql_hint', '')
    if not num_hint:
        return

    try:
        num_jql_raw = num_hint.format(**fmt_vars)
    except KeyError:
        num_jql_raw = num_hint
    try:
        denom_jql_raw = denom_hint.format(**fmt_vars) if denom_hint else ''
    except KeyError:
        denom_jql_raw = denom_hint

    num_jql = _apply_runtime_filters(num_jql_raw, created_from, created_to, effective_selected_release)
    denom_jql = _apply_runtime_filters(denom_jql_raw, created_from, created_to, effective_selected_release) if denom_jql_raw else ''

    _execute_custom_percentage(tile, num_jql, denom_jql, credentials, ram_warnings, format_http_error_message)


def _generic_leakage(tile, jql_logic, app_def, fmt_vars,
                      created_from, created_to, effective_selected_release,
                      credentials, ram_warnings, format_http_error_message):
    """Generic leakage: numerator / (numerator + preprod) * 100.

    Supports two variants:
    - Default (ACC-Prod style): uses numerator_jql_hint / denominator_jql_hint from _BUILTIN_KPI_JQL_LOGIC
    - Alt config (ACES-IST style): uses prod_defect_leakage_base_jql / preprod_defect_leakage_base_jql
      from the app definition with date/release scoping via build_aces_ist_defect_leakage_scope_jql
    """
    alt_num_key = jql_logic.get('alt_numerator_config_key', '')
    alt_denom_key = jql_logic.get('alt_denominator_config_key', '')
    alt_num_jql = str(app_def.get(alt_num_key) or '').strip() if alt_num_key else ''
    alt_denom_jql = str(app_def.get(alt_denom_key) or '').strip() if alt_denom_key else ''

    # Fallback: if dedicated leakage JQLs are not configured, use base_jql / preprod_base_jql
    if not alt_num_jql and alt_num_key:
        alt_num_jql = fmt_vars.get('base_jql', '')
    if not alt_denom_jql and alt_denom_key:
        alt_denom_jql = fmt_vars.get('preprod_base_jql', '')

    if alt_num_jql and alt_denom_jql:
        # ACES-IST variant: use separate leakage base JQLs with date/release scoping
        num_jql = build_aces_ist_defect_leakage_scope_jql(
            alt_num_jql, created_from, created_to, effective_selected_release,
        )
        denom_jql = build_aces_ist_defect_leakage_scope_jql(
            alt_denom_jql, created_from, created_to, effective_selected_release,
        )
    else:
        # Default variant: use JQL hints from _BUILTIN_KPI_JQL_LOGIC
        num_hint = jql_logic.get('numerator_jql_hint', '')
        denom_hint = jql_logic.get('denominator_jql_hint', '')
        if not num_hint:
            return
        try:
            num_jql_raw = num_hint.format(**fmt_vars)
        except KeyError:
            return
        try:
            denom_jql_raw = denom_hint.format(**fmt_vars) if denom_hint else ''
        except KeyError:
            denom_jql_raw = ''
        # Leakage is cumulative for the year: when release is selected without
        # dates, use current year bounds instead of the release clause.
        leakage_from, leakage_to = created_from, created_to
        leakage_release = effective_selected_release
        if effective_selected_release and not (created_from and created_to):
            leakage_from, leakage_to = get_current_year_bounds()
            leakage_release = ''
        num_jql = _apply_runtime_filters(num_jql_raw, leakage_from, leakage_to, leakage_release)
        denom_jql = _apply_runtime_filters(denom_jql_raw, leakage_from, leakage_to, leakage_release) if denom_jql_raw else ''

    # Always exclude Cancelled defects from the production numerator
    if 'status' not in num_jql.lower() or 'cancelled' not in num_jql.lower():
        num_jql = f'({num_jql}) and status not in (Cancelled)'

    _execute_custom_leakage(tile, num_jql, denom_jql, credentials, ram_warnings, format_http_error_message)


def _generic_cancelled_non_dev(tile, jql_logic, fmt_vars,
                                created_from, created_to, effective_selected_release,
                                credentials, ram_warnings, format_http_error_message):
    """Generic cancelled non-dev: fetch cancelled issues, check lifecycle."""
    num_hint = jql_logic.get('numerator_jql_hint', '')
    if not num_hint:
        return
    try:
        cancelled_jql_raw = num_hint.format(**fmt_vars)
    except KeyError:
        return
    cancelled_jql = _apply_runtime_filters(cancelled_jql_raw, created_from, created_to, effective_selected_release)
    _execute_custom_cancelled_non_dev(tile, cancelled_jql, credentials, ram_warnings, format_http_error_message)


def _generic_ontime_action(tile, jql_logic, executed_jql,
                            created_from, created_to, action_rate_working_days,
                            credentials, ram_warnings, format_http_error_message):
    """Generic on-time action rate using status history."""
    statuses = set(jql_logic.get('statuses', []))
    working_days = jql_logic.get('working_days', action_rate_working_days)
    if not statuses:
        return
    scope_jql = build_ram_status_scope_jql(executed_jql, statuses, created_from, created_to)
    issues = execute_ram_query(
        f'Generic KPI on-time action: {tile["title"]}',
        lambda: fetch_ram_status_history_issues(
            jql=scope_jql,
            username=credentials.get('username'),
            password=credentials.get('password'),
        ),
        ram_warnings,
        format_http_error_message,
    )
    if issues is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable.')
        return
    result = calculate_status_on_time_action_rate(issues, statuses, working_days)
    tile['value'] = result['percentage']
    tile['fraction_numerator'] = result['numerator']
    tile['fraction_denominator'] = result['denominator']
    tile['logic'] = (
        f'No. of defects moved out of {"/".join(statuses)} within {working_days} working days '
        f'/ Total number of defects moved to {"/".join(statuses)}'
    )
    tile['queries'] = f'Query: {scope_jql}\nStatuses: {", ".join(statuses)}\nWorking Days Target: {working_days}'


def _generic_burndown(tile, base_jql, created_from, created_to,
                       effective_selected_release, app_def,
                       credentials, ram_warnings, format_http_error_message):
    """Generic defect burndown rate: resolved / (resolved + open).

    Supports two variants:
    - Date range: resolved in period / (resolved in period + overall open)
    - Release-based (ACES-IST): Accepted+Cancelled for release / Total defects for release
    """
    burndown_base_jql = strip_created_date_clauses(base_jql)

    if app_def.get('supports_release_filter') and effective_selected_release and not (created_from and created_to):
        # ACES-IST release variant
        burndown_release_jql = build_ram_release_scoped_jql(burndown_base_jql, effective_selected_release)
        burndown_numerator_jql = f'({burndown_release_jql}) and status in (Accepted, Cancelled)'
        burndown_denominator_jql = burndown_release_jql
        resolved_period_defects = execute_ram_query(
            f'Generic KPI burndown numerator (Accepted/Cancelled): {tile["title"]}',
            lambda: fetch_issue_count(
                jql=burndown_numerator_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
        overall_open_defects = execute_ram_query(
            f'Generic KPI burndown denominator (all release): {tile["title"]}',
            lambda: fetch_issue_count(
                jql=burndown_denominator_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
        if resolved_period_defects is not None and overall_open_defects is not None:
            denominator_val = overall_open_defects
            tile['value'] = f'{round((resolved_period_defects / denominator_val) * 100) if denominator_val else 0}%'
            tile['fraction_numerator'] = resolved_period_defects
            tile['fraction_denominator'] = denominator_val
            tile['logic'] = 'No. of defects where STATUS in (Accepted, Cancelled) for selected release / Total defects for selected release'
            tile['queries'] = f'Query 1 (Numerator - Accepted/Cancelled): {burndown_numerator_jql}\n\nQuery 2 (Denominator - All Defects): {burndown_denominator_jql}'
        else:
            set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable.')
    else:
        # Default date-range variant
        resolved_period_defects = execute_ram_query(
            f'Generic KPI resolved defects: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=build_resolved_period_ram_jql(burndown_base_jql, created_from, created_to),
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
        overall_open_defects = execute_ram_query(
            f'Generic KPI open defects: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=build_open_ram_jql(burndown_base_jql),
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
        if resolved_period_defects is not None and overall_open_defects is not None:
            result = calculate_defect_burndown_rate_kpi(resolved_period_defects, overall_open_defects)
            tile['value'] = result['percentage']
            tile['fraction_numerator'] = result['numerator']
            tile['fraction_denominator'] = result['denominator']
            tile['logic'] = result['logic']
            resolved_period_jql = build_resolved_period_ram_jql(burndown_base_jql, created_from, created_to)
            open_jql = build_open_ram_jql(burndown_base_jql)
            tile['queries'] = f'Query 1 (Resolved in Period): {resolved_period_jql}\n\nQuery 2 (Overall Open): {open_jql}'
        else:
            set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable.')


def _generic_period_comparison(tile, jql_logic, executed_jql, base_ram_jql,
                                created_from, created_to, effective_selected_release,
                                app_def, triaged_defects, release_options,
                                credentials, ram_warnings, format_http_error_message,
                                tile_base_jql=None):
    """Generic period comparison (triage productivity improvement)."""
    if triaged_defects is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} requires triage efficiency to be computed first.')
        return

    # When a release is selected (with or without dates), prefer release-based comparison
    if app_def.get('supports_release_filter') and effective_selected_release:
        # Release-based comparison: selected release vs average of other configured releases
        configured_release_labels = list(app_def.get('defect_density_date_range_labels') or ())
        all_release_values = build_release_names_from_configured_labels(configured_release_labels)
        if not all_release_values:
            all_release_values = [
                str(v).strip() for v in (release_options or [])
                if str(v).strip() and str(v).strip().lower().startswith('bsse pi ')
            ]
        other_release_values = [v for v in all_release_values if v != effective_selected_release]
        if other_release_values:
            avg_release_scope_jql = f'({base_ram_jql}) and {build_ram_release_clause_for_values(other_release_values)}'
            avg_release_triaged_jql = build_triaged_ram_jql(avg_release_scope_jql)
            avg_release_triaged_total = execute_ram_query(
                f'Generic KPI comparison releases triaged: {tile["title"]}',
                lambda: fetch_issue_count(
                    jql=avg_release_triaged_jql,
                    username=credentials.get('username'),
                    password=credentials.get('password'),
                ),
                ram_warnings,
                format_http_error_message,
            )
            if avg_release_triaged_total is not None:
                release_selected_productivity = triaged_defects
                avg_release_productivity = round(avg_release_triaged_total / len(other_release_values), 2)
                tile['value'] = f'{abs(calculate_percentage_change(release_selected_productivity, avg_release_productivity))}%'
                tile['fraction_numerator'] = abs(round(release_selected_productivity - avg_release_productivity, 2))
                tile['fraction_denominator'] = round(avg_release_productivity, 2)
                tile['logic'] = '(ReleaseSelectedProductivity - AvgReleaseProductivity)/AvgReleaseProductivity * 100'
                tile['queries'] = (
                    f'Query 1 (ReleaseSelectedProductivity): {build_triaged_ram_jql(executed_jql)}\n\n'
                    f'Query 2 (AvgReleaseProductivity Scope): {avg_release_triaged_jql}\n\n'
                    f'AvgReleaseProductivity = Query 2 result / {len(other_release_values)} release(s)'
                )
                return
        set_ram_tile_unavailable(tile, f'{tile["title"]} — no comparison releases found.')
    elif created_from and created_to:
        if tile_base_jql is not None:
            # Use the per-tile base JQL for the prior-year query
            _py_from, _py_before = get_last_calendar_year_bounds()
            prior_year_triaged_jql = f'({tile_base_jql}) and created >= "{_py_from}" and created < "{_py_before}" and status not in ("To Do")'
        else:
            prior_year_triaged_jql = build_triaged_last_calendar_year_ram_jql(app_def.get('name', ''))
        prior_year_triaged_defects = execute_ram_query(
            f'Generic KPI prior-year triaged: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=prior_year_triaged_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
        if prior_year_triaged_defects is None:
            set_ram_tile_unavailable(tile, f'{tile["title"]} prior-year data unavailable.')
            return
        working_days_selected = count_working_days_in_period(created_from, created_to)
        prior_year_from, prior_year_exclusive_to = get_last_calendar_year_bounds()
        prior_year_to = (datetime.strptime(prior_year_exclusive_to, '%Y-%m-%d').date() - timedelta(days=1)).isoformat()
        working_days_prior_year = count_working_days_in_period(prior_year_from, prior_year_to)
        current_productivity = triaged_defects / working_days_selected if working_days_selected else 0
        prior_productivity = (prior_year_triaged_defects / working_days_prior_year) if working_days_prior_year else 0
        productivity_delta = round(current_productivity - prior_productivity, 2)
        tile['value'] = f'{abs(calculate_percentage_change(current_productivity, prior_productivity))}%'
        tile['fraction_numerator'] = abs(productivity_delta)
        tile['fraction_denominator'] = round(prior_productivity, 2)
        tile['logic'] = '(Current year productivity - previous year productivity for selected period)/Previous year productivity *100'
        tile['queries'] = (
            f'Query 1 (Current Triaged): {build_triaged_ram_jql(executed_jql)}\n\n'
            f'Query 2 (Prior-Year Triaged Jan–Dec): {prior_year_triaged_jql}'
        )
    else:
        set_ram_tile_unavailable(tile, f'{tile["title"]} requires date range or release selection.')


def _generic_app_config_percentage(tile, jql_logic, app_def,
                                    credentials, ram_warnings, format_http_error_message):
    """Generic percentage using JQL stored directly in app config fields."""
    num_key = jql_logic.get('numerator_config_key', '')
    denom_key = jql_logic.get('denominator_config_key', '')
    num_jql = str(app_def.get(num_key) or '').strip() if num_key else ''
    denom_jql = str(app_def.get(denom_key) or '').strip() if denom_key else ''
    if not num_jql:
        return
    _execute_custom_percentage(tile, num_jql, denom_jql, credentials, ram_warnings, format_http_error_message)


def _generic_defect_density(tile, app_def, executed_jql, base_ram_jql,
                              created_from, created_to, effective_selected_release,
                              credentials, ram_warnings, format_http_error_message):
    """Generic defect density: active defects / unique feature labels."""
    configured_labels = list(app_def.get('defect_density_date_range_labels') or ())
    density_labels = (
        filter_release_labels_by_year_notation(configured_labels, created_from, created_to)
        if created_from and created_to and not effective_selected_release
        else configured_labels
    )
    release_label_value = extract_release_numeric_value(effective_selected_release)

    # Numerator: active defects
    if release_label_value:
        numerator_jql = build_active_defect_density_ram_jql(executed_jql)
    else:
        numerator_jql = build_active_defect_density_ram_jql(
            build_full_year_created_scope_jql(base_ram_jql, created_from, created_to)
        )
    numerator = execute_ram_query(
        f'Generic KPI defect density numerator: {tile["title"]}',
        lambda: fetch_issue_count(
            jql=numerator_jql,
            username=credentials.get('username'),
            password=credentials.get('password'),
        ),
        ram_warnings,
        format_http_error_message,
    )
    if numerator is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} numerator is temporarily unavailable.')
        return

    # Denominator: label-based count
    denominator = None
    denominator_jql = ''
    if release_label_value:
        denominator_jql = build_defect_density_denominator_ram_jql(
            selected_release=effective_selected_release,
            label_values=configured_labels,
        )
        denominator = execute_ram_query(
            f'Generic KPI defect density denominator: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=denominator_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
    elif density_labels:
        denominator_jql = build_defect_density_denominator_ram_jql(dynamic_labels=density_labels)
        denominator = execute_ram_query(
            f'Generic KPI defect density denominator labels: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=denominator_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
    else:
        denominator = 0

    if numerator is not None and denominator is not None:
        logic = build_defect_density_formula(
            effective_selected_release,
            density_labels if not release_label_value else None,
            label_values=configured_labels,
        )
        if denominator:
            tile['value'] = f'{round(numerator / denominator, 2)}'
            tile['fraction_numerator'] = numerator
            tile['fraction_denominator'] = denominator
            tile['logic'] = logic
            tile['queries'] = f'Query 1 (Numerator): {numerator_jql}\n\nQuery 2 (Denominator): {denominator_jql}'
        else:
            tile['value'] = 'N/A'
            tile['fraction_numerator'] = numerator
            tile['fraction_denominator'] = 0
            tile['logic'] = logic
            tile['queries'] = f'Query 1 (Numerator): {numerator_jql}\n\nQuery 2 (Denominator): {denominator_jql}'
            tile['status_note'] = 'No matching labels were found for the current selection.'


def _generic_label_comparison(tile, app_def, executed_jql,
                                created_from, created_to, effective_selected_release,
                                credentials, ram_warnings, format_http_error_message):
    """Generic label-based productivity improvement."""
    configured_labels = list(app_def.get('defect_density_date_range_labels') or ())
    all_labels = (
        filter_release_labels_by_year_notation(configured_labels, created_from, created_to)
        if created_from and created_to and not effective_selected_release
        else configured_labels
    )
    denominator_labels = build_productivity_improvement_denominator_labels(
        effective_selected_release, all_labels,
    )
    denominator_jql = ''
    denominator_issue_count = None
    if denominator_labels:
        denominator_jql = build_defect_density_denominator_ram_jql(dynamic_labels=denominator_labels)
        denominator_issue_count = execute_ram_query(
            f'Generic KPI productivity improvement denominator: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=denominator_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
    unique_label_count = count_unique_defect_density_labels(all_labels)
    divisor = max(0, unique_label_count - 1)
    denominator = None
    if denominator_issue_count is not None and divisor:
        denominator = round(denominator_issue_count / divisor, 2)
    elif denominator_issue_count is not None:
        denominator = 0

    productivity_label = build_productivity_improvement_label(
        effective_selected_release, label_values=all_labels,
    )
    if productivity_label and denominator is not None:
        numerator_jql = build_labels_only_ram_jql([productivity_label])
        numerator = execute_ram_query(
            f'Generic KPI productivity improvement numerator: {tile["title"]}',
            lambda: fetch_issue_count(
                jql=numerator_jql,
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
        if numerator is not None:
            productivity_difference = abs(round(numerator - denominator, 2))
            tile['value'] = f'{abs(calculate_percentage_change(numerator, denominator))}%'
            tile['fraction_numerator'] = productivity_difference
            tile['fraction_denominator'] = denominator
            tile['logic'] = build_productivity_improvement_formula(productivity_label, denominator_labels)
            tile['queries'] = f'Query 1 (Numerator - {productivity_label}): {numerator_jql}\n\nQuery 2 (Denominator): {denominator_jql}'
    else:
        set_ram_tile_unavailable(tile, f'{tile["title"]} requires label configuration.')


def _generic_zephyr_percentage(tile, app_def,
                                credentials, ram_warnings, format_http_error_message):
    """Generic Zephyr-based automation utilization percentage."""
    fix_versions = [
        str(v).strip() for v in (app_def.get('automation_utilization_fix_versions') or ())
        if str(v).strip()
    ]
    executed_by = [
        str(v).strip() for v in (app_def.get('automation_utilization_executed_by') or ())
        if str(v).strip()
    ]
    if not fix_versions:
        return
    quoted_fix_versions = ', '.join(f'"{v}"' for v in fix_versions)
    base_zql = f'project = "BTEST" AND fixVersion in ({quoted_fix_versions})'
    denominator = execute_ram_query(
        f'Generic KPI Zephyr denominator: {tile["title"]}',
        lambda: fetch_zephyr_zql_total_count(
            zql_query=base_zql,
            username=credentials.get('username'),
            password=credentials.get('password'),
        ),
        ram_warnings,
        format_http_error_message,
    )
    numerator = None
    if executed_by:
        executed_by_clause = ', '.join(executed_by)
        numerator = execute_ram_query(
            f'Generic KPI Zephyr numerator: {tile["title"]}',
            lambda: fetch_zephyr_zql_total_count(
                zql_query=f'{base_zql} AND executedBy in ({executed_by_clause})',
                username=credentials.get('username'),
                password=credentials.get('password'),
            ),
            ram_warnings,
            format_http_error_message,
        )
    if numerator is not None and denominator is not None:
        tile['value'] = f'{round((numerator / denominator) * 100) if denominator else 0}%'
        tile['fraction_numerator'] = numerator
        tile['fraction_denominator'] = denominator
        tile['logic'] = 'No. of test cases executed by Automation/Total No. of test cases executed'
        tile['queries'] = (
            f'Query 1 (Denominator - ZQL): {base_zql}\n\n'
            f'Query 2 (Numerator - ZQL): {base_zql} AND executedBy in ({", ".join(executed_by)})'
        ) if executed_by else f'Query 1 (Denominator - ZQL): {base_zql}'


# ============================================================================
# CUSTOM KPI EXECUTION HELPERS
# ============================================================================


def _execute_custom_percentage(tile, num_jql, denom_jql, credentials, ram_warnings, format_http_error_message):
    """Execute a percentage-formula custom KPI (numerator / denominator * 100)."""
    numerator = execute_ram_query(
        f'Custom KPI numerator: {tile["title"]}',
        lambda: fetch_issue_count(jql=num_jql, username=credentials.get('username'), password=credentials.get('password')),
        ram_warnings,
        format_http_error_message,
    )
    if numerator is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable due to Jira response time.')
        return
    if denom_jql:
        denominator = execute_ram_query(
            f'Custom KPI denominator: {tile["title"]}',
            lambda: fetch_issue_count(jql=denom_jql, username=credentials.get('username'), password=credentials.get('password')),
            ram_warnings,
            format_http_error_message,
        )
        if denominator is None:
            set_ram_tile_unavailable(tile, f'{tile["title"]} denominator is temporarily unavailable due to Jira response time.')
            return
        pct = round((numerator / denominator) * 100) if denominator else 0
        tile['value'] = f'{pct}%'
        tile['fraction_numerator'] = numerator
        tile['fraction_denominator'] = denominator
        tile['queries'] = f'Query 1 (Numerator): {num_jql}\n\nQuery 2 (Denominator): {denom_jql}'
    else:
        tile['value'] = str(numerator)
        tile['fraction_numerator'] = numerator
        tile['fraction_denominator'] = None
        tile['queries'] = f'Query 1: {num_jql}'


def _execute_custom_leakage(tile, num_jql, denom_jql, credentials, ram_warnings, format_http_error_message):
    """Execute a leakage-formula custom KPI: numerator / (numerator + denominator) * 100."""
    numerator = execute_ram_query(
        f'Custom KPI numerator: {tile["title"]}',
        lambda: fetch_issue_count(jql=num_jql, username=credentials.get('username'), password=credentials.get('password')),
        ram_warnings,
        format_http_error_message,
    )
    if numerator is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable due to Jira response time.')
        return
    if denom_jql:
        preprod_count = execute_ram_query(
            f'Custom KPI denominator (PreProd): {tile["title"]}',
            lambda: fetch_issue_count(jql=denom_jql, username=credentials.get('username'), password=credentials.get('password')),
            ram_warnings,
            format_http_error_message,
        )
        if preprod_count is None:
            set_ram_tile_unavailable(tile, f'{tile["title"]} PreProd query is temporarily unavailable due to Jira response time.')
            return
        total = numerator + preprod_count
        pct = round((numerator / total) * 100) if total else 0
        tile['value'] = f'{pct}%'
        tile['fraction_numerator'] = numerator
        tile['fraction_denominator'] = total
        tile['queries'] = f'Query 1 (Production Leakage): {num_jql}\n\nQuery 2 (PreProd): {denom_jql}'
    else:
        tile['value'] = str(numerator)
        tile['fraction_numerator'] = numerator
        tile['fraction_denominator'] = None
        tile['queries'] = f'Query 1: {num_jql}'


def _execute_custom_cancelled_non_dev(tile, cancelled_jql, credentials, ram_warnings, format_http_error_message):
    """Execute cancelled-non-dev KPI: cancelled defects where Assigned to Team is not Development in entire lifecycle."""
    cancelled_count = execute_ram_query(
        f'Custom KPI cancelled count: {tile["title"]}',
        lambda: fetch_issue_count(jql=cancelled_jql, username=credentials.get('username'), password=credentials.get('password')),
        ram_warnings,
        format_http_error_message,
    )
    if cancelled_count is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable due to Jira response time.')
        return
    cancelled_issues = execute_ram_query(
        f'Custom KPI cancelled lifecycle data: {tile["title"]}',
        lambda: fetch_ram_cancelled_issues(jql=cancelled_jql, username=credentials.get('username'), password=credentials.get('password')),
        ram_warnings,
        format_http_error_message,
    )
    if cancelled_issues is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} lifecycle data is temporarily unavailable due to Jira response time.')
        return
    non_dev_count = sum(
        1 for issue in cancelled_issues if issue_has_non_development_assigned_team_entire_lifecycle(issue)
    )
    pct = round((non_dev_count / cancelled_count) * 100) if cancelled_count else 0
    tile['value'] = f'{pct}%'
    tile['fraction_numerator'] = non_dev_count
    tile['fraction_denominator'] = cancelled_count
    tile['queries'] = f'Query (Cancelled): {cancelled_jql}'


def _execute_custom_count(tile, num_jql, credentials, ram_warnings, format_http_error_message):
    """Execute a count-formula custom KPI (just a total issue count)."""
    count = execute_ram_query(
        f'Custom KPI count: {tile["title"]}',
        lambda: fetch_issue_count(jql=num_jql, username=credentials.get('username'), password=credentials.get('password')),
        ram_warnings,
        format_http_error_message,
    )
    if count is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable due to Jira response time.')
        return
    tile['value'] = str(count)
    tile['fraction_numerator'] = count
    tile['fraction_denominator'] = None
    tile['queries'] = f'Query: {num_jql}'


def _execute_custom_period_comparison(tile, num_jql, credentials, created_from, created_to,
                                      effective_selected_release, selected_application_definition,
                                      release_options, ram_warnings, format_http_error_message):
    """Execute a period-over-period comparison custom KPI using the selected comparison mode."""
    comparison_mode = tile.get('_comparison_mode', 'date')
    username = credentials.get('username')
    password = credentials.get('password')

    # Auto-promote to release mode when only a release is selected (no dates)
    # or when both date and release are selected, use release-based comparison.
    supports_release = (selected_application_definition or {}).get('supports_release_filter', False)
    if comparison_mode == 'date' and supports_release and effective_selected_release:
        comparison_mode = 'release'

    current_count = execute_ram_query(
        f'Custom KPI current period: {tile["title"]}',
        lambda: fetch_issue_count(jql=num_jql, username=username, password=password),
        ram_warnings,
        format_http_error_message,
    )
    if current_count is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable due to Jira response time.')
        return

    if comparison_mode == 'two_jql':
        # User provided both JQLs explicitly
        denom_jql = _apply_runtime_filters(tile.get('_denominator_jql', ''), created_from, created_to, effective_selected_release)
        if not denom_jql:
            set_ram_tile_unavailable(tile, f'{tile["title"]} comparison JQL is empty.')
            return
        comparison_count = execute_ram_query(
            f'Custom KPI comparison: {tile["title"]}',
            lambda: fetch_issue_count(jql=denom_jql, username=username, password=password),
            ram_warnings,
            format_http_error_message,
        )
        if comparison_count is None:
            set_ram_tile_unavailable(tile, f'{tile["title"]} comparison query is temporarily unavailable.')
            return
        current_days = count_working_days_in_period(created_from, created_to) if created_from and created_to else 1
        current_rate = current_count / current_days if current_days else 0
        comparison_rate = comparison_count / current_days if current_days else 0
        pct_change = round(((current_rate - comparison_rate) / comparison_rate) * 100) if comparison_rate else 0
        tile['value'] = f'{abs(pct_change)}%'
        tile['fraction_numerator'] = current_count
        tile['fraction_denominator'] = comparison_count
        tile['queries'] = f'Query 1: {num_jql}\n\nQuery 2 (Comparison): {denom_jql}'
        return

    if comparison_mode == 'release' and selected_application_definition and effective_selected_release:
        # Release-based: selected release vs average of other releases (mirrors built-in logic)
        configured_release_labels = list((selected_application_definition.get('defect_density_date_range_labels') or ()))
        all_release_values = build_release_names_from_configured_labels(configured_release_labels)
        if not all_release_values:
            all_release_values = [
                str(v).strip()
                for v in (release_options or [])
                if str(v).strip() and str(v).strip().lower().startswith('bsse pi ')
            ]
        other_release_values = [v for v in all_release_values if v != effective_selected_release]
        if other_release_values:
            raw_jql = tile.get('_numerator_jql', '')
            cleaned = strip_created_date_clauses(raw_jql)
            cleaned = RAM_RELEASE_CLAUSE_PATTERN.sub('', cleaned)
            cleaned = re.sub(r'\(\s*\)', '', cleaned)
            cleaned = re.sub(r'\band\s+and\b', 'and', cleaned, flags=re.IGNORECASE)
            cleaned = re.sub(r'^\s*and\s+', '', cleaned, flags=re.IGNORECASE)
            cleaned = re.sub(r'\s+and\s*$', '', cleaned, flags=re.IGNORECASE)
            cleaned = re.sub(r'\s+', ' ', cleaned).strip()
            avg_scope_jql = f'({cleaned}) and {build_ram_release_clause_for_values(other_release_values)}' if cleaned else ''
            if avg_scope_jql:
                avg_count = execute_ram_query(
                    f'Custom KPI comparison releases: {tile["title"]}',
                    lambda: fetch_issue_count(jql=avg_scope_jql, username=username, password=password),
                    ram_warnings,
                    format_http_error_message,
                )
                if avg_count is not None:
                    avg_release_productivity = round(avg_count / len(other_release_values), 2)
                    pct_change = round(((current_count - avg_release_productivity) / avg_release_productivity) * 100) if avg_release_productivity else 0
                    tile['value'] = f'{abs(pct_change)}%'
                    tile['fraction_numerator'] = current_count
                    tile['fraction_denominator'] = round(avg_release_productivity, 2)
                    tile['queries'] = (
                        f'Query 1 (Selected Release): {num_jql}\n\n'
                        f'Query 2 (Other Releases Scope): {avg_scope_jql}\n\n'
                        f'Avg = Query 2 result / {len(other_release_values)} release(s)'
                    )
                    return
        set_ram_tile_unavailable(tile, f'{tile["title"]} — no comparison releases found.')
        return

    # Default: date-based comparison (current vs prior calendar year, normalized by working days)
    if not (created_from and created_to):
        set_ram_tile_unavailable(tile, f'{tile["title"]} requires a date range for date-based comparison.')
        return
    prior_from, prior_to = shift_ram_period_to_last_year(created_from, created_to)
    prior_jql = _apply_runtime_filters(tile.get('_numerator_jql', ''), prior_from, prior_to, None)
    prior_count = execute_ram_query(
        f'Custom KPI prior period: {tile["title"]}',
        lambda: fetch_issue_count(jql=prior_jql, username=username, password=password),
        ram_warnings,
        format_http_error_message,
    )
    if prior_count is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} prior period is temporarily unavailable due to Jira response time.')
        return
    current_days = count_working_days_in_period(created_from, created_to)
    prior_days = count_working_days_in_period(prior_from, prior_to)
    if prior_days and prior_count and current_days:
        current_rate = current_count / current_days
        prior_rate = prior_count / prior_days
        pct_change = round(((current_rate - prior_rate) / prior_rate) * 100) if prior_rate else 0
    else:
        pct_change = 0
    tile['value'] = f'{abs(pct_change)}%'
    tile['fraction_numerator'] = current_count
    tile['fraction_denominator'] = prior_count
    tile['queries'] = f'Query 1 (Current Period): {num_jql}\n\nQuery 2 (Prior Period): {prior_jql}'


def _execute_custom_ontime_action(tile, num_jql, credentials, created_from, created_to, ram_warnings, format_http_error_message):
    """Execute an on-time action rate custom KPI (% of issues actioned within N working days)."""
    statuses = tile.get('_statuses', [])
    working_days = tile.get('_action_working_days', 3)
    issues = execute_ram_query(
        f'Custom KPI on-time action: {tile["title"]}',
        lambda: fetch_ram_status_history_issues(
            jql=num_jql,
            username=credentials.get('username'),
            password=credentials.get('password'),
        ),
        ram_warnings,
        format_http_error_message,
    )
    if issues is None:
        set_ram_tile_unavailable(tile, f'{tile["title"]} is temporarily unavailable due to Jira response time.')
        return
    result = calculate_status_on_time_action_rate(issues, statuses, working_days)
    tile['value'] = result['percentage']
    tile['fraction_numerator'] = result['numerator']
    tile['fraction_denominator'] = result['denominator']
    tile['queries'] = f'Query: {num_jql}\nStatuses: {", ".join(statuses)}\nWorking Days Target: {working_days}'


def _apply_runtime_filters(jql, created_from, created_to, release_name):
    """Strip sample date/release clauses from custom KPI JQL and inject the dashboard values."""
    if not jql:
        return jql
    # Strip any existing created >= / created <= date clauses
    cleaned = strip_created_date_clauses(jql)
    # Strip any existing release clause  (cf[18971] in (...) or cf[18972] in (...))
    cleaned = RAM_RELEASE_CLAUSE_PATTERN.sub('', cleaned)
    # Clean up leftover dangling ANDs
    cleaned = re.sub(r'\(\s*\)', '', cleaned)
    cleaned = re.sub(r'\band\s+and\b', 'and', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'^\s*and\s+', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s+and\s*$', '', cleaned, flags=re.IGNORECASE)
    cleaned = re.sub(r'\s+', ' ', cleaned).strip()
    # Append actual date range or release from the dashboard picker
    parts = [cleaned] if cleaned else []
    if created_from and created_to:
        parts.append(f'created >= "{created_from}"')
        parts.append(f'created <= "{created_to}"')
    elif release_name:
        parts.append(build_ram_release_clause(release_name))
    return ' and '.join(parts)


def get_ram_kpi_tile_ids(application):
    application_definition = get_ram_application_definition(application)
    if not application_definition:
        return tuple()
    return tuple(application_definition.get('tile_ids') or ())


def build_ram_kpi_tiles(application='', created_from='', created_to='', release_name=''):
    application_definition = get_ram_application_definition(application)
    visible_tile_ids = get_ram_kpi_tile_ids(application)
    if not visible_tile_ids:
        return []
    tile_lookup = {tile['id']: tile for tile in RAM_KPI_TILES}
    tiles = [dict(tile_lookup[tile_id]) for tile_id in visible_tile_ids if tile_id in tile_lookup]
    tile_overrides = (application_definition or {}).get('tile_overrides') or {}
    contextual_overrides = build_ram_tile_context_overrides(
        application,
        created_from=created_from,
        created_to=created_to,
        release_name=release_name,
    )
    for tile in tiles:
        for attribute_name, attribute_value in (tile_overrides.get(tile['id']) or {}).items():
            tile[attribute_name] = attribute_value
        for attribute_name, attribute_value in (contextual_overrides.get(tile['id']) or {}).items():
            tile[attribute_name] = attribute_value
    apply_ram_tile_targets(tiles, application)
    return tiles


def build_ram_tile_context_overrides(application='', created_from='', created_to='', release_name=''):
    application_definition = get_ram_application_definition(application) or {}
    if not application_definition.get('supports_release_filter'):
        return {}

    label_values = list(application_definition.get('defect_density_date_range_labels') or ())
    triage_productivity_formula = '(Current year productivity - previous year productivity for selected period)/Previous year productivity *100'
    if release_name and not (created_from and created_to):
        triage_productivity_formula = '(Current year productivity - previous year productivity for selected period)/Previous year productivity *100'
    productivity_label = build_productivity_improvement_label(release_name)

    return {
        'defect-density': {
            'formula': 'No. of defects where STATUS not in (Canceled, Cancelled) / labels in (ACES_IST_PI*)',
        },
        'productivity-improvement': {
            'formula': '((Count of labels in (Selected/Latest Release) - (Count of results in labels in (ACES_IST_PI*, Excluding Selected/Latest Release) / (Count of unique labels - 1))) / (Count of results in labels in (ACES_IST_PI*, Excluding Selected/Latest Release) / (Count of unique labels - 1))) * 100',
        },
        'triage-productivity-improvement': {
            'formula': triage_productivity_formula,
        },
    }


def build_ram_kpi_sections(kpi_tiles):
    if not kpi_tiles:
        return []
    sections = []
    section_lookup = {}
    default_section = {'title': None, 'tiles': []}
    for tile in kpi_tiles:
        section_title = tile.get('section')
        if not section_title:
            default_section['tiles'].append(tile)
            continue
        section = section_lookup.get(section_title)
        if section is None:
            section = {'title': section_title, 'tiles': []}
            section_lookup[section_title] = section
            sections.append(section)
        section['tiles'].append(tile)
    if default_section['tiles']:
        sections.insert(0, default_section)
    return sections


def parse_ram_percentage_value(value):
    if value is None:
        return None
    normalized_value = str(value).strip()
    if not normalized_value:
        return None
    if normalized_value.endswith('%'):
        normalized_value = normalized_value[:-1]
    try:
        return float(normalized_value)
    except ValueError:
        return None


def evaluate_ram_rag_status(actual_value, direction, threshold, amber_delta=5):
    if actual_value is None:
        return 'neutral'
    if direction == 'max':
        if actual_value <= threshold:
            return 'green'
        if actual_value <= threshold + amber_delta:
            return 'amber'
        return 'red'
    if actual_value >= threshold:
        return 'green'
    if actual_value >= threshold - amber_delta:
        return 'amber'
    return 'red'


def apply_ram_tile_targets(tiles, application):
    application_definition = get_ram_application_definition(application)
    target_specs = (application_definition or {}).get('rag_targets') or {}
    for tile in tiles:
        target_spec = target_specs.get(tile['id'])
        tile['rag_status'] = 'neutral'
        if target_spec is None:
            continue
        tile['target_label'] = target_spec['label']
        tile['rag_status'] = evaluate_ram_rag_status(
            parse_ram_percentage_value(tile.get('value')),
            target_spec['direction'],
            target_spec['threshold'],
        )


def format_ram_run_duration(duration_seconds):
    if duration_seconds is None:
        return None
    if duration_seconds < 1:
        return f'{round(duration_seconds * 1000)} ms'
    if duration_seconds < 60:
        return f'{duration_seconds:.1f} sec'
    duration_minutes = duration_seconds / 60
    if duration_minutes < 60:
        whole_minutes = int(duration_seconds // 60)
        remaining_seconds = duration_seconds - (whole_minutes * 60)
        return f'{whole_minutes} min {remaining_seconds:.1f} sec'
    duration_hours = duration_minutes / 60
    whole_hours = int(duration_seconds // 3600)
    remaining_minutes = int((duration_seconds % 3600) // 60)
    remaining_seconds = duration_seconds % 60
    return f'{whole_hours} hr {remaining_minutes} min {remaining_seconds:.1f} sec'


def build_ram_export_payload(application, created_from, created_to, executed_jql, ram_run_duration, kpi_tiles, ram_warnings, selected_release=''):
    return {
        'application': application,
        'created_from': created_from,
        'created_to': created_to,
        'selected_release': selected_release or '',
        'executed_jql': executed_jql,
        'ram_run_duration': ram_run_duration,
        'export_timestamp': datetime.now().strftime('%Y%m%d_%H%M%S'),
        'ram_warnings': list(ram_warnings or []),
        'kpi_tiles': [
            {
                'title': tile.get('title', ''),
                'value': tile.get('value', ''),
                'fraction_numerator': tile.get('fraction_numerator', ''),
                'fraction_denominator': tile.get('fraction_denominator', ''),
                'target_label': tile.get('target_label', ''),
                'rag_status': tile.get('rag_status', ''),
                'formula': tile.get('formula', ''),
                'status_note': tile.get('status_note', ''),
                'section': tile.get('section', ''),
                'queries': tile.get('queries', ''),
            }
            for tile in kpi_tiles
        ],
    }


def build_ram_export_filename(application, export_timestamp):
    safe_application = ''.join(character if character.isalnum() or character in {'-', '_'} else '_' for character in application).strip('_') or 'Application'
    safe_timestamp = ''.join(character if character.isalnum() or character == '_' else '' for character in export_timestamp) or datetime.now().strftime('%Y%m%d_%H%M%S')
    return f'QualityLens360_RAM_{safe_application}_{safe_timestamp}.xlsx'


def stream_ram_export(payload):
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = 'RAM KPIs'

    title_fill = PatternFill(fill_type='solid', fgColor='0F4C81')
    section_fill = PatternFill(fill_type='solid', fgColor='D9EAF7')
    header_fill = PatternFill(fill_type='solid', fgColor='009FDB')
    warning_fill = PatternFill(fill_type='solid', fgColor='FFF4E5')
    border = Border(
        left=Side(style='thin', color='D7DEE7'),
        right=Side(style='thin', color='D7DEE7'),
        top=Side(style='thin', color='D7DEE7'),
        bottom=Side(style='thin', color='D7DEE7'),
    )
    title_font = Font(color='FFFFFF', bold=True, size=14)
    section_font = Font(color='0F172A', bold=True)
    header_font = Font(color='FFFFFF', bold=True)
    body_alignment = Alignment(vertical='top', wrap_text=True)
    body_alignment_no_wrap = Alignment(vertical='top', wrap_text=False)
    centered_alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)

    worksheet.merge_cells('A1:I1')
    worksheet['A1'] = 'Quality Lens 360 RAM KPI Export'
    worksheet['A1'].fill = title_fill
    worksheet['A1'].font = title_font
    worksheet['A1'].alignment = Alignment(horizontal='center', vertical='center')

    worksheet['A3'] = 'Run Details'
    worksheet['A3'].fill = section_fill
    worksheet['A3'].font = section_font

    metadata_rows = [
        ('Application', payload.get('application', '')),
        ('Defect Creation Date From', payload.get('created_from', '')),
        ('Defect Creation Date To', payload.get('created_to', '')),
        ('Run Duration', payload.get('ram_run_duration', '')),
        ('Generated At', payload.get('export_timestamp', '')),
        ('Executed JQL', payload.get('executed_jql', '')),
    ]

    current_row = 4
    for label, value in metadata_rows:
        worksheet.cell(row=current_row, column=1, value=label)
        worksheet.cell(row=current_row, column=2, value=value)
        worksheet.cell(row=current_row, column=1).fill = section_fill
        worksheet.cell(row=current_row, column=1).font = section_font
        worksheet.cell(row=current_row, column=1).alignment = body_alignment
        worksheet.cell(row=current_row, column=2).alignment = body_alignment_no_wrap if label == 'Executed JQL' else body_alignment
        worksheet.cell(row=current_row, column=1).border = border
        worksheet.cell(row=current_row, column=2).border = border
        current_row += 1

    warnings = payload.get('ram_warnings') or []
    if warnings:
        worksheet.cell(row=current_row, column=1, value='Warnings')
        worksheet.cell(row=current_row, column=1).fill = warning_fill
        worksheet.cell(row=current_row, column=1).font = section_font
        current_row += 1
        for warning in warnings:
            worksheet.cell(row=current_row, column=1, value='Warning')
            worksheet.cell(row=current_row, column=2, value=warning)
            worksheet.cell(row=current_row, column=1).fill = warning_fill
            worksheet.cell(row=current_row, column=1).font = section_font
            worksheet.cell(row=current_row, column=1).alignment = body_alignment
            worksheet.cell(row=current_row, column=2).alignment = body_alignment
            worksheet.cell(row=current_row, column=1).border = border
            worksheet.cell(row=current_row, column=2).border = border
            current_row += 1

    current_row += 1
    headers = ['KPI', 'Value', 'Numerator', 'Denominator', 'Target', 'RAG Status', 'Formula', 'Queries', 'Status Note']
    for column_index, header in enumerate(headers, start=1):
        cell = worksheet.cell(row=current_row, column=column_index, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = centered_alignment
        cell.border = border

    rag_fills = {
        'green': PatternFill(fill_type='solid', fgColor='DCFCE7'),
        'amber': PatternFill(fill_type='solid', fgColor='FEF3C7'),
        'red': PatternFill(fill_type='solid', fgColor='FEE2E2'),
        'neutral': PatternFill(fill_type='solid', fgColor='F8FAFC'),
    }

    for tile in payload.get('kpi_tiles') or []:
        current_row += 1
        row_values = [
            tile.get('title', ''),
            tile.get('value', ''),
            tile.get('fraction_numerator', ''),
            tile.get('fraction_denominator', ''),
            tile.get('target_label', ''),
            str(tile.get('rag_status', '')).title(),
            tile.get('formula', ''),
            tile.get('queries', ''),
            tile.get('status_note', ''),
        ]
        for column_index, value in enumerate(row_values, start=1):
            cell = worksheet.cell(row=current_row, column=column_index, value=value)
            cell.border = border
            cell.alignment = centered_alignment if column_index in {2, 3, 4, 5, 6} else body_alignment
        worksheet.cell(row=current_row, column=6).fill = rag_fills.get(str(tile.get('rag_status', 'neutral')).casefold(), rag_fills['neutral'])

    worksheet.freeze_panes = 'A12'
    worksheet.row_dimensions[1].height = 24
    column_widths = {'A': 38, 'B': 14, 'C': 14, 'D': 16, 'E': 14, 'F': 14, 'G': 72, 'H': 60, 'I': 48}
    for column_letter, width in column_widths.items():
        worksheet.column_dimensions[column_letter].width = width

    file_bytes = io.BytesIO()
    workbook.save(file_bytes)
    file_bytes.seek(0)
    return send_file(
        file_bytes,
        as_attachment=True,
        download_name=build_ram_export_filename(payload.get('application', ''), payload.get('export_timestamp', '')),
        mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    )


def set_ram_tile_unavailable(tile, reason):
    tile['value'] = 'N/A'
    tile['status_note'] = reason
    tile['rag_status'] = 'neutral'


def mark_ram_tiles_unavailable(kpi_tiles, reason):
    for tile in kpi_tiles:
        set_ram_tile_unavailable(tile, reason)


def populate_ram_tiles(
    kpi_tiles,
    production_defect_leakage,
    triage_efficiency,
    cancellation_rate,
    cancellation_efficiency_by_triage,
    defect_burndown_rate,
    defect_density,
    productivity_improvement,
    automation_coverage_overall,
    automation_coverage_automatable,
    defect_discovery_rate,
    automation_utilization,
    retest_on_time_action_rate,
    returned_rejected_on_time_action_rate,
    triage_productivity_improvement,
    defect_acceptance_rate=None,
    defect_leakage_alt=None,
):
    result_lookup = {
        'production-defect-leakage': (production_defect_leakage, 'Defect Leakage is temporarily unavailable due to Jira response time.'),
        'defect-leakage-alt': (defect_leakage_alt, 'Defect Leakage* is temporarily unavailable due to Jira response time.'),
        'triage-efficiency': (triage_efficiency, 'Triage Efficiency is temporarily unavailable due to Jira response time.'),
        'cancellation-rate': (cancellation_rate, 'Cancellation Rate is temporarily unavailable due to Jira response time.'),
        'cancellation-efficiency-by-triage': (cancellation_efficiency_by_triage, 'Cancellation Efficiency by Triage is temporarily unavailable due to Jira response time.'),
        'defect-burndown-rate': (defect_burndown_rate, 'Defect Burndown Rate is temporarily unavailable due to Jira response time.'),
        'defect-acceptance-rate': (defect_acceptance_rate, 'Defect Acceptance Rate is temporarily unavailable due to Jira response time.'),
        'defect-density': (defect_density, 'Defect Density is temporarily unavailable due to Jira response time.'),
        'productivity-improvement': (productivity_improvement, 'Productivity Improvement is temporarily unavailable due to Jira response time.'),
        'automation-coverage-overall': (automation_coverage_overall, 'Automation Coverage (Against Overall) is temporarily unavailable due to Jira response time.'),
        'automation-coverage-automatable': (automation_coverage_automatable, 'Automation Coverage (Against Automatable) is temporarily unavailable due to Jira response time.'),
        'defect-discovery-rate': (defect_discovery_rate, 'Defect Discovery Rate is temporarily unavailable due to Jira response time.'),
        'automation-utilization': (automation_utilization, 'Automation Utilization is temporarily unavailable due to Jira response time.'),
        'retest-defects-ontime-action-rate': (retest_on_time_action_rate, 'Retest OnTime Action Rate is temporarily unavailable due to Jira response time.'),
        'return-rejected-defects-ontime-action-rate': (returned_rejected_on_time_action_rate, 'Return/Rejected OnTime Action Rate is temporarily unavailable due to Jira response time.'),
        'triage-productivity-improvement': (triage_productivity_improvement, 'Triage Productivity Improvement is temporarily unavailable due to Jira response time.'),
    }
    for tile in kpi_tiles:
        if tile.get('_custom'):
            continue
        result, unavailable_message = result_lookup.get(tile['id'], (None, None))
        if result is None:
            set_ram_tile_unavailable(tile, unavailable_message or 'RAM KPI is temporarily unavailable due to Jira response time.')
            continue
        tile['value'] = result['percentage']
        tile['fraction_numerator'] = result['numerator']
        tile['fraction_denominator'] = result['denominator']
        tile['logic'] = result['logic']
        tile['formula'] = result['logic']
        if 'status_note' in result:
            tile['status_note'] = result['status_note']
        if 'queries' in result:
            tile['queries'] = result['queries']


# ============================================================================
# KPI HANDLERS (imported from application-specific subfolders)
# ============================================================================

from ram.acc_prod.kpi_handler import run_acc_prod_ram_kpis  # noqa: E402
from ram.aces_ist.kpi_handler import run_aces_ist_ram_kpis  # noqa: E402

register_kpi_handler('ACC-Prod', run_acc_prod_ram_kpis)
register_kpi_handler('ACES-IST', run_aces_ist_ram_kpis)