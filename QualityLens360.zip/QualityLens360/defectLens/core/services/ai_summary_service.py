"""Generate executive summaries from analysis results."""

from __future__ import annotations

import re
from typing import Any


DEFAULT_SECTION_HEADINGS = {
    "summary": "## Summary:",
    "overlap": "## Top Application Teams - Action Required:",
    "recommendations": "## Recommendations:",
}


def _safe_percent(value: Any) -> float:
    try:
        return round(float(value or 0) * 100, 1)
    except (TypeError, ValueError):
        return 0.0


def _safe_days(row: dict[str, Any]) -> float:
    try:
        return float(row.get("days") or 0)
    except (TypeError, ValueError):
        return 0.0


def _safe_name(row: dict[str, Any]) -> str:
    return str(row.get("application") or row.get("team") or "Unknown").strip() or "Unknown"


def _parse_duration_to_days(value: Any) -> float | None:
    if value in (None, "", "TBD"):
        return None
    text = str(value).strip().lower()
    match = re.search(r"-?\d+(?:\.\d+)?", text)
    if not match:
        return None
    amount = float(match.group(0))
    if "day" in text:
        return amount
    if "hr" in text:
        return amount / 24.0
    if "min" in text:
        return amount / 1440.0
    return amount


def _top_driver_text(rows: list[dict[str, Any]], empty_text: str, prefix: str) -> str:
    if not rows:
        return empty_text
    top = rows[0]
    return f"{prefix} {_safe_name(top)} at {_safe_days(top):.2f} days."


def _normalize_app_name(value: Any) -> str:
    return str(value or "").strip().lower()


def _display_name_map(*row_groups: list[dict[str, Any]]) -> dict[str, str]:
    names: dict[str, str] = {}
    for rows in row_groups:
        for row in rows[:10]:
            raw_name = _safe_name(row)
            key = _normalize_app_name(raw_name)
            if key and key not in names:
                names[key] = raw_name
    return names


def _collect_overlap(
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
) -> list[str]:
    hold_set = {
        _normalize_app_name(row.get("application"))
        for row in top_contrib_rows[:10]
        if _normalize_app_name(row.get("application"))
    }
    mtti_set = {
        _normalize_app_name(row.get("application"))
        for row in mtti_rows[:10]
        if _normalize_app_name(row.get("application"))
    }
    mttf_set = {
        _normalize_app_name(row.get("application"))
        for row in mttf_rows[:10]
        if _normalize_app_name(row.get("application"))
    }
    mttr_set = {
        _normalize_app_name(row.get("application"))
        for row in mttr_rows[:10]
        if _normalize_app_name(row.get("application"))
    }
    display_names = _display_name_map(top_contrib_rows, mtti_rows, mttf_rows, mttr_rows)
    return [display_names[name] for name in sorted(hold_set & mtti_set & mttf_set & mttr_set)]


def _build_overlap_sentence(overlap_names: list[str]) -> str:
    if overlap_names:
        return f"The key contributors across all 4 OKRs are {', '.join(overlap_names)}."
    return (
        "The key contributors across all 4 OKRs could not be narrowed to a common "
        "overlapping application from the current top 10 contributor lists."
    )


def _build_recommendations(
    overlap_names: list[str],
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
) -> list[str]:
    recommendations: list[str] = []
    ftra_pct = _safe_percent(okrs.get("ftra"))
    mtti_days = _parse_duration_to_days(okrs.get("mtti"))
    mttf_days = _parse_duration_to_days(okrs.get("mttf"))
    mttr_days = _parse_duration_to_days(okrs.get("mttr"))

    ftra_status = "GREEN" if ftra_pct > 90 else "AMBER" if ftra_pct >= 85 else "RED"
    mtti_status = None if mtti_days is None else ("GREEN" if mtti_days <= 4 else "AMBER" if mtti_days <= 5 else "RED")
    mttf_status = None if mttf_days is None else ("GREEN" if mttf_days <= 11 else "AMBER" if mttf_days <= 13 else "RED")
    mttr_status = None if mttr_days is None else ("GREEN" if mttr_days <= 4.6 else "AMBER" if mttr_days <= 5.6 else "RED")

    if overlap_names and any(status in {"RED", "AMBER"} for status in (ftra_status, mtti_status, mttf_status, mttr_status)):
        recommendations.append(
            f"Prioritize a focused action plan for {', '.join(overlap_names[:3])} first, since these teams overlap across the top 10 contributors for FTRA, MTTI, MTTF, and MTTR."
        )

    if ftra_status in {"RED", "AMBER"} and top_contrib_rows:
        recommendations.append(
            f"FTRA is {ftra_status}. Reduce reassignment churn for {_safe_name(top_contrib_rows[0])} by validating ownership rules, queue routing, and initial assignment accuracy."
        )

    if mtti_status in {"RED", "AMBER"} and mtti_rows:
        recommendations.append(
            f"MTTI is {mtti_status}. Tighten triage SLAs and last-assigned team response time for {_safe_name(mtti_rows[0])}."
        )

    if mttf_status in {"RED", "AMBER"} and mttf_rows:
        recommendations.append(
            f"MTTF is {mttf_status}. Accelerate fix validation, retest readiness, and closure handoffs for {_safe_name(mttf_rows[0])}."
        )

    if mttr_status in {"RED", "AMBER"} and mttr_rows:
        recommendations.append(
            f"MTTR is {mttr_status}. Reduce end-to-end resolution time for {_safe_name(mttr_rows[0])} by tightening triage-to-close ownership and closure governance."
        )

    if not recommendations:
        recommendations.append(
            "All tracked OKRs are currently GREEN or insufficient data is available to generate action recommendations."
        )

    return recommendations


def _extract_section_headings(prompt_template: str) -> dict[str, str]:
    headings = dict(DEFAULT_SECTION_HEADINGS)
    for line in prompt_template.splitlines():
        stripped = line.strip()
        if not stripped.startswith("##"):
            continue

        heading_match = re.match(r"^(##\s*[^:]+:)", stripped)
        heading = heading_match.group(1).strip() if heading_match else stripped
        normalized = heading.lower()
        if "recommend" in normalized:
            headings["recommendations"] = heading
        elif "top application" in normalized or "action required" in normalized:
            headings["overlap"] = heading
        elif "summary" in normalized:
            headings["summary"] = heading

    return headings


def _build_section_summary(
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
    section_heading: str,
) -> str:
    bullets = [
        f"Current OKRs shows FTRA at {_safe_percent(okrs.get('ftra')):.1f}%, MTTI at {okrs.get('mtti', 'TBD')}, MTTF at {okrs.get('mttf', 'TBD')}, and MTTR at {okrs.get('mttr', 'TBD')}.",
        _top_driver_text(top_contrib_rows, "No hold-time delay driver data is available.", "The largest hold-time delay driver is"),
        _top_driver_text(mtti_rows, "No MTTI contributor data is available.", "The main MTTI contributor is"),
        _top_driver_text(mttf_rows, "No MTTF contributor data is available.", "The main MTTF contributor is"),
        _top_driver_text(mttr_rows, "No MTTR contributor data is available.", "The main MTTR contributor is"),
    ]
    return "\n".join([section_heading] + [f"- {item}" for item in bullets])


def _build_overlap_section(overlap_names: list[str], section_heading: str) -> str:
    return "\n".join([section_heading, f"- {_build_overlap_sentence(overlap_names)}"])


def _build_recommendation_section(
    overlap_names: list[str],
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
    section_heading: str,
) -> str:
    recommendations = _build_recommendations(overlap_names, okrs, top_contrib_rows, mtti_rows, mttf_rows, mttr_rows)
    return "\n".join([section_heading] + [f"- {item}" for item in recommendations])


def generate_prompt_file_insights(
    prompt_template: str,
    summary: dict[str, Any],
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
) -> str:
    """Generate the plain-text AI summary shown in the UI."""

    section_headings = _extract_section_headings(prompt_template or "")
    overlap_names = _collect_overlap(top_contrib_rows, mtti_rows, mttf_rows, mttr_rows)
    lines = [
        _build_section_summary(okrs, top_contrib_rows, mtti_rows, mttf_rows, mttr_rows, section_headings["summary"]),
        _build_overlap_section(overlap_names, section_headings["overlap"]),
        _build_recommendation_section(
            overlap_names,
            okrs,
            top_contrib_rows,
            mtti_rows,
            mttf_rows,
            mttr_rows,
            section_headings["recommendations"],
        ),
    ]

    if int(summary.get("processed", 0) or 0) == 0:
        lines.append(
            "\n".join(
                [
                    "## Run Context",
                    f"- Processed {int(summary.get('processed', 0) or 0)} issues and skipped {int(summary.get('skipped_no_data', 0) or 0)} due to missing Jira data.",
                ]
            )
        )

    return "\n\n".join(lines).strip()


def _compute_rag_status(okrs: dict[str, Any]) -> dict[str, str | None]:
    ftra_pct = _safe_percent(okrs.get("ftra"))
    mtti_days = _parse_duration_to_days(okrs.get("mtti"))
    mttf_days = _parse_duration_to_days(okrs.get("mttf"))
    mttr_days = _parse_duration_to_days(okrs.get("mttr"))
    return {
        "ftra": "GREEN" if ftra_pct > 90 else "AMBER" if ftra_pct >= 85 else "RED",
        "mtti": None if mtti_days is None else ("GREEN" if mtti_days <= 4 else "AMBER" if mtti_days <= 5 else "RED"),
        "mttf": None if mttf_days is None else ("GREEN" if mttf_days <= 11 else "AMBER" if mttf_days <= 13 else "RED"),
        "mttr": None if mttr_days is None else ("GREEN" if mttr_days <= 4.6 else "AMBER" if mttr_days <= 5.6 else "RED"),
    }


def _build_analysis_context(
    summary: dict[str, Any],
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
) -> dict[str, Any]:
    overlap_names = _collect_overlap(top_contrib_rows, mtti_rows, mttf_rows, mttr_rows)
    return {
        "run_summary": {
            "processed": int(summary.get("processed", 0) or 0),
            "skipped_blank": int(summary.get("skipped_blank", 0) or 0),
            "skipped_no_data": int(summary.get("skipped_no_data", 0) or 0),
            "elapsed_seconds": float(summary.get("elapsed_seconds", 0) or 0),
            "elapsed_hms": str(summary.get("elapsed_hms") or "0:00:00"),
        },
        "okrs": {
            "ftra_percent": _safe_percent(okrs.get("ftra")),
            "mtti": okrs.get("mtti", "TBD"),
            "mttf": okrs.get("mttf", "TBD"),
            "mttr": okrs.get("mttr", "TBD"),
            "status": _compute_rag_status(okrs),
            "noh_counts": dict(okrs.get("counts") or {}),
            "noh_percentages": {
                key: round(float(value or 0.0) * 100.0, 1)
                for key, value in dict(okrs.get("pct") or {}).items()
            },
        },
        "top_hold_time_contributors": [dict(row) for row in top_contrib_rows[:10]],
        "top_mtti_contributors": [dict(row) for row in mtti_rows[:10]],
        "top_mttf_contributors": [dict(row) for row in mttf_rows[:10]],
        "top_mttr_contributors": [dict(row) for row in mttr_rows[:10]],
        "highest_level_observations": {
            "top_hold_time_driver": {
                "application": _safe_name(top_contrib_rows[0]),
                "days": round(_safe_days(top_contrib_rows[0]), 2),
            }
            if top_contrib_rows
            else None,
            "top_mtti_driver": {
                "application": _safe_name(mtti_rows[0]),
                "days": round(_safe_days(mtti_rows[0]), 2),
            }
            if mtti_rows
            else None,
            "top_mttf_driver": {
                "application": _safe_name(mttf_rows[0]),
                "days": round(_safe_days(mttf_rows[0]), 2),
            }
            if mttf_rows
            else None,
            "top_mttr_driver": {
                "application": _safe_name(mttr_rows[0]),
                "days": round(_safe_days(mttr_rows[0]), 2),
            }
            if mttr_rows
            else None,
            "overlap_applications_across_top_10": overlap_names,
        },
    }


def build_ai_user_prompt(
    prompt_template: str,
    summary: dict[str, Any],
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
    mttr_rows: list[dict[str, Any]],
) -> str:
    """Build the user prompt passed to the AI model."""

    context = _build_analysis_context(summary, okrs, top_contrib_rows, mtti_rows, mttf_rows, mttr_rows)
    return (
        f"Prompt from prompt.md:\n{prompt_template.strip()}\n\n"
        "Use only the analysis context below. Do not invent metrics, applications, "
        "or recommendations that are not supported by the provided data.\n\n"
        f"Analysis context (JSON):\n{json.dumps(context, indent=2)}\n"
    )


def _extract_message_text(payload: dict[str, Any]) -> str:
    choices = payload.get("choices") or []
    if not choices:
        raise RuntimeError("AI response did not include any choices.")

    message = dict(choices[0].get("message") or {})
    content = message.get("content", "")
    if isinstance(content, str):
        return content.strip()

    if isinstance(content, list):
        parts: list[str] = []
        for item in content:
            if not isinstance(item, dict):
                continue
            text = item.get("text")
            if isinstance(text, str) and text.strip():
                parts.append(text.strip())
        if parts:
            return "\n".join(parts).strip()

    raise RuntimeError("AI response content was empty.")


def _strip_code_fences(text: str) -> str:
    cleaned = text.strip()
    if cleaned.startswith("```") and cleaned.endswith("```"):
        lines = cleaned.splitlines()
        cleaned = "\n".join(lines[1:-1]).strip()
    return cleaned


def generate_ai_summary(
    settings: Settings,
    prompt_template: str,
    summary: dict[str, Any],
    okrs: dict[str, Any],
    top_contrib_rows: list[dict[str, Any]],
    mtti_rows: list[dict[str, Any]],
    mttf_rows: list[dict[str, Any]],
) -> AISummaryResult:
    """Generate an AI summary using the configured chat-completions endpoint."""

    ai_token = resolve_ai_token(settings)
    if not ai_token:
        raise RuntimeError("Set defect_lens_AI_TOKEN or GITHUB_TOKEN to enable AI insights generation.")
    if not settings.ai_api_url:
        raise RuntimeError("Set defect_lens_AI_API_URL to a valid GitHub Models inference endpoint.")
    if not settings.ai_model:
        raise RuntimeError("Set defect_lens_AI_MODEL to a valid GitHub Models model ID.")

    prompt_signature = build_ai_prompt_signature(prompt_template)
    request_payload = {
        "model": settings.ai_model,
        "messages": [
            {"role": "system", "content": DEFAULT_SYSTEM_PROMPT},
            {
                "role": "user",
                "content": build_ai_user_prompt(
                    prompt_template=prompt_template,
                    summary=summary,
                    okrs=okrs,
                    top_contrib_rows=top_contrib_rows,
                    mtti_rows=mtti_rows,
                    mttf_rows=mttf_rows,
                ),
            },
        ],
        "temperature": 0.2,
        "max_tokens": settings.ai_max_tokens,
        "stream": False,
    }
    headers = {
        "Accept": "application/vnd.github+json",
        "Authorization": f"Bearer {ai_token}",
        "Content-Type": "application/json",
    }
    if settings.ai_api_version:
        headers["X-GitHub-Api-Version"] = settings.ai_api_version

    try:
        response = requests.post(
            settings.ai_api_url,
            headers=headers,
            json=request_payload,
            timeout=settings.ai_timeout_seconds,
        )
        response.raise_for_status()
    except requests.RequestException as exc:
        detail = ""
        if exc.response is not None:
            try:
                detail = exc.response.text.strip()
            except Exception:
                detail = ""
        message = f"AI inference request failed: {exc}"
        if detail:
            message = f"{message} | {detail}"
        raise RuntimeError(message) from exc

    payload = response.json()
    text = _strip_code_fences(_extract_message_text(payload))
    if not text:
        raise RuntimeError("AI response was empty.")

    return AISummaryResult(
        title=DEFAULT_AI_TITLE,
        text=text,
        prompt_signature=prompt_signature,
        model=settings.ai_model,
    )
