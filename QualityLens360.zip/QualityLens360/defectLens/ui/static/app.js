// ----------------------------
// Defect Lens - UI Controller
// ----------------------------

let currentJobId = null;
let logIndex = 0;
let timer = null;
let insightsRequested = false;
let insightsInFlight = false;

let topChart = null;     // existing donut: Top 5 Contributors (hold-time)
let mttiChart = null;    // donut: Top 5 Contributors (MTTI)
let mttfChart = null;    // ✅ NEW donut: Top 5 Contributors (MTTF)
let mttrChart = null;    // donut: Top 5 Contributors (MTTR)
const OKR_SEVERITY_KEYS = ['Sev 1', 'Sev 2', 'Sev 3', 'Sev 4'];
const OKR_SEVERITY_DISPLAY = {
  'Sev 1': 'Severity 1',
  'Sev 2': 'Severity 2',
  'Sev 3': 'Severity 3',
  'Sev 4': 'Severity 4'
};
const SEVERITY_SLA_DAYS = {
  'Sev 1': 0.5,
  'Sev 2': 3,
  'Sev 3': 5,
  'Sev 4': 10
};

function $(id) {
  return document.getElementById(id);
}

function setBadge(state) {
  const badge = $('statusBadge');
  if (!badge) return;

  badge.className = 'badge';
  if (state === 'running' || state === 'queued') badge.classList.add('text-bg-primary');
  else if (state === 'completed') badge.classList.add('text-bg-success');
  else if (state === 'failed') badge.classList.add('text-bg-danger');
  else badge.classList.add('text-bg-secondary');

  const s = String(state || 'ready');
  const label = s.charAt(0).toUpperCase() + s.slice(1);
  if (state === 'running' || state === 'queued') {
    badge.innerHTML = '<span class="ql-spinner"></span>' + label;
  } else {
    badge.textContent = label;
  }
}

function setProgress(pct) {
  const bar = $('progressBar');
  if (!bar) return;

  const v = Math.max(0, Math.min(100, Number(pct || 0)));
  bar.style.width = v.toFixed(1) + '%';
  bar.textContent = v.toFixed(0) + '%';

  if (bar.parentElement) {
    bar.parentElement.setAttribute('aria-valuenow', v.toFixed(0));
  }
}

function setStatusText(t) {
  const el = $('statusText');
  if (el) el.textContent = t || '';
}

function setAI(t) {
  const el = $('aiText');
  if (el) el.textContent = t || '';
}

function setAITitle(t) {
  const el = $('aiTitle');
  if (el) el.textContent = t || 'AI Insights';
}

function appendLog(lines) {
  const box = $('logText');
  if (!box) return;
  if (!lines || !lines.length) return;

  box.textContent += lines.join('\n') + '\n';
  box.scrollTop = box.scrollHeight;
}

function setSummary(summary) {
  const el = $('summaryBox');
  if (!el) return;

  if (!summary) {
    el.innerHTML = '';
    return;
  }

  el.innerHTML = `
    <div><b>Processed:</b> ${summary.processed ?? 0}</div>
    <div><b>Skipped blank:</b> ${summary.skipped_blank ?? 0}</div>
    <div><b>Skipped no data:</b> ${summary.skipped_no_data ?? 0}</div>
    <div><b>Time:</b> ${summary.elapsed_seconds ?? 0}s (${summary.elapsed_hms ?? ''})</div>
  `;
}

// ----------------------------
// OKRs rendering
// ----------------------------

// Convert a duration string like "2.5 days" / "10.3 hrs" / "45.0 mins" to days.
function parseToDays(val) {
  if (!val || val === 'TBD' || val === 'NA') return null;
  const s = String(val).toLowerCase().trim();
  const n = parseFloat(s);
  if (isNaN(n)) return null;
  if (s.includes('day')) return n;
  if (s.includes('hr'))  return n / 24;
  if (s.includes('min')) return n / 1440;
  return n; // fallback: treat as days
}

// Apply a RAG badge to an element. status: 'GREEN' | 'AMBER' | 'RED' | null
function applyRag(elId, status) {
  const el = $(elId);
  if (!el) return;
  el.className = 'okr-rag-badge';
  const map = {
    GREEN: ['okr-rag-green', '\u25CF GREEN'],
    AMBER: ['okr-rag-amber', '\u25CF AMBER'],
    RED:   ['okr-rag-red',   '\u25CF RED'],
  };
  const [cls, txt] = map[status] || ['okr-rag-grey', '\u25CF --'];
  el.classList.add(cls);
  el.textContent = txt;
}

function displayMetricValue(value, fallback = 'NA') {
  if (value === null || value === undefined || value === '' || value === 'TBD') return fallback;
  return String(value);
}

function breakdownStatus(metricKey, severityKey, rawValue) {
  if (!rawValue || rawValue === 'TBD' || rawValue === 'NA') return null;

  if (metricKey === 'ftra') {
    const pct = parseFloat(String(rawValue).replace('%', ''));
    if (Number.isNaN(pct)) return null;
    if (pct > 90) return 'green';
    if (pct >= 85) return 'amber';
    return 'red';
  }

  const slaDays = SEVERITY_SLA_DAYS[severityKey];
  if (!slaDays) return null;

  const multiplierMap = {
    mtti: 0.2,
    mttf: 0.6,
    mttr: 1.0
  };
  const multiplier = multiplierMap[metricKey];
  if (!multiplier) return null;

  const targetDays = slaDays * multiplier;
  const valueDays = parseToDays(rawValue);
  if (valueDays === null) return null;
  if (valueDays <= targetDays) return 'green';
  if (valueDays <= targetDays * 1.2) return 'amber';
  return 'red';
}

function renderSeverityBreakdown(containerId, valuesBySeverity, metricKey) {
  const container = $(containerId);
  if (!container) return;

  const values = valuesBySeverity || {};
  container.innerHTML = '';

  const fragment = document.createDocumentFragment();
  for (const severityKey of OKR_SEVERITY_KEYS) {
    const row = document.createElement('div');
    row.className = 'okr-breakdown-row';

    const name = document.createElement('span');
    name.className = 'okr-breakdown-severity';
    name.textContent = OKR_SEVERITY_DISPLAY[severityKey] || severityKey;

    const value = document.createElement('span');
    value.className = 'okr-breakdown-value';
    const renderedValue = displayMetricValue(values[severityKey]);
    value.textContent = renderedValue;
    const status = breakdownStatus(metricKey, severityKey, renderedValue);
    if (status) {
      value.classList.add(`okr-breakdown-${status}`);
    }

    row.appendChild(name);
    row.appendChild(value);
    fragment.appendChild(row);
  }

  container.appendChild(fragment);
}

function setOKRs(okrs) {
  if (!okrs) return;

  const total = okrs.total || 0;
  const ftra = Number(okrs.ftra || 0);

  if ($('okrFtra')) $('okrFtra').textContent = (ftra * 100).toFixed(0) + '%';
  if ($('okrTotal')) $('okrTotal').textContent = total ? String(total) : '--';
  if ($('okrMtti')) $('okrMtti').textContent = displayMetricValue(okrs.mtti);
  if ($('okrMttf')) $('okrMttf').textContent = displayMetricValue(okrs.mttf);
  if ($('okrMttr')) $('okrMttr').textContent = displayMetricValue(okrs.mttr);

  const severityBreakdown = okrs.severityBreakdown || {};
  renderSeverityBreakdown('okrFtraBreakdown', severityBreakdown.ftra, 'ftra');
  renderSeverityBreakdown('okrMttiBreakdown', severityBreakdown.mtti, 'mtti');
  renderSeverityBreakdown('okrMttfBreakdown', severityBreakdown.mttf, 'mttf');
  renderSeverityBreakdown('okrMttrBreakdown', severityBreakdown.mttr, 'mttr');

  // NOH table with conditional % coloring
  const tbody = $('okrNohTable');
  if (!tbody) return;

  const buckets = ['No Hops', '1 Hop', '2 Hops', '3-5 Hops', '6-10 Hops', '>10 Hops'];
  const counts = okrs.counts || {};
  const pct = okrs.pct || {};

  tbody.innerHTML = '';

  buckets.forEach((b, idx) => {
    const c = counts[b] || 0;
    const p = Number(pct[b] || 0);
    const pctText = (p * 100).toFixed(0) + '%';

    // first 2 rows green; rest red
    const pctClass = (idx <= 1) ? 'pct-green' : 'pct-red';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${b}</td>
      <td class="text-center">${c}</td>
      <td class="text-center ${pctClass}">${pctText}</td>
    `;
    tbody.appendChild(tr);
  });

  // Total row
  const trt = document.createElement('tr');
  trt.innerHTML = `
    <td><b>Total</b></td>
    <td class="text-center"><b>${total}</b></td>
    <td class="text-center"><b>${total ? '100%' : '0%'}</b></td>
  `;
  tbody.appendChild(trt);

  // --- RAG status ---
  const ftraPct = ftra * 100;
  const ftraStatus = ftraPct > 90 ? 'GREEN' : ftraPct >= 85 ? 'AMBER' : 'RED';
  applyRag('okrFtraRag', ftraStatus);

  const mttiDays = parseToDays(displayMetricValue(okrs.mtti));
  const mttiStatus = mttiDays === null ? null : mttiDays <= 4 ? 'GREEN' : mttiDays <= 5 ? 'AMBER' : 'RED';
  applyRag('okrMttiRag', mttiStatus);

  const mttfDays = parseToDays(displayMetricValue(okrs.mttf));
  const mttfStatus = mttfDays === null ? null : mttfDays <= 11 ? 'GREEN' : mttfDays <= 13 ? 'AMBER' : 'RED';
  applyRag('okrMttfRag', mttfStatus);

  const mttrDays = parseToDays(displayMetricValue(okrs.mttr));
  const mttrStatus = mttrDays === null ? null : mttrDays <= 4.6 ? 'GREEN' : mttrDays <= 5.6 ? 'AMBER' : 'RED';
  applyRag('okrMttrRag', mttrStatus);
}

// ----------------------------
// Existing: Key Contributors (Hold-time) table + chart
// ----------------------------
function setTopContribTable(rows) {
  const tbody = $('topContribTable');
  if (!tbody) return;

  if (!rows || !rows.length) {
    tbody.innerHTML = `<tr><td colspan="4" class="text-muted p-3">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  for (const r of rows) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.application || ''}</td>
      <td class="text-center">${Number(r.hours ?? 0).toFixed(2)}</td>
      <td class="text-center">${Number(r.days ?? 0).toFixed(2)}</td>
      <td class="text-center">${Number(r.pct ?? 0).toFixed(1)}%</td>
    `;
    tbody.appendChild(tr);
  }
}

function buildDonutChart(canvasId, existingChartRef, payload, titleIgnored) {
  const canvas = $(canvasId);
  if (!canvas) return { chart: existingChartRef };

  const labels = (payload && payload.labels) ? payload.labels : [];
  const values = (payload && payload.values) ? payload.values : [];

  if (!labels.length || !values.length || typeof Chart === 'undefined') {
    if (existingChartRef) {
      existingChartRef.destroy();
      existingChartRef = null;
    }
    return { chart: existingChartRef };
  }

  const ctx = canvas.getContext('2d');
  const colors = [
    '#5B9BD5', '#ED7D31', '#A5A5A5', '#FFC000', '#4472C4',
    '#70AD47', '#264478', '#9E480E', '#636363', '#987300'
  ];

  if (existingChartRef) {
    existingChartRef.destroy();
    existingChartRef = null;
  }

  existingChartRef = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels,
      datasets: [{
        data: values,
        backgroundColor: labels.map((_, i) => colors[i % colors.length]),
        borderWidth: 0,
        hoverOffset: 6
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      cutout: '65%',
      plugins: {
        legend: {
          display: true,
          position: 'bottom',
          labels: { boxWidth: 10, boxHeight: 10 }
        },
        tooltip: {
          callbacks: {
            label: (context) => `${context.label}: ${Number(context.raw ?? 0).toFixed(1)}%`
          }
        }
      }
    }
  });

  return { chart: existingChartRef };
}

function setTopContribChart(payload) {
  const r = buildDonutChart('topContribChart', topChart, payload);
  topChart = r.chart;
}

// ----------------------------
// MTTI Contributors table + chart
// ----------------------------
function setMttiContribTable(rows) {
  const tbody = $('mttiContribTable');
  if (!tbody) return;

  if (!rows || !rows.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="text-muted p-3">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  for (const r of rows) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.application || ''}</td>
      <td class="text-center">${Number(r.days ?? 0).toFixed(2)}</td>
      <td class="text-center">${Number(r.pct ?? 0).toFixed(1)}%</td>
    `;
    tbody.appendChild(tr);
  }
}

function setMttiContribChart(payload) {
  const r = buildDonutChart('mttiContribChart', mttiChart, payload);
  mttiChart = r.chart;
}

// ----------------------------
// ✅ NEW: MTTF Contributors table + chart
// ----------------------------
function setMttfContribTable(rows) {
  const tbody = $('mttfContribTable');
  if (!tbody) return;

  if (!rows || !rows.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="text-muted p-3">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  for (const r of rows) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.application || ''}</td>
      <td class="text-center">${Number(r.days ?? 0).toFixed(2)}</td>
      <td class="text-center">${Number(r.pct ?? 0).toFixed(1)}%</td>
    `;
    tbody.appendChild(tr);
  }
}

function setMttfContribChart(payload) {
  const r = buildDonutChart('mttfContribChart', mttfChart, payload);
  mttfChart = r.chart;
}

function setMttrContribTable(rows) {
  const tbody = $('mttrContribTable');
  if (!tbody) return;

  if (!rows || !rows.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="text-muted p-3">No data.</td></tr>`;
    return;
  }

  tbody.innerHTML = '';
  for (const r of rows) {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${r.application || ''}</td>
      <td class="text-center">${Number(r.days ?? 0).toFixed(2)}</td>
      <td class="text-center">${Number(r.pct ?? 0).toFixed(1)}%</td>
    `;
    tbody.appendChild(tr);
  }
}

function setMttrContribChart(payload) {
  const r = buildDonutChart('mttrContribChart', mttrChart, payload);
  mttrChart = r.chart;
}

function bindOkrExpandButtons() {
  document.querySelectorAll('[data-okr-toggle]').forEach((button) => {
    button.addEventListener('click', () => {
      const targetId = button.getAttribute('data-okr-toggle');
      const panel = targetId ? $(targetId) : null;
      if (!panel) return;

      const isExpanded = button.getAttribute('aria-expanded') === 'true';
      const nextExpanded = !isExpanded;
      button.setAttribute('aria-expanded', String(nextExpanded));

      const label = button.querySelector('.okr-expand-label');
      const icon = button.querySelector('.okr-expand-icon');
      if (label) label.textContent = nextExpanded ? 'Hide Details' : 'Show Details';
      if (icon) icon.innerHTML = nextExpanded ? '&#9652;' : '&#9662;';

      panel.hidden = !nextExpanded;
    });
  });
}

// ----------------------------
// Polling loop
// ----------------------------
async function poll() {
  if (!currentJobId) return;

  const statusRes = await fetch(`/api/status/${currentJobId}`);
  const statusJson = await statusRes.json();
  if (!statusJson.ok) return;

  setBadge(statusJson.status);
  setProgress(statusJson.progress);
  setStatusText(statusJson.message);

  if (statusJson.aiTitle) setAITitle(statusJson.aiTitle);
  if (statusJson.ai) setAI(statusJson.ai);
  if (statusJson.summary) setSummary(statusJson.summary);
  if (statusJson.okrs) setOKRs(statusJson.okrs);

  // Existing contributors (hold-time)
  if (statusJson.topContrib) setTopContribTable(statusJson.topContrib);
  if (statusJson.topContribChart) setTopContribChart(statusJson.topContribChart);

  // MTTI contributors
  if (statusJson.mttiContrib) setMttiContribTable(statusJson.mttiContrib);
  if (statusJson.mttiContribChart) setMttiContribChart(statusJson.mttiContribChart);

  // ✅ NEW MTTF contributors
  if (statusJson.mttfContrib) setMttfContribTable(statusJson.mttfContrib);
  if (statusJson.mttfContribChart) setMttfContribChart(statusJson.mttfContribChart);

  // MTTR contributors
  if (statusJson.mttrContrib) setMttrContribTable(statusJson.mttrContrib);
  if (statusJson.mttrContribChart) setMttrContribChart(statusJson.mttrContribChart);

  // Run log
  const logRes = await fetch(`/api/log/${currentJobId}?since=${logIndex}`);
  const logJson = await logRes.json();
  if (logJson.ok) {
    appendLog(logJson.lines);
    logIndex = logJson.next;
  }

  // Download enablement
  const downloadBtn = $('downloadBtn');
  if (statusJson.status === 'completed' && downloadBtn) {
    downloadBtn.classList.remove('disabled');
    downloadBtn.href = `/download/${currentJobId}`;
    downloadBtn.removeAttribute('aria-disabled');
    downloadBtn.removeAttribute('tabindex');
    setStatusText(''); // clear progress text once complete
    clearInterval(timer);

    const promptIsStale = Boolean(statusJson.currentPromptSignature) &&
      statusJson.aiPromptSignature !== statusJson.currentPromptSignature;

    if ((!statusJson.ai || promptIsStale) && !insightsRequested) {
      provideAIInsights(true);
    }
  }

  if (statusJson.status === 'failed') {
    clearInterval(timer);
  }
}

async function provideAIInsights(autoTriggered = false) {
  if (!currentJobId || insightsInFlight) return;

  insightsRequested = true;
  insightsInFlight = true;

  try {
    const response = await fetch(`/api/insights/${currentJobId}`, { method: 'POST' });
    const payload = await response.json();

    if (!payload.ok) {
      appendLog([`Error: ${payload.error || 'Failed to generate AI insights.'}`]);
      insightsRequested = false;
      return;
    }

    setAI(payload.text || '');
    setAITitle(payload.title || 'AI Insights');
    if (!autoTriggered) {
      appendLog(['AI Insights generated successfully.']);
    }
  } catch (err) {
    insightsRequested = false;
    appendLog([String(err)]);
  } finally {
    insightsInFlight = false;
  }
}

// ----------------------------
// Bootstrapping
// ----------------------------
document.addEventListener('DOMContentLoaded', () => {
  bindOkrExpandButtons();
  const form = $('runForm');
  const runBtn = $('runBtn');
  if (!form) return;

  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    if (runBtn) runBtn.disabled = true;
    currentJobId = null;
    logIndex = 0;
    insightsRequested = false;
    insightsInFlight = false;

    if ($('logText')) $('logText').textContent = '';
  setAITitle('AI Insights');
    if ($('aiText')) $('aiText').textContent = '';
    if ($('summaryBox')) $('summaryBox').innerHTML = '';

    // Reset existing contributors
    if ($('topContribTable')) {
      $('topContribTable').innerHTML =
        `<tr><td colspan="4" class="text-muted p-3">Run analysis to populate this table.</td></tr>`;
    }
    if (topChart) { topChart.destroy(); topChart = null; }

    // Reset MTTI contributors
    if ($('mttiContribTable')) {
      $('mttiContribTable').innerHTML =
        `<tr><td colspan="3" class="text-muted p-3">Run analysis to populate this table.</td></tr>`;
    }
    if (mttiChart) { mttiChart.destroy(); mttiChart = null; }

    // ✅ Reset MTTF contributors
    if ($('mttfContribTable')) {
      $('mttfContribTable').innerHTML =
        `<tr><td colspan="3" class="text-muted p-3">Run analysis to populate this table.</td></tr>`;
    }
    if (mttfChart) { mttfChart.destroy(); mttfChart = null; }

    if ($('mttrContribTable')) {
      $('mttrContribTable').innerHTML =
        `<tr><td colspan="3" class="text-muted p-3">Run analysis to populate this table.</td></tr>`;
    }
    if (mttrChart) { mttrChart.destroy(); mttrChart = null; }

    // Reset OKR RAG badges
    applyRag('okrFtraRag', null);
    applyRag('okrMttiRag', null);
    applyRag('okrMttfRag', null);
    applyRag('okrMttrRag', null);

    const downloadBtn = $('downloadBtn');
    if (downloadBtn) {
      downloadBtn.classList.add('disabled');
      downloadBtn.href = '#';
    }

    setBadge('queued');
    setProgress(0);
    setStatusText('Starting...');

    try {
      const isJql = document.querySelector('#inputModeTabs .nav-link.active')?.id === 'jqlModeBtn';
      let runRes;

      if (isJql) {
        // ---- JQL mode ---------------------------------------------------
        const jql = ($('jqlInput')?.value || '').trim();
        if (!jql) {
          setBadge('failed');
          setStatusText('Please enter a JQL query.');
          appendLog(['Error: JQL query is required.']);
          if (runBtn) runBtn.disabled = false;
          return;
        }
        const fd = new FormData();
        fd.append('username', form.querySelector('[name=username]').value);
        fd.append('password', form.querySelector('[name=password]').value);
        fd.append('jql', jql);
        runRes = await fetch('/api/run-jql', { method: 'POST', body: fd });
      } else {
        // ---- Upload mode ------------------------------------------------
        const fileInput = $('fileInput');
        if (!fileInput || !fileInput.files || !fileInput.files.length) {
          setBadge('failed');
          setStatusText('Please upload an Excel .xlsx file.');
          appendLog(['Error: No file selected.']);
          if (runBtn) runBtn.disabled = false;
          return;
        }
        const formData = new FormData(form);
        runRes = await fetch('/api/run', { method: 'POST', body: formData });
      }
      const runJson = await runRes.json();

      if (!runJson.ok) {
        setBadge('failed');
        setStatusText(runJson.error || 'Failed to start job.');
        appendLog([`Error: ${runJson.error || 'Unknown error'}`]);
        return;
      }

      currentJobId = runJson.jobId;
      appendLog([`Job started: ${currentJobId}`]);

      setBadge('running');
      setStatusText('Running...');

      if (timer) clearInterval(timer);
      timer = setInterval(poll, 900);

    } catch (err) {
      setBadge('failed');
      setStatusText('Failed to start (see log).');
      appendLog([String(err)]);
    } finally {
      if (runBtn) setTimeout(() => { runBtn.disabled = false; }, 600);
    }
  });

  const clearBtn = $('clearLog');
  if (clearBtn) {
    clearBtn.addEventListener('click', () => {
      if ($('logText')) $('logText').textContent = '';
      logIndex = 0;
    });
  }
});