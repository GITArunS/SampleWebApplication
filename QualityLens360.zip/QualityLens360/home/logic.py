import json
import os
import re
from threading import RLock

WORKSPACE_ROOT = os.path.dirname(os.path.dirname(__file__))
LOG_DIRECTORY = os.path.join(WORKSPACE_ROOT, 'logs')
LOG_FILE_PATH = os.path.join(LOG_DIRECTORY, 'operations_hub_email.log')
HUB_METRICS_FILE_PATH = os.path.join(LOG_DIRECTORY, 'hub_metrics.json')
HUB_METRICS_LOCK = RLock()
HUB_METRICS_DEFAULTS = {
    'run_hits': 0,
    'emails_sent': 0,
    'self_heals_done': 0,
    'tile_clicks': {
        'ram': 0,
        'operations': 0,
        'defect-lens': 0,
        'advanced-reporting': 0,
    },
    'bootstrap_completed': True,
}


def _safe_int(value, default=0):
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return default


def build_hub_metrics_from_log():
    metrics = dict(HUB_METRICS_DEFAULTS)
    if not os.path.exists(LOG_FILE_PATH):
        return metrics

    self_heal_update_pattern = re.compile(r'Self-heal .* updated (\d+) issues:')
    with open(LOG_FILE_PATH, 'r', encoding='utf-8', errors='ignore') as log_file:
        for log_line in log_file:
            if "Starting Outlook send for subject '" in log_line:
                metrics['run_hits'] += 1
            elif 'Self-heal ' in log_line and ' updated ' in log_line and ' issues:' in log_line:
                metrics['run_hits'] += 1
                match = self_heal_update_pattern.search(log_line)
                if match:
                    metrics['self_heals_done'] += int(match.group(1))

            if 'Outlook Send() completed' in log_line:
                metrics['emails_sent'] += 1

    return metrics


def load_hub_metrics():
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    with HUB_METRICS_LOCK:
        if not os.path.exists(HUB_METRICS_FILE_PATH):
            metrics = build_hub_metrics_from_log()
            save_hub_metrics(metrics)
            return metrics

        try:
            with open(HUB_METRICS_FILE_PATH, 'r', encoding='utf-8') as metrics_file:
                metrics = json.load(metrics_file)
        except (OSError, ValueError, TypeError):
            metrics = build_hub_metrics_from_log()
            save_hub_metrics(metrics)
            return metrics

        normalized_metrics = dict(HUB_METRICS_DEFAULTS)
        for key in ('run_hits', 'emails_sent', 'self_heals_done'):
            normalized_metrics[key] = _safe_int(metrics.get(key, 0))
        normalized_tile_clicks = dict(HUB_METRICS_DEFAULTS['tile_clicks'])
        raw_tile_clicks = metrics.get('tile_clicks') or {}
        if isinstance(raw_tile_clicks, dict):
            for tile_id in normalized_tile_clicks:
                normalized_tile_clicks[tile_id] = _safe_int(raw_tile_clicks.get(tile_id, 0))
        normalized_metrics['tile_clicks'] = normalized_tile_clicks
        return normalized_metrics


def save_hub_metrics(metrics):
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    temp_metrics_path = f'{HUB_METRICS_FILE_PATH}.tmp'
    with open(temp_metrics_path, 'w', encoding='utf-8') as metrics_file:
        json.dump(metrics, metrics_file)
    os.replace(temp_metrics_path, HUB_METRICS_FILE_PATH)


def update_hub_metrics(run_hits=0, emails_sent=0, self_heals_done=0, tile_click_id=None):
    with HUB_METRICS_LOCK:
        metrics = load_hub_metrics()
        metrics['run_hits'] = max(0, metrics['run_hits'] + int(run_hits))
        metrics['emails_sent'] = max(0, metrics['emails_sent'] + int(emails_sent))
        metrics['self_heals_done'] = max(0, metrics['self_heals_done'] + int(self_heals_done))
        if tile_click_id in metrics['tile_clicks']:
            metrics['tile_clicks'][tile_click_id] = max(0, metrics['tile_clicks'][tile_click_id] + 1)
        save_hub_metrics(metrics)
        return metrics


def record_operation_run():
    update_hub_metrics(run_hits=1)


def record_email_sent():
    update_hub_metrics(emails_sent=1)


def record_self_heal_updates(update_count):
    if update_count:
        update_hub_metrics(self_heals_done=int(update_count))


def record_dashboard_tile_click(tile_click_id):
    if tile_click_id:
        update_hub_metrics(tile_click_id=tile_click_id)


def get_hub_metrics_summary():
    metrics = load_hub_metrics()
    return {
        'run_hits': metrics['run_hits'],
        'emails_sent': metrics['emails_sent'],
        'self_heals_done': metrics['self_heals_done'],
        'tile_clicks': dict(metrics['tile_clicks']),
    }
