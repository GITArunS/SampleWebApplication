"""
RAM KPI PowerPoint Slide Generator — mirrors the QualityLens 360 dashboard styling.

Builds a presentation from the same export payload used by the Excel export.
The slide layout replicates the dashboard's KPI card grid with:
- Tiles grouped by section (Defect Triage, Functional Efficiency, Automation …)
- RAG-tinted card backgrounds matching the HTML gradient fills
- Rounded card tiles, target pill, fraction display
- AT&T logo in the bottom-right corner of every slide
"""

import io
import os
from datetime import datetime

from pptx import Presentation
from pptx.util import Inches, Pt, Emu
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
from pptx.enum.shapes import MSO_SHAPE


# ── Resolve AT&T logo path ─────────────────────────────────────────────────
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_LOGO_PATH = os.path.join(_THIS_DIR, 'core', 'logo.jpg')
_LOGO_PATH = os.path.normpath(_LOGO_PATH)

# ── Palette matching the dashboard CSS ──────────────────────────────────────
CLR_DARK_NAVY = RGBColor(0x0F, 0x4C, 0x81)
CLR_TEAL = RGBColor(0x08, 0x91, 0xB2)
CLR_VALUE_BLUE = RGBColor(0x07, 0x59, 0x85)  # .kpi-value color
CLR_WHITE = RGBColor(0xFF, 0xFF, 0xFF)
CLR_SLIDE_BG = RGBColor(0xFF, 0xFF, 0xFF)    # white background
CLR_CARD_BG = RGBColor(0xFF, 0xFF, 0xFF)
CLR_BORDER = RGBColor(0x94, 0xA3, 0xB8)      # muted border
CLR_TEXT = RGBColor(0x0F, 0x17, 0x2A)
CLR_MUTED = RGBColor(0x64, 0x74, 0x8B)
CLR_SUBTITLE = RGBColor(0xBF, 0xDB, 0xFE)
CLR_SECTION_TITLE = RGBColor(0x0B, 0x63, 0xC9)  # blue accent for section headings

RAG_ACCENT = {
    'green': RGBColor(0x22, 0xC5, 0x5E),
    'amber': RGBColor(0xF5, 0x9E, 0x0B),
    'red': RGBColor(0xEF, 0x44, 0x44),
    'neutral': CLR_BORDER,
}

# Card background tint — lighter versions matching the HTML gradient fills
RAG_CARD_BG = {
    'green': RGBColor(0xF2, 0xFB, 0xF5),   # linear-gradient(… #f2fbf5)
    'amber': RGBColor(0xFF, 0xF8, 0xEB),   # linear-gradient(… #fff8eb)
    'red': RGBColor(0xFF, 0xF4, 0xF4),     # linear-gradient(… #fff4f4)
    'neutral': CLR_CARD_BG,
}

RAG_BORDER_CLR = {
    'green': RGBColor(0x86, 0xEF, 0xAC),   # rgba(34,197,94,0.28) approx
    'amber': RGBColor(0xFD, 0xD8, 0x7A),   # rgba(245,158,11,0.3)  approx
    'red': RGBColor(0xFC, 0xA5, 0xA5),     # rgba(239,68,68,0.26)  approx
    'neutral': RGBColor(0xD8, 0xE1, 0xEB),
}

RAG_TARGET_TEXT = {
    'green': RGBColor(0x16, 0x65, 0x34),
    'amber': RGBColor(0x92, 0x40, 0x0E),
    'red': RGBColor(0x99, 0x1B, 0x1B),
    'neutral': CLR_MUTED,
}

RAG_TARGET_BG = {
    'green': RGBColor(0xDC, 0xFC, 0xE7),
    'amber': RGBColor(0xFE, 0xF3, 0xC7),
    'red': RGBColor(0xFE, 0xE2, 0xE2),
    'neutral': RGBColor(0xE2, 0xE8, 0xF0),
}

SLIDE_WIDTH = Inches(13.333)
SLIDE_HEIGHT = Inches(7.5)

# Logo at native size (66x27 px @ 96 DPI ≈ 0.69" x 0.28")
LOGO_W = Inches(0.69)
LOGO_H = Inches(0.28)
LOGO_X = SLIDE_WIDTH - LOGO_W - Inches(0.3)
LOGO_Y = SLIDE_HEIGHT - LOGO_H - Inches(0.15)

COPYRIGHT_TEXT = '\u00a9 2026 AT&T Intellectual Property - AT&T Proprietary (Internal Use Only)\u200b'
CLR_FOOTER = RGBColor(0x9C, 0xA3, 0xAF)  # grey for footer text


# ── Helpers ─────────────────────────────────────────────────────────────────

def _add_logo(slide):
    """Place the AT&T logo in the bottom-right corner of a slide."""
    if os.path.isfile(_LOGO_PATH):
        slide.shapes.add_picture(_LOGO_PATH, LOGO_X, LOGO_Y, LOGO_W, LOGO_H)


def _add_footer(slide, page_num, total_pages):
    """Add pagination count and copyright text in grey at the bottom of a slide."""
    # Bottom-left: page number followed by copyright
    ftx = slide.shapes.add_textbox(Inches(0.4), SLIDE_HEIGHT - Inches(0.38), Inches(10), Inches(0.3))
    fp = ftx.text_frame.paragraphs[0]
    fp.alignment = PP_ALIGN.LEFT
    # Page number run
    run_num = fp.add_run()
    run_num.text = str(page_num)
    run_num.font.size = Pt(8)
    run_num.font.bold = True
    run_num.font.color.rgb = CLR_FOOTER
    # Separator
    run_sep = fp.add_run()
    run_sep.text = '    |    '
    run_sep.font.size = Pt(7)
    run_sep.font.color.rgb = CLR_FOOTER
    # Copyright run
    run_cr = fp.add_run()
    run_cr.text = COPYRIGHT_TEXT
    run_cr.font.size = Pt(7)
    run_cr.font.color.rgb = CLR_FOOTER


def _build_sections(tiles):
    """Group flat tile list into ordered sections (mirrors build_ram_kpi_sections)."""
    sections = []
    section_lookup = {}
    default_section = {'title': None, 'tiles': []}
    for tile in tiles:
        section_title = tile.get('section') or None
        if not section_title:
            default_section['tiles'].append(tile)
            continue
        section = section_lookup.get(section_title)
        if section is None:
            section = {'title': section_title, 'tiles': []}
            section_lookup[section_title] = section
            sections.append(section)
        section['tiles'].append(tile)
    if default_section['tiles']:
        sections.insert(0, default_section)
    return sections


# ── TITLE SLIDE ─────────────────────────────────────────────────────────────

def _add_title_slide(prs, payload):
    """Slide 1 — branded title with application name and date range."""
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = CLR_SLIDE_BG

    band = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), SLIDE_WIDTH, Inches(2.6),
    )
    band.fill.solid()
    band.fill.fore_color.rgb = CLR_DARK_NAVY
    band.line.fill.background()

    application = payload.get('application', '')

    txbox = slide.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(11), Inches(1.2))
    tf = txbox.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = f'{application} : Real-Time Analysis & Metrics Report'
    p.font.size = Pt(28)
    p.font.bold = True
    p.font.color.rgb = CLR_WHITE

    date_from = payload.get('created_from', '')
    date_to = payload.get('created_to', '')
    selected_release = payload.get('selected_release', '')
    if date_from and date_to:
        period = f'{date_from}  \u2192  {date_to}'
    elif selected_release:
        period = f'Release: {selected_release}'
    else:
        period = 'All dates'
    sub = tf.add_paragraph()
    sub.text = period
    sub.font.size = Pt(14)
    sub.font.color.rgb = CLR_SUBTITLE
    sub.space_before = Pt(6)

    # ── Center content area: descriptive text to fill empty space ──
    desc_box = slide.shapes.add_textbox(Inches(0.8), Inches(3.2), Inches(11.5), Inches(3.5))
    desc_tf = desc_box.text_frame
    desc_tf.word_wrap = True

    p1 = desc_tf.paragraphs[0]
    p1.text = f'Provide insights on the automated, data-driven KPI measurement for {application}.'
    p1.font.size = Pt(20)
    p1.font.bold = True
    p1.font.color.rgb = CLR_DARK_NAVY
    p1.space_after = Pt(20)

    p2 = desc_tf.add_paragraph()
    p2.text = (
        'This enables Metrics Driven Operating model to assess key KPIs in real-time '
        'by pulling live data from iTrack and compute them against defined '
        'RAG (Red/Amber/Green) targets.'
    )
    p2.font.size = Pt(18)
    p2.font.color.rgb = CLR_TEXT
    p2.space_before = Pt(12)

    # 'Generated by' text — bottom-left, aligned above the footer pagination
    ft = slide.shapes.add_textbox(Inches(0.4), SLIDE_HEIGHT - Inches(0.72), Inches(8), Inches(0.3))
    fp = ft.text_frame.paragraphs[0]
    fp.text = f'Generated by QualityLens 360  |  {datetime.now().strftime("%B %d, %Y %I:%M %p")}'
    fp.font.size = Pt(9)
    fp.font.color.rgb = CLR_MUTED

    _add_logo(slide)


# ── KPI TILE SLIDES (section-grouped) ───────────────────────────────────────

def _add_kpi_slides(prs, payload):
    """KPI grid slides grouped by section — 4 columns, multiple sections per slide."""
    tiles = payload.get('kpi_tiles', [])
    if not tiles:
        return

    sections = _build_sections(tiles)
    application = payload.get('application', '')

    cols = 4
    tile_w = Inches(2.95)
    tile_h = Inches(2.55)
    margin_left = Inches(0.4)
    gap_x = Inches(0.24)
    gap_y = Inches(0.2)
    header_h = Inches(0.7)
    section_label_h = Inches(0.38)
    content_top = header_h + Inches(0.12)
    max_y_bottom = SLIDE_HEIGHT - Inches(0.55)  # leave room for logo

    slide = None
    cursor_y = max_y_bottom  # force first slide creation

    def _new_slide():
        nonlocal slide, cursor_y
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        bg = slide.background.fill
        bg.solid()
        bg.fore_color.rgb = CLR_SLIDE_BG

        band = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), SLIDE_WIDTH, header_h,
        )
        band.fill.solid()
        band.fill.fore_color.rgb = CLR_DARK_NAVY
        band.line.fill.background()

        htx = slide.shapes.add_textbox(Inches(0.5), Inches(0.12), Inches(10), Inches(0.5))
        hp = htx.text_frame.paragraphs[0]
        hp.text = f'{application}  —  KPI Results'
        hp.font.size = Pt(14)
        hp.font.bold = True
        hp.font.color.rgb = CLR_WHITE

        cursor_y = content_top
        _add_logo(slide)
        return slide

    for section in sections:
        section_tiles = section['tiles']
        section_title = section.get('title')
        if not section_tiles:
            continue

        # Check if section header + at least one row fits on current slide
        needed_h = (section_label_h if section_title else 0) + tile_h
        if slide is None or (cursor_y + needed_h) > max_y_bottom:
            _new_slide()

        # Section title label
        if section_title:
            stx = slide.shapes.add_textbox(margin_left, cursor_y, Inches(10), section_label_h)
            stx.text_frame.word_wrap = True
            sp = stx.text_frame.paragraphs[0]
            sp.text = section_title
            sp.font.size = Pt(11)
            sp.font.bold = True
            sp.font.color.rgb = CLR_SECTION_TITLE
            cursor_y += section_label_h

        # Lay out tiles in rows of 4
        for row_start in range(0, len(section_tiles), cols):
            row_tiles = section_tiles[row_start:row_start + cols]

            # Need new slide for this row?
            if (cursor_y + tile_h) > max_y_bottom:
                _new_slide()
                # Re-print section title on continuation slide
                if section_title:
                    stx = slide.shapes.add_textbox(margin_left, cursor_y, Inches(10), section_label_h)
                    sp = stx.text_frame.paragraphs[0]
                    sp.text = f'{section_title} (cont.)'
                    sp.font.size = Pt(11)
                    sp.font.bold = True
                    sp.font.color.rgb = CLR_SECTION_TITLE
                    cursor_y += section_label_h

            for col_idx, tile in enumerate(row_tiles):
                x = margin_left + col_idx * (tile_w + gap_x)
                y = cursor_y
                _draw_tile(slide, tile, x, y, tile_w, tile_h)

            cursor_y += tile_h + gap_y


def _draw_tile(slide, tile, x, y, tile_w, tile_h):
    """Draw a single KPI tile card at (x, y) matching the dashboard HTML styling."""
    rag_status = tile.get('rag_status', 'neutral') or 'neutral'

    # Card shape — RAG-tinted background
    card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, x, y, tile_w, tile_h)
    card.fill.solid()
    card.fill.fore_color.rgb = RAG_CARD_BG.get(rag_status, CLR_CARD_BG)
    card.line.color.rgb = RAG_BORDER_CLR.get(rag_status, RAG_BORDER_CLR['neutral'])
    card.line.width = Pt(1.2)
    card.shadow.inherit = False

    # Left accent strip
    strip = slide.shapes.add_shape(
        MSO_SHAPE.ROUNDED_RECTANGLE, x - Inches(0.02), y + Inches(0.25),
        Inches(0.1), tile_h - Inches(0.5),
    )
    strip.fill.solid()
    strip.fill.fore_color.rgb = RAG_ACCENT.get(rag_status, CLR_BORDER)
    strip.line.fill.background()

    # KPI title (bold, dark)
    ttx = slide.shapes.add_textbox(x + Inches(0.22), y + Inches(0.12), tile_w - Inches(0.35), Inches(0.65))
    ttx.text_frame.word_wrap = True
    tp = ttx.text_frame.paragraphs[0]
    tp.text = tile.get('title', '')
    tp.font.size = Pt(9)
    tp.font.bold = True
    tp.font.color.rgb = CLR_TEXT

    # Target pill
    target_label = tile.get('target_label', '')
    if target_label:
        pill = slide.shapes.add_shape(
            MSO_SHAPE.ROUNDED_RECTANGLE,
            x + Inches(0.22), y + Inches(0.78),
            Inches(1.1), Inches(0.28),
        )
        pill.fill.solid()
        pill.fill.fore_color.rgb = RAG_TARGET_BG.get(rag_status, RAG_TARGET_BG['neutral'])
        pill.line.fill.background()
        pill_tf = pill.text_frame
        pill_tf.margin_top = Pt(2)
        pill_tf.margin_bottom = Pt(2)
        pill_tf.margin_left = Pt(4)
        pill_tf.margin_right = Pt(4)
        pill_p = pill_tf.paragraphs[0]
        pill_p.text = f'Target {target_label}'
        pill_p.font.size = Pt(7)
        pill_p.font.bold = True
        pill_p.font.color.rgb = RAG_TARGET_TEXT.get(rag_status, CLR_MUTED)
        pill_p.alignment = PP_ALIGN.CENTER

    # Value (large, teal-blue)
    vtx = slide.shapes.add_textbox(x + Inches(0.22), y + Inches(1.15), Inches(1.6), Inches(0.65))
    vp = vtx.text_frame.paragraphs[0]
    vp.text = str(tile.get('value', '--%'))
    vp.font.size = Pt(26)
    vp.font.bold = True
    vp.font.color.rgb = CLR_VALUE_BLUE

    # Fraction (numerator / denominator)
    num = tile.get('fraction_numerator', '')
    den = tile.get('fraction_denominator', '')
    if num != '' and den != '':
        ftx = slide.shapes.add_textbox(x + Inches(1.7), y + Inches(1.2), Inches(1.1), Inches(0.6))
        ftx.text_frame.word_wrap = True
        fn = ftx.text_frame.paragraphs[0]
        fn.text = str(num)
        fn.font.size = Pt(9)
        fn.font.bold = True
        fn.font.color.rgb = CLR_TEXT
        fn.alignment = PP_ALIGN.CENTER
        fl = ftx.text_frame.add_paragraph()
        fl.text = '―――'
        fl.font.size = Pt(7)
        fl.font.color.rgb = CLR_MUTED
        fl.alignment = PP_ALIGN.CENTER
        fl.space_before = Pt(0)
        fl.space_after = Pt(0)
        fd = ftx.text_frame.add_paragraph()
        fd.text = str(den)
        fd.font.size = Pt(9)
        fd.font.bold = True
        fd.font.color.rgb = CLR_TEXT
        fd.alignment = PP_ALIGN.CENTER

    # Formula / logic footnote
    note_text = tile.get('status_note', '') or tile.get('formula', '')
    if note_text:
        ntx = slide.shapes.add_textbox(x + Inches(0.22), y + Inches(1.95), tile_w - Inches(0.35), Inches(0.5))
        ntx.text_frame.word_wrap = True
        np_ = ntx.text_frame.paragraphs[0]
        np_.text = note_text[:120]
        np_.font.size = Pt(7)
        np_.font.color.rgb = CLR_MUTED


# ── WARNINGS SLIDE ──────────────────────────────────────────────────────────

def _add_warnings_slide(prs, payload):
    """Optional slide listing any warnings from the run."""
    warnings = payload.get('ram_warnings', [])
    if not warnings:
        return
    slide = prs.slides.add_slide(prs.slide_layouts[6])

    bg = slide.background.fill
    bg.solid()
    bg.fore_color.rgb = CLR_SLIDE_BG

    band = slide.shapes.add_shape(
        MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), SLIDE_WIDTH, Inches(0.7),
    )
    band.fill.solid()
    band.fill.fore_color.rgb = CLR_DARK_NAVY
    band.line.fill.background()

    htx = slide.shapes.add_textbox(Inches(0.5), Inches(0.12), Inches(10), Inches(0.5))
    hp = htx.text_frame.paragraphs[0]
    hp.text = 'Warnings'
    hp.font.size = Pt(14)
    hp.font.bold = True
    hp.font.color.rgb = CLR_WHITE

    wtx = slide.shapes.add_textbox(Inches(0.5), Inches(1.1), Inches(12), Inches(5.5))
    wtx.text_frame.word_wrap = True
    for idx, warning in enumerate(warnings):
        p = wtx.text_frame.paragraphs[0] if idx == 0 else wtx.text_frame.add_paragraph()
        p.text = f'• {warning}'
        p.font.size = Pt(11)
        p.font.color.rgb = CLR_TEXT
        p.space_after = Pt(6)

    _add_logo(slide)


# ── PUBLIC API ───────────────────────────────────────────────────────────────

def build_ram_slides(payload):
    """Return an in-memory PowerPoint file (BytesIO) from an export payload dict."""
    prs = Presentation()
    prs.slide_width = SLIDE_WIDTH
    prs.slide_height = SLIDE_HEIGHT

    _add_title_slide(prs, payload)
    _add_kpi_slides(prs, payload)
    _add_warnings_slide(prs, payload)

    # Post-pass: add footer with pagination to every slide
    total_pages = len(prs.slides)
    for page_num, slide in enumerate(prs.slides, start=1):
        _add_footer(slide, page_num, total_pages)

    buf = io.BytesIO()
    prs.save(buf)
    buf.seek(0)
    return buf


def build_ram_slides_filename(application, export_timestamp):
    safe_app = ''.join(c if c.isalnum() or c in {'-', '_'} else '_' for c in application).strip('_') or 'Application'
    safe_ts = ''.join(c if c.isalnum() or c == '_' else '' for c in export_timestamp) or datetime.now().strftime('%Y%m%d_%H%M%S')
    return f'QualityLens360_RAM_{safe_app}_{safe_ts}.pptx'

