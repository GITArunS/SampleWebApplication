"""Excel workbook adapter used by the analysis flows."""

from __future__ import annotations

from collections.abc import Iterable

from openpyxl import load_workbook
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont
from openpyxl.styles.colors import Color


class ExcelService:
    """Small wrapper around openpyxl with workbook-specific helpers."""

    def __init__(self, file_path: str, sheet_name: str | None = None):
        self.file_path = file_path
        self.wb = load_workbook(file_path)
        self.ws = self.wb[sheet_name] if sheet_name else self.wb.active

    def last_row(self) -> int:
        return self.ws.max_row

    def get_cell(self, row: int, col: int):
        return self.ws.cell(row=row, column=col).value

    def set_cell(self, row: int, col: int, value) -> None:
        self.ws.cell(row=row, column=col).value = value

    def get_or_create_sheet(self, sheet_name: str):
        if sheet_name in self.wb.sheetnames:
            return self.wb[sheet_name]
        return self.wb.create_sheet(sheet_name)

    def save(self) -> None:
        self.wb.save(self.file_path)

    def set_rich_text(self, row: int, col: int, runs: Iterable[tuple[str, bool]]) -> None:
        """Write mixed-color rich text into a cell."""

        cell = self.ws.cell(row=row, column=col)
        rich = CellRichText()
        black_font = InlineFont(color=Color(rgb="000000"))
        red_font = InlineFont(color=Color(rgb="FF0000"))

        for text, make_red in runs:
            rich.append(TextBlock(text=text or "", font=red_font if make_red else black_font))

        cell.value = rich
