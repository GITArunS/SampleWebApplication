from contextlib import contextmanager
from datetime import datetime, time, timedelta, timezone
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape
from io import BytesIO
import json
import logging
import os
import re
import smtplib
from tempfile import TemporaryDirectory
import threading
from threading import RLock
from urllib.parse import parse_qsl, unquote, urlencode, urlsplit, urlunsplit

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
import requests
from requests.auth import HTTPBasicAuth
# import pythoncom
# import win32com.client

from shared.http_session import get_http_session

from operations.config import (
    APPLICATION_FIXED_IN_CQE_STATUS_NOT_ACCEPTED_CANCELLED_JQL,
    APPLICATION_FIXED_IN_CQE_ACCEPTED_CANCELLED_JQL,
    ASSIGNED_TO_TEAM_TESTING_VS_ASSIGNEE_JQL,
    ETA_SLIPPED_DEFECTS_JQL,
    NOT_AN_APPLICATION_REQUESTING_REVIEW_JQL,
    PROGRESSION_OPEN_DEFECTS_JQL,
    PROGRESSION_RESOLVED_TODAY_JQL,
    REGRESSION_OPEN_DEFECTS_JQL,
    REGRESSION_RESOLVED_TODAY_JQL,
    RELEASE_OPEN_DEFECTS_JQL,
    RELEASE_OPEN_DEFECTS_MAX_RESULTS,
    ROOT_CAUSE_APP_MATCHES_APPLICATION_FIXED_IN_JQL,
    RETURN_REJECTED_RETEST_TEST_BLOCKED_ASSIGNED_TO_TEAM_TESTING_JQL,
    RETURN_REJECT_DEFECTS_JQL,
    RETEST_DEFECTS_JQL,
    TRIBE_LABEL_SELF_HEAL_JQL,
)
from shared.shared_config import JIRA_API_TOKEN, JIRA_URL, JIRA_USER

DEFAULT_JQL = RELEASE_OPEN_DEFECTS_JQL
DEFAULT_FILENAME = "CurrentRelease_OpenDefects.xlsx"
DEFAULT_MAX_RESULTS = RELEASE_OPEN_DEFECTS_MAX_RESULTS
OPEN_DEFECTS_FILENAME_PREFIX = "CurrentRelease_OpenDefects"
PROGRESSION_OPEN_DEFECTS_FILENAME_PREFIX = "CurrentRelease_OpenDefects_Progression_WithDMComments"
REGRESSION_OPEN_DEFECTS_FILENAME_PREFIX = "CurrentRelease_OpenDefects_Regression_WithDMComments"
RETEST_DEFECTS_FILENAME_PREFIX = "CurrentRelease_RetestDefects"
RETURN_REJECT_DEFECTS_FILENAME_PREFIX = "CurrentRelease_ReturnRejectDefects"
ETA_SLIPPED_DEFECTS_FILENAME_PREFIX = "CurrentRelease_ETASlippedDefects"
BLOCKING_FIELD_EMPTY_DEFECTS_FILENAME_PREFIX = "CurrentRelease_BlockingFieldEmptyDefects"
PAST_DATED_FIX_VERSION_DEFECTS_FILENAME_PREFIX = "ACCProd_PastDatedFixVersions"
NOT_AN_APPLICATION_REQUESTING_REVIEW_FILENAME_PREFIX = "CurrentRelease_NotAnApplication_RequestingReview"
ACC_PROD_NEW_DEFECTS_CREATED_FILENAME_PREFIX = "ACCProd_NewDefectsCreated"
ACC_PROD_OUT_OF_SLA_SALES_FILENAME_PREFIX = "ACCProd_OutOfSLASales"
ACC_PROD_OUT_OF_SLA_NON_SALES_FILENAME_PREFIX = "ACCProd_OutOfSLANonSales"
ACC_PROD_MISSING_ORDER_IMPACT_FILENAME_PREFIX = "ACCProd_MissingOrderImpact"
ACC_PROD_PILOT_DEFECTS_WLS_FILENAME_PREFIX = "ACCProd_PilotDefectsWLS"
OPEN_DEFECTS_SUBJECT = "ACTION Required: ACES IST - Current Release - Open Defects"
ACC_PROD_NEW_DEFECTS_CREATED_SUBJECT = "ACTION Required: ACC Prod - New Defects Created"
ACC_PROD_OUT_OF_SLA_SALES_SUBJECT = "ACTION Required: ACC Prod - Out of SLA (Sales)"
ACC_PROD_OUT_OF_SLA_NON_SALES_SUBJECT = "ACTION Required: ACC Prod - Out of SLA (Non-Sales)"
ACC_PROD_MISSING_ORDER_IMPACT_SUBJECT = "ACTION Required: ACC Prod - Missing Order Impact Value"
RETEST_DEFECTS_SUBJECT = "ACTION Required: ACES IST - Current Release - Retest Defects"
RETURN_REJECT_DEFECTS_SUBJECT = "ACTION Required: ACES IST - Current Release - Return/Rejected Defects"
ETA_SLIPPED_DEFECTS_SUBJECT = "ACTION Required: ACES IST - Current Release - ETA Slipped Defects"
BLOCKING_FIELD_EMPTY_DEFECTS_SUBJECT = "ACTION Required: ACES IST - Current Release - Blocking Field Empty"
PAST_DATED_FIX_VERSION_DEFECTS_SUBJECT = "ACTION Required: ACC Prod - Past Dated Fix Versions"
NOT_AN_APPLICATION_REQUESTING_REVIEW_SUBJECT = "ACTION Required: ACES IST - Assigned to Team:Not an Application - Requesting Review"
PROGRESSION_REGRESSION_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Progression/Regression Updates"
ASSIGNED_TO_TEAM_TESTING_VS_ASSIGNEE_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Assigned To Team: Testing > Assignee: Update to Reporter Updates"
ASSIGNED_TO_TEAM_TESTING_STATUS_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Status: Return/Rejected or Retest or Test Blocked > Assigned to Team: Update to Testing"
APPLICATION_FIXED_IN_CQE_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Application Fixed In CQE Accepted/Cancelled Sync"
APPLICATION_FIXED_IN_CQE_REVERT_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Application Fixed In CQE Non-Accepted/Cancelled Sync"
ROOT_CAUSE_APP_MATCHES_APPLICATION_FIXED_IN_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Status: Accepted/Cancelled/Retest/Dev Complete/Test Blocked/Deferred/Test Failed > Application Fixed in = Root Cause App"
TRIBE_LABEL_SELF_HEAL_SUBJECT = "ACES IST - Self Heal iTrack Fields - Tribe Label Updates"
OPEN_DEFECTS_WORKSHEET_TITLE = "Open Defects"
PROGRESSION_OPEN_DEFECTS_WORKSHEET_TITLE = "Open Defects Progression"
REGRESSION_OPEN_DEFECTS_WORKSHEET_TITLE = "Open Defects Regression"
RETEST_DEFECTS_WORKSHEET_TITLE = "Retest Defects"
RETURN_REJECT_DEFECTS_WORKSHEET_TITLE = "Return Reject Defects"
ETA_SLIPPED_DEFECTS_WORKSHEET_TITLE = "ETA Slipped Defects"
BLOCKING_FIELD_EMPTY_DEFECTS_WORKSHEET_TITLE = "Blocking Field Empty"
PAST_DATED_FIX_VERSION_DEFECTS_WORKSHEET_TITLE = "Past Dated Fix Versions"
HEADER_FILL = PatternFill(fill_type="solid", fgColor="009FDB")
HEADER_FONT = Font(color="FFFFFF", bold=True)
SLA_BREACH_FILL = PatternFill(fill_type="solid", fgColor="F8D7DA")
SLA_BREACH_FONT = Font(color="7F1D1D")
FULL_HEADER_TITLES = [
    "Key",
    "Status @ 10 AM IST",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
    "iXP Flag",
    "Progression/Regression",
    "Latest Status",
    "DM Comments",
]
OVERALL_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
    "iXP Flag",
    "Progression/Regression",
]
ACC_PROD_NO_IXP_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
    "Progression/Regression",
]
ACC_PROD_EMAIL_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
]
ACC_PROD_RETEST_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
    "Phase Found In",
    "Progression/Regression",
]
ACC_PROD_RETEST_EMAIL_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
    "Phase Found In",
]
ETA_SLIPPED_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "EST Fix Date Changes Count",
    "EST Fix Date Transitions-History",
    "Application Fixed In",
    "iXP Flag",
    "Progression/Regression",
]
BLOCKING_FIELD_EMPTY_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
    "iXP Flag",
    "Progression/Regression",
    "Blocking Field",
]
PAST_DATED_FIX_VERSION_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "EST Fix Date",
    "Application Fixed In",
]
NOT_AN_APPLICATION_REQUESTING_REVIEW_HEADER_TITLES = [
    "Key",
    "Status",
    "Severity",
    "Summary",
    "Created",
    "Age",
    "Assignee",
    "Application Fixed In",
    "Assigned To Team",
    "Root Cause Category/Reason",
    "Root Cause App",
]
DEFAULT_CC_RECIPIENTS = (
    'ATT_DM_ACES <dl-ATT_DM_ACES@intl.att.com>; '
    'Ramalingam, Jayalakshmi <jayalakshmi.ramalingam@intl.att.com>; '
    'GADWAL, VENKAT <vg763v@att.com>; '
    'KANT, RENUKA <rk7836@att.com>; '
    'S, Balachandar <balachandar.s@intl.att.com>; '
    'P K, Vipin <vipin.p.k@intl.att.com>; '
    'RAO, NAGA <nageswara.raosingu@amdocs.com>; '
    'LAKKIMSETTI, LAKSHMI <lakshmil@amdocs.com>; '
    'BSSe_ACES_IST_Leads <DL-BSSe_ACES_IST_Leads@att.com>'
)
ACC_PROD_RETURN_REJECT_CC_RECIPIENTS = (
    'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com'
)
ACC_PROD_NEW_DEFECTS_TO_RECIPIENTS = (
    'CQE_ACC_Integration_Testing <DL-CQE_ACC_Integration_Testing@att.com>; '
    'dl-CQE_ACC_Core_Group@intl.att.com'
)
ACC_PROD_NEW_DEFECTS_CC_RECIPIENTS = (
    'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com; '
    'Vundavalli, Padmini <padmini.vundavalli@intl.att.com>; '
    'Abdul Aziz, Neji <neji.abdul.aziz@intl.att.com>'
)
ACC_PROD_OUT_OF_SLA_SALES_CC_RECIPIENTS = (
    'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com'
)
ACC_PROD_OUT_OF_SLA_NON_SALES_CC_RECIPIENTS = (
    'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com'
)
ACC_PROD_MISSING_ORDER_IMPACT_TO_RECIPIENTS = (
    'dl-CTXEngOps-ACC-PME@intl.att.com'
)
ACC_PROD_MISSING_ORDER_IMPACT_CC_RECIPIENTS = (
    'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com'
)
ACC_PROD_PILOT_DEFECTS_WLS_TO_RECIPIENTS = (
    '"ROGERS, TRACI L" <tr9497@att.com>; '
    '"GAMBRELL, MAEGAN" <mg663n@att.com>; '
    '"PORURI, SRINIVAS K" <sp160t@att.com>; '
    '"VITTA, SANKAR" <UV6377@att.com>; '
    '"CTXEngOps-ACC-PME" <dl-CTXEngOps-ACC-PME@intl.att.com>'
)
ACC_PROD_PILOT_DEFECTS_WLS_CC_RECIPIENTS = (
    '"Ramalingam, Jayalakshmi" <jayalakshmi.ramalingam@intl.att.com>; '
    '"L M, Sujatha" <sujatha.l.m@intl.att.com>; '
    '"MUDDAGOUNI, PRITHVI" <pm137b@att.com>; '
    '"JOHNSON, JENNIFER" <jj629m@att.com>; '
    '"MALLICK, SAGARIKA" <sm058t@att.com>; '
    '"CTX-IDC-CQE-ACC Prod DM" <dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com>'
)
ACC_PROD_PILOT_DEFECTS_WLS_HEADER_TITLES = [
    "SP #",
    "Key",
    "Severity",
    "Status",
    "Summary",
    "Assignee",
    "Director",
    "AVP",
    "Created",
    "Scrum Team",
    "Application Fixed In",
    "Root Cause Category/Reason",
    "Fix Version/s",
    "Aging",
    "Comments",
]
PILOT_WLS_MAPPING_CACHE_DIRECTORY = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs", "pilot_wls_mapping")
PILOT_WLS_MAPPING_CACHE_FILENAME = "pilot_wls_mapping.xlsx"
ETA_SLIPPED_TO_RECIPIENTS = (
    'ATT_DM_ACES <dl-ATT_DM_ACES@intl.att.com>; '
    'Ramalingam, Jayalakshmi <jayalakshmi.ramalingam@intl.att.com>; '
    'GADWAL, VENKAT <vg763v@att.com>; '
    'KANT, RENUKA <rk7836@att.com>; '
    'S, Balachandar <balachandar.s@intl.att.com>; '
    'P K, Vipin <vipin.p.k@intl.att.com>; '
    'RAO, NAGA <nageswara.raosingu@amdocs.com>; '
    'LAKKIMSETTI, LAKSHMI <lakshmil@amdocs.com>'
)
SELF_HEAL_NOTIFICATION_TO_RECIPIENTS = (
    'ATT_DM_ACES <dl-ATT_DM_ACES@intl.att.com>; '
)
DEFAULT_FROM_ADDRESS = 'dl-ATT_DM_ACES@intl.att.com'
ACC_PROD_FROM_ADDRESS = 'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com'
ACC_PROD_FROM_DISPLAY_NAME = 'CTX-IDC-CQE-ACC Prod DM'
PROGRESSION_REGRESSION_FIELD_NAME = "Progression/Regression"
PROGRESSION_REGRESSION_FIELD_KEY = "customfield_16390"
PHASE_FOUND_IN_FIELD_NAME = "Phase Found In"
PROGRESSION_REGRESSION_SUMMARY_KEYWORDS = ("regression", "smoke", "shakeout")
ASSIGNED_TO_TEAM_FIELD_NAME = "Assigned to Team"
ASSIGNED_TO_TEAM_FIELD_KEY = "customfield_19870"
ASSIGNED_TO_TEAM_TESTING_VALUE = "Testing"
ASSIGNED_TO_TEAM_TRIAGE_VALUE = "Triage"
APPLICATION_FIXED_IN_FIELD_NAME = "Application Fixed In"
APPLICATION_FIXED_IN_FIELD_KEY = "customfield_17001"
APPLICATION_FIXED_IN_NOT_AN_APPLICATION_VALUE = "Not An Application:Not An Application"
ROOT_CAUSE_APP_FIELD_NAME = "Root Cause App"
ROOT_CAUSE_APP_FIELD_KEY = "customfield_18870"
ROOT_CAUSE_REASON_FIELD_NAME = "Root Cause Category/Reason"
ROOT_CAUSE_REASON_FIELD_KEY = "customfield_18871"
ROOT_CAUSE_REASON_KEYWORDS = ("coding", "configuration", "deployment", "design specification", "requirements")
ROOT_CAUSE_APP_DISALLOWED_KEYWORDS = ("cqe", "not an application", "tbd")
TRIBE_GENERIC_LABEL = "Tribe_Generic"
TRIBE_LABEL_MAPPING_SOURCE = os.environ.get(
    "TRIBE_LABEL_MAPPING_SOURCE",
    "https://att.sharepoint.com/:x:/r/sites/CQEBSSe2/_layouts/15/Doc.aspx?sourcedoc=%7B51D3EB05-EAC2-4E2D-BFA1-72D437B7F694%7D&file=ACES_IST_Team_Structure_APRIL_26.xlsx&action=default&mobileredirect=true",
)
TRIBE_LABEL_MAPPING_TRIBE_COLUMN_INDEX = 2
TRIBE_LABEL_MAPPING_REPORTER_COLUMN_INDEX = 4
TRIBE_LABEL_CACHE_DIRECTORY = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs", "tribe_mapping")
NOT_AN_APPLICATION_REVIEW_ALLOWED_REASON_KEYWORDS = (
    "anamoly",
    "anomaly",
    "application availability",
    "environment",
    "other",
    "process",
    "testing",
    "training",
)
JIRA_REQUEST_TIMEOUT_SECONDS = 120
LOG_DIRECTORY = os.path.join(os.path.dirname(os.path.dirname(__file__)), "logs")
LOG_FILE_PATH = os.path.join(LOG_DIRECTORY, "operations_hub_email.log")
HUB_METRICS_FILE_PATH = os.path.join(LOG_DIRECTORY, "hub_metrics.json")
HUB_METRICS_LOCK = RLock()
HUB_METRICS_DEFAULTS = {
    "run_hits": 0,
    "emails_sent": 0,
    "self_heals_done": 0,
    "tile_clicks": {
        "ram": 0,
        "operations": 0,
        "defect-lens": 0,
        "advanced-reporting": 0,
    },
    "bootstrap_completed": True,
}


def configure_logger():
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    logger = logging.getLogger("aces_operations_hub.email")
    if logger.handlers:
        return logger

    logger.setLevel(logging.INFO)
    file_handler = logging.FileHandler(LOG_FILE_PATH, encoding="utf-8")
    file_handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(message)s"))
    logger.addHandler(file_handler)
    logger.propagate = False
    return logger


LOGGER = configure_logger()
IST_TIMEZONE = timezone(timedelta(hours=5, minutes=30))


def build_hub_metrics_from_log():
    metrics = dict(HUB_METRICS_DEFAULTS)
    if not os.path.exists(LOG_FILE_PATH):
        return metrics

    self_heal_update_pattern = re.compile(r"Self-heal .* updated (\d+) issues:")
    with open(LOG_FILE_PATH, "r", encoding="utf-8", errors="ignore") as log_file:
        for log_line in log_file:
            if "Sending subject '" in log_line and "via Graph API." in log_line:
                metrics["run_hits"] += 1
            elif "Self-heal " in log_line and " updated " in log_line and " issues:" in log_line:
                metrics["run_hits"] += 1
                match = self_heal_update_pattern.search(log_line)
                if match:
                    metrics["self_heals_done"] += int(match.group(1))
            elif "Sending " in log_line and " email via Graph API." in log_line:
                metrics["run_hits"] += 1

            if "Graph API send completed for subject '" in log_line:
                metrics["emails_sent"] += 1

    return metrics


def load_hub_metrics():
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    with HUB_METRICS_LOCK:
        if not os.path.exists(HUB_METRICS_FILE_PATH):
            metrics = build_hub_metrics_from_log()
            save_hub_metrics(metrics)
            return metrics

        try:
            with open(HUB_METRICS_FILE_PATH, "r", encoding="utf-8") as metrics_file:
                metrics = json.load(metrics_file)
        except (OSError, ValueError, TypeError):
            metrics = build_hub_metrics_from_log()
            save_hub_metrics(metrics)
            return metrics

        normalized_metrics = dict(HUB_METRICS_DEFAULTS)
        for metric_name in ("run_hits", "emails_sent", "self_heals_done"):
            try:
                normalized_metrics[metric_name] = max(0, int(metrics.get(metric_name, 0)))
            except (TypeError, ValueError):
                normalized_metrics[metric_name] = 0
        normalized_tile_clicks = dict(HUB_METRICS_DEFAULTS["tile_clicks"])
        raw_tile_clicks = metrics.get("tile_clicks", {})
        if isinstance(raw_tile_clicks, dict):
            for tile_id in normalized_tile_clicks:
                try:
                    normalized_tile_clicks[tile_id] = max(0, int(raw_tile_clicks.get(tile_id, 0)))
                except (TypeError, ValueError):
                    normalized_tile_clicks[tile_id] = 0
        normalized_metrics["tile_clicks"] = normalized_tile_clicks
        return normalized_metrics


def save_hub_metrics(metrics):
    os.makedirs(LOG_DIRECTORY, exist_ok=True)
    temp_metrics_path = f"{HUB_METRICS_FILE_PATH}.tmp"
    with open(temp_metrics_path, "w", encoding="utf-8") as metrics_file:
        json.dump(metrics, metrics_file)
    os.replace(temp_metrics_path, HUB_METRICS_FILE_PATH)


def update_hub_metrics(run_hits=0, emails_sent=0, self_heals_done=0, tile_click_id=None):
    with HUB_METRICS_LOCK:
        metrics = load_hub_metrics()
        metrics["run_hits"] = max(0, metrics["run_hits"] + int(run_hits))
        metrics["emails_sent"] = max(0, metrics["emails_sent"] + int(emails_sent))
        metrics["self_heals_done"] = max(0, metrics["self_heals_done"] + int(self_heals_done))
        if tile_click_id in metrics["tile_clicks"]:
            metrics["tile_clicks"][tile_click_id] = max(0, metrics["tile_clicks"][tile_click_id] + 1)
        save_hub_metrics(metrics)
        return metrics


def record_operation_run():
    update_hub_metrics(run_hits=1)


def record_email_sent():
    update_hub_metrics(emails_sent=1)


def record_self_heal_updates(update_count):
    if update_count:
        update_hub_metrics(self_heals_done=int(update_count))


def record_dashboard_tile_click(tile_click_id):
    if tile_click_id:
        update_hub_metrics(tile_click_id=tile_click_id)


def get_hub_metrics_summary():
    metrics = load_hub_metrics()
    return {
        "run_hits": metrics["run_hits"],
        "emails_sent": metrics["emails_sent"],
        "self_heals_done": metrics["self_heals_done"],
        "tile_clicks": dict(metrics["tile_clicks"]),
    }


def get_nested_value(mapping, *keys, default=""):
    current_value = mapping
    for key in keys:
        if not isinstance(current_value, dict):
            return default
        current_value = current_value.get(key)
        if current_value is None:
            return default
    return current_value


def stringify_field_value(value):
    if value is None:
        return ""
    if isinstance(value, dict):
        for preferred_key in ("value", "name", "displayName"):
            preferred_value = value.get(preferred_key)
            if preferred_value not in (None, ""):
                return str(preferred_value)
        return ""
    if isinstance(value, list):
        return ", ".join(stringify_field_value(item) for item in value if stringify_field_value(item))
    return str(value)


def parse_comment_date(date_text):
    normalized_date = (date_text or "").strip().replace(".", "/").replace("-", "/")
    for date_format in (
        "%m/%d/%Y",
        "%m/%d/%y",
        "%Y/%m/%d",
        "%d/%m/%Y",
        "%d/%m/%y",
        "%d/%b/%Y",
        "%d/%b/%y",
        "%d/%B/%Y",
        "%d/%B/%y",
    ):
        try:
            return datetime.strptime(normalized_date, date_format)
        except ValueError:
            continue
    return None


def parse_est_fix_date(value):
    normalized_date = stringify_field_value(value).strip()
    if not normalized_date:
        return None

    normalized_date = normalized_date.replace("T00:00:00.000+0000", "").replace("T00:00:00.000", "")
    normalized_date = normalized_date.replace("T00:00:00+0000", "").replace("T00:00:00", "")

    for date_format in (
        "%Y-%m-%d",
        "%Y/%m/%d",
        "%m/%d/%Y",
        "%m/%d/%y",
        "%d/%m/%Y",
        "%d/%m/%y",
    ):
        try:
            return datetime.strptime(normalized_date, date_format).date()
        except ValueError:
            continue

    return None


def format_est_fix_date(value):
    parsed_date = parse_est_fix_date(value)
    if parsed_date is None:
        return stringify_field_value(value).strip()
    return parsed_date.strftime("%m/%d/%Y")


def extract_latest_user4_update(value):
    text_value = stringify_field_value(value)
    if not text_value:
        return ""

    normalized_text = re.sub(r"<br\s*/?>", "\n", text_value, flags=re.IGNORECASE)
    candidate_lines = [line.strip() for line in re.split(r"\r?\n", normalized_text) if line.strip()]
    if not candidate_lines:
        return ""

    dated_lines = []
    for index, line in enumerate(candidate_lines):
        date_match = re.search(r"\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\d{4}[/-]\d{1,2}[/-]\d{1,2}|\d{1,2}[-/][A-Za-z]{3,9}[-/]\d{2,4})\b", line)
        if not date_match:
            continue

        parsed_date = parse_comment_date(date_match.group(1))
        if parsed_date is None:
            continue

        dated_lines.append((parsed_date, index, line))

    if dated_lines:
        dated_lines.sort(key=lambda item: (item[0], item[1]))
        return dated_lines[-1][2]

    return candidate_lines[-1]


def parse_jira_datetime(value):
    timestamp = stringify_field_value(value)
    if not timestamp:
        return None

    for date_format in (
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
    ):
        try:
            return datetime.strptime(timestamp, date_format)
        except ValueError:
            continue

    return None


def build_status_cutoff(now=None):
    current_ist = (now or datetime.now(IST_TIMEZONE)).astimezone(IST_TIMEZONE)
    return datetime.combine(current_ist.date(), time(hour=10), tzinfo=IST_TIMEZONE)


def build_progression_reporting_window(now=None):
    current_ist = (now or datetime.now(IST_TIMEZONE)).astimezone(IST_TIMEZONE)
    today_10am = datetime.combine(current_ist.date(), time(hour=10), tzinfo=IST_TIMEZONE)
    today_10pm = datetime.combine(current_ist.date(), time(hour=22), tzinfo=IST_TIMEZONE)

    if today_10am <= current_ist <= today_10pm:
        return {
            "status_cutoff": today_10am,
            "resolution_window_start": today_10am,
            "resolution_window_end": min(current_ist, today_10pm),
            "status_header_title": "Status @ 10 AM IST",
        }

    if current_ist < today_10am:
        previous_day = current_ist.date() - timedelta(days=1)
        previous_day_10pm = datetime.combine(previous_day, time(hour=22), tzinfo=IST_TIMEZONE)
        return {
            "status_cutoff": previous_day_10pm,
            "resolution_window_start": previous_day_10pm,
            "resolution_window_end": min(current_ist, today_10am),
            "status_header_title": "Status @ 10 PM IST",
        }

    tomorrow_10am = datetime.combine(current_ist.date() + timedelta(days=1), time(hour=10), tzinfo=IST_TIMEZONE)
    return {
        "status_cutoff": today_10pm,
        "resolution_window_start": today_10pm,
        "resolution_window_end": min(current_ist, tomorrow_10am),
        "status_header_title": "Status @ 10 PM IST",
    }


def build_today_resolution_window(now=None):
    current_ist = (now or datetime.now(IST_TIMEZONE)).astimezone(IST_TIMEZONE)
    window_start = datetime.combine(current_ist.date(), time(hour=10), tzinfo=IST_TIMEZONE)
    window_end = datetime.combine(current_ist.date(), time(hour=22), tzinfo=IST_TIMEZONE)
    if current_ist < window_start:
        return window_start, current_ist
    return window_start, min(current_ist, window_end)


def resolve_status_as_of_cutoff(issue, cutoff_datetime):
    fields = issue.get("fields") or {}
    current_status = get_nested_value(fields, "status", "name")
    created_datetime = parse_jira_datetime(fields.get("created"))
    if created_datetime and created_datetime.astimezone(IST_TIMEZONE) > cutoff_datetime:
        return ""

    status_at_cutoff = current_status
    status_histories = []
    for history in ((issue.get("changelog") or {}).get("histories") or []):
        history_created = parse_jira_datetime(history.get("created"))
        if history_created is None:
            continue
        for item in history.get("items") or []:
            if stringify_field_value(item.get("field")).casefold() != "status":
                continue
            status_histories.append((history_created, item))

    status_histories.sort(key=lambda entry: entry[0], reverse=True)
    for history_created, item in status_histories:
        if history_created.astimezone(IST_TIMEZONE) <= cutoff_datetime:
            continue
        status_at_cutoff = stringify_field_value(item.get("fromString"))

    return status_at_cutoff


def issue_moved_to_status_within_window(issue, target_statuses, window_start, window_end):
    if window_end <= window_start:
        return False

    normalized_target_statuses = {status.casefold() for status in target_statuses}
    for history in ((issue.get("changelog") or {}).get("histories") or []):
        history_created = parse_jira_datetime(history.get("created"))
        if history_created is None:
            continue

        history_created_ist = history_created.astimezone(IST_TIMEZONE)
        if history_created_ist < window_start or history_created_ist > window_end:
            continue

        for item in history.get("items") or []:
            if stringify_field_value(item.get("field")).casefold() != "status":
                continue
            if stringify_field_value(item.get("toString")).strip().casefold() in normalized_target_statuses:
                return True

    return False


def filter_issues_moved_to_status_within_window(issues, target_statuses, window_start, window_end):
    return [
        issue
        for issue in issues
        if issue_moved_to_status_within_window(issue, target_statuses, window_start, window_end)
    ]


def merge_issue_lists(primary_issues, additional_issues):
    merged_issues = []
    seen_issue_keys = set()
    for issue in list(primary_issues) + list(additional_issues):
        issue_key = stringify_field_value(issue.get("key")).strip()
        if not issue_key or issue_key in seen_issue_keys:
            continue
        merged_issues.append(issue)
        seen_issue_keys.add(issue_key)
    return merged_issues


def resolve_issue_severity(fields):
    severity_value = stringify_field_value(fields.get("customfield_10552"))
    if severity_value:
        return severity_value
    return get_nested_value(fields, "priority", "name")


def parse_severity_level(value):
    severity_text = stringify_field_value(value)
    severity_match = re.search(r"(\d)", severity_text)
    if not severity_match:
        return None
    return int(severity_match.group(1))


def parse_age_days(value):
    age_text = stringify_field_value(value).strip()
    age_match = re.search(r"(\d+)", age_text)
    if not age_match:
        return -1
    return int(age_match.group(1))


def is_sla_breached(issue, now=None):
    fields = issue.get("fields") or {}
    created_datetime = parse_jira_datetime(fields.get("created"))
    severity_level = parse_severity_level(resolve_issue_severity(fields))
    if created_datetime is None or severity_level is None:
        return False

    threshold_by_severity = {
        1: timedelta(hours=12),
        2: timedelta(days=3),
        3: timedelta(days=5),
        4: timedelta(days=10),
    }
    sla_threshold = threshold_by_severity.get(severity_level)
    if sla_threshold is None:
        return False

    comparison_now = now or datetime.now(IST_TIMEZONE)
    issue_age = comparison_now.astimezone(IST_TIMEZONE) - created_datetime.astimezone(IST_TIMEZONE)
    return issue_age > sla_threshold


def build_sla_breach_flags(issues):
    comparison_now = datetime.now(IST_TIMEZONE)
    return [is_sla_breached(issue, now=comparison_now) for issue in issues]


def get_est_fix_date_transitions(issue):
    transitions = []

    for history in ((issue.get("changelog") or {}).get("histories") or []):
        history_created = parse_jira_datetime(history.get("created"))
        if history_created is None:
            continue

        for item in history.get("items") or []:
            field_name = stringify_field_value(item.get("field")).casefold()
            field_id = stringify_field_value(item.get("fieldId")).casefold()
            if field_name != "est fix date" and field_id != "customfield_16406":
                continue

            previous_date = parse_est_fix_date(item.get("fromString"))
            updated_date = parse_est_fix_date(item.get("toString"))
            if previous_date is None and updated_date is None:
                continue
            if previous_date is None and updated_date is not None:
                continue

            transitions.append(
                {
                    "changed_at": history_created.astimezone(IST_TIMEZONE),
                    "from_date": previous_date,
                    "to_date": updated_date,
                    "from_value": format_est_fix_date(item.get("fromString")),
                    "to_value": format_est_fix_date(item.get("toString")),
                }
            )

    transitions.sort(key=lambda entry: entry["changed_at"])
    return transitions


def get_select_field_transitions(issue, field_key, field_name):
    transitions = []
    target_field_key = stringify_field_value(field_key).casefold()
    target_field_name = stringify_field_value(field_name).casefold()

    for history in ((issue.get("changelog") or {}).get("histories") or []):
        history_created = parse_jira_datetime(history.get("created"))
        if history_created is None:
            continue

        for item in history.get("items") or []:
            item_field_name = stringify_field_value(item.get("field")).casefold()
            item_field_id = stringify_field_value(item.get("fieldId")).casefold()
            if item_field_name != target_field_name and item_field_id != target_field_key:
                continue

            transitions.append(
                {
                    "changed_at": history_created.astimezone(IST_TIMEZONE),
                    "from_value": stringify_field_value(item.get("fromString")).strip(),
                    "to_value": stringify_field_value(item.get("toString")).strip(),
                }
            )

    transitions.sort(key=lambda entry: entry["changed_at"])
    return transitions


def resolve_previous_application_fixed_in_value(issue, current_value):
    return resolve_previous_select_field_value(
        issue,
        current_value,
        APPLICATION_FIXED_IN_FIELD_KEY,
        APPLICATION_FIXED_IN_FIELD_NAME,
    )


def resolve_previous_select_field_value(issue, current_value, field_key, field_name):
    transitions = get_select_field_transitions(
        issue,
        field_key,
        field_name,
    )
    normalized_current_value = stringify_field_value(current_value).strip()
    if not normalized_current_value:
        return ""

    for transition in reversed(transitions):
        if not select_field_values_match(transition["to_value"], normalized_current_value):
            continue
        return stringify_field_value(transition["from_value"]).strip()

    return ""


def resolve_previous_root_cause_app_value(issue, current_value):
    return resolve_previous_select_field_value(
        issue,
        current_value,
        ROOT_CAUSE_APP_FIELD_KEY,
        ROOT_CAUSE_APP_FIELD_NAME,
    )


def contains_disallowed_root_cause_app_text(value):
    normalized_value = stringify_field_value(value).strip().casefold()
    if not normalized_value:
        return True
    return any(keyword in normalized_value for keyword in ROOT_CAUSE_APP_DISALLOWED_KEYWORDS)


def resolve_previous_allowed_select_field_value(issue, current_value, field_key, field_name, disallowed_matcher):
    transitions = get_select_field_transitions(issue, field_key, field_name)
    tracked_value = stringify_field_value(current_value).strip()
    if not tracked_value:
        return ""

    for transition in reversed(transitions):
        if not select_field_values_match(transition["to_value"], tracked_value):
            continue

        previous_value = stringify_field_value(transition["from_value"]).strip()
        if previous_value and not disallowed_matcher(previous_value):
            return previous_value

        tracked_value = previous_value
        if not tracked_value:
            break

    return ""


def resolve_previous_allowed_application_fixed_in_value(issue, current_value):
    return resolve_previous_allowed_select_field_value(
        issue,
        current_value,
        APPLICATION_FIXED_IN_FIELD_KEY,
        APPLICATION_FIXED_IN_FIELD_NAME,
        contains_disallowed_root_cause_app_text,
    )


def build_est_fix_date_transition_history(issue):
    transitions = get_est_fix_date_transitions(issue)
    if not transitions:
        return ""

    history_entries = []
    for transition in transitions:
        from_value = transition["from_value"] or "Blank"
        to_value = transition["to_value"] or "Blank"
        changed_at = transition["changed_at"].strftime("%m/%d/%Y %I:%M %p IST")
        history_entries.append(f"{from_value} -> {to_value} ({changed_at})")

    return " | ".join(history_entries)


def count_est_fix_date_changes(issue):
    return len(get_est_fix_date_transitions(issue))


def resolve_original_est_fix_date(issue):
    transitions = get_est_fix_date_transitions(issue)
    if transitions:
        first_transition = transitions[0]
        if first_transition["from_date"] is not None:
            return first_transition["from_date"]
        if first_transition["to_date"] is not None:
            return first_transition["to_date"]

        for transition in transitions[1:]:
            if transition["from_date"] is not None:
                return transition["from_date"]
            if transition["to_date"] is not None:
                return transition["to_date"]

    return parse_est_fix_date(get_nested_value(issue, "fields", "customfield_16406"))


def was_est_fix_date_slipped(issue):
    original_committed_date = resolve_original_est_fix_date(issue)
    if original_committed_date is None:
        return False

    for transition in get_est_fix_date_transitions(issue):
        updated_date = transition["to_date"]
        if updated_date is None:
            continue

        if updated_date > original_committed_date:
            return True

    return False


def filter_eta_slipped_issues(issues):
    return [issue for issue in issues if was_est_fix_date_slipped(issue)]


def filter_blank_blocking_field_issues(issues):
    return [
        issue
        for issue in issues
        if not stringify_field_value(get_nested_value(issue, "fields", "customfield_16418")).strip()
    ]


def filter_not_an_application_requesting_review_issues(issues, field_name_lookup=None):
    field_name_lookup = field_name_lookup or {}
    filtered_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        root_cause_reason_value = resolve_root_cause_reason_display(
            fields,
            field_name_lookup=field_name_lookup,
        ).casefold()
        if any(keyword in root_cause_reason_value for keyword in NOT_AN_APPLICATION_REVIEW_ALLOWED_REASON_KEYWORDS):
            continue
        filtered_issues.append(issue)
    return filtered_issues


def resolve_issue_assignee_display(fields):
    assignee = fields.get("assignee") or {}
    return stringify_field_value(
        assignee.get("displayName")
        or assignee.get("emailAddress")
        or assignee.get("name")
    )


def resolve_issue_reporter_display(fields):
    reporter = fields.get("reporter") or {}
    return stringify_field_value(
        reporter.get("displayName")
        or reporter.get("emailAddress")
        or reporter.get("name")
        or reporter.get("key")
    )


def resolve_blocking_field_display(fields):
    return stringify_field_value(fields.get("customfield_16418")).strip()


def resolve_assigned_to_team_display(fields, field_name_lookup=None):
    field_name_lookup = field_name_lookup or {}
    assigned_to_team_value = stringify_field_value(fields.get(ASSIGNED_TO_TEAM_FIELD_KEY)).strip()
    if assigned_to_team_value:
        return assigned_to_team_value
    return get_field_value_by_name(fields, field_name_lookup, ASSIGNED_TO_TEAM_FIELD_NAME).strip()


def resolve_phase_found_in_display(fields, field_name_lookup=None):
    field_name_lookup = field_name_lookup or {}
    return get_field_value_by_name(fields, field_name_lookup, PHASE_FOUND_IN_FIELD_NAME).strip()


def resolve_root_cause_reason_display(fields, field_name_lookup=None):
    field_name_lookup = field_name_lookup or {}
    root_cause_reason_value = stringify_field_value(fields.get(ROOT_CAUSE_REASON_FIELD_KEY)).strip()
    if root_cause_reason_value:
        return root_cause_reason_value
    return get_field_value_by_name(fields, field_name_lookup, ROOT_CAUSE_REASON_FIELD_NAME).strip()


def resolve_root_cause_app_display(fields, field_name_lookup=None):
    field_name_lookup = field_name_lookup or {}
    root_cause_app_value = stringify_field_value(fields.get(ROOT_CAUSE_APP_FIELD_KEY)).strip()
    if root_cause_app_value:
        return root_cause_app_value
    return get_field_value_by_name(fields, field_name_lookup, ROOT_CAUSE_APP_FIELD_NAME).strip()


def get_cached_pilot_wls_mapping_path():
    os.makedirs(PILOT_WLS_MAPPING_CACHE_DIRECTORY, exist_ok=True)
    return os.path.join(PILOT_WLS_MAPPING_CACHE_DIRECTORY, PILOT_WLS_MAPPING_CACHE_FILENAME)


def normalize_mapping_header(value):
    return re.sub(r'[^a-z0-9]+', '', stringify_field_value(value).casefold())


def normalize_scrum_team_name(value):
    return re.sub(r'\s+', ' ', stringify_field_value(value).strip()).casefold()


def load_pilot_wls_mapping(source_path=None):
    workbook_path = source_path or get_cached_pilot_wls_mapping_path()
    if not workbook_path or not os.path.exists(workbook_path):
        raise ValueError('Upload the Pilot Defects WLS mapping workbook before running this workflow.')

    workbook = load_workbook(workbook_path, read_only=True, data_only=True)
    try:
        worksheet = workbook.active
        header_row = None
        for row in worksheet.iter_rows(values_only=True):
            normalized_headers = [normalize_mapping_header(cell) for cell in row]
            if any(header in {"scrumteamassigned", "scrumteam", "scrumname"} for header in normalized_headers):
                header_row = normalized_headers
                break

        if header_row is None:
            raise ValueError('The Pilot Defects WLS mapping workbook must contain Scrum Name or Scrum Team, plus Director and AVP columns.')

        def find_column_index(candidates):
            for index, header in enumerate(header_row):
                if header in candidates:
                    return index
            return -1

        scrum_team_index = find_column_index({"scrumteamassigned", "scrumteam", "scrumname"})
        application_fixed_in_index = find_column_index({"applicationfixedin", "application", "applicationfixed"})
        director_index = find_column_index({"director"})
        avp_index = find_column_index({"avp"})
        if min(scrum_team_index, director_index, avp_index) < 0:
            raise ValueError('The Pilot Defects WLS mapping workbook must contain Scrum Name or Scrum Team, plus Director and AVP columns.')

        mapping = {
            'by_scrum_team': {},
            'by_application_fixed_in': {},
        }
        for row in worksheet.iter_rows(values_only=True):
            scrum_team = stringify_field_value(row[scrum_team_index] if len(row) > scrum_team_index else '').strip()
            application_fixed_in = stringify_field_value(row[application_fixed_in_index] if application_fixed_in_index >= 0 and len(row) > application_fixed_in_index else '').strip()
            normalized_scrum_team = normalize_scrum_team_name(scrum_team)
            normalized_application_fixed_in = normalize_scrum_team_name(application_fixed_in)
            if (
                normalize_mapping_header(scrum_team) in {"scrumteamassigned", "scrumteam", "scrumname"}
                or normalize_mapping_header(application_fixed_in) in {"applicationfixedin", "application", "applicationfixed"}
            ):
                continue
            if not normalized_scrum_team and not normalized_application_fixed_in:
                continue
            mapping_entry = {
                'director': stringify_field_value(row[director_index] if len(row) > director_index else '').strip(),
                'avp': stringify_field_value(row[avp_index] if len(row) > avp_index else '').strip(),
            }
            if normalized_scrum_team:
                mapping['by_scrum_team'][normalized_scrum_team] = mapping_entry
            if normalized_application_fixed_in:
                mapping['by_application_fixed_in'][normalized_application_fixed_in] = mapping_entry

        if not mapping['by_scrum_team'] and not mapping['by_application_fixed_in']:
            raise ValueError('The Pilot Defects WLS mapping workbook did not contain any Scrum Name/Application Fixed In to Director/AVP mappings.')
        return mapping
    finally:
        workbook.close()


def resolve_scrum_team_display(fields, field_name_lookup=None):
    field_name_lookup = field_name_lookup or {}
    for display_name in ("Scrum Team Assigned", "Scrum Team"):
        value = get_field_value_by_name(fields, field_name_lookup, display_name).strip()
        if value:
            return value
    return ""


def resolve_issue_fix_versions_display(fields):
    fix_versions = fields.get('fixVersions') or []
    resolved_values = []
    for fix_version in fix_versions:
        fix_version_name = stringify_field_value((fix_version or {}).get('name')).strip()
        if fix_version_name:
            resolved_values.append(fix_version_name)
    return ', '.join(resolved_values)


def extract_sp_identifier(summary_value):
    summary_text = stringify_field_value(summary_value)
    match = re.search(r'\bSP-\d+\b', summary_text, re.IGNORECASE)
    return match.group(0).upper() if match else 'NA'


def format_short_created_date(value):
    parsed_datetime = parse_jira_datetime(value)
    if parsed_datetime is None:
        return stringify_field_value(value)[:10]
    return parsed_datetime.astimezone(IST_TIMEZONE).strftime('%-m/%-d/%y') if os.name != 'nt' else parsed_datetime.astimezone(IST_TIMEZONE).strftime('%m/%d/%y').lstrip('0').replace('/0', '/')


def build_acc_prod_pilot_defects_wls_rows(issues, field_name_lookup, scrum_team_mapping):
    now = datetime.now(IST_TIMEZONE)
    issue_rows = []
    for issue in issues:
        fields = issue.get('fields') or {}
        summary_value = stringify_field_value(fields.get('summary')).strip()
        scrum_team_value = resolve_scrum_team_display(fields, field_name_lookup=field_name_lookup)
        application_fixed_in_value = stringify_field_value(fields.get(APPLICATION_FIXED_IN_FIELD_KEY)).strip() or get_field_value_by_name(fields, field_name_lookup, APPLICATION_FIXED_IN_FIELD_NAME).strip()
        mapping_entry = scrum_team_mapping.get('by_scrum_team', {}).get(normalize_scrum_team_name(scrum_team_value), {})
        if not mapping_entry:
            mapping_entry = scrum_team_mapping.get('by_application_fixed_in', {}).get(normalize_scrum_team_name(application_fixed_in_value), {})
        created_datetime = parse_jira_datetime(fields.get('created'))
        aging_days = ''
        if created_datetime is not None:
            aging_days = str(max(0, (now - created_datetime.astimezone(IST_TIMEZONE)).days))

        issue_rows.append([
            extract_sp_identifier(summary_value),
            stringify_field_value(issue.get('key')).strip(),
            resolve_issue_severity(fields),
            get_nested_value(fields, 'status', 'name'),
            summary_value,
            resolve_issue_assignee_display(fields),
            mapping_entry.get('director', ''),
            mapping_entry.get('avp', ''),
            format_short_created_date(fields.get('created')),
            scrum_team_value,
            application_fixed_in_value,
            resolve_root_cause_reason_display(fields, field_name_lookup=field_name_lookup),
            resolve_issue_fix_versions_display(fields),
            aging_days,
            extract_latest_user4_update(fields.get('customfield_16419')),
        ])

    return issue_rows


def build_field_name_lookup(field_names):
    return {
        str(field_name).casefold(): field_key
        for field_key, field_name in (field_names or {}).items()
        if field_name
    }


def get_field_value_by_name(fields, field_name_lookup, display_name):
    field_key = field_name_lookup.get(display_name.casefold(), "")
    if not field_key:
        return ""
    return stringify_field_value(fields.get(field_key))


def resolve_issue_labels(fields):
    label_values = fields.get("labels") or []
    return [
        stringify_field_value(label_value).strip()
        for label_value in label_values
        if stringify_field_value(label_value).strip()
    ]


def append_unique(values, candidate):
    if candidate and candidate not in values:
        values.append(candidate)


def build_reporter_lookup_candidates(value):
    text_value = stringify_field_value(value).strip()
    if not text_value:
        return []

    candidates = []

    def add_candidate(candidate_value):
        candidate_text = stringify_field_value(candidate_value).strip()
        if not candidate_text:
            return
        append_unique(candidates, candidate_text.casefold())
        compact_candidate = re.sub(r"[^a-z0-9]+", "", candidate_text.casefold())
        append_unique(candidates, compact_candidate)

    add_candidate(text_value)

    normalized_text = re.sub(r"[\r\n]+", ";", text_value)
    for segment in normalized_text.split(";"):
        segment = segment.strip()
        if segment:
            add_candidate(segment)

    without_parentheses = re.sub(r"\([^)]*\)", " ", text_value)
    if without_parentheses.strip() and without_parentheses.strip() != text_value:
        add_candidate(without_parentheses)

    for email_match in re.findall(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", text_value):
        add_candidate(email_match)
        add_candidate(email_match.split("@", 1)[0])

    if "," in text_value:
        name_parts = [part.strip() for part in text_value.split(",", 1)]
        if len(name_parts) == 2 and name_parts[0] and name_parts[1]:
            add_candidate(f"{name_parts[1]} {name_parts[0]}")

    return candidates


def resolve_issue_reporter_lookup_candidates(fields):
    reporter = fields.get("reporter") or {}
    candidates = []
    for reporter_value in (
        reporter.get("displayName"),
        reporter.get("emailAddress"),
        reporter.get("name"),
        reporter.get("key"),
    ):
        for candidate in build_reporter_lookup_candidates(reporter_value):
            append_unique(candidates, candidate)
    return candidates


def normalize_tribe_label(value):
    normalized_value = stringify_field_value(value).strip()
    if not normalized_value:
        return ""
    normalized_value = re.sub(r"\s+", "_", normalized_value)
    if normalized_value.casefold() in {"tribegeneric", "tribe_generic"}:
        return TRIBE_GENERIC_LABEL
    return normalized_value


def build_sharepoint_download_urls(source_value):
    parsed_source = urlsplit(source_value)
    if not parsed_source.scheme or not parsed_source.netloc:
        return [source_value]

    download_urls = []

    def add_url(url_value):
        if url_value not in download_urls:
            download_urls.append(url_value)

    add_url(source_value)

    query_pairs = parse_qsl(parsed_source.query, keep_blank_values=True)
    query_map = {key: value for key, value in query_pairs}
    query_with_download = dict(query_map)
    query_with_download["download"] = "1"
    add_url(
        urlunsplit(
            (
                parsed_source.scheme,
                parsed_source.netloc,
                parsed_source.path,
                urlencode(query_with_download),
                parsed_source.fragment,
            )
        )
    )

    if parsed_source.path.endswith("/Doc.aspx"):
        add_url(
            urlunsplit(
                (
                    parsed_source.scheme,
                    parsed_source.netloc,
                    parsed_source.path[:-8] + "/download.aspx",
                    urlencode(query_map),
                    parsed_source.fragment,
                )
            )
        )

    return download_urls


def extract_workbook_filename(source_value):
    parsed_source = urlsplit(source_value)
    query_map = {key: value for key, value in parse_qsl(parsed_source.query, keep_blank_values=True)}

    file_name = stringify_field_value(query_map.get("file")).strip()
    if file_name:
        return unquote(file_name)

    path_name = os.path.basename(parsed_source.path)
    if path_name.lower().endswith(".xlsx"):
        return unquote(path_name)

    return ""


def build_local_workbook_search_roots():
    roots = []
    for candidate_root in (
        TRIBE_LABEL_CACHE_DIRECTORY,
        os.environ.get("TRIBE_LABEL_MAPPING_SEARCH_ROOT"),
    ):
        candidate_root = stringify_field_value(candidate_root).strip()
        if candidate_root and candidate_root not in roots:
            roots.append(candidate_root)
    return roots


def build_project_cached_workbook_path(source_value):
    workbook_name = extract_workbook_filename(source_value) or "tribe_mapping.xlsx"
    os.makedirs(TRIBE_LABEL_CACHE_DIRECTORY, exist_ok=True)
    return os.path.join(TRIBE_LABEL_CACHE_DIRECTORY, workbook_name)


def save_project_cached_workbook(source_value, workbook_bytes):
    cached_workbook_path = build_project_cached_workbook_path(source_value)
    with open(cached_workbook_path, "wb") as workbook_file:
        workbook_file.write(workbook_bytes)
    return cached_workbook_path


def find_local_workbook_path(source_value):
    if os.path.exists(source_value):
        return source_value

    cached_workbook_path = build_project_cached_workbook_path(source_value)
    if os.path.exists(cached_workbook_path):
        return cached_workbook_path

    workbook_name = extract_workbook_filename(source_value)
    if not workbook_name:
        return ""

    for search_root in build_local_workbook_search_roots():
        for root_path, _, file_names in os.walk(search_root):
            for file_name in file_names:
                if file_name.casefold() == workbook_name.casefold():
                    return os.path.join(root_path, file_name)

    return ""


def looks_like_html_payload(content_bytes):
    preview = content_bytes[:2048].decode("utf-8", errors="ignore").casefold()
    return (
        "<!doctype html" in preview
        or "<html" in preview
        or "<head" in preview
        or "<body" in preview
        or "sharepoint" in preview
    )


def load_tribe_label_mapping_workbook(source_value=TRIBE_LABEL_MAPPING_SOURCE):
    resolved_source = stringify_field_value(source_value).strip()
    if not resolved_source:
        raise ValueError("TRIBE_LABEL_MAPPING_SOURCE is empty. Provide a SharePoint Excel URL or a local workbook path.")

    local_workbook_path = find_local_workbook_path(resolved_source)
    if local_workbook_path:
        with open(local_workbook_path, "rb") as workbook_file:
            return load_workbook(BytesIO(workbook_file.read()), data_only=True, read_only=True)

    last_error = None
    for candidate_url in build_sharepoint_download_urls(resolved_source):
        try:
            response = get_http_session().get(
                candidate_url,
                timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
                allow_redirects=True,
            )
            response.raise_for_status()
            if looks_like_html_payload(response.content):
                raise ValueError("SharePoint returned an HTML page instead of the Excel workbook.")
            save_project_cached_workbook(resolved_source, response.content)
            return load_workbook(BytesIO(response.content), data_only=True, read_only=True)
        except Exception as error:
            last_error = error

    local_workbook_path = find_local_workbook_path(resolved_source)
    if local_workbook_path:
        with open(local_workbook_path, "rb") as workbook_file:
            return load_workbook(BytesIO(workbook_file.read()), data_only=True, read_only=True)

    workbook_name = extract_workbook_filename(resolved_source)
    searched_locations = ", ".join(build_local_workbook_search_roots())

    raise ValueError(
        "Unable to load the tribe mapping workbook from SharePoint or the project cache. "
        f"Expected workbook: {workbook_name or 'unknown'}. Searched: {searched_locations or 'no local search roots available'}. "
        "If SharePoint download is blocked, place the workbook in the project cache folder or set TRIBE_LABEL_MAPPING_SOURCE to a local .xlsx path and retry."
    ) from last_error


def load_tribe_reporter_mapping(source_value=TRIBE_LABEL_MAPPING_SOURCE):
    workbook = load_tribe_label_mapping_workbook(source_value=source_value)
    reporter_mapping = {}

    try:
        for worksheet in workbook.worksheets:
            for row in worksheet.iter_rows(min_row=2, values_only=True):
                tribe_label = normalize_tribe_label(
                    row[TRIBE_LABEL_MAPPING_TRIBE_COLUMN_INDEX]
                    if len(row) > TRIBE_LABEL_MAPPING_TRIBE_COLUMN_INDEX
                    else ""
                )
                reporter_value = (
                    row[TRIBE_LABEL_MAPPING_REPORTER_COLUMN_INDEX]
                    if len(row) > TRIBE_LABEL_MAPPING_REPORTER_COLUMN_INDEX
                    else ""
                )
                if not reporter_value:
                    continue

                resolved_label = tribe_label or TRIBE_GENERIC_LABEL
                for reporter_candidate in build_reporter_lookup_candidates(reporter_value):
                    existing_label = reporter_mapping.get(reporter_candidate)
                    if existing_label and existing_label != TRIBE_GENERIC_LABEL:
                        continue
                    reporter_mapping[reporter_candidate] = resolved_label
    finally:
        try:
            workbook.close()
        except Exception:
            pass

    if not reporter_mapping:
        raise ValueError(
            "The tribe mapping workbook did not contain any reporter-to-tribe mappings in column E mapped to column C."
        )

    return reporter_mapping


def resolve_issue_tribe_label(fields, reporter_mapping):
    for reporter_candidate in resolve_issue_reporter_lookup_candidates(fields):
        tribe_label = reporter_mapping.get(reporter_candidate)
        if tribe_label:
            return tribe_label, "Mapped from sheet"
    return TRIBE_GENERIC_LABEL, "Reporter not found in sheet"


def resolve_select_field_value_variants(value):
    normalized_value = stringify_field_value(value).strip()
    if not normalized_value:
        return []

    variants = [normalized_value]
    if ":" in normalized_value:
        colon_parts = [part.strip() for part in normalized_value.split(":") if part.strip()]
        for part in colon_parts:
            if part not in variants:
                variants.append(part)
    return variants


def select_field_values_match(left_value, right_value):
    left_variants = {variant.casefold() for variant in resolve_select_field_value_variants(left_value)}
    right_variants = {variant.casefold() for variant in resolve_select_field_value_variants(right_value)}
    return bool(left_variants and right_variants and left_variants.intersection(right_variants))


def build_search_url():
    parsed = urlsplit(JIRA_URL)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("JIRA_URL must include a valid scheme and host.")
    return urlunsplit((parsed.scheme, parsed.netloc, "/rest/api/2/search", "", ""))


def build_myself_url():
	parsed = urlsplit(JIRA_URL)
	if not parsed.scheme or not parsed.netloc:
		raise ValueError("JIRA_URL must include a valid scheme and host.")
	return urlunsplit((parsed.scheme, parsed.netloc, "/rest/api/2/myself", "", ""))


def build_issue_url(issue_key=""):
    parsed = urlsplit(JIRA_URL)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("JIRA_URL must include a valid scheme and host.")
    issue_path = "/rest/api/2/issue"
    if issue_key:
        issue_path = f"{issue_path}/{issue_key}"
    return urlunsplit((parsed.scheme, parsed.netloc, issue_path, "", ""))


def build_issue_editmeta_url(issue_key):
    parsed = urlsplit(JIRA_URL)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("JIRA_URL must include a valid scheme and host.")
    issue_path = f"/rest/api/2/issue/{issue_key}/editmeta"
    return urlunsplit((parsed.scheme, parsed.netloc, issue_path, "", ""))


def build_issue_comment_url(issue_key):
    parsed = urlsplit(JIRA_URL)
    if not parsed.scheme or not parsed.netloc:
        raise ValueError("JIRA_URL must include a valid scheme and host.")
    issue_path = f"/rest/api/2/issue/{issue_key}/comment"
    return urlunsplit((parsed.scheme, parsed.netloc, issue_path, "", ""))


def build_export_filename(filename_prefix=OPEN_DEFECTS_FILENAME_PREFIX, now=None):
    timestamp = (now or datetime.now()).strftime("%Y%m%d_%H%M%S")
    return f"{filename_prefix}_{timestamp}.xlsx"


def resolve_progression_regression_label(issue_rows, fallback_label="Progression/Regression"):
    for row in issue_rows:
        progression_regression_value = stringify_field_value(row[10]).strip()
        if progression_regression_value:
            return progression_regression_value
    return fallback_label


def build_progression_regression_subject(issue_rows):
    label = resolve_progression_regression_label(issue_rows)
    return (
        "ACTION Required: ACES IST - Current Release - Open Defects "
        f"({label}) - Status As On {datetime.now().strftime('%m/%d')}"
    )


def build_open_defects_subject():
    return (
        "ACTION Required: ACES IST - Current Release - Open Defects "
        f"- Status As On {datetime.now().strftime('%m/%d')}"
    )


def transform_overall_issue_row(issue_row):
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[7],
        issue_row[8],
        issue_row[9],
        issue_row[10],
    ]


def transform_acc_prod_no_ixp_issue_row(issue_row):
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[7],
        issue_row[8],
        issue_row[10],
    ]


def transform_eta_slipped_issue_row(issue_row, issue):
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[7],
        count_est_fix_date_changes(issue),
        build_est_fix_date_transition_history(issue),
        issue_row[8],
        issue_row[9],
        issue_row[10],
    ]


def transform_blocking_field_empty_issue_row(issue_row, issue):
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[7],
        issue_row[8],
        issue_row[9],
        issue_row[10],
        resolve_blocking_field_display(issue.get("fields") or {}),
    ]


def transform_past_dated_fix_version_issue_row(issue_row):
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[7],
        issue_row[8],
    ]


def transform_acc_prod_retest_issue_row(issue_row, issue, field_name_lookup=None):
    fields = issue.get("fields") or {}
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[7],
        issue_row[8],
        resolve_phase_found_in_display(fields, field_name_lookup=field_name_lookup),
        issue_row[10],
    ]


def sort_issue_rows_by_severity_and_age(issue_rows, severity_index=2, age_index=5):
    return sorted(
        issue_rows,
        key=lambda row: (
            parse_severity_level(row[severity_index]) if parse_severity_level(row[severity_index]) is not None else 999,
            -parse_age_days(row[age_index]),
            stringify_field_value(row[0]).casefold(),
        ),
    )


def transform_not_an_application_requesting_review_issue_row(issue_row, issue, field_name_lookup=None):
    fields = issue.get("fields") or {}
    return [
        issue_row[0],
        issue_row[11],
        issue_row[2],
        issue_row[3],
        issue_row[4],
        issue_row[5],
        issue_row[6],
        issue_row[8],
        resolve_assigned_to_team_display(fields, field_name_lookup=field_name_lookup),
        resolve_root_cause_reason_display(fields, field_name_lookup=field_name_lookup),
        resolve_root_cause_app_display(fields, field_name_lookup=field_name_lookup),
    ]


OUTLOOK_CONNECT_TIMEOUT_SECONDS = 30


# @contextmanager
# def get_outlook_session():
#     LOGGER.info("Initialising Outlook COM session (pythoncom.CoInitialize)...")
#     pythoncom.CoInitialize()
#     try:
#         result = [None, None]  # [outlook, error]

#         def _dispatch():
#             try:
#                 pythoncom.CoInitialize()
#                 result[0] = win32com.client.Dispatch("Outlook.Application")
#             except Exception as error:
#                 result[1] = error
#             finally:
#                 pythoncom.CoUninitialize()

#         LOGGER.info("Dispatching Outlook.Application COM object (timeout=%ss)...", OUTLOOK_CONNECT_TIMEOUT_SECONDS)
#         dispatch_thread = threading.Thread(target=_dispatch, daemon=True)
#         dispatch_thread.start()
#         dispatch_thread.join(timeout=OUTLOOK_CONNECT_TIMEOUT_SECONDS)

#         if dispatch_thread.is_alive():
#             LOGGER.error("Outlook COM Dispatch timed out after %ss.", OUTLOOK_CONNECT_TIMEOUT_SECONDS)
#             raise ValueError(
#                 f"Outlook COM connection timed out after {OUTLOOK_CONNECT_TIMEOUT_SECONDS}s. "
#                 "Ensure Outlook is running on the server with an active profile, "
#                 "or run the app locally to use Outlook email delivery."
#             )

#         if result[1] is not None:
#             LOGGER.exception("Outlook COM Dispatch failed: %s", result[1])
#             raise ValueError(
#                 "Unable to access the local Outlook client. Ensure Outlook is installed and that the signed-in profile is available on this machine."
#             ) from result[1]

#         outlook = result[0]
#         try:
#             session = outlook.Session
#         except Exception as error:
#             LOGGER.exception("Outlook COM Session access failed.")
#             raise ValueError(
#                 "Unable to access the local Outlook client. Ensure Outlook is installed and that the signed-in profile is available on this machine."
#             ) from error

#         LOGGER.info("Outlook COM session acquired successfully.")

#         if session.Accounts.Count < 1:
#             raise ValueError("No Outlook account is available in the current local Outlook profile.")

#         yield outlook, session
#     finally:
#         pythoncom.CoUninitialize()


def resolve_outlook_sender(session):
    account = session.Accounts.Item(1)
    sender_email = getattr(account, "SmtpAddress", "") or getattr(account, "DisplayName", "")
    sender_name = getattr(account, "DisplayName", "") or sender_email or session.CurrentUser.Name
    return account, sender_name, sender_email or sender_name


def get_outlook_delivery_details():
    raise ValueError('Local Outlook delivery is disabled. Use Microsoft Graph API for email delivery.')


def test_outlook_connection():
    raise ValueError('Local Outlook delivery is disabled. Use Microsoft Graph API for email delivery.')


# ---------------------------------------------------------------------------
# SMTP email transport (used when Outlook COM is unavailable on the server)
# ---------------------------------------------------------------------------

def is_smtp_configured():
    return False


def send_email_via_smtp(
    subject,
    html_body,
    to_recipients,
    cc_recipients=None,
    from_address=None,
    attachment_bytes=None,
    attachment_filename=None,
):
    raise ValueError('SMTP delivery is disabled. Use Microsoft Graph API for email delivery.')


# ---------------------------------------------------------------------------
# Microsoft Graph API email transport (preferred fallback over SMTP)
# ---------------------------------------------------------------------------

def is_graph_configured():
    from shared.shared_config import GRAPH_TENANT_ID, GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET
    return bool(GRAPH_TENANT_ID and GRAPH_CLIENT_ID and GRAPH_CLIENT_SECRET)


def _get_graph_access_token():
    from shared.shared_config import GRAPH_TENANT_ID, GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET
    token_url = f"https://login.microsoftonline.com/{GRAPH_TENANT_ID}/oauth2/v2.0/token"
    response = get_http_session().post(token_url, data={
        'grant_type': 'client_credentials',
        'client_id': GRAPH_CLIENT_ID,
        'client_secret': GRAPH_CLIENT_SECRET,
        'scope': 'https://graph.microsoft.com/.default',
    }, timeout=30)
    response.raise_for_status()
    return response.json()['access_token']


def _extract_email_address(entry):
    match = re.search(r'<([^<>]+)>', entry)
    return (match.group(1).strip() if match else entry.strip())


def send_email_via_graph(
    subject,
    html_body,
    to_recipients,
    cc_recipients=None,
    from_address=None,
    attachment_bytes=None,
    attachment_filename=None,
):
    from shared.shared_config import GRAPH_SENDER_EMAIL, GRAPH_FROM_ADDRESS
    import base64

    # GRAPH_SENDER_EMAIL = licensed user/shared mailbox (used in the API URL)
    # GRAPH_FROM_ADDRESS = display "from" address (can be a DL)
    mailbox = GRAPH_SENDER_EMAIL
    display_from = from_address or GRAPH_FROM_ADDRESS or DEFAULT_FROM_ADDRESS

    def _build_recipient_list(entries):
        result = []
        for entry in (entries or []):
            addr = _extract_email_address(entry)
            if addr:
                result.append({"emailAddress": {"address": addr}})
        return result

    message_payload = {
        "message": {
            "subject": subject,
            "body": {
                "contentType": "HTML",
                "content": html_body,
            },
            "from": {"emailAddress": {"address": display_from}},
            "sender": {"emailAddress": {"address": mailbox}},
            "toRecipients": _build_recipient_list(to_recipients),
            "ccRecipients": _build_recipient_list(cc_recipients),
        },
        "saveToSentItems": "true",
    }

    if attachment_bytes and attachment_filename:
        message_payload["message"]["attachments"] = [{
            "@odata.type": "#microsoft.graph.fileAttachment",
            "name": attachment_filename,
            "contentType": "application/octet-stream",
            "contentBytes": base64.b64encode(attachment_bytes).decode("ascii"),
        }]

    access_token = _get_graph_access_token()
    send_url = f"https://graph.microsoft.com/v1.0/users/{mailbox}/sendMail"

    LOGGER.info(
        "Sending email via Graph API subject='%s' mailbox='%s' from='%s' to %s recipients.",
        subject, mailbox, display_from, len(message_payload["message"]["toRecipients"]),
    )
    response = get_http_session().post(
        send_url,
        json=message_payload,
        headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"},
        timeout=60,
    )
    response.raise_for_status()
    LOGGER.info("Graph API send completed for subject '%s'.", subject)
    record_email_sent()


def parse_recipient_entries(recipient_text):
    return [entry.strip() for entry in (recipient_text or "").split(";") if entry.strip()]


def normalize_recipient_entry(value):
    normalized_value = (value or "").strip()
    if not normalized_value:
        return ""

    bracket_match = re.search(r"<([^<>]+)>", normalized_value)
    if bracket_match:
        return bracket_match.group(1).strip()

    return normalized_value


def split_person_name(value):
    normalized_value = (value or "").strip()
    if not normalized_value or "@" in normalized_value:
        return "", ""
    if normalized_value.casefold().startswith(("smtp:", "x500:", "/o=", "/ou=", "cn=")):
        return "", ""

    if "," in normalized_value:
        last_name, first_name = [part.strip() for part in normalized_value.split(",", 1)]
        return first_name, last_name

    name_parts = [part for part in re.split(r"\s+", normalized_value) if part]
    if len(name_parts) >= 2:
        return name_parts[0], name_parts[-1]

    return "", ""


def recipient_has_first_and_last_name(recipient):
    try:
        address_entry = getattr(recipient, "AddressEntry", None)
        if address_entry is not None:
            try:
                exchange_user = address_entry.GetExchangeUser()
            except Exception:
                exchange_user = None

            if exchange_user is not None:
                first_name = stringify_field_value(getattr(exchange_user, "FirstName", "")).strip()
                last_name = stringify_field_value(getattr(exchange_user, "LastName", "")).strip()
                if first_name and last_name:
                    return True
    except Exception:
        pass

    first_name, last_name = split_person_name(getattr(recipient, "Name", ""))
    return bool(first_name and last_name)


def build_outlook_lookup_alias(recipient_entry):
    normalized_entry = normalize_recipient_entry(recipient_entry)
    if not normalized_entry:
        return ""
    if normalized_entry.casefold().endswith("@att.com"):
        return normalized_entry.rsplit("@", 1)[0]
    return ""


def resolve_assignee_recipient_entry(session, recipient_entry):
    normalized_entry = normalize_recipient_entry(recipient_entry)
    if not normalized_entry or "@" not in normalized_entry:
        return normalized_entry

    recipient = session.CreateRecipient(normalized_entry)
    if recipient.Resolve() and recipient_has_first_and_last_name(recipient):
        return normalized_entry

    outlook_lookup_alias = build_outlook_lookup_alias(normalized_entry)
    if outlook_lookup_alias:
        alias_recipient = session.CreateRecipient(outlook_lookup_alias)
        if alias_recipient.Resolve() and recipient_has_first_and_last_name(alias_recipient):
            LOGGER.info(
                "Using Outlook alias fallback for %s -> %s",
                normalized_entry,
                outlook_lookup_alias,
            )
            return outlook_lookup_alias

    return normalized_entry


def resolve_assignee_recipients(session, recipient_entries):
    resolved_recipients = []
    seen_recipients = set()

    for recipient_entry in recipient_entries:
        resolved_entry = resolve_assignee_recipient_entry(session, recipient_entry)
        if not resolved_entry:
            continue

        normalized_key = resolved_entry.casefold()
        if normalized_key in seen_recipients:
            continue

        resolved_recipients.append(resolved_entry)
        seen_recipients.add(normalized_key)

    return resolved_recipients


def add_outlook_recipients(message, recipient_entries, recipient_type):
    for recipient_entry in recipient_entries:
        recipient = message.Recipients.Add(recipient_entry)
        recipient.Type = recipient_type


def resolve_outlook_recipients(message):
    unresolved_recipients = []

    if message.Recipients.ResolveAll():
        LOGGER.info(
            "Outlook resolved recipients successfully: %s",
            "; ".join(
                str(getattr(recipient, "Name", "") or getattr(recipient, "Address", ""))
                for recipient in message.Recipients
            ),
        )
        return

    for recipient in message.Recipients:
        if not recipient.Resolved:
            unresolved_recipients.append(recipient.Name)

    if unresolved_recipients:
        raise ValueError(
            "Outlook could not resolve these recipients: "
            + ", ".join(unresolved_recipients)
        )


def extract_assignee_recipients(issue_rows):
    recipients = []
    seen_recipients = set()

    for row in issue_rows:
        recipient_entry = normalize_recipient_entry(str(row[6] or ""))
        if not recipient_entry:
            continue
        normalized_email = recipient_entry.casefold()
        if normalized_email in seen_recipients:
            continue
        recipients.append(recipient_entry)
        seen_recipients.add(normalized_email)

    if not recipients:
        raise ValueError(
            "No email recipients were found in the Assignee column. Expected Jira/iTrack assignee values to include resolvable Outlook recipients."
        )

    return recipients


def extract_issue_recipients(issues):
    recipients = []
    seen_recipients = set()

    for issue in issues:
        fields = issue.get("fields") or {}
        assignee = fields.get("assignee") or {}
        candidate_values = [
            assignee.get("emailAddress"),
            assignee.get("name"),
            assignee.get("displayName"),
        ]

        for candidate_value in candidate_values:
            recipient_entry = normalize_recipient_entry(stringify_field_value(candidate_value))
            if not recipient_entry:
                continue

            normalized_email = recipient_entry.casefold()
            if normalized_email in seen_recipients:
                break

            recipients.append(recipient_entry)
            seen_recipients.add(normalized_email)
            break

    return recipients


def build_basic_auth(username=None, password=None):
    resolved_username = username or JIRA_USER
    resolved_password = password or JIRA_API_TOKEN
    if not resolved_username or not resolved_password:
        raise ValueError("Jira/iTrack credentials are required.")
    return HTTPBasicAuth(resolved_username, resolved_password)


def summarize_jira_error_response(response, max_length=300):
    if response is None:
        return ""

    response_text = (response.text or "").strip()
    if not response_text:
        return ""

    content_type = (response.headers.get("Content-Type") or "").lower()
    lowered_text = response_text.lower()
    looks_like_html = (
        "text/html" in content_type
        or "<!doctype html" in lowered_text
        or "<html" in lowered_text
        or "<head" in lowered_text
        or "<body" in lowered_text
        or "<style" in lowered_text
    )
    if looks_like_html:
        return ""

    response_text = response_text.replace("<br/>", " ").replace("<br>", " ")
    response_text = re.sub(r"<[^>]+>", " ", response_text)
    response_text = " ".join(response_text.split())
    if not response_text:
        return ""

    if len(response_text) > max_length:
        response_text = response_text[:max_length] + "..."

    return response_text


def fetch_open_defects_payload(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None, start_at=0, fields=None, expand='names,changelog'):
    headers = {
        "Content-Type": "application/json",
    }
    params = {
        "jql": jql,
        "maxResults": max_results,
        "startAt": max(0, int(start_at)),
    }
    if expand:
        params["expand"] = expand
    if fields:
        if isinstance(fields, (list, tuple, set)):
            params["fields"] = ",".join(str(field_name) for field_name in fields if str(field_name).strip())
        else:
            params["fields"] = str(fields)
    http = get_http_session()
    response = http.get(
        build_search_url(),
        headers=headers,
        auth=build_basic_auth(username=username, password=password),
        params=params,
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    return response.json()


def validate_jira_credentials(username=None, password=None):
    http = get_http_session()
    response = http.get(
        build_myself_url(),
        headers={"Content-Type": "application/json"},
        auth=build_basic_auth(username=username, password=password),
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    return response.json()


def fetch_open_defects(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None, start_at=0, fields=None, expand='names,changelog'):
    return fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        start_at=start_at,
        fields=fields,
        expand=expand,
    ).get("issues", [])


def fetch_issue_count(jql=DEFAULT_JQL, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=0,
        username=username,
        password=password,
        start_at=0,
        expand=None,
    )
    try:
        return max(0, int(payload.get("total", 0)))
    except (TypeError, ValueError):
        return 0


def issue_to_row(issue, now=None, field_name_lookup=None, status_cutoff=None):
    now = now or datetime.utcnow()
    fields = issue.get("fields") or {}
    field_name_lookup = field_name_lookup or {}
    status_cutoff = status_cutoff or build_status_cutoff()
    created_value = stringify_field_value(fields.get("created"))
    assignee_value = resolve_issue_assignee_display(fields)
    age = ""
    if len(created_value) >= 10:
        try:
            created = datetime.strptime(created_value[:10], "%Y-%m-%d")
            age = f"{(now - created).days}d"
        except ValueError:
            age = ""

    return [
        issue.get("key", ""),
        resolve_status_as_of_cutoff(issue, status_cutoff),
        resolve_issue_severity(fields),
        stringify_field_value(fields.get("summary")),
        created_value[:10] if created_value else "",
        age,
        assignee_value,
        stringify_field_value(fields.get("customfield_16406")),
        stringify_field_value(fields.get("customfield_17001")),
        stringify_field_value(fields.get("customfield_29170")),
        get_field_value_by_name(fields, field_name_lookup, "Progression/Regression"),
        get_nested_value(fields, "status", "name"),
        extract_latest_user4_update(fields.get("customfield_16419")),
    ]


def build_issue_rows(issues, field_name_lookup=None):
    now = datetime.utcnow()
    status_cutoff = build_status_cutoff()
    return [
        issue_to_row(issue, now=now, field_name_lookup=field_name_lookup, status_cutoff=status_cutoff)
        for issue in issues
    ]


def build_issue_rows_with_cutoff(issues, field_name_lookup=None, status_cutoff=None):
    now = datetime.utcnow()
    resolved_status_cutoff = status_cutoff or build_status_cutoff()
    return [
        issue_to_row(issue, now=now, field_name_lookup=field_name_lookup, status_cutoff=resolved_status_cutoff)
        for issue in issues
    ]


def build_progression_header_titles(status_header_title):
    header_titles = list(FULL_HEADER_TITLES)
    header_titles[1] = status_header_title
    return header_titles


def resolve_progression_regression_target(issue):
    fields = issue.get("fields") or {}
    user5_value = stringify_field_value(fields.get("customfield_16381")).strip()
    if user5_value:
        if "regression" in user5_value.casefold():
            return "Regression"
        return "Progression"

    summary_value = stringify_field_value(fields.get("summary")).casefold()
    if any(keyword in summary_value for keyword in PROGRESSION_REGRESSION_SUMMARY_KEYWORDS):
        return "Regression"
    return "Progression"


def normalize_identity_value(value):
    normalized_value = stringify_field_value(value).strip()
    if not normalized_value:
        return ""
    return normalized_value.casefold()


def users_match(left_user, right_user):
    left_user = left_user or {}
    right_user = right_user or {}
    for comparable_key in ("accountId", "name", "key", "emailAddress"):
        left_value = normalize_identity_value(left_user.get(comparable_key))
        right_value = normalize_identity_value(right_user.get(comparable_key))
        if left_value and right_value and left_value == right_value:
            return True

    left_display_name = normalize_identity_value(left_user.get("displayName"))
    right_display_name = normalize_identity_value(right_user.get("displayName"))
    return bool(left_display_name and right_display_name and left_display_name == right_display_name)


def build_assignee_update_candidates(target_user):
    target_user = target_user or {}
    candidate_values = []
    for identity_key in ("accountId", "name", "key", "emailAddress"):
        identity_value = stringify_field_value(target_user.get(identity_key)).strip()
        if identity_value:
            candidate_values.append({identity_key: identity_value})

    request_payloads = []
    seen_payloads = set()
    for candidate_value in candidate_values:
        payload_variants = [
            {"fields": {"assignee": candidate_value}},
            {"update": {"assignee": [{"set": candidate_value}]}} ,
        ]
        for payload_variant in payload_variants:
            payload_key = repr(payload_variant)
            if payload_key in seen_payloads:
                continue
            request_payloads.append(payload_variant)
            seen_payloads.add(payload_key)

    return request_payloads


def update_issue_assignee(issue_key, target_user, username=None, password=None):
    request_payloads = build_assignee_update_candidates(target_user)
    if not request_payloads:
        raise ValueError(f"Unable to update Assignee for {issue_key}. Reporter has no usable Jira/iTrack identity.")

    last_error = None
    for request_payload in request_payloads:
        try:
            update_issue(
                issue_key,
                request_payload,
                username=username,
                password=password,
            )
            return
        except requests.HTTPError as error:
            if error.response is not None and error.response.status_code in {401, 403}:
                raise ValueError(
                    f"Unable to update Assignee for {issue_key}. Jira/iTrack allowed the self-heal search but rejected the field update. "
                    "Use a Jira/iTrack password or API token with REST edit permission for issues, then retry."
                ) from error
            if error.response is None or error.response.status_code != 400:
                raise
            last_error = error

    error_details = ""
    if last_error is not None and last_error.response is not None:
        response_text = summarize_jira_error_response(last_error.response)
        if response_text:
            error_details = f" Jira response: {response_text}"

    raise ValueError(
        f"Unable to update Assignee for {issue_key}. Jira rejected all supported payload formats.{error_details}"
    )


def update_issue(issue_key, request_payload, username=None, password=None):
    response = get_http_session().put(
        build_issue_url(issue_key),
        headers={"Content-Type": "application/json"},
        auth=build_basic_auth(username=username, password=password),
        json=request_payload,
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()


def update_issue_fields(issue_key, fields_payload, username=None, password=None):
    update_issue(
        issue_key,
        {"fields": fields_payload},
        username=username,
        password=password,
    )


def update_issue_labels(issue_key, current_labels, labels_to_add, username=None, password=None):
    normalized_existing_labels = {stringify_field_value(label).strip().casefold() for label in (current_labels or [])}
    resolved_labels_to_add = []
    for label_to_add in labels_to_add or []:
        normalized_label = stringify_field_value(label_to_add).strip()
        if not normalized_label or normalized_label.casefold() in normalized_existing_labels:
            continue
        resolved_labels_to_add.append(normalized_label)
        normalized_existing_labels.add(normalized_label.casefold())

    if not resolved_labels_to_add:
        return

    merged_labels = list(current_labels or []) + resolved_labels_to_add
    request_payloads = [
        {"update": {"labels": [{"add": label_value} for label_value in resolved_labels_to_add]}},
        {"fields": {"labels": merged_labels}},
    ]

    last_error = None
    for request_payload in request_payloads:
        try:
            update_issue(
                issue_key,
                request_payload,
                username=username,
                password=password,
            )
            return
        except requests.HTTPError as error:
            if error.response is not None and error.response.status_code in {401, 403}:
                raise ValueError(
                    f"Unable to update Labels for {issue_key}. Jira/iTrack allowed the self-heal search but rejected the field update. "
                    "Use a Jira/iTrack password or API token with REST edit permission for issues, then retry."
                ) from error
            if error.response is None or error.response.status_code != 400:
                raise
            last_error = error

    error_details = ""
    if last_error is not None and last_error.response is not None:
        response_text = summarize_jira_error_response(last_error.response)
        if response_text:
            error_details = f" Jira response: {response_text}"

    raise ValueError(
        f"Unable to update Labels for {issue_key}. Jira rejected all supported payload formats.{error_details}"
    )


def add_issue_comment(issue_key, comment_body, username=None, password=None):
    normalized_comment_body = stringify_field_value(comment_body).strip()
    if not normalized_comment_body:
        raise ValueError(f"Unable to add comment for {issue_key}. Comment body is empty.")

    response = get_http_session().post(
        build_issue_comment_url(issue_key),
        headers={"Content-Type": "application/json"},
        auth=build_basic_auth(username=username, password=password),
        json={"body": normalized_comment_body},
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    try:
        response.raise_for_status()
    except requests.HTTPError as error:
        if error.response is not None and error.response.status_code in {401, 403}:
            raise ValueError(
                f"Unable to add a comment for {issue_key}. Jira/iTrack allowed the search but rejected comment creation. "
                "Use a Jira/iTrack password or API token with comment permission, then retry."
            ) from error

        error_details = ""
        if error.response is not None:
            error_details = summarize_jira_error_response(error.response)
        raise ValueError(
            f"Unable to add a comment for {issue_key}."
            + (f" Jira response: {error_details}" if error_details else "")
        ) from error


def fetch_issue_editmeta(issue_key, username=None, password=None):
    response = get_http_session().get(
        build_issue_editmeta_url(issue_key),
        headers={"Content-Type": "application/json"},
        auth=build_basic_auth(username=username, password=password),
        timeout=JIRA_REQUEST_TIMEOUT_SECONDS,
    )
    response.raise_for_status()
    return response.json()


def build_select_field_update_candidates(issue_key, field_key, target_value, username=None, password=None):
    try:
        editmeta = fetch_issue_editmeta(issue_key, username=username, password=password)
    except requests.RequestException:
        editmeta = {}

    field_meta = (editmeta.get("fields") or {}).get(field_key) or {}
    allowed_values = field_meta.get("allowedValues") or []
    candidate_values = []
    target_value_variants = resolve_select_field_value_variants(target_value)

    for allowed_value in allowed_values:
        allowed_text = stringify_field_value(
            allowed_value.get("value")
            or allowed_value.get("name")
        ).strip()
        if not any(allowed_text.casefold() == variant.casefold() for variant in target_value_variants):
            continue

        candidate_values.append(allowed_value)
        option_id = stringify_field_value(allowed_value.get("id")).strip()
        if option_id:
            candidate_values.append({"id": option_id})

        if allowed_text:
            candidate_values.append({"value": allowed_text})

    for target_value_variant in target_value_variants:
        candidate_values.extend(
            [
                {"value": target_value_variant},
                target_value_variant,
            ]
        )

    request_payloads = []
    seen_payloads = set()
    for candidate_value in candidate_values:
        payload_variants = [
            {"fields": {field_key: candidate_value}},
            {"fields": {field_key: [candidate_value]}},
            {"update": {field_key: [{"set": candidate_value}]}} ,
            {"update": {field_key: [{"set": [candidate_value]}]}} ,
        ]
        for payload_variant in payload_variants:
            payload_key = repr(payload_variant)
            if payload_key in seen_payloads:
                continue
            request_payloads.append(payload_variant)
            seen_payloads.add(payload_key)

    return request_payloads


def update_select_field(issue_key, field_key, target_value, username=None, password=None):
    request_payloads = build_select_field_update_candidates(
        issue_key,
        field_key,
        target_value,
        username=username,
        password=password,
    )
    last_error = None
    for request_payload in request_payloads:
        try:
            update_issue(
                issue_key,
                request_payload,
                username=username,
                password=password,
            )
            return
        except requests.HTTPError as fallback_error:
            if fallback_error.response is not None and fallback_error.response.status_code in {401, 403}:
                raise ValueError(
                    f"Unable to update field {field_key} for {issue_key}. Jira/iTrack allowed the self-heal search but rejected the field update. "
                    "Use a Jira/iTrack password or API token with REST edit permission for issues, then retry."
                ) from fallback_error
            if fallback_error.response is None or fallback_error.response.status_code != 400:
                raise
            last_error = fallback_error

    error_details = ""
    if last_error is not None and last_error.response is not None:
        response_text = summarize_jira_error_response(last_error.response)
        if response_text:
            error_details = f" Jira response: {response_text}"

    raise ValueError(
        f'Unable to update field {field_key} for {issue_key}. Jira rejected all supported payload formats.{error_details}'
    )


def update_progression_regression_field(issue_key, field_key, target_value, username=None, password=None):
    try:
        update_select_field(
            issue_key,
            field_key,
            target_value,
            username=username,
            password=password,
        )
    except ValueError as error:
        raise ValueError(
            f'Unable to update Progression/Regression for {issue_key}. {error}'
        ) from error


def update_assigned_to_team_field(issue_key, field_key, target_value, username=None, password=None):
    try:
        update_select_field(
            issue_key,
            field_key,
            target_value,
            username=username,
            password=password,
        )
    except ValueError as error:
        raise ValueError(
            f'Unable to update Assigned to Team for {issue_key}. {error}'
        ) from error


def update_application_fixed_in_field(issue_key, field_key, target_value, username=None, password=None):
    try:
        update_select_field(
            issue_key,
            field_key,
            target_value,
            username=username,
            password=password,
        )
    except ValueError as error:
        raise ValueError(
            f'Unable to update Application Fixed In for {issue_key}. {error}'
        ) from error


def update_root_cause_app_field(issue_key, field_key, target_value, username=None, password=None):
    try:
        update_select_field(
            issue_key,
            field_key,
            target_value,
            username=username,
            password=password,
        )
    except ValueError as error:
        raise ValueError(
            f'Unable to update Root Cause App for {issue_key}. {error}'
        ) from error


def self_heal_progression_regression_fields(jql=ETA_SLIPPED_DEFECTS_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql.replace(
            'ORDER BY Severity ASC, cf[18971] ASC, created ASC',
            'and "Progression/Regression" is EMPTY ORDER BY Severity ASC, cf[18971] ASC, created ASC',
        ),
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    progression_regression_field_key = field_name_lookup.get(PROGRESSION_REGRESSION_FIELD_NAME.casefold())
    if not progression_regression_field_key:
        progression_regression_field_key = PROGRESSION_REGRESSION_FIELD_KEY
    if not progression_regression_field_key:
        raise ValueError('Unable to locate the "Progression/Regression" field in Jira/iTrack.')

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        current_value = stringify_field_value(fields.get(progression_regression_field_key)).strip()
        if not current_value:
            current_value = stringify_field_value(fields.get(PROGRESSION_REGRESSION_FIELD_KEY)).strip()
        if not current_value:
            current_value = get_field_value_by_name(fields, field_name_lookup, PROGRESSION_REGRESSION_FIELD_NAME).strip()
        if current_value:
            continue

        target_value = resolve_progression_regression_target(issue)
        update_progression_regression_field(
            issue.get("key", ""),
            progression_regression_field_key,
            target_value,
            username=username,
            password=password,
        )
        updated_issues.append((issue.get("key", ""), target_value))

    LOGGER.info(
        "Self-heal Progression/Regression updated %s issues: %s",
        len(updated_issues),
        ", ".join(f"{issue_key}:{target_value}" for issue_key, target_value in updated_issues),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_tribe_label_fields(jql=TRIBE_LABEL_SELF_HEAL_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    reporter_mapping = load_tribe_reporter_mapping()

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        current_labels = resolve_issue_labels(fields)
        target_label, mapping_source = resolve_issue_tribe_label(fields, reporter_mapping)
        if target_label.casefold() in {label_value.casefold() for label_value in current_labels}:
            continue

        update_issue_labels(
            issue.get("key", ""),
            current_labels,
            [target_label],
            username=username,
            password=password,
        )
        updated_issues.append(
            (
                issue.get("key", ""),
                resolve_issue_reporter_display(fields),
                target_label,
                mapping_source,
            )
        )

    LOGGER.info(
        "Self-heal Tribe-Label updated %s issues: %s",
        len(updated_issues),
        ", ".join(f"{issue_key}:{label_value}" for issue_key, _, label_value, _ in updated_issues),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_assigned_to_team_testing_vs_assignee_fields(jql=ASSIGNED_TO_TEAM_TESTING_VS_ASSIGNEE_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        reporter = fields.get("reporter") or {}
        assignee = fields.get("assignee") or {}
        if not reporter:
            continue
        if users_match(assignee, reporter):
            continue

        update_issue_assignee(
            issue.get("key", ""),
            reporter,
            username=username,
            password=password,
        )
        updated_issues.append(
            (
                issue.get("key", ""),
                resolve_issue_assignee_display(fields),
                resolve_issue_reporter_display(fields),
            )
        )

    LOGGER.info(
        "Self-heal Assigned To Team: Testing > Assignee: Update to Reporter updated %s issues: %s",
        len(updated_issues),
        ", ".join(
            f"{issue_key}:{reporter_display}"
            for issue_key, _, reporter_display in updated_issues
        ),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_assigned_to_team_testing_status_fields(
    jql=RETURN_REJECTED_RETEST_TEST_BLOCKED_ASSIGNED_TO_TEAM_TESTING_JQL,
    max_results=DEFAULT_MAX_RESULTS,
    username=None,
    password=None,
    operation_label='Status: Return/Rejected or Retest or Test Blocked > Assigned to Team: Update to Testing',
    target_assigned_to_team_value=ASSIGNED_TO_TEAM_TESTING_VALUE,
    protected_current_values=(),
):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    assigned_to_team_field_key = ASSIGNED_TO_TEAM_FIELD_KEY
    if assigned_to_team_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(ASSIGNED_TO_TEAM_FIELD_NAME.casefold())
        if fallback_field_key:
            assigned_to_team_field_key = fallback_field_key

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        current_value = stringify_field_value(fields.get(assigned_to_team_field_key)).strip()
        if not current_value:
            current_value = stringify_field_value(fields.get(ASSIGNED_TO_TEAM_FIELD_KEY)).strip()
        if not current_value:
            current_value = get_field_value_by_name(fields, field_name_lookup, ASSIGNED_TO_TEAM_FIELD_NAME).strip()
        if current_value.casefold() == target_assigned_to_team_value.casefold():
            continue
        if current_value and current_value.casefold() in {
            stringify_field_value(value).strip().casefold()
            for value in protected_current_values
            if stringify_field_value(value).strip()
        }:
            continue

        update_assigned_to_team_field(
            issue.get("key", ""),
            assigned_to_team_field_key,
            target_assigned_to_team_value,
            username=username,
            password=password,
        )
        updated_issues.append(
            (
                issue.get("key", ""),
                stringify_field_value(current_value),
                target_assigned_to_team_value,
                stringify_field_value(get_nested_value(fields, "status", "name")),
            )
        )

    LOGGER.info(
        "Self-heal %s updated %s issues: %s",
        operation_label,
        len(updated_issues),
        ", ".join(
            f"{issue_key}:{updated_value}"
            for issue_key, _, updated_value, _ in updated_issues
        ),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_application_fixed_in_cqe_fields(jql=APPLICATION_FIXED_IN_CQE_ACCEPTED_CANCELLED_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    application_fixed_in_field_key = APPLICATION_FIXED_IN_FIELD_KEY
    if application_fixed_in_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(APPLICATION_FIXED_IN_FIELD_NAME.casefold())
        if fallback_field_key:
            application_fixed_in_field_key = fallback_field_key

    root_cause_app_field_key = ROOT_CAUSE_APP_FIELD_KEY
    if root_cause_app_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(ROOT_CAUSE_APP_FIELD_NAME.casefold())
        if fallback_field_key:
            root_cause_app_field_key = fallback_field_key

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        current_value = stringify_field_value(fields.get(application_fixed_in_field_key)).strip()
        if not current_value:
            current_value = stringify_field_value(fields.get(APPLICATION_FIXED_IN_FIELD_KEY)).strip()
        if not current_value:
            current_value = get_field_value_by_name(fields, field_name_lookup, APPLICATION_FIXED_IN_FIELD_NAME).strip()

        root_cause_app_value = stringify_field_value(fields.get(root_cause_app_field_key)).strip()
        if not root_cause_app_value:
            root_cause_app_value = stringify_field_value(fields.get(ROOT_CAUSE_APP_FIELD_KEY)).strip()
        if not root_cause_app_value:
            root_cause_app_value = get_field_value_by_name(fields, field_name_lookup, ROOT_CAUSE_APP_FIELD_NAME).strip()

        target_application_fixed_in_value = root_cause_app_value
        target_root_cause_app_value = root_cause_app_value
        if contains_disallowed_root_cause_app_text(root_cause_app_value):
            target_application_fixed_in_value = APPLICATION_FIXED_IN_NOT_AN_APPLICATION_VALUE
            target_root_cause_app_value = APPLICATION_FIXED_IN_NOT_AN_APPLICATION_VALUE

        requires_application_fixed_in_update = not select_field_values_match(current_value, target_application_fixed_in_value)
        requires_root_cause_app_update = not select_field_values_match(root_cause_app_value, target_root_cause_app_value)
        if not requires_application_fixed_in_update and not requires_root_cause_app_update:
            continue

        if requires_application_fixed_in_update:
            update_application_fixed_in_field(
                issue.get("key", ""),
                application_fixed_in_field_key,
                target_application_fixed_in_value,
                username=username,
                password=password,
            )
        if requires_root_cause_app_update:
            update_root_cause_app_field(
                issue.get("key", ""),
                root_cause_app_field_key,
                target_root_cause_app_value,
                username=username,
                password=password,
            )

        updated_issues.append(
            (
                issue.get("key", ""),
                stringify_field_value(current_value),
                stringify_field_value(target_application_fixed_in_value),
                stringify_field_value(get_nested_value(fields, "status", "name")),
            )
        )

    LOGGER.info(
        "Self-heal Application Fixed in: CQE & Status = Accepted/Cancelled > Sync Application Fixed In using Root Cause App / Not An Application fallback updated %s issues: %s",
        len(updated_issues),
        ", ".join(
            f"{issue_key}:{updated_value}"
            for issue_key, _, updated_value, _ in updated_issues
        ),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_application_fixed_in_cqe_revert_to_previous_fields(jql=APPLICATION_FIXED_IN_CQE_STATUS_NOT_ACCEPTED_CANCELLED_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    application_fixed_in_field_key = APPLICATION_FIXED_IN_FIELD_KEY
    if application_fixed_in_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(APPLICATION_FIXED_IN_FIELD_NAME.casefold())
        if fallback_field_key:
            application_fixed_in_field_key = fallback_field_key

    root_cause_app_field_key = ROOT_CAUSE_APP_FIELD_KEY
    if root_cause_app_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(ROOT_CAUSE_APP_FIELD_NAME.casefold())
        if fallback_field_key:
            root_cause_app_field_key = fallback_field_key

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        current_value = stringify_field_value(fields.get(application_fixed_in_field_key)).strip()
        if not current_value:
            current_value = stringify_field_value(fields.get(APPLICATION_FIXED_IN_FIELD_KEY)).strip()
        if not current_value:
            current_value = get_field_value_by_name(fields, field_name_lookup, APPLICATION_FIXED_IN_FIELD_NAME).strip()
        if not current_value:
            continue

        root_cause_app_value = stringify_field_value(fields.get(root_cause_app_field_key)).strip()
        if not root_cause_app_value:
            root_cause_app_value = stringify_field_value(fields.get(ROOT_CAUSE_APP_FIELD_KEY)).strip()
        if not root_cause_app_value:
            root_cause_app_value = get_field_value_by_name(fields, field_name_lookup, ROOT_CAUSE_APP_FIELD_NAME).strip()

        target_value = root_cause_app_value
        if contains_disallowed_root_cause_app_text(root_cause_app_value):
            target_value = resolve_previous_allowed_application_fixed_in_value(issue, current_value)

        if not target_value:
            continue

        requires_application_fixed_in_update = not select_field_values_match(current_value, target_value)
        requires_root_cause_app_update = not select_field_values_match(root_cause_app_value, target_value)
        if not requires_application_fixed_in_update and not requires_root_cause_app_update:
            continue

        if requires_application_fixed_in_update:
            update_application_fixed_in_field(
                issue.get("key", ""),
                application_fixed_in_field_key,
                target_value,
                username=username,
                password=password,
            )
        if requires_root_cause_app_update:
            update_root_cause_app_field(
                issue.get("key", ""),
                root_cause_app_field_key,
                target_value,
                username=username,
                password=password,
            )

        updated_issues.append(
            (
                issue.get("key", ""),
                stringify_field_value(current_value),
                stringify_field_value(target_value),
                stringify_field_value(get_nested_value(fields, "status", "name")),
            )
        )

    LOGGER.info(
        "Self-heal Application Fixed in: CQE & Status != Accepted/Cancelled - Sync from Root Cause App or revert to latest valid prior value updated %s issues: %s",
        len(updated_issues),
        ", ".join(
            f"{issue_key}:{updated_value}"
            for issue_key, _, updated_value, _ in updated_issues
        ),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_root_cause_app_matches_application_fixed_in_fields(jql=ROOT_CAUSE_APP_MATCHES_APPLICATION_FIXED_IN_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})

    application_fixed_in_field_key = APPLICATION_FIXED_IN_FIELD_KEY
    if application_fixed_in_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(APPLICATION_FIXED_IN_FIELD_NAME.casefold())
        if fallback_field_key:
            application_fixed_in_field_key = fallback_field_key

    root_cause_app_field_key = ROOT_CAUSE_APP_FIELD_KEY
    if root_cause_app_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(ROOT_CAUSE_APP_FIELD_NAME.casefold())
        if fallback_field_key:
            root_cause_app_field_key = fallback_field_key

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        application_fixed_in_value = stringify_field_value(fields.get(application_fixed_in_field_key)).strip()
        if not application_fixed_in_value:
            application_fixed_in_value = stringify_field_value(fields.get(APPLICATION_FIXED_IN_FIELD_KEY)).strip()
        if not application_fixed_in_value:
            application_fixed_in_value = get_field_value_by_name(fields, field_name_lookup, APPLICATION_FIXED_IN_FIELD_NAME).strip()
        if not application_fixed_in_value:
            continue

        root_cause_app_value = stringify_field_value(fields.get(root_cause_app_field_key)).strip()
        if not root_cause_app_value:
            root_cause_app_value = stringify_field_value(fields.get(ROOT_CAUSE_APP_FIELD_KEY)).strip()
        if not root_cause_app_value:
            root_cause_app_value = get_field_value_by_name(fields, field_name_lookup, ROOT_CAUSE_APP_FIELD_NAME).strip()

        if select_field_values_match(root_cause_app_value, application_fixed_in_value):
            continue

        update_root_cause_app_field(
            issue.get("key", ""),
            root_cause_app_field_key,
            application_fixed_in_value,
            username=username,
            password=password,
        )
        updated_issues.append(
            (
                issue.get("key", ""),
                stringify_field_value(root_cause_app_value),
                stringify_field_value(application_fixed_in_value),
                stringify_field_value(get_nested_value(fields, "status", "name")),
            )
        )

    LOGGER.info(
        "Self-heal Status: Accepted/Cancelled/Retest/Dev Complete/Test Blocked/Deferred/Test Failed > Application Fixed in = Root Cause App updated %s issues: %s",
        len(updated_issues),
        ", ".join(
            f"{issue_key}:{updated_value}"
            for issue_key, _, updated_value, _ in updated_issues
        ),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def self_heal_application_fixed_in_matches_root_cause_app_fields(jql, max_results=DEFAULT_MAX_RESULTS, username=None, password=None, operation_label='Status: Application Fixed in : Root Cause App in Sync'):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    application_fixed_in_field_key = APPLICATION_FIXED_IN_FIELD_KEY
    if application_fixed_in_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(APPLICATION_FIXED_IN_FIELD_NAME.casefold())
        if fallback_field_key:
            application_fixed_in_field_key = fallback_field_key

    root_cause_app_field_key = ROOT_CAUSE_APP_FIELD_KEY
    if root_cause_app_field_key not in (payload.get("names") or {}):
        fallback_field_key = field_name_lookup.get(ROOT_CAUSE_APP_FIELD_NAME.casefold())
        if fallback_field_key:
            root_cause_app_field_key = fallback_field_key

    updated_issues = []
    for issue in issues:
        fields = issue.get("fields") or {}
        current_value = stringify_field_value(fields.get(application_fixed_in_field_key)).strip()
        if not current_value:
            current_value = stringify_field_value(fields.get(APPLICATION_FIXED_IN_FIELD_KEY)).strip()
        if not current_value:
            current_value = get_field_value_by_name(fields, field_name_lookup, APPLICATION_FIXED_IN_FIELD_NAME).strip()

        root_cause_app_value = stringify_field_value(fields.get(root_cause_app_field_key)).strip()
        if not root_cause_app_value:
            root_cause_app_value = stringify_field_value(fields.get(ROOT_CAUSE_APP_FIELD_KEY)).strip()
        if not root_cause_app_value:
            root_cause_app_value = get_field_value_by_name(fields, field_name_lookup, ROOT_CAUSE_APP_FIELD_NAME).strip()
        if not root_cause_app_value:
            continue

        if select_field_values_match(current_value, root_cause_app_value):
            continue

        update_application_fixed_in_field(
            issue.get("key", ""),
            application_fixed_in_field_key,
            root_cause_app_value,
            username=username,
            password=password,
        )
        updated_issues.append(
            (
                issue.get("key", ""),
                stringify_field_value(current_value),
                stringify_field_value(root_cause_app_value),
                stringify_field_value(get_nested_value(fields, "status", "name")),
            )
        )

    LOGGER.info(
        "Self-heal %s updated %s issues: %s",
        operation_label,
        len(updated_issues),
        ", ".join(
            f"{issue_key}:{updated_value}"
            for issue_key, _, updated_value, _ in updated_issues
        ),
    )
    record_self_heal_updates(len(updated_issues))
    return updated_issues


def _send_self_heal_notification(subject, html_body, description="self-heal notification"):
    """Send a self-heal notification email via Microsoft Graph API."""
    recipients = parse_recipient_entries(SELF_HEAL_NOTIFICATION_TO_RECIPIENTS)
    if not is_graph_configured():
        raise ValueError('Microsoft Graph email delivery is not configured. Set GRAPH_TENANT_ID, GRAPH_CLIENT_ID, and GRAPH_CLIENT_SECRET and retry.')
    LOGGER.info("Sending %s email via Graph API.", description)
    send_email_via_graph(
        subject=subject,
        html_body=html_body,
        to_recipients=recipients,
    )


def send_self_heal_progression_regression_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(target_value)}</td>'
            "</tr>"
        )
        for issue_key, target_value in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Progression/Regression.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:640px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Updated Value</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=PROGRESSION_REGRESSION_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Progression/Regression self-heal",
    )


def send_self_heal_tribe_label_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(reporter_value or "")}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(updated_label)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(mapping_source)}</td>'
            "</tr>"
        )
        for issue_key, reporter_value, updated_label, mapping_source in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Tribe-Label.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:920px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Reporter</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Added Label</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Mapping Source</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=TRIBE_LABEL_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Tribe-Label self-heal",
    )


def send_self_heal_assigned_to_team_testing_vs_assignee_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(previous_assignee or "")}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(reporter_value)}</td>'
            "</tr>"
        )
        for issue_key, previous_assignee, reporter_value in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Assigned To Team: Testing &gt; Assignee: Update to Reporter.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:760px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Previous Assignee</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Reporter / New Assignee</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=ASSIGNED_TO_TEAM_TESTING_VS_ASSIGNEE_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Assigned To Team Testing vs Assignee self-heal",
    )


def send_self_heal_assigned_to_team_testing_status_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(previous_value or "")}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(updated_value)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(status_value)}</td>'
            "</tr>"
        )
        for issue_key, previous_value, updated_value, status_value in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Return/Rejected or Retest or Test Blocked Defects &gt; Assigned to Team: Update to Testing.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:860px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Previous Assigned to Team</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Updated Assigned to Team</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Status</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=ASSIGNED_TO_TEAM_TESTING_STATUS_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Assigned to Team Testing status self-heal",
    )


def send_self_heal_application_fixed_in_cqe_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(previous_value or "")}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(updated_value)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(status_value)}</td>'
            "</tr>"
        )
        for issue_key, previous_value, updated_value, status_value in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Application Fixed In: CQE &amp; Status = Accepted/Cancelled by syncing Application Fixed In from Root Cause App when valid, otherwise setting both fields to Not An Application.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:860px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Previous Application Fixed In</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Updated Application Fixed In</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Status</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=APPLICATION_FIXED_IN_CQE_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Application Fixed In CQE self-heal",
    )


def send_self_heal_application_fixed_in_cqe_revert_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(previous_value or "")}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(updated_value)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(status_value)}</td>'
            "</tr>"
        )
        for issue_key, previous_value, updated_value, status_value in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Application Fixed In: CQE &amp; Status != Accepted/Cancelled by syncing from Root Cause App when valid, otherwise reverting to the latest prior allowed Application Fixed In value and matching Root Cause App.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:860px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Current Application Fixed In</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Updated Application Fixed In</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Status</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=APPLICATION_FIXED_IN_CQE_REVERT_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Application Fixed In revert self-heal",
    )


def send_self_heal_root_cause_app_matches_application_fixed_in_email(updated_issues):
    if not updated_issues:
        return

    body_rows = "".join(
        (
            "<tr>"
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(issue_key)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(previous_value or "")}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(updated_value)}</td>'
            f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{escape(status_value)}</td>'
            "</tr>"
        )
        for issue_key, previous_value, updated_value, status_value in updated_issues
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hello Team,</p>'
        '<p>The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Status: Accepted/Cancelled/Retest/Dev Complete/Test Blocked/Deferred/Test Failed &gt; Application Fixed in = Root Cause App.</p>'
        '<table style="border-collapse:collapse;width:100%;max-width:860px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">CDEX#</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Previous Root Cause App</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Updated Root Cause App</th>'
        '<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">Status</th>'
        '</tr></thead>'
        f'<tbody>{body_rows}</tbody>'
        '</table>'
        '<p style="margin-top:16px;">Regards,<br/>ACES IST DM Team</p>'
        '</body></html>'
    )
    _send_self_heal_notification(
        subject=ROOT_CAUSE_APP_MATCHES_APPLICATION_FIXED_IN_SELF_HEAL_SUBJECT,
        html_body=html_body,
        description="Root Cause App sync self-heal",
    )


def apply_workbook_formatting(worksheet, sla_breach_flags=None):
    sla_breach_flags = sla_breach_flags or []
    for header_cell in worksheet[1]:
        header_cell.fill = HEADER_FILL
        header_cell.font = HEADER_FONT
        header_cell.alignment = Alignment(horizontal="center", vertical="center")

    for row_index, row in enumerate(worksheet.iter_rows(min_row=2), start=0):
        sla_breached = row_index < len(sla_breach_flags) and sla_breach_flags[row_index]
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if sla_breached:
                cell.fill = SLA_BREACH_FILL
                cell.font = SLA_BREACH_FONT

    for column_cells in worksheet.columns:
        column_letter = column_cells[0].column_letter
        max_length = max(len(str(cell.value or "")) for cell in column_cells)
        worksheet.column_dimensions[column_letter].width = min(max(max_length + 2, 12), 40)

    worksheet.freeze_panes = "A2"


def build_workbook(issue_rows, worksheet_title=OPEN_DEFECTS_WORKSHEET_TITLE, header_titles=None, sla_breach_flags=None):
    header_titles = header_titles or FULL_HEADER_TITLES
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = worksheet_title
    worksheet.append(header_titles)

    for row in issue_rows:
        worksheet.append(row)

    apply_workbook_formatting(worksheet, sla_breach_flags=sla_breach_flags)

    return workbook


def categorize_latest_status(latest_status, est_fix_date):
    normalized_status = stringify_field_value(latest_status).strip().casefold()
    has_est_fix_date = bool(stringify_field_value(est_fix_date).strip())

    if normalized_status == "accepted":
        return "Resolved", "Accepted"
    if normalized_status in {"cancelled", "canceled"}:
        return "Resolved", "Cancelled"
    if normalized_status == "retest":
        return "Close to Resolution", "Retest"
    if normalized_status == "dev complete":
        return "Close to Resolution", "Dev Complete"
    if normalized_status == "deferred":
        return "Deferred (Planned for future Releases)", "Deferred"
    if normalized_status == "in progress":
        if has_est_fix_date:
            return "Dev Analysis/Fix In Progress", "In Progress (with ETA)"
        return "Dev Analysis/Fix In Progress", "In Progress (no ETA)"
    if normalized_status in {"request for retest failed", "retest failed"}:
        return "Dev Analysis/Fix In Progress", "Retest Failed"
    if normalized_status in {"workaround", "work around"}:
        return "Dev Analysis/Fix In Progress", "Work Around"
    if normalized_status == "to do":
        return "Pending with CQE", "To do"
    if normalized_status == "test blocked":
        return "Pending with CQE", "Test Blocked"
    if normalized_status in {"returned/rejected", "return/rejected"}:
        return "Pending with CQE", "Return/Rejected"
    return None, None


def build_status_summary(issue_rows):
    category_order = [
        ("Resolved", ["Accepted", "Cancelled"]),
        ("Close to Resolution", ["Retest", "Dev Complete"]),
        ("Deferred (Planned for future Releases)", ["Deferred"]),
        ("Dev Analysis/Fix In Progress", ["In Progress (with ETA)", "In Progress (no ETA)", "Retest Failed", "Work Around"]),
        ("Pending with CQE", ["To do", "Test Blocked", "Return/Rejected"]),
    ]

    subcategory_counts = {
        category: {subcategory: 0 for subcategory in subcategories}
        for category, subcategories in category_order
    }

    total_reviewed = 0
    for row in issue_rows:
        category, subcategory = categorize_latest_status(row[11], row[7])
        if not category or not subcategory:
            continue
        subcategory_counts[category][subcategory] += 1
        total_reviewed += 1

    summary_rows = []
    for category, subcategories in category_order:
        category_total = sum(subcategory_counts[category].values())
        percentage = f"{round((category_total / total_reviewed) * 100)}%" if total_reviewed else "0%"
        for index, subcategory in enumerate(subcategories):
            summary_rows.append(
                {
                    "category": category,
                    "show_category": index == 0,
                    "category_rowspan": len(subcategories),
                    "subcategory": subcategory,
                    "count": subcategory_counts[category][subcategory],
                    "show_percentage": index == 0,
                    "percentage_rowspan": len(subcategories),
                    "percentage": percentage,
                }
            )

    return summary_rows, total_reviewed


def build_summary_table_html(issue_rows):
    summary_rows, total_reviewed = build_status_summary(issue_rows)
    body_rows = []
    for row in summary_rows:
        category_cell = ""
        if row["show_category"]:
            category_cell = (
                f'<td rowspan="{row["category_rowspan"]}" style="padding:8px 10px;border:1px solid #111827;vertical-align:middle;">'
                f'{escape(row["category"])}</td>'
            )
        percentage_cell = ""
        if row["show_percentage"]:
            percentage_cell = (
                f'<td rowspan="{row["percentage_rowspan"]}" style="padding:8px 10px;border:1px solid #111827;vertical-align:middle;text-align:center;color:#16a34a;">'
                f'{escape(row["percentage"])}</td>'
            )
        body_rows.append(
            '<tr>'
            f'{category_cell}'
            f'<td style="padding:8px 10px;border:1px solid #111827;">{escape(row["subcategory"])}</td>'
            f'<td style="padding:8px 10px;border:1px solid #111827;">{row["count"]}</td>'
            f'{percentage_cell}'
            '</tr>'
        )

    body_rows.append(
        '<tr>'
        '<td style="padding:8px 10px;border:1px solid #111827;"></td>'
        '<td style="padding:8px 10px;border:1px solid #111827;font-weight:600;">Total Defects Reviewed Today</td>'
        f'<td style="padding:8px 10px;border:1px solid #111827;">{total_reviewed}</td>'
        '<td style="padding:8px 10px;border:1px solid #111827;"></td>'
        '</tr>'
    )

    return (
        '<table style="border-collapse:collapse;width:760px;max-width:100%;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        '<thead><tr>'
        '<th style="background-color:#d9ead3;padding:8px 10px;border:1px solid #111827;text-align:left;">Category</th>'
        '<th style="background-color:#d9ead3;padding:8px 10px;border:1px solid #111827;text-align:left;">Sub-Category</th>'
        '<th style="background-color:#d9ead3;padding:8px 10px;border:1px solid #111827;text-align:left;">CDEX#</th>'
        '<th style="background-color:#d9ead3;padding:8px 10px;border:1px solid #111827;text-align:center;">%</th>'
        '</tr></thead>'
        f'<tbody>{"".join(body_rows)}</tbody>'
        '</table>'
    )


def build_email_table_html(issue_rows, header_titles=None, empty_state_message="No open defects were returned for the current release.", sla_breach_flags=None):
    header_titles = header_titles or FULL_HEADER_TITLES
    sla_breach_flags = sla_breach_flags or [False] * len(issue_rows)
    header_cells = "".join(
        (
            f'<th style="background-color:{"#6b7280" if title in {"Latest Status", "DM Comments"} else "#009fdb"};color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">{escape(title)}</th>'
        )
        for title in header_titles
    )
    body_rows = []
    for row, sla_breached in zip(issue_rows, sla_breach_flags):
        cell_style = "padding:10px 12px;border:1px solid #cbd5e1;vertical-align:top;"
        if sla_breached:
            cell_style += "background-color:#f8d7da;color:#7f1d1d;"
        cells = []
        for idx, value in enumerate(row):
            # Hyperlink the Key column (first column) with the iTrack URL
            if idx == 0 and value:
                key = str(value)
                url = f'https://itrack.web.att.com/browse/{escape(key)}'
                cell_html = f'<a href="{url}" style="color:#009fdb;text-decoration:underline;" target="_blank">{escape(key)}</a>'
                cells.append(f'<td style="{cell_style}">{cell_html}</td>')
            else:
                cells.append(f'<td style="{cell_style}">{escape(str(value or ""))}</td>')
        body_rows.append(f"<tr>{''.join(cells)}</tr>")

    if not body_rows:
        body_rows.append(
            f'<tr><td colspan="{len(header_titles)}" style="padding:12px;border:1px solid #cbd5e1;text-align:center;">{escape(empty_state_message)}</td></tr>'
        )

    return (
        '<table style="border-collapse:collapse;width:100%;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
        f"<thead><tr>{header_cells}</tr></thead>"
        f"<tbody>{''.join(body_rows)}</tbody>"
        "</table>"
    )


def export_defects(
    jql=DEFAULT_JQL,
    max_results=DEFAULT_MAX_RESULTS,
    username=None,
    password=None,
    filename_prefix=OPEN_DEFECTS_FILENAME_PREFIX,
    worksheet_title=OPEN_DEFECTS_WORKSHEET_TITLE,
    header_titles=None,
    row_transform=None,
):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    issue_rows = build_issue_rows(issues, field_name_lookup=field_name_lookup)
    sla_breach_flags = build_sla_breach_flags(issues)
    if row_transform is not None:
        issue_rows = [row_transform(issue_row) for issue_row in issue_rows]
    workbook = build_workbook(
        issue_rows,
        worksheet_title=worksheet_title,
        header_titles=header_titles,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=filename_prefix), len(issues), issue_rows, issues


def export_release_open_defects(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=OPEN_DEFECTS_FILENAME_PREFIX,
        worksheet_title=OPEN_DEFECTS_WORKSHEET_TITLE,
        header_titles=OVERALL_HEADER_TITLES,
        row_transform=transform_overall_issue_row,
    )


def export_progression_open_defects(open_jql=PROGRESSION_OPEN_DEFECTS_JQL, resolved_today_jql=PROGRESSION_RESOLVED_TODAY_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    reporting_window = build_progression_reporting_window()
    payload = fetch_open_defects_payload(
        jql=open_jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    resolution_window_start = reporting_window["resolution_window_start"]
    resolution_window_end = reporting_window["resolution_window_end"]
    resolved_today_payload = fetch_open_defects_payload(
        jql=resolved_today_jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    resolved_today_issues = filter_issues_moved_to_status_within_window(
        resolved_today_payload.get("issues", []),
        target_statuses={"Accepted", "Cancelled"},
        window_start=resolution_window_start,
        window_end=resolution_window_end,
    )
    issues = merge_issue_lists(issues, resolved_today_issues)
    field_name_lookup = build_field_name_lookup(
        payload.get("names") or resolved_today_payload.get("names") or {}
    )
    issue_rows = build_issue_rows_with_cutoff(
        issues,
        field_name_lookup=field_name_lookup,
        status_cutoff=reporting_window["status_cutoff"],
    )
    sla_breach_flags = build_sla_breach_flags(issues)
    header_titles = build_progression_header_titles(reporting_window["status_header_title"])
    workbook = build_workbook(
        issue_rows,
        worksheet_title=PROGRESSION_OPEN_DEFECTS_WORKSHEET_TITLE,
        header_titles=header_titles,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=PROGRESSION_OPEN_DEFECTS_FILENAME_PREFIX), len(issues), issue_rows, issues, header_titles


def export_regression_open_defects(open_jql=REGRESSION_OPEN_DEFECTS_JQL, resolved_today_jql=REGRESSION_RESOLVED_TODAY_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    reporting_window = build_progression_reporting_window()
    payload = fetch_open_defects_payload(
        jql=open_jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    resolution_window_start = reporting_window["resolution_window_start"]
    resolution_window_end = reporting_window["resolution_window_end"]
    resolved_today_payload = fetch_open_defects_payload(
        jql=resolved_today_jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    resolved_today_issues = filter_issues_moved_to_status_within_window(
        resolved_today_payload.get("issues", []),
        target_statuses={"Accepted", "Cancelled"},
        window_start=resolution_window_start,
        window_end=resolution_window_end,
    )
    issues = merge_issue_lists(issues, resolved_today_issues)
    field_name_lookup = build_field_name_lookup(
        payload.get("names") or resolved_today_payload.get("names") or {}
    )
    issue_rows = build_issue_rows_with_cutoff(
        issues,
        field_name_lookup=field_name_lookup,
        status_cutoff=reporting_window["status_cutoff"],
    )
    sla_breach_flags = build_sla_breach_flags(issues)
    header_titles = build_progression_header_titles(reporting_window["status_header_title"])
    workbook = build_workbook(
        issue_rows,
        worksheet_title=REGRESSION_OPEN_DEFECTS_WORKSHEET_TITLE,
        header_titles=header_titles,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=REGRESSION_OPEN_DEFECTS_FILENAME_PREFIX), len(issues), issue_rows, issues, header_titles


def export_retest_defects(jql=RETEST_DEFECTS_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=RETEST_DEFECTS_FILENAME_PREFIX,
        worksheet_title=RETEST_DEFECTS_WORKSHEET_TITLE,
        header_titles=OVERALL_HEADER_TITLES,
        row_transform=transform_overall_issue_row,
    )


def export_acc_prod_retest_defects(jql=RETEST_DEFECTS_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    issue_rows = build_issue_rows(issues, field_name_lookup=field_name_lookup)
    issue_rows = [
        transform_acc_prod_retest_issue_row(issue_row, issue, field_name_lookup=field_name_lookup)
        for issue_row, issue in zip(issue_rows, issues)
    ]
    sla_breach_flags = build_sla_breach_flags(issues)
    workbook = build_workbook(
        issue_rows,
        worksheet_title=RETEST_DEFECTS_WORKSHEET_TITLE,
        header_titles=ACC_PROD_RETEST_HEADER_TITLES,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=RETEST_DEFECTS_FILENAME_PREFIX), len(issues), issue_rows, issues


def export_return_reject_defects(jql=RETURN_REJECT_DEFECTS_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=RETURN_REJECT_DEFECTS_FILENAME_PREFIX,
        worksheet_title=RETURN_REJECT_DEFECTS_WORKSHEET_TITLE,
        header_titles=OVERALL_HEADER_TITLES,
        row_transform=transform_overall_issue_row,
    )


def export_acc_prod_return_reject_defects(jql=RETURN_REJECT_DEFECTS_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=RETURN_REJECT_DEFECTS_FILENAME_PREFIX,
        worksheet_title=RETURN_REJECT_DEFECTS_WORKSHEET_TITLE,
        header_titles=ACC_PROD_NO_IXP_HEADER_TITLES,
        row_transform=transform_acc_prod_no_ixp_issue_row,
    )


def export_acc_prod_new_defects_created(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=ACC_PROD_NEW_DEFECTS_CREATED_FILENAME_PREFIX,
        worksheet_title="New Defects Created",
        header_titles=ACC_PROD_NO_IXP_HEADER_TITLES,
        row_transform=transform_acc_prod_no_ixp_issue_row,
    )


def export_acc_prod_out_of_sla_sales(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=ACC_PROD_OUT_OF_SLA_SALES_FILENAME_PREFIX,
        worksheet_title="Out of SLA Sales",
        header_titles=ACC_PROD_NO_IXP_HEADER_TITLES,
        row_transform=transform_acc_prod_no_ixp_issue_row,
    )


def export_acc_prod_out_of_sla_non_sales(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=ACC_PROD_OUT_OF_SLA_NON_SALES_FILENAME_PREFIX,
        worksheet_title="Out of SLA Non Sales",
        header_titles=ACC_PROD_NO_IXP_HEADER_TITLES,
        row_transform=transform_acc_prod_no_ixp_issue_row,
    )


def export_acc_prod_missing_order_impact(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    return export_defects(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        filename_prefix=ACC_PROD_MISSING_ORDER_IMPACT_FILENAME_PREFIX,
        worksheet_title="Missing Order Impact",
        header_titles=ACC_PROD_NO_IXP_HEADER_TITLES,
        row_transform=transform_acc_prod_no_ixp_issue_row,
    )


def export_acc_prod_pilot_defects_wls(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
        expand='names',
    )
    issues = payload.get('issues', [])
    field_name_lookup = build_field_name_lookup(payload.get('names') or {})
    scrum_team_mapping = load_pilot_wls_mapping()
    issue_rows = build_acc_prod_pilot_defects_wls_rows(issues, field_name_lookup, scrum_team_mapping)
    workbook = build_workbook(
        issue_rows,
        worksheet_title='Pilot Defects WLS',
        header_titles=ACC_PROD_PILOT_DEFECTS_WLS_HEADER_TITLES,
        sla_breach_flags=[False] * len(issue_rows),
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=ACC_PROD_PILOT_DEFECTS_WLS_FILENAME_PREFIX), len(issues), issue_rows, issues


from operations.config import ETA_SLIPPED_DEFECTS_MAX_RESULTS

def export_eta_slipped_defects(jql=ETA_SLIPPED_DEFECTS_JQL, max_results=None, username=None, password=None):
    if max_results is None:
        max_results = ETA_SLIPPED_DEFECTS_MAX_RESULTS
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = filter_eta_slipped_issues(payload.get("issues", []))
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    issue_rows = build_issue_rows(issues, field_name_lookup=field_name_lookup)
    issue_rows = [
        transform_eta_slipped_issue_row(issue_row, issue)
        for issue_row, issue in zip(issue_rows, issues)
    ]
    sla_breach_flags = build_sla_breach_flags(issues)
    workbook = build_workbook(
        issue_rows,
        worksheet_title=ETA_SLIPPED_DEFECTS_WORKSHEET_TITLE,
        header_titles=ETA_SLIPPED_HEADER_TITLES,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=ETA_SLIPPED_DEFECTS_FILENAME_PREFIX), len(issues), issue_rows, issues


def export_blocking_field_empty_defects(jql=RELEASE_OPEN_DEFECTS_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = filter_blank_blocking_field_issues(payload.get("issues", []))
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    issue_rows = build_issue_rows(issues, field_name_lookup=field_name_lookup)
    issue_rows = [
        transform_blocking_field_empty_issue_row(issue_row, issue)
        for issue_row, issue in zip(issue_rows, issues)
    ]
    sla_breach_flags = build_sla_breach_flags(issues)
    workbook = build_workbook(
        issue_rows,
        worksheet_title=BLOCKING_FIELD_EMPTY_DEFECTS_WORKSHEET_TITLE,
        header_titles=BLOCKING_FIELD_EMPTY_HEADER_TITLES,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=BLOCKING_FIELD_EMPTY_DEFECTS_FILENAME_PREFIX), len(issues), issue_rows, issues


def export_past_dated_fix_version_defects(jql=DEFAULT_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    issues = payload.get("issues", [])
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    issue_rows = build_issue_rows(issues, field_name_lookup=field_name_lookup)
    issue_rows = [transform_past_dated_fix_version_issue_row(issue_row) for issue_row in issue_rows]
    issue_rows = sort_issue_rows_by_severity_and_age(issue_rows)
    sla_breach_flags = build_sla_breach_flags(issues)
    workbook = build_workbook(
        issue_rows,
        worksheet_title=PAST_DATED_FIX_VERSION_DEFECTS_WORKSHEET_TITLE,
        header_titles=PAST_DATED_FIX_VERSION_HEADER_TITLES,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=PAST_DATED_FIX_VERSION_DEFECTS_FILENAME_PREFIX), len(issues), issue_rows, issues


def export_not_an_application_requesting_review_defects(jql=NOT_AN_APPLICATION_REQUESTING_REVIEW_JQL, max_results=DEFAULT_MAX_RESULTS, username=None, password=None):
    payload = fetch_open_defects_payload(
        jql=jql,
        max_results=max_results,
        username=username,
        password=password,
    )
    field_name_lookup = build_field_name_lookup(payload.get("names") or {})
    issues = filter_not_an_application_requesting_review_issues(
        payload.get("issues", []),
        field_name_lookup=field_name_lookup,
    )
    issue_rows = build_issue_rows(issues, field_name_lookup=field_name_lookup)
    issue_rows = [
        transform_not_an_application_requesting_review_issue_row(
            issue_row,
            issue,
            field_name_lookup=field_name_lookup,
        )
        for issue_row, issue in zip(issue_rows, issues)
    ]
    sla_breach_flags = build_sla_breach_flags(issues)
    workbook = build_workbook(
        issue_rows,
        worksheet_title="Not An Application Review",
        header_titles=NOT_AN_APPLICATION_REQUESTING_REVIEW_HEADER_TITLES,
        sla_breach_flags=sla_breach_flags,
    )
    output = BytesIO()
    workbook.save(output)
    output.seek(0)
    return output, build_export_filename(filename_prefix=NOT_AN_APPLICATION_REQUESTING_REVIEW_FILENAME_PREFIX), len(issues), issue_rows, issues


def send_defects_email(
    file_bytes,
    issue_rows,
    filename=DEFAULT_FILENAME,
    issues=None,
    subject=OPEN_DEFECTS_SUBJECT,
    summary_text=(
        'Kindly find below the open ACES defects for current release that needs immediate action by the respective development teams (For In-Progress Defects)/CQE teams (For Retest/Return-Rejected defects). '
        'For the latest updates on defects, please refer to the '
        '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
    ),
    empty_state_message="No open defects were returned for the current release.",
    summary_heading="",
    include_summary_section=True,
    header_titles=None,
    to_recipients=None,
    cc_recipients=None,
    greeting_text="Hello Team,",
    closing_signature_html='Regards,<br/>ACES IST DM Team',
    from_address=None,
    sent_on_behalf_of_name=None,
):
    email_preview = build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=subject,
        summary_text=summary_text,
        empty_state_message=empty_state_message,
        summary_heading=summary_heading,
        include_summary_section=include_summary_section,
        header_titles=header_titles,
        to_recipients=to_recipients,
        cc_recipients=cc_recipients,
        greeting_text=greeting_text,
        closing_signature_html=closing_signature_html,
        from_address=from_address,
        sent_on_behalf_of_name=sent_on_behalf_of_name,
    )
    html_body = email_preview["html_body"]
    recipients = email_preview["to_recipients"]
    resolved_cc_recipients = email_preview["cc_recipients"]
    attachment_filename = email_preview["attachment_filename"]
    if not is_graph_configured():
        raise ValueError('Microsoft Graph email delivery is not configured. Set GRAPH_TENANT_ID, GRAPH_CLIENT_ID, and GRAPH_CLIENT_SECRET and retry.')
    LOGGER.info(
        "Sending subject '%s' with %s issue rows and attachment '%s' via Graph API.",
        subject,
        len(issue_rows),
        filename,
    )
    send_email_via_graph(
        subject=subject,
        html_body=html_body,
        to_recipients=recipients,
        cc_recipients=resolved_cc_recipients,
        from_address=from_address,
        attachment_bytes=file_bytes,
        attachment_filename=attachment_filename,
    )


def build_defects_email_preview(
    issue_rows,
    filename=DEFAULT_FILENAME,
    issues=None,
    subject=OPEN_DEFECTS_SUBJECT,
    summary_text=(
        'Kindly find below the open ACES defects for current release that needs immediate action by the respective development teams (For In-Progress Defects)/CQE teams (For Retest/Return-Rejected defects). '
        'For the latest updates on defects, please refer to the '
        '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
    ),
    empty_state_message="No open defects were returned for the current release.",
    summary_heading="",
    include_summary_section=True,
    header_titles=None,
    to_recipients=None,
    cc_recipients=None,
    greeting_text="Hello Team,",
    closing_signature_html='Regards,<br/>ACES IST DM Team',
    from_address=None,
    sent_on_behalf_of_name=None,
):
    header_titles = header_titles or FULL_HEADER_TITLES
    summary_spacer = '<div style="height:24px;line-height:24px;font-size:24px;">&nbsp;</div>' if include_summary_section else ""
    sla_breach_flags = build_sla_breach_flags(issues or []) if issues else [False] * len(issue_rows)
    bot_note_html = (
        '<div style="margin-top:24px; margin-bottom:8px; color:#0f0202; font-size:14px;">'
        'Note: This is a BOT generated email, kindly reach out to '
        '<a href="mailto:dl-ATT_DM_ACES@intl.att.com">dl-ATT_DM_ACES@intl.att.com</a> for any questions.</div>'
    )
    closing_html = (
        bot_note_html +
        '<div style="height:24px;line-height:24px;font-size:24px;">&nbsp;</div>'
        f'<p style="margin-top:16px;">{closing_signature_html}</p>'
        if closing_signature_html
        else bot_note_html
    )
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        f'<p>{greeting_text}</p>'
        f'<p>{summary_text}</p>'
        f'{summary_heading if include_summary_section else ""}'
        f'{build_summary_table_html(issue_rows) if include_summary_section else ""}'
        f'{summary_spacer}'
        f'{build_email_table_html(issue_rows, header_titles=header_titles, empty_state_message=empty_state_message, sla_breach_flags=sla_breach_flags)}'
        f'{closing_html}'
        '</body></html>'
    )
    sender_email = "the active Outlook account"
    recipients = to_recipients or extract_issue_recipients(issues or []) or extract_assignee_recipients(issue_rows)
    resolved_cc_recipients = (
        parse_recipient_entries(DEFAULT_CC_RECIPIENTS)
        if cc_recipients is None
        else cc_recipients
    )
    attachment_filename = os.path.basename(filename) or DEFAULT_FILENAME
    return {
        "subject": subject,
        "html_body": html_body,
        "to_recipients": recipients,
        "cc_recipients": resolved_cc_recipients,
        "attachment_filename": attachment_filename,
        "from_address": from_address,
        "sent_on_behalf_of_name": sent_on_behalf_of_name,
    }


def build_release_open_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=build_open_defects_subject(),
        empty_state_message="No open defects were returned for the current release.",
        include_summary_section=False,
        header_titles=OVERALL_HEADER_TITLES,
    )


def build_acc_prod_new_defects_created_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=ACC_PROD_NEW_DEFECTS_CREATED_SUBJECT,
        summary_text=(
            'Kindly find below the Prod defects created since the start of the previous day for review and follow-up.'
        ),
        empty_state_message='No new prod defects were created during the selected reporting window.',
        include_summary_section=False,
        header_titles=ACC_PROD_EMAIL_HEADER_TITLES,
        to_recipients=parse_recipient_entries(ACC_PROD_NEW_DEFECTS_TO_RECIPIENTS),
        cc_recipients=parse_recipient_entries(ACC_PROD_NEW_DEFECTS_CC_RECIPIENTS),
        closing_signature_html='Regards,<br/>ACC Prod DM Team',
        from_address=ACC_PROD_FROM_ADDRESS,
    )


def build_acc_prod_out_of_sla_sales_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=ACC_PROD_OUT_OF_SLA_SALES_SUBJECT,
        summary_text=(
            'Good day!<br/><br/>'
            'This is an email from the ACC Production Defect Management team.<br/><br/>'
            'Below are the Sales defects that are currently out of SLA and need immediate action.<br/><br/>'
            'Please review them and update the latest progress accordingly in iTrack.'
        ),
        empty_state_message='No ACC Prod Sales defects are currently out of SLA.',
        include_summary_section=False,
        header_titles=ACC_PROD_EMAIL_HEADER_TITLES,
        cc_recipients=parse_recipient_entries(ACC_PROD_OUT_OF_SLA_SALES_CC_RECIPIENTS),
        closing_signature_html='Regards,<br/>ACC Prod DM Team',
        from_address=ACC_PROD_FROM_ADDRESS,
    )


def build_acc_prod_out_of_sla_non_sales_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=ACC_PROD_OUT_OF_SLA_NON_SALES_SUBJECT,
        summary_text=(
            'Good day!<br/><br/>'
            'This is an email from the ACC Production Defect Management team.<br/><br/>'
            'Below are the Non-Sales defects that are currently out of SLA and need immediate action.<br/><br/>'
            'Please review them and update the latest progress accordingly in iTrack.'
        ),
        empty_state_message='No ACC Prod Non-Sales defects are currently out of SLA.',
        include_summary_section=False,
        header_titles=ACC_PROD_EMAIL_HEADER_TITLES,
        cc_recipients=parse_recipient_entries(ACC_PROD_OUT_OF_SLA_NON_SALES_CC_RECIPIENTS),
        closing_signature_html='Regards,<br/>ACC Prod DM Team',
        from_address=ACC_PROD_FROM_ADDRESS,
    )


def build_acc_prod_missing_order_impact_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=ACC_PROD_MISSING_ORDER_IMPACT_SUBJECT,
        summary_text=(
            'Good day!<br/><br/>'
            'This is an email from the ACC Production Defect Management team.<br/><br/>'
            'Below are the Shop and Purchase defects where the Order Impact value is missing and needs immediate update.<br/><br/>'
            'Please review them and update the missing value accordingly in iTrack.'
        ),
        empty_state_message='No ACC Prod Shop/Purchase defects with missing Order Impact value were found.',
        include_summary_section=False,
        header_titles=ACC_PROD_EMAIL_HEADER_TITLES,
        to_recipients=parse_recipient_entries(ACC_PROD_MISSING_ORDER_IMPACT_TO_RECIPIENTS),
        cc_recipients=parse_recipient_entries(ACC_PROD_MISSING_ORDER_IMPACT_CC_RECIPIENTS),
        closing_signature_html='Regards,<br/>ACC Prod DM Team',
        from_address=ACC_PROD_FROM_ADDRESS,
    )


def build_acc_prod_pilot_defects_wls_subject(now=None):
    return f'Update on ACC Wireless Pilot Sev-2 and Sev-3 Defects - {(now or datetime.now(IST_TIMEZONE)).strftime("%Y-%m-%d")}'


def build_acc_prod_pilot_defects_wls_highlights_html(issue_rows):
    release_issue_map = {}
    tracking_issue_labels = []
    now = datetime.now(IST_TIMEZONE).date()

    for row in issue_rows or []:
        status_value = stringify_field_value(row[3]).strip()
        issue_key = stringify_field_value(row[1]).strip()
        sp_identifier = stringify_field_value(row[0]).strip()
        comments_value = stringify_field_value(row[14]).strip()
        fix_version_value = stringify_field_value(row[12]).strip()
        normalized_issue_key = issue_key.replace('CDEX-', '').strip() if issue_key.upper().startswith('CDEX-') else issue_key

        for fix_version_name in [value.strip() for value in fix_version_value.split(',') if value.strip()]:
            release_issue_map.setdefault(fix_version_name, []).append(
                {
                    'issue_key': issue_key,
                    'normalized_issue_key': normalized_issue_key,
                    'status': status_value,
                    'comments': comments_value,
                }
            )

        if status_value.casefold() == 'tracking':
            if sp_identifier:
                tracking_issue_labels.append(f'{normalized_issue_key} ({sp_identifier})')
            else:
                tracking_issue_labels.append(normalized_issue_key)

    highlight_items = []
    for release_name, release_issues in release_issue_map.items():
        count = len(release_issues)
        release_date_match = re.match(r'^\s*(\d{1,2}/\d{1,2})(?:/\d{2,4})?\b', release_name)
        verb_phrase = 'getting fixed in'
        if release_date_match:
            release_date_text = release_date_match.group(1)
            try:
                release_date = datetime.strptime(f'{release_date_text}/{now.year}', '%m/%d/%Y').date()
                if release_date < now:
                    verb_phrase = 'got fixed in'
            except ValueError:
                pass

        issue_notes = []
        for release_issue in release_issues:
            if release_issue['comments']:
                issue_notes.append(f"{release_issue['issue_key']} {release_issue['comments']}")
            elif release_issue['status'].casefold() == 'tracking':
                issue_notes.append(f"{release_issue['issue_key']} is kept in Tracking")

        highlight_text = (
            f'{count} CDEX{"s" if count != 1 else ""} {verb_phrase} {escape(release_name)} Release'
        )
        if issue_notes:
            highlight_text = f'{highlight_text}. {escape(" ".join(issue_notes))}'
        highlight_items.append(highlight_text)

    if tracking_issue_labels:
        tracking_count = len(tracking_issue_labels)
        highlight_items.append(
            f'{tracking_count} CDEX{"s" if tracking_count != 1 else ""} '
            f'{"are" if tracking_count != 1 else "is"} moved to Tracking state '
            f'({escape(", ".join(tracking_issue_labels))})'
        )

    if not highlight_items:
        highlight_items.append('No pilot defect highlights are available for the current table list.')

    return '<ul>' + ''.join(f'<li>{item}</li>' for item in highlight_items) + '</ul>'


def build_acc_prod_pilot_defects_wls_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    html_body = (
        '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
        '<p>Hi Everyone,</p>'
        '<p>Please find the below list of CDEXs raised in Prod for Retail and Centers Wireless Pilot Program. Request you to check and populate the fix version or provide updates.</p>'
        '<p><strong>Highlights:</strong> (As per the report pulled as attached)</p>'
        f'{build_acc_prod_pilot_defects_wls_highlights_html(issue_rows)}'
        f'{build_email_table_html(issue_rows, header_titles=ACC_PROD_PILOT_DEFECTS_WLS_HEADER_TITLES, empty_state_message="No Pilot Wireless defects matched the selected criteria.", sla_breach_flags=[False] * len(issue_rows))}'
        '<div style="height:24px;line-height:24px;font-size:24px;">&nbsp;</div>'
        '<p>Regards,<br/>ACC Prod DM Team</p>'
        '</body></html>'
    )
    return {
        'subject': build_acc_prod_pilot_defects_wls_subject(),
        'html_body': html_body,
        'to_recipients': parse_recipient_entries(ACC_PROD_PILOT_DEFECTS_WLS_TO_RECIPIENTS),
        'cc_recipients': parse_recipient_entries(ACC_PROD_PILOT_DEFECTS_WLS_CC_RECIPIENTS),
        'attachment_filename': os.path.basename(filename) or DEFAULT_FILENAME,
        'from_address': ACC_PROD_FROM_ADDRESS,
        'sent_on_behalf_of_name': None,
    }


def build_progression_open_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None, header_titles=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=build_progression_regression_subject(issue_rows),
        summary_text=(
            f'Listed below are the <strong>Open {escape(resolve_progression_regression_label(issue_rows))}</strong> Defects for traction from Engineering/CQE Leads. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No progression open defects were returned for the current release.",
        summary_heading='<p style="margin:0 0 10px 0;"><strong><u>Summary</u></strong></p>',
        header_titles=header_titles or FULL_HEADER_TITLES,
    )


def build_regression_open_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None, header_titles=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=build_progression_regression_subject(issue_rows),
        summary_text=(
            f'Listed below are the <strong>Open {escape(resolve_progression_regression_label(issue_rows))}</strong> Defects for traction from Engineering/CQE Leads. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No regression open defects were returned for the current release.",
        summary_heading='<p style="margin:0 0 10px 0;"><strong><u>Summary</u></strong></p>',
        header_titles=header_titles or FULL_HEADER_TITLES,
    )


def build_retest_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None, cc_recipients=None, is_acc_prod=False):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=RETEST_DEFECTS_SUBJECT,
        summary_text=(
            (
                'The defects listed below are currently pending with the Execution Team. Kindly review them and update the status as appropriate.<br/><br/>'
                'Leads: Your support is requested in reviewing and prioritizing defects pending with the Execution Team'
            )
            if is_acc_prod else
            (
                'The defects listed below are currently <strong>pending with the Execution Team</strong>. Kindly review them and update the status as appropriate.<br/><br/>'
                '<strong>@Tribe Lead:</strong> Your support is requested in reviewing and prioritizing defects pending with the Execution Team.<br/><br/>'
                'For the latest updates on defects, please refer to the '
                '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
            )
        ),
        empty_state_message="No retest defects were returned for the current release.",
        include_summary_section=False,
        header_titles=ACC_PROD_RETEST_EMAIL_HEADER_TITLES if is_acc_prod else OVERALL_HEADER_TITLES,
        cc_recipients=cc_recipients,
        closing_signature_html='Regards,<br/>ACC Prod DM Team' if is_acc_prod else 'Regards,<br/>ACES IST DM Team',
        from_address=ACC_PROD_FROM_ADDRESS if is_acc_prod else None,
    )


def build_return_reject_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None, cc_recipients=None, is_acc_prod=False):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=RETURN_REJECT_DEFECTS_SUBJECT,
        summary_text=(
            'The defects listed below are currently <strong>pending with the Execution Team</strong>. Kindly review them and update the status as appropriate.<br/><br/>'
            '<strong>@Tribe Lead:</strong> Your support is requested in reviewing and prioritizing defects pending with the Execution Team.<br/><br/>'
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No return/reject defects were returned for the current release.",
        include_summary_section=False,
        header_titles=ACC_PROD_EMAIL_HEADER_TITLES if is_acc_prod else OVERALL_HEADER_TITLES,
        cc_recipients=cc_recipients,
    )


def build_eta_slipped_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=ETA_SLIPPED_DEFECTS_SUBJECT,
        summary_text=(
            'Kindly find below the defects where EST Fix Date was slipped from the previously committed date to a future date. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No ETA slipped defects were identified today.",
        include_summary_section=False,
        header_titles=ETA_SLIPPED_HEADER_TITLES,
        to_recipients=parse_recipient_entries(ETA_SLIPPED_TO_RECIPIENTS),
        cc_recipients=[],
    )


def build_blocking_field_empty_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=BLOCKING_FIELD_EMPTY_DEFECTS_SUBJECT,
        summary_text=(
            'Kindly find below the current release open defects where the Blocking field is blank in iTrack. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No current release open defects with a blank Blocking field were returned.",
        include_summary_section=False,
        header_titles=BLOCKING_FIELD_EMPTY_HEADER_TITLES,
    )


def build_past_dated_fix_version_defects_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=PAST_DATED_FIX_VERSION_DEFECTS_SUBJECT,
        summary_text=(
            'Good day!<br/><br/>'
            'This is an Email from ACC Production Defect Management team.<br/><br/>'
            'Below are the list of defects which has an Outdated Fix Version.<br/><br/>'
            'Could you please take further actions and update the latest progress accordingly if the fix is deployed to Production.<br/><br/>'
            'Also if the fix is still pending for deployment, requesting you to kindly update the FixVersion it is planned for.'
        ),
        empty_state_message='No prod defects with past dated fix versions were returned.',
        include_summary_section=False,
        header_titles=PAST_DATED_FIX_VERSION_HEADER_TITLES,
        greeting_text='Hi Team',
        closing_signature_html='',
        cc_recipients=[],
        sent_on_behalf_of_name=ACC_PROD_FROM_DISPLAY_NAME,
    )


def build_not_an_application_requesting_review_email_preview(issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return build_defects_email_preview(
        issue_rows,
        filename=filename,
        issues=issues,
        subject=NOT_AN_APPLICATION_REQUESTING_REVIEW_SUBJECT,
        summary_text=(
            'Listed below are defects with <strong>Application Fixed In = Not an Application</strong> where the Root Cause Category/Reason needs review because it does not match the expected review values.'
        ),
        empty_state_message="No Not an Application defects required review.",
        include_summary_section=False,
        header_titles=NOT_AN_APPLICATION_REQUESTING_REVIEW_HEADER_TITLES,
        to_recipients=parse_recipient_entries('ATT_DM_ACES <dl-ATT_DM_ACES@intl.att.com>'),
        cc_recipients=[],
    )


def send_release_open_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=build_open_defects_subject(),
        empty_state_message="No open defects were returned for the current release.",
        include_summary_section=False,
        header_titles=OVERALL_HEADER_TITLES,
    )


def send_progression_open_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None, header_titles=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=build_progression_regression_subject(issue_rows),
        summary_text=(
            f'Listed below are the <strong>Open {escape(resolve_progression_regression_label(issue_rows))}</strong> Defects for traction from Engineering/CQE Leads. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No progression open defects were returned for the current release.",
        summary_heading='<p style="margin:0 0 10px 0;"><strong><u>Summary</u></strong></p>',
        header_titles=header_titles or FULL_HEADER_TITLES,
    )


def send_regression_open_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None, header_titles=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=build_progression_regression_subject(issue_rows),
        summary_text=(
            f'Listed below are the <strong>Open {escape(resolve_progression_regression_label(issue_rows))}</strong> Defects for traction from Engineering/CQE Leads. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No regression open defects were returned for the current release.",
        summary_heading='<p style="margin:0 0 10px 0;"><strong><u>Summary</u></strong></p>',
        header_titles=header_titles or FULL_HEADER_TITLES,
    )


def send_retest_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=RETEST_DEFECTS_SUBJECT,
        summary_text=(
            'The defects listed below are currently <strong>pending with the Execution Team</strong>. Kindly review them and update the status as appropriate.<br/><br/>'
            '<strong>@Tribe Lead:</strong> Your support is requested in reviewing and prioritizing defects pending with the Execution Team.<br/><br/>'
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No retest defects were returned for the current release.",
        include_summary_section=False,
        header_titles=OVERALL_HEADER_TITLES,
    )


def send_return_reject_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=RETURN_REJECT_DEFECTS_SUBJECT,
        summary_text=(
            'The defects listed below are currently <strong>pending with the Execution Team</strong>. Kindly review them and update the status as appropriate.<br/><br/>'
            '<strong>@Tribe Lead:</strong> Your support is requested in reviewing and prioritizing defects pending with the Execution Team.<br/><br/>'
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No return/reject defects were returned for the current release.",
        include_summary_section=False,
        header_titles=OVERALL_HEADER_TITLES,
    )


def send_eta_slipped_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=ETA_SLIPPED_DEFECTS_SUBJECT,
        summary_text=(
            'Kindly find below the defects where EST Fix Date was slipped from the previously committed date to a future date. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No ETA slipped defects were identified today.",
        include_summary_section=False,
        header_titles=ETA_SLIPPED_HEADER_TITLES,
        to_recipients=parse_recipient_entries(ETA_SLIPPED_TO_RECIPIENTS),
        cc_recipients=[],
    )


def send_blocking_field_empty_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=BLOCKING_FIELD_EMPTY_DEFECTS_SUBJECT,
        summary_text=(
            'Kindly find below the current release open defects where the Blocking field is blank in iTrack. '
            'For the latest updates on defects, please refer to the '
            '<a href="https://itrack.web.att.com/secure/Dashboard.jspa?selectPageId=104578">ACES_DM_Dashboard - iTrack</a>.'
        ),
        empty_state_message="No current release open defects with a blank Blocking field were returned.",
        include_summary_section=False,
        header_titles=BLOCKING_FIELD_EMPTY_HEADER_TITLES,
    )


def send_past_dated_fix_version_defects_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=PAST_DATED_FIX_VERSION_DEFECTS_SUBJECT,
        summary_text=(
            'Good day!<br/><br/>'
            'This is an Email from ACC Production Defect Management team.<br/><br/>'
            'Below are the list of defects which has an Outdated Fix Version.<br/><br/>'
            'Could you please take further actions and update the latest progress accordingly if the fix is deployed to Production.<br/><br/>'
            'Also if the fix is still pending for deployment, requesting you to kindly update the FixVersion it is planned for.'
        ),
        empty_state_message='No prod defects with past dated fix versions were returned.',
        include_summary_section=False,
        header_titles=PAST_DATED_FIX_VERSION_HEADER_TITLES,
        greeting_text='Hi Team',
        closing_signature_html='',
        cc_recipients=[],
        sent_on_behalf_of_name=ACC_PROD_FROM_DISPLAY_NAME,
    )


def send_not_an_application_requesting_review_email(file_bytes, issue_rows, filename=DEFAULT_FILENAME, issues=None):
    return send_defects_email(
        file_bytes,
        issue_rows,
        filename=filename,
        issues=issues,
        subject=NOT_AN_APPLICATION_REQUESTING_REVIEW_SUBJECT,
        summary_text=(
            'Listed below are defects with <strong>Application Fixed In = Not an Application</strong> where the Root Cause Category/Reason needs review because it does not match the expected review values.'
        ),
        empty_state_message="No Not an Application defects required review.",
        include_summary_section=False,
        header_titles=NOT_AN_APPLICATION_REQUESTING_REVIEW_HEADER_TITLES,
        to_recipients=parse_recipient_entries('ATT_DM_ACES <dl-ATT_DM_ACES@intl.att.com>'),
        cc_recipients=[],
    )


def main():
    output, filename, _, issue_rows, issues = export_release_open_defects()
    send_release_open_defects_email(output.getvalue(), issue_rows, filename, issues=issues)


if __name__ == "__main__":
    main()
