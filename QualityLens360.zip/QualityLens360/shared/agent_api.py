"""
JSON API blueprint for VS Code extension ↔ Flask backend communication.

This module registers `/api/...` routes that return JSON, sitting alongside
the existing HTML-rendering routes. The web UI is not affected.
"""

import logging
import threading
import uuid

from flask import Blueprint, jsonify, request, session

LOGGER = logging.getLogger(__name__)

api_bp = Blueprint("agent_api", __name__, url_prefix="/api")

# Reference to the feature instances — set during registration
_operations_feature = None
_ram_feature = None
_defect_lens_feature = None
_advanced_reporting_feature = None
_get_session_credentials = None


def register_api(
    app,
    operations_feature,
    ram_feature,
    defect_lens_feature,
    advanced_reporting_feature,
    get_session_credentials,
):
    """Attach the JSON API blueprint and wire feature references."""
    global _operations_feature, _ram_feature, _defect_lens_feature
    global _advanced_reporting_feature, _get_session_credentials

    _operations_feature = operations_feature
    _ram_feature = ram_feature
    _defect_lens_feature = defect_lens_feature
    _advanced_reporting_feature = advanced_reporting_feature
    _get_session_credentials = get_session_credentials
    app.register_blueprint(api_bp)


# ── Credential extraction ─────────────────────────────────────────

def _extract_credentials():
    """
    Get Jira credentials from either:
    1. X-Jira-Username / X-Jira-Password headers (extension auth)
    2. Session credentials (web UI fallback)
    """
    username = request.headers.get("X-Jira-Username")
    password = request.headers.get("X-Jira-Password")
    if username and password:
        return {"username": username, "password": password}
    if _get_session_credentials:
        return _get_session_credentials()
    return None


def _require_credentials():
    """Return credentials or raise a 401-able dict."""
    creds = _extract_credentials()
    if not creds:
        return None
    return creds


# ── Self-Heal ──────────────────────────────────────────────────────

SELF_HEAL_DISPATCH = {
    "tribe-label": "run_tribe_label_self_heal",
    "progression-regression-self-heal": "run_progression_regression_self_heal",
    "return-rejected-retest-test-blocked-assigned-to-team-testing-self-heal": "run_assigned_to_team_testing_status_self_heal",
    "assigned-to-team-testing-vs-assignee-self-heal": "run_assigned_to_team_testing_vs_assignee_self_heal",
    "application-fixed-in-cqe-accepted-cancelled-self-heal": "run_application_fixed_in_cqe_self_heal",
    "application-fixed-in-cqe-revert-to-previous-self-heal": "run_application_fixed_in_cqe_revert_to_previous_self_heal",
    "root-cause-app-matches-application-fixed-in-self-heal": "run_root_cause_app_matches_application_fixed_in_self_heal",
    "retest-test-blocked-assigned-to-team-testing-self-heal": "run_acc_prod_assigned_to_team_testing_status_self_heal",
    "return-rejected-assigned-to-team-triage-self-heal": "run_acc_prod_assigned_to_team_triage_status_self_heal",
    "application-fixed-in-root-cause-app-sync-self-heal": "run_acc_prod_application_fixed_in_root_cause_app_sync_self_heal",
    "assigned-to-team-business-application-fixed-in-self-heal": "run_acc_prod_assigned_to_team_business_application_fixed_in_self_heal",
    "assigned-to-team-production-support-application-fixed-in-self-heal": "run_acc_prod_assigned_to_team_production_support_application_fixed_in_self_heal",
    "assigned-to-team-triage-update-assignee-self-heal": "run_acc_prod_assigned_to_team_triage_update_assignee_self_heal",
    "bug-issue-conversion-self-heal": "run_acc_prod_bug_issue_conversion_self_heal",
    "customer-impact-less-update-severity-self-heal": "run_acc_prod_customer_impact_less_update_severity_self_heal",
    "non-monitoring-pilot-sev4-defects-label-addition-self-heal": "run_acc_prod_non_monitoring_pilot_sev4_label_addition_self_heal",
    "update-est-retest-date-self-heal": "run_acc_prod_update_est_retest_date_self_heal",
}


@api_bp.post("/operations/self-heal")
def api_self_heal():
    creds = _require_credentials()
    if not creds:
        return jsonify({"status": "error", "message": "Authentication required."}), 401

    data = request.get_json(silent=True) or {}
    operation_id = data.get("operation_id", "").strip()

    method_name = SELF_HEAL_DISPATCH.get(operation_id)
    if not method_name:
        return jsonify({
            "status": "error",
            "message": f"Unknown self-heal operation: {operation_id}",
            "available": list(SELF_HEAL_DISPATCH.keys()),
        }), 400

    method = getattr(_operations_feature, method_name, None)
    if not method:
        return jsonify({"status": "error", "message": f"Method {method_name} not found on operations feature."}), 500

    # Run in background thread, return job ID
    job_id = uuid.uuid4().hex
    result_store = {}

    def _run():
        try:
            message = method()
            result_store["status"] = "success"
            result_store["message"] = message
        except Exception as exc:
            LOGGER.exception("Self-heal %s failed", operation_id)
            result_store["status"] = "error"
            result_store["message"] = str(exc)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return jsonify({"job_id": job_id, "operation_id": operation_id, "status": "running"})


# ── Trigger Email ──────────────────────────────────────────────────

TRIGGER_EMAIL_DISPATCH = {
    "release-open-defects": "download_release_open_defects",
    "release-open-defects-progression-dm-comments": "download_progression_open_defects",
    "release-open-defects-regression-dm-comments": "download_regression_open_defects",
    "eta-slipped-defects": "download_eta_slipped_defects",
    "blocking-field-empty": "download_blocking_field_empty_defects",
    "retest-defects": "download_retest_defects",
    "return-reject-defects": "download_return_reject_defects",
    "new-defects-created": "download_new_defects_created",
    "missing-order-impact": "download_missing_order_impact",
    "pilot-defects-wls": "download_pilot_defects_wls",
    "out-of-sla-sales": "download_out_of_sla_sales",
    "out-of-sla-non-sales": "download_out_of_sla_non_sales",
    "not-an-application-requesting-review": "download_not_an_application_requesting_review",
    "deferred-defects": "download_deferred_defects",
}


@api_bp.post("/operations/trigger-email")
def api_trigger_email():
    creds = _require_credentials()
    if not creds:
        return jsonify({"status": "error", "message": "Authentication required."}), 401

    data = request.get_json(silent=True) or {}
    operation_id = data.get("operation_id", "").strip()

    method_name = TRIGGER_EMAIL_DISPATCH.get(operation_id)
    if not method_name:
        return jsonify({
            "status": "error",
            "message": f"Unknown email report: {operation_id}",
            "available": list(TRIGGER_EMAIL_DISPATCH.keys()),
        }), 400

    method = getattr(_operations_feature, method_name, None)
    if not method:
        return jsonify({"status": "error", "message": f"Method {method_name} not found."}), 500

    job_id = uuid.uuid4().hex

    def _run():
        try:
            method()
        except Exception:
            LOGGER.exception("Trigger email %s failed", operation_id)

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()

    return jsonify({"job_id": job_id, "operation_id": operation_id, "status": "running"})


# ── DefectLens ─────────────────────────────────────────────────────

@api_bp.post("/defect-lens/run")
def api_defect_lens_run():
    creds = _require_credentials()
    if not creds:
        return jsonify({"status": "error", "message": "Authentication required."}), 401

    data = request.get_json(silent=True) or {}
    application = data.get("application", "ACES-IST")
    release_name = data.get("release_name", "")
    jql = data.get("jql", "")
    resolved_from = data.get("resolved_from", "")
    resolved_to = data.get("resolved_to", "")

    try:
        if not jql:
            jql = _defect_lens_feature.build_defect_lens_generated_jql(
                application, release_name, resolved_from, resolved_to
            )

        service = _defect_lens_feature.get_defect_lens_service()
        job = service.submit(
            jql=jql,
            username=creds["username"],
            password=creds["password"],
        )
        return jsonify({
            "job_id": job.job_id,
            "jql": jql,
            "status": "running",
        })
    except Exception as exc:
        LOGGER.exception("DefectLens run failed")
        return jsonify({"status": "error", "message": str(exc)}), 400


@api_bp.get("/defect-lens/status/<job_id>")
def api_defect_lens_status(job_id):
    try:
        service = _defect_lens_feature.get_defect_lens_service()
        job = service.get(job_id)
        if job is None:
            return jsonify({"status": "error", "message": "Job not found."}), 404

        return jsonify({
            "job_id": job_id,
            "status": job.status,
            "progress": getattr(job, "progress", None),
            "message": getattr(job, "message", ""),
            "summary": getattr(job, "summary", None),
        })
    except Exception as exc:
        return jsonify({"status": "error", "message": str(exc)}), 500


# ── KPI Metrics ────────────────────────────────────────────────────

@api_bp.post("/ram/kpis")
def api_ram_kpis():
    creds = _require_credentials()
    if not creds:
        return jsonify({"status": "error", "message": "Authentication required."}), 401

    data = request.get_json(silent=True) or {}
    application = data.get("application", "ACC-Prod")
    release_name = data.get("release_name", "")
    created_from = data.get("created_from", "")
    created_to = data.get("created_to", "")

    try:
        kpi_handler = _ram_feature.get_kpi_handler(application)
        if not kpi_handler:
            return jsonify({"status": "error", "message": f"No KPI handler for {application}."}), 400

        results = kpi_handler.compute_all(
            username=creds["username"],
            password=creds["password"],
            release_name=release_name,
            created_from=created_from,
            created_to=created_to,
        )
        return jsonify({"status": "success", "kpis": results})
    except Exception as exc:
        LOGGER.exception("KPI computation failed")
        return jsonify({"status": "error", "message": str(exc)}), 500


@api_bp.post("/ram/kpi-chat")
def api_ram_kpi_chat():
    data = request.get_json(silent=True) or {}
    message = data.get("message", "").strip()
    if not message:
        return jsonify({"status": "error", "message": "Provide a question."}), 400

    try:
        reply = _ram_feature.handle_kpi_chat(message)
        return jsonify({"status": "success", "reply": reply})
    except Exception as exc:
        LOGGER.exception("KPI chat failed")
        return jsonify({"status": "error", "message": str(exc)}), 500


# ── Operations Hub Chat ───────────────────────────────────────────

_ops_chat_states = {}


@api_bp.post("/operations/ops-chat")
def api_operations_ops_chat():
    from operations.ops_chat import handle_chat_message

    data = request.get_json(silent=True) or {}
    message = data.get("message", "").strip()

    chat_key = session.get("credentials_key", "default")
    chat_state = _ops_chat_states.get(chat_key, {})
    try:
        reply, new_state = handle_chat_message(chat_state, message)
        _ops_chat_states[chat_key] = new_state
        return jsonify({"status": "success", "reply": reply})
    except Exception as exc:
        LOGGER.exception("Operations chat failed")
        return jsonify({"status": "error", "message": str(exc)}), 500


# ── Advanced Reporting ─────────────────────────────────────────────

@api_bp.post("/advanced-reporting/run")
def api_advanced_reporting_run():
    creds = _require_credentials()
    if not creds:
        return jsonify({"status": "error", "message": "Authentication required."}), 401

    data = request.get_json(silent=True) or {}
    report_type = data.get("report_type", "")
    release_name = data.get("release_name", "")
    created_from = data.get("created_from", "")
    created_to = data.get("created_to", "")

    try:
        if report_type == "cancellation":
            result = _advanced_reporting_feature.run_cancellation_report(
                username=creds["username"],
                password=creds["password"],
                release_name=release_name,
                created_from=created_from,
                created_to=created_to,
            )
        elif report_type == "accepted-defects-rca":
            result = _advanced_reporting_feature.run_accepted_defects_rca(
                username=creds["username"],
                password=creds["password"],
                release_name=release_name,
                created_from=created_from,
                created_to=created_to,
            )
        else:
            return jsonify({
                "status": "error",
                "message": f"Unknown report type: {report_type}",
                "available": ["cancellation", "accepted-defects-rca"],
            }), 400

        return jsonify({"status": "success", "data": result})
    except Exception as exc:
        LOGGER.exception("Advanced reporting failed")
        return jsonify({"status": "error", "message": str(exc)}), 500


# ── Job status (shared) ───────────────────────────────────────────

@api_bp.get("/operations/job-status/<job_id>")
def api_job_status(job_id):
    from operations.feature import _get_job
    job = _get_job(job_id)
    if job is None:
        return jsonify({"status": "error", "message": "Job not found."}), 404
    return jsonify(job)
