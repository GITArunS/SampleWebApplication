"""CDEX changelog parsing helpers."""

from __future__ import annotations

import re
from typing import Any

from defectLens.config import get_settings

FROM_RE = re.compile(r"From:\s*(.*)", re.IGNORECASE)
TO_RE = re.compile(r"To:\s*(.*)", re.IGNORECASE)


def count_field_changes(data: dict[str, Any], field_to_check: str | None = None) -> int:
    """Count changelog updates for the configured field."""

    target_field = field_to_check or get_settings().field_to_check
    return sum(
        1
        for history in data.get("changelog", {}).get("histories", [])
        for item in history.get("items", [])
        if item.get("field") == target_field
    )


def parse_field_changes(data: dict[str, Any], field_to_check: str | None = None) -> str:
    """Flatten changelog updates into the workbook's details text format."""

    target_field = field_to_check or get_settings().field_to_check
    output: list[str] = []

    for history in data.get("changelog", {}).get("histories", []):
        created = history.get("created", "")
        for item in history.get("items", []):
            if item.get("field") != target_field:
                continue
            output.append(
                f"Change on: {created}\n"
                f"Field: {target_field}\n"
                f"From: {item.get('fromString', '')}\n"
                f"To: {item.get('toString', '')}\n"
                "-----------------------------"
            )

    return "\n".join(output)


def count_unique_hops(text: str, excluded_values: tuple[str, ...] | None = None) -> int:
    """Count unique application team names from the flattened changelog text."""

    exclusions = excluded_values or get_settings().excluded_values
    values: set[str] = set()
    if not text:
        return 0

    for line in text.split("\n"):
        if not line.startswith(("From:", "To:")):
            continue
        value = line.split(":", 1)[1].strip()
        if value and not any(exclusion in value for exclusion in exclusions):
            values.add(value)

    return len(values)


def _extract_first_last_from_to(text: str) -> tuple[str, str, str, str]:
    first_from = ""
    first_to = ""
    last_from = ""
    last_to = ""

    if not text:
        return first_from, first_to, last_from, last_to

    for line in text.splitlines():
        stripped = line.strip()
        if not stripped:
            continue

        from_match = FROM_RE.search(stripped)
        if from_match:
            value = from_match.group(1).strip()
            if not first_from:
                first_from = value
            last_from = value

        to_match = TO_RE.search(stripped)
        if to_match:
            value = to_match.group(1).strip()
            if not first_to:
                first_to = value
            last_to = value

    return first_from, first_to, last_from, last_to


def compute_final_hop_adjustment(changelog_text: str | None, hop_count: float | None) -> float | None:
    """Replicate the legacy VBA final hop adjustment logic."""

    if changelog_text is None:
        return None

    text = str(changelog_text).strip()
    if not text or hop_count in (None, ""):
        return None

    try:
        hops = float(hop_count)
    except (TypeError, ValueError):
        return None

    first_from, first_to, last_from, last_to = _extract_first_last_from_to(text)

    def contains_cqe(value: str) -> bool:
        return "cqe" in (value or "").lower()

    if contains_cqe(last_to):
        adjustment = 0 if first_from == last_from else hops - 1
        if contains_cqe(first_from):
            adjustment = 0 if first_to == last_from else hops - 1
        return adjustment

    return 0 if first_from == last_to else hops - 1


def build_cdex_metrics_from_issue_data(issue_data: dict[str, Any]) -> dict[str, Any]:
    """Return the derived changelog fields used by the workbook."""

    settings = get_settings()
    parsed_text = parse_field_changes(issue_data, settings.field_to_check)
    hop_count = count_unique_hops(parsed_text, settings.excluded_values)
    final_hop_adjustment = compute_final_hop_adjustment(parsed_text, hop_count)
    return {
        "parsed_text": parsed_text,
        "hop_count": hop_count,
        "final_hop_Adjustment": final_hop_adjustment,
    }
