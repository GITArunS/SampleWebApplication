from pathlib import Path
import os
import sys

BASE_DIR = Path(__file__).resolve().parents[1]
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from flask import Flask, session
from flask_session import Session
from jinja2 import ChoiceLoader, FileSystemLoader

from home.logic import (
    get_hub_metrics_summary,
    record_dashboard_tile_click,
)
from shared.feedback import get_home_feedback, set_home_feedback
from shared.http_errors import format_http_error_message
from shared.shared_logic import validate_jira_credentials
from advancedReporting.feature import AdvancedReportingFeature
from advancedReporting.learning_feature import LearningFeature
from defectLens.feature import DefectLensFeature
from home.feature import HomeFeature
from login.auth import SessionCredentialStore, build_login_required
from login.feature import LoginFeature
from operations.feature import OperationsFeature
from ram.feature import RamFeature


app = Flask(
    __name__,
    static_folder=str(BASE_DIR / 'shared' / 'static'),
    static_url_path='/static',
)
app.jinja_loader = ChoiceLoader([
    FileSystemLoader(str(BASE_DIR / 'login')),
    FileSystemLoader(str(BASE_DIR / 'home')),
    FileSystemLoader(str(BASE_DIR / 'ram')),
    FileSystemLoader(str(BASE_DIR / 'operations')),
    FileSystemLoader(str(BASE_DIR / 'defectLens')),
    FileSystemLoader(str(BASE_DIR / 'advancedReporting')),
])
app.config['SECRET_KEY'] = os.environ.get('FLASK_SECRET_KEY', 'aces-operations-hub-dev-secret')

# ── Server-side sessions (shared across Gunicorn workers) ──
_session_dir = BASE_DIR / 'flask_sessions'
_session_dir.mkdir(exist_ok=True)
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_FILE_DIR'] = str(_session_dir)
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True          # sign the session-id cookie
app.config['SESSION_FILE_THRESHOLD'] = 500       # max cached session files
Session(app)

credential_store = SessionCredentialStore()


def get_session_credentials():
    return credential_store.get_session_credentials(session)


def store_session_credentials(username, password):
    credential_store.store_session_credentials(
        session,
        username,
        password,
    )


def clear_session_credentials():
    credential_store.clear_session_credentials(session)


login_required = build_login_required(get_session_credentials)


login_feature = LoginFeature(
    get_session_credentials=get_session_credentials,
    store_session_credentials=store_session_credentials,
    clear_session_credentials=clear_session_credentials,
    validate_jira_credentials=validate_jira_credentials,
)
login_feature.register(app)
home_feature = HomeFeature(
    get_session_credentials=get_session_credentials,
    get_hub_metrics_summary=get_hub_metrics_summary,
    record_dashboard_tile_click=record_dashboard_tile_click,
)
home_feature.register(app, login_required)

defect_lens_feature = DefectLensFeature(
    get_session_credentials=get_session_credentials,
)
defect_lens_feature.register(app, login_required)

advanced_reporting_feature = AdvancedReportingFeature(
    get_session_credentials=get_session_credentials,
)
advanced_reporting_feature.register(app, login_required)

learning_feature = LearningFeature(
    get_session_credentials=get_session_credentials,
)
learning_feature.register(app, login_required)


ram_feature = RamFeature(
    get_session_credentials=get_session_credentials,
    format_http_error_message=format_http_error_message,
)
ram_feature.register(app, login_required)

operations_feature = OperationsFeature(
    get_session_credentials=get_session_credentials,
    clear_session_credentials=clear_session_credentials,
    set_home_feedback=set_home_feedback,
    get_home_feedback=get_home_feedback,
    format_http_error_message=format_http_error_message,
)
operations_feature.register(app, login_required)

# ── JSON API for VS Code extension (@qualitylens360 agent) ──
from shared.agent_api import register_api

register_api(
    app,
    operations_feature=operations_feature,
    ram_feature=ram_feature,
    defect_lens_feature=defect_lens_feature,
    advanced_reporting_feature=advanced_reporting_feature,
    get_session_credentials=get_session_credentials,
)


if __name__ == '__main__':
    host = os.environ.get('HOST', '0.0.0.0')
    port = int(os.environ.get('PORT', 8000))
    debug = os.environ.get('FLASK_DEBUG', '').lower() in {'1', 'true', 'yes'}
    app.run(host=host, port=port, debug=debug)
