"""Application entry points."""

from __future__ import annotations

from defectLens.app import create_app
from defectLens.config import get_settings


def main() -> None:
    """Run the Flask development server."""

    settings = get_settings()
    app = create_app(settings)
    app.run(host=settings.flask_host, port=settings.flask_port, debug=settings.flask_debug)
