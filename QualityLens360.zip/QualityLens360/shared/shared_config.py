import os
from pathlib import Path

from dotenv import load_dotenv

# Load environment-specific .env file: .env.dev (local) or .env.prod (server).
# Set FLASK_ENV=production on the server; defaults to development locally.
_BASE_DIR = Path(__file__).resolve().parents[1]
_flask_env = os.environ.get('FLASK_ENV', 'development').lower()
if _flask_env == 'production':
    load_dotenv(_BASE_DIR / '.env.prod')
else:
    load_dotenv(_BASE_DIR / '.env.dev')
# Also load .env as a shared fallback (won't override values already set).
load_dotenv(_BASE_DIR / '.env', override=False)


def get_env_int(name, default):
    value = os.environ.get(name)
    if value in (None, ''):
        return default
    try:
        return int(value)
    except ValueError as error:
        raise ValueError(f'{name} must be an integer.') from error


JIRA_URL = os.environ.get('JIRA_URL', 'https://itrack.web.att.com/rest/api/2/issue/')
JIRA_USER = os.environ.get('JIRA_USER', '')
JIRA_API_TOKEN = os.environ.get('JIRA_API_TOKEN', '')

# ── Microsoft Graph API email configuration (preferred fallback) ──
GRAPH_TENANT_ID = os.environ.get('GRAPH_TENANT_ID', 'e741d71c-c6b6-47b0-803c-0f3b32b07556')
GRAPH_CLIENT_ID = os.environ.get('GRAPH_CLIENT_ID', '04d754e7-55d9-4b2c-99f5-6fbf551bada5')
GRAPH_CLIENT_SECRET = os.environ.get('GRAPH_CLIENT_SECRET', 'Eop8Q~Uu6V8X2LX7b4sv6RMyBZtLkvkHBCjpab-j')
GRAPH_SENDER_EMAIL = os.environ.get('GRAPH_SENDER_EMAIL', 'rm-cqecomms@intl.att.com')  # must be a licensed user/shared mailbox
GRAPH_FROM_ADDRESS = os.environ.get('GRAPH_FROM_ADDRESS', 'rm-cqecomms@intl.att.com')  # display "from" address (can be a DL)

# ── SMTP email configuration (used when Outlook COM is unavailable) ──
SMTP_SERVER = os.environ.get('SMTP_SERVER', 'mta02.az.3pc.att.com')  # internal relay or 'smtp.office365.com'
SMTP_PORT = get_env_int('SMTP_PORT', 19831)
SMTP_USERNAME = os.environ.get('SMTP_USERNAME', '')  # leave empty for unauthenticated relays
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', '')  # leave empty for unauthenticated relays
SMTP_USE_TLS = os.environ.get('SMTP_USE_TLS', 'false').lower() in {'1', 'true', 'yes'}

# ── HTTP proxy configuration (for iTrack / Jira / external HTTPS) ──
HTTPS_PROXY = os.environ.get('HTTPS_PROXY', os.environ.get('https_proxy', ''))
HTTP_PROXY = os.environ.get('HTTP_PROXY', os.environ.get('http_proxy', ''))
NO_PROXY = os.environ.get('NO_PROXY', os.environ.get('no_proxy', ''))
# Path to a custom CA bundle (PEM) for corporate TLS inspection proxies.
# Leave empty to use the default system/certifi bundle.
REQUESTS_CA_BUNDLE = os.environ.get('REQUESTS_CA_BUNDLE', '')
