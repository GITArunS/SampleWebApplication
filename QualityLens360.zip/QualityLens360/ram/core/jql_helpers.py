"""
RAM Core — Shared JQL Helpers

Stable infrastructure functions used by both ACC-Prod and ACES-IST.
Changes here are infrequent and should be coordinated across teams.
"""

import re

from ram.app_config import (
    RAM_APPLICATION_DEFINITIONS,
    RAM_DISPLAY_ONLY_APPLICATIONS,
    RAM_RELEASE_CLAUSE_PATTERN,
    get_ram_application_definition,
)
from shared.shared_logic import IST_TIMEZONE


# ============================================================================
# JQL ESCAPING AND FORMATTING
# ============================================================================

def escape_ram_jql_string(value):
    return str(value).replace('\\', '\\\\').replace('"', '\\"').strip()


# ============================================================================
# APPLICATION HELPERS
# ============================================================================

def is_acc_ram_application(application):
    application_definition = get_ram_application_definition(application)
    return bool(application_definition and application_definition.get('preprod_base_jql'))


def is_ram_display_only_application(application):
    return application in RAM_DISPLAY_ONLY_APPLICATIONS


def build_ram_base_jql(application):
    application_definition = get_ram_application_definition(application)
    if application_definition is None:
        configured_applications = ', '.join(sorted(RAM_APPLICATION_DEFINITIONS))
        raise ValueError(f'RAM KPI logic is currently configured only for: {configured_applications}.')
    return application_definition['base_jql']


# ============================================================================
# RELEASE FILTERING
# ============================================================================

def build_ram_release_clause(release_name):
    escaped_release_name = escape_ram_jql_string(release_name)
    return f'(cf[18971] in ("{escaped_release_name}") or cf[18972] in ("{escaped_release_name}"))'


def build_ram_release_clause_for_values(release_names):
    normalized_release_names = [str(release_name).strip() for release_name in (release_names or []) if str(release_name).strip()]
    if not normalized_release_names:
        raise ValueError('At least one release value is required.')
    escaped_values = ', '.join(f'"{escape_ram_jql_string(release_name)}"' for release_name in normalized_release_names)
    return f'(cf[18971] in ({escaped_values}) or cf[18972] in ({escaped_values}))'


def build_ram_release_scoped_jql(base_jql, release_name):
    if not release_name:
        return base_jql
    scoped_jql, replaced_count = RAM_RELEASE_CLAUSE_PATTERN.subn(build_ram_release_clause(release_name), base_jql, count=1)
    if replaced_count:
        return scoped_jql
    order_by_index = base_jql.casefold().find(' order by ')
    if order_by_index == -1:
        return f'({base_jql}) and {build_ram_release_clause(release_name)}'
    return f'{base_jql[:order_by_index]} and {build_ram_release_clause(release_name)}{base_jql[order_by_index:]}'


# ============================================================================
# DATE AND SCOPE FILTERING
# ============================================================================

def build_ram_scope_jql(base_jql, created_from, created_to, release_name=''):
    scoped_jql = build_ram_release_scoped_jql(base_jql, release_name)
    jql_parts = [scoped_jql]
    if created_from:
        jql_parts.append(f'created >= "{created_from}"')
    if created_to:
        jql_parts.append(f'created <= "{created_to}"')
    return ' and '.join(jql_parts)


def build_ram_jql(application, created_from, created_to, release_name=''):
    base_jql = build_ram_base_jql(application)
    application_definition = get_ram_application_definition(application)
    if application_definition and application_definition.get('supports_release_filter'):
        return build_ram_scope_jql(base_jql, created_from, created_to, release_name)
    jql_parts = [base_jql]
    if created_from:
        jql_parts.append(f'created >= "{created_from}"')
    if created_to:
        jql_parts.append(f'created <= "{created_to}"')
    return ' and '.join(jql_parts)


def strip_created_date_clauses(jql):
    """Remove all created >= and created <= date clauses from a JQL string."""
    result = re.sub(r'and created >= ".*?"', '', jql)
    result = re.sub(r'and created <= ".*?"', '', result)
    result = re.sub(r'created >= ".*?" and ', '', result)
    result = re.sub(r'created <= ".*?" and ', '', result)
    result = re.sub(r'created >= ".*?"', '', result)
    result = re.sub(r'created <= ".*?"', '', result)
    return re.sub(r'\s+', ' ', result).strip()


def build_resolved_period_ram_jql(base_jql, created_from, created_to):
    jql_parts = [f'({base_jql})']
    if created_from:
        jql_parts.append(f'resolved >= "{created_from}"')
    if created_to:
        jql_parts.append(f'resolved <= "{created_to}"')
    return ' and '.join(jql_parts)


# ============================================================================
# STATUS-BASED FILTERS
# ============================================================================

def build_open_ram_jql(base_jql):
    return f'({base_jql}) and status not in (Accepted, Cancelled)'


def build_triaged_ram_jql(jql):
    return f'({jql}) and status not in ("To Do")'


def build_cancelled_ram_jql(jql):
    return f'({jql}) and status in (Cancelled)'


def build_ram_status_history_jql(jql):
    return (
        f'({jql}) and ('
        'status in (Cancelled) '
        'or status changed to Retest '
        'or status changed to Returned '
        'or status changed to Rejected '
        'or status changed to "returned/rejected" '
        'or status changed to "Returned/Rejected"'
        ')'
    )


def build_ram_status_changed_during_jql(jql, target_statuses, created_from, created_to):
    status_clauses = [
        f'status changed to "{str(target_status).strip()}" DURING ("{created_from}", "{created_to}")'
        for target_status in target_statuses
        if str(target_status).strip()
    ]
    if not status_clauses:
        raise ValueError('At least one RAM lifecycle status is required.')
    return f'({jql}) and ({" or ".join(status_clauses)})'


def build_ram_status_changed_jql(jql, target_statuses):
    status_clauses = [
        f'status changed to "{str(target_status).strip()}"'
        for target_status in target_statuses
        if str(target_status).strip()
    ]
    if not status_clauses:
        raise ValueError('At least one RAM lifecycle status is required.')
    return f'({jql}) and ({" or ".join(status_clauses)})'


def build_ram_status_scope_jql(jql, target_statuses, created_from, created_to):
    if created_from and created_to:
        return build_ram_status_changed_during_jql(jql, target_statuses, created_from, created_to)
    return build_ram_status_changed_jql(jql, target_statuses)


# ============================================================================
# HISTORICAL QUERIES
# ============================================================================

def shift_ram_period_to_last_year(created_from, created_to):
    from datetime import datetime

    def shift_one(date_text):
        parsed_date = datetime.strptime(date_text, '%Y-%m-%d').date()
        try:
            shifted_date = parsed_date.replace(year=parsed_date.year - 1)
        except ValueError:
            shifted_date = parsed_date.replace(year=parsed_date.year - 1, day=28)
        return shifted_date.isoformat()
    return shift_one(created_from), shift_one(created_to)


def build_triaged_last_year_ram_jql(application, created_from, created_to, release_name=''):
    prior_year_from, prior_year_to = shift_ram_period_to_last_year(created_from, created_to)
    return build_triaged_ram_jql(build_ram_jql(application, prior_year_from, prior_year_to, release_name))


def get_last_calendar_year_bounds(reference_datetime=None):
    from datetime import datetime

    if reference_datetime is None:
        current_datetime = datetime.now(IST_TIMEZONE)
    elif getattr(reference_datetime, 'tzinfo', None) is None:
        current_datetime = reference_datetime
    else:
        current_datetime = reference_datetime.astimezone(IST_TIMEZONE)
    previous_year = current_datetime.year - 1
    return f'{previous_year}-01-01', f'{previous_year + 1}-01-01'


def build_triaged_last_calendar_year_ram_jql(application):
    created_from, created_before = get_last_calendar_year_bounds()
    base_jql = build_ram_base_jql(application)
    return f'({base_jql}) and created >= "{created_from}" and created < "{created_before}" and status not in ("To Do")'
