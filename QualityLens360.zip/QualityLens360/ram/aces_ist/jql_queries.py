"""
ACES-IST — JQL Queries & Label Logic

Application-specific JQL builders, label resolution, and metrics logic for ACES-IST.
Owned by the ACES-IST team. Changes here do not affect ACC-Prod.
"""

import re
from datetime import datetime

from ram.app_config import RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS
from ram.core.jql_helpers import (
    build_resolved_period_ram_jql,
    strip_created_date_clauses,
)
from shared.shared_logic import IST_TIMEZONE


# ============================================================================
# ACES-IST SPECIFIC STATUS FILTERS
# ============================================================================

def build_active_defect_density_ram_jql(jql):
    return f'({jql}) and status not in (Canceled, Cancelled)'


def build_accepted_ram_jql(jql):
    return f'({jql}) and status in (Accepted)'


def build_resolved_burndown_ram_jql(base_jql, created_from, created_to):
    jql = strip_created_date_clauses(base_jql)
    if created_from or created_to:
        return build_resolved_period_ram_jql(jql, created_from, created_to)
    return f'({jql}) and resolved is not EMPTY'


# ============================================================================
# ACES-IST SCOPE BUILDERS
# ============================================================================

def build_full_year_created_scope_jql(base_jql, created_from='', created_to=''):
    try:
        from_year = datetime.strptime(created_from, '%Y-%m-%d').year if created_from else None
        to_year = datetime.strptime(created_to, '%Y-%m-%d').year if created_to else None
    except ValueError:
        return base_jql

    if from_year is None and to_year is None:
        return base_jql

    start_year = from_year if from_year is not None else to_year
    end_year = to_year if to_year is not None else from_year
    full_year_from = f'{start_year}-01-01'
    full_year_to = f'{end_year}-12-31'
    return f'({base_jql}) and created >= "{full_year_from}" and created <= "{full_year_to}"'


def get_current_year_bounds(reference_datetime=None):
    if reference_datetime is None:
        current_datetime = datetime.now(IST_TIMEZONE)
    elif getattr(reference_datetime, 'tzinfo', None) is None:
        current_datetime = reference_datetime
    else:
        current_datetime = reference_datetime.astimezone(IST_TIMEZONE)
    current_year = current_datetime.year
    return f'{current_year}-01-01', f'{current_year}-12-31'


def build_aces_ist_defect_leakage_scope_jql(base_jql, created_from='', created_to='', release_name=''):
    scope_from = created_from
    scope_to = created_to
    if release_name and not (scope_from and scope_to):
        scope_from, scope_to = get_current_year_bounds()
    jql_parts = [f'({base_jql})']
    if scope_from:
        jql_parts.append(f'created >= "{scope_from}"')
    if scope_to:
        jql_parts.append(f'created <= "{scope_to}"')
    return ' and '.join(jql_parts)


# ============================================================================
# RELEASE LABEL PARSING AND RESOLUTION
# ============================================================================

def extract_release_numeric_value(release_name):
    release_text = str(release_name or '').strip()
    if not release_text:
        return ''
    match = re.search(r'PI\s*([0-9]+(?:\.[0-9]+)*)', release_text, re.IGNORECASE)
    if match:
        return match.group(1)
    fallback_match = re.search(r'([0-9]+(?:\.[0-9]+)*)', release_text)
    return fallback_match.group(1) if fallback_match else ''


def count_unique_defect_density_labels(label_values):
    return len({str(label).strip() for label in (label_values or []) if str(label).strip()})


def parse_release_label_numeric_value(label_value):
    text = str(label_value or '').strip().strip("'").strip('"')
    match = re.search(r'ACES_IST_PI([0-9]+(?:\.[0-9]+)*)', text, re.IGNORECASE)
    if not match:
        match = re.search(r'PI\s*([0-9]+(?:\.[0-9]+)*)', text, re.IGNORECASE)
    if not match:
        match = re.search(r'([0-9]+(?:\.[0-9]+)+)', text)
    return tuple(int(part) for part in match.group(1).split('.')) if match else tuple()


def extract_release_numeric_from_label(label_value):
    text = str(label_value or '').strip().strip("'").strip('"')
    match = re.search(r'ACES_IST_PI([0-9]+(?:\.[0-9]+)*)', text, re.IGNORECASE)
    if not match:
        match = re.search(r'PI\s*([0-9]+(?:\.[0-9]+)*)', text, re.IGNORECASE)
    if not match:
        match = re.search(r'([0-9]+(?:\.[0-9]+)+)', text)
    return match.group(1) if match else ''


def build_release_names_from_configured_labels(label_values):
    release_names = []
    for label_value in (label_values or []):
        release_numeric_value = extract_release_numeric_from_label(label_value)
        if release_numeric_value:
            release_names.append(f'BSSe PI {release_numeric_value}')
    return list(dict.fromkeys(release_names))


def get_selected_year_notations(created_from='', created_to=''):
    year_notations = set()
    date_values = [created_from, created_to]
    for date_value in date_values:
        if not date_value:
            continue
        try:
            year_value = datetime.strptime(date_value, '%Y-%m-%d').year
        except ValueError:
            continue
        year_notations.add(str(year_value))
    return year_notations


def filter_release_labels_by_year_notation(label_values, created_from='', created_to=''):
    normalized_labels = [str(label).strip() for label in (label_values or []) if str(label).strip()]
    if not normalized_labels:
        return []

    selected_year_notations = get_selected_year_notations(created_from, created_to)
    if not selected_year_notations:
        return normalized_labels

    filtered_labels = []
    for label in normalized_labels:
        year_match = re.search(r'(?<!\d)(20\d{2})(?!\d)', label)
        if year_match and year_match.group(1) in selected_year_notations:
            filtered_labels.append(label)
            continue
        release_match = re.search(r'(?:ACES_IST_)?PI\s*([0-9]{2})(?:\.|$)', label, re.IGNORECASE)
        if release_match and f'20{release_match.group(1)}' in selected_year_notations:
            filtered_labels.append(label)
    return filtered_labels


def resolve_release_label_for_selected_release(selected_release='', label_values=None):
    release_numeric_value = extract_release_numeric_value(selected_release)
    if not release_numeric_value:
        return ''

    release_numeric_tuple = tuple(int(part) for part in release_numeric_value.split('.'))
    normalized_labels = [str(label).strip() for label in (label_values or RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS) if str(label).strip()]
    for label in normalized_labels:
        if parse_release_label_numeric_value(label) == release_numeric_tuple:
            return label

    return ''


def get_latest_productivity_improvement_label(label_values=None):
    label_values = list(label_values or RAM_ACES_IST_DEFECT_DENSITY_DATE_RANGE_LABELS)
    if not label_values:
        return ''
    return max(label_values, key=parse_release_label_numeric_value)


def build_productivity_improvement_label(selected_release='', label_values=None):
    release_numeric_value = extract_release_numeric_value(selected_release)
    if release_numeric_value:
        return resolve_release_label_for_selected_release(selected_release, label_values=label_values)
    return get_latest_productivity_improvement_label(label_values=label_values)


def build_productivity_improvement_denominator_labels(selected_release='', label_values=None):
    normalized_labels = [str(label).strip() for label in (label_values or []) if str(label).strip()]
    if not normalized_labels:
        return []
    selected_label = build_productivity_improvement_label(selected_release, label_values=normalized_labels)
    return [label for label in normalized_labels if label != selected_label]


def build_labels_only_ram_jql(label_values):
    normalized_labels = [str(label).strip() for label in (label_values or []) if str(label).strip()]
    if not normalized_labels:
        raise ValueError('At least one label is required.')
    # Sanitize: Jira labels cannot contain spaces
    sanitized = [lbl.replace(' ', '_') if ' ' in lbl else lbl for lbl in normalized_labels]
    label_clause = ', '.join(f'"{label}"' for label in sanitized)
    return f'labels in ({label_clause})'


# ============================================================================
# DEFECT DENSITY AND PRODUCTIVITY FORMULAS
# ============================================================================

def build_defect_density_formula(selected_release='', dynamic_labels=None, label_values=None):
    release_numeric_value = extract_release_numeric_value(selected_release)
    if release_numeric_value:
        release_label = resolve_release_label_for_selected_release(selected_release, label_values=label_values)
        return (
            'No. of defects in Release (cf[18971]/cf[18972]) where STATUS not in (Canceled, Cancelled) '
            f'/ labels in ({release_label})'
        )
    if dynamic_labels:
        label_clause = ', '.join(dynamic_labels)
        return (
            'No. of defects where STATUS not in (Canceled, Cancelled) '
            f'/ labels in ({label_clause})'
        )
    return (
        'No. of defects where STATUS not in (Canceled, Cancelled) / unique labels from configured date-range labels'
    )


def build_defect_density_denominator_ram_jql(selected_release='', dynamic_labels=None, label_values=None):
    release_numeric_value = extract_release_numeric_value(selected_release)
    if release_numeric_value:
        release_label = resolve_release_label_for_selected_release(selected_release, label_values=label_values)
        if release_label:
            return f'labels in ("{release_label}")'
        return f'labels in ("{selected_release}")'
    label_values = dynamic_labels or []
    if not label_values:
        raise ValueError('At least one date-range label is required for Defect Density.')
    # Sanitize: Jira labels cannot contain spaces
    sanitized = [lbl.replace(' ', '_') if ' ' in lbl else lbl for lbl in label_values]
    label_clause = ', '.join(f'"{label}"' for label in sanitized)
    return f'labels in ({label_clause})'


def build_productivity_improvement_formula(label_value, denominator_labels=None):
    label_values = [str(label).strip() for label in (denominator_labels or []) if str(label).strip()]
    if label_values:
        label_clause = ', '.join(label_values)
        return f'((Count of labels in ({label_value}) - (Count of results in labels in ({label_clause}) / (Count of unique labels - 1))) / (Count of results in labels in ({label_clause}) / (Count of unique labels - 1))) * 100'
    return f'((Count of labels in ({label_value}) - Count of overall labels used for Defect Density) / Count of overall labels used for Defect Density) * 100'


def calculate_absolute_percentage_change(current_numerator, current_denominator):
    if not current_denominator:
        return 0
    return round(abs(((current_numerator - current_denominator) / current_denominator) * 100))


def calculate_percentage_change(current_numerator, current_denominator):
    if not current_denominator:
        return 0
    return round(((current_numerator - current_denominator) / current_denominator) * 100)
