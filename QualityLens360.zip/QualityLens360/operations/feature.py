
import logging
import os
import json
import re
import tempfile
import threading
import time
import uuid
from pathlib import Path
from datetime import datetime, timedelta, timezone
from html import escape, unescape
from io import BytesIO
from urllib.parse import quote

from flask import copy_current_request_context, jsonify, redirect, render_template, render_template_string, request, send_file, session, url_for
import requests

from shared.http_session import get_http_session

LOGGER = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Filesystem-backed job tracker (works across multiple WSGI worker processes)
# ---------------------------------------------------------------------------
_JOBS_DIR = Path(__file__).resolve().parents[1] / 'flask_jobs'
_JOBS_DIR.mkdir(exist_ok=True)
_artifacts_lock = threading.Lock()
_artifacts = {}  # artifact_owner_key -> {'export_bytes': ..., 'export_filename': ..., 'email_html': ...}

JOB_TIMEOUT_SECONDS = 600  # 10 minutes
JOB_TIMEOUT_MESSAGE = 'Operation timed out after 10 minutes. The server may still be processing - check the logs.'
GRAPH_CHAT_DELEGATED_SCOPES = tuple(
    scope.strip()
    for scope in os.environ.get(
        'GRAPH_CHAT_DELEGATED_SCOPES',
        'openid profile offline_access User.Read User.ReadBasic.All Chat.Create Chat.ReadWrite ChatMessage.Send',
    ).split()
    if scope.strip()
)


def _job_path(job_id: str) -> Path:
    return _JOBS_DIR / f'{job_id}.json'


def _write_job(job_id: str, data: dict) -> None:
    path = _job_path(job_id)
    fd, tmp = tempfile.mkstemp(dir=str(_JOBS_DIR))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(data, f)
        os.replace(tmp, str(path))
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _create_job():
    job_id = uuid.uuid4().hex
    _write_job(job_id, {'status': 'running', 'message': '', 'started': time.time()})
    return job_id


def _complete_job(job_id, status, message):
    path = _job_path(job_id)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (FileNotFoundError, json.JSONDecodeError):
        return
    data['status'] = status
    data['message'] = message
    _write_job(job_id, data)


def _get_job(job_id):
    path = _job_path(job_id)
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
    except (FileNotFoundError, json.JSONDecodeError):
        return None
    if data['status'] == 'running' and (time.time() - data.get('started', 0)) > JOB_TIMEOUT_SECONDS:
        data['status'] = 'error'
        data['message'] = JOB_TIMEOUT_MESSAGE
        _write_job(job_id, data)
    return {'status': data['status'], 'message': data['message']}


def _get_artifact_owner_key():
    credentials_key = session.get('credentials_key')
    if credentials_key:
        return credentials_key
    return request.remote_addr or 'anonymous'


def _set_last_generated_artifact(payload):
    with _artifacts_lock:
        _artifacts[_get_artifact_owner_key()] = payload


def _clear_last_generated_artifact():
    with _artifacts_lock:
        _artifacts.pop(_get_artifact_owner_key(), None)


def _get_last_generated_artifact():
    with _artifacts_lock:
        artifact = _artifacts.get(_get_artifact_owner_key())
        if artifact is None:
            return None
        return dict(artifact)


def _build_last_generated_state(artifact):
    artifact = artifact or {}
    return {
        'export_ready': bool(artifact.get('export_bytes')),
        'preview_ready': bool(artifact.get('email_html')),
        'send_ready': bool(artifact.get('email_html') and GRAPH_TENANT_ID and GRAPH_CLIENT_ID and GRAPH_CLIENT_SECRET),
        'export_filename': artifact.get('export_filename', ''),
        'email_subject': artifact.get('email_subject', ''),
        'operation_title': artifact.get('operation_title', ''),
        'jql': artifact.get('jql', ''),
    }

from operations.config import (
    APPLICATION_FIXED_IN_CQE_ACCEPTED_CANCELLED_JQL,
    APPLICATION_FIXED_IN_CQE_STATUS_NOT_ACCEPTED_CANCELLED_JQL,
    ACC_PROD_ASSIGNED_TO_TRIAGE_UPDATE_ASSIGNEE_JQL,
    ACC_PROD_ASSIGNED_TO_TEAM_BUSINESS_APPLICATION_FIXED_IN_JQL,
    ACC_PROD_BUG_ISSUE_CONVERSION_JQL,
    ACC_PROD_NON_MONITORING_PILOT_SEV4_LABEL_ADDITION_JQL,
    ACC_PROD_CUSTOMER_IMPACT_LESS_UPDATE_SEVERITY_JQL,
    ACC_PROD_UPDATE_EST_RETEST_DATE_JQL,
    ACC_PROD_ASSIGNED_TO_TEAM_PRODUCTION_SUPPORT_APPLICATION_FIXED_IN_JQL,
    ACC_PROD_APPLICATION_FIXED_IN_ROOT_CAUSE_APP_SYNC_JQL,
    ACC_PROD_RETURN_REJECTED_ASSIGNED_TO_TEAM_TRIAGE_JQL,
    ACC_PROD_RETEST_TEST_BLOCKED_ASSIGNED_TO_TEAM_TESTING_JQL,
    ASSIGNED_TO_TEAM_TESTING_VS_ASSIGNEE_JQL,
    CHATROOM_CREATION_BASE_JQL,
    ETA_SLIPPED_DEFECTS_JQL,
    NOT_AN_APPLICATION_REQUESTING_REVIEW_JQL,
    PROGRESSION_OPEN_DEFECTS_JQL,
    PROGRESSION_RESOLVED_TODAY_JQL,
    REGRESSION_OPEN_DEFECTS_JQL,
    REGRESSION_RESOLVED_TODAY_JQL,
    RELEASE_OPEN_DEFECTS_JQL,
    ROOT_CAUSE_APP_MATCHES_APPLICATION_FIXED_IN_JQL,
    RETURN_REJECTED_RETEST_TEST_BLOCKED_ASSIGNED_TO_TEAM_TESTING_JQL,
    RETURN_REJECT_DEFECTS_JQL,
    RETEST_DEFECTS_JQL,
    TRIBE_LABEL_SELF_HEAL_JQL,
)
from shared.shared_config import JIRA_USER
from shared.shared_config import GRAPH_CLIENT_ID, GRAPH_CLIENT_SECRET, GRAPH_TENANT_ID
from operations.logic import (
    build_acc_prod_pilot_defects_wls_email_preview,
    build_acc_prod_missing_order_impact_email_preview,
    build_acc_prod_out_of_sla_non_sales_email_preview,
    build_acc_prod_new_defects_created_email_preview,
    build_acc_prod_out_of_sla_sales_email_preview,
    build_blocking_field_empty_defects_email_preview,
    build_eta_slipped_defects_email_preview,
    build_not_an_application_requesting_review_email_preview,
    build_past_dated_fix_version_defects_email_preview,
    build_progression_open_defects_email_preview,
    build_regression_open_defects_email_preview,
    build_release_open_defects_email_preview,
    build_return_reject_defects_email_preview,
    build_retest_defects_email_preview,
    export_acc_prod_pilot_defects_wls,
    export_acc_prod_missing_order_impact,
    export_acc_prod_new_defects_created,
    export_acc_prod_out_of_sla_non_sales,
    export_acc_prod_out_of_sla_sales,
    export_acc_prod_return_reject_defects,
    export_acc_prod_retest_defects,
    export_blocking_field_empty_defects,
    export_eta_slipped_defects,
    export_not_an_application_requesting_review_defects,
    export_past_dated_fix_version_defects,
    export_progression_open_defects,
    export_regression_open_defects,
    export_release_open_defects,
    export_return_reject_defects,
    export_retest_defects,
    self_heal_acc_prod_assigned_to_triage_update_assignee_fields,
    self_heal_application_fixed_in_cqe_fields,
    self_heal_application_fixed_in_cqe_revert_to_previous_fields,
    self_heal_application_fixed_in_for_business_team_fields,
    self_heal_application_fixed_in_matches_root_cause_app_fields,
    self_heal_assigned_to_team_testing_status_fields,
    self_heal_assigned_to_team_testing_vs_assignee_fields,
    self_heal_bug_issue_conversion_fields,
    self_heal_customer_impact_less_update_severity_fields,
    self_heal_progression_regression_fields,
    self_heal_root_cause_app_matches_application_fixed_in_fields,
    self_heal_update_est_retest_date_fields,
    self_heal_tribe_label_fields,
)
from shared.shared_logic import (
    TRIBE_LABEL_MAPPING_SOURCE,
    build_project_cached_workbook_path,
    fetch_issue_editmeta,
    fetch_open_defects,
    parse_jira_datetime,
)
from shared.release_open_defects import add_issue_comment
from shared.release_open_defects import ACC_PROD_RETURN_REJECT_CC_RECIPIENTS
from shared.release_open_defects import DEFAULT_CC_RECIPIENTS
from shared.release_open_defects import get_cached_pilot_wls_mapping_path
from shared.release_open_defects import parse_recipient_entries
from shared.release_open_defects import resolve_issue_severity
from shared.release_open_defects import send_email_via_graph
from shared.release_open_defects import update_issue_labels
from ram.app_config import RAM_CORE_APPLICATION_OPTIONS, get_ram_application_definition


OPERATIONS_APPLICATION_OPTIONS = list(RAM_CORE_APPLICATION_OPTIONS)
OPERATIONS_WIRED_APPLICATION = 'ACES-IST'


def get_operations_application_options():
    """Return application list including custom apps added via the chatbot."""
    from operations.ops_chat import load_all_app_configs
    options = list(OPERATIONS_APPLICATION_OPTIONS)
    for cfg in load_all_app_configs():
        if cfg.get('disabled'):
            continue
        name = cfg.get('name', '')
        if name and name not in options:
            options.append(name)
    return options
OPERATIONS_CHATROOM_APPLICATION = OPERATIONS_WIRED_APPLICATION
OPERATIONS_RELEASE_FIELD_KEY = 'customfield_18971'
OPERATIONS_RELEASE_FIELD_NAME = 'Detected in Release'
OPERATIONS_RELEASE_SEED_FALLBACK = 'BSSe PI 27.5'
OPERATIONS_FIX_VERSION_FIELD_KEY = 'fixVersions'
OPERATIONS_FIX_VERSION_FIELD_NAME = 'Fix Version'
OPERATIONS_RELEASE_CLAUSE_PATTERN = re.compile(
    r'\(cf\[18971\]\s+in\s+\(".*?"\)\s+or\s+cf\[18972\]\s+in\s+\(".*?"\)\)',
    re.IGNORECASE,
)
ACC_PROD_PAST_DATED_FIX_VERSION_TITLE = 'Past Dated Fix Version'
ACC_PROD_PAST_DATED_FIX_VERSION_DESCRIPTION = 'Select current active release fix version to Pull Prod defects in not in "Retest/Test Complete/Dev Complete" status with past dated fix Versions'
OPERATIONS_CHATROOMS = [
    {
        'id': 'chatroom-creation',
        'title': 'Chatroom Creation',
        'description': 'For newly matched ACES-IST CDEX defects in the selected release, create a Teams chat with reporter, assignee, configured DM SPOCs, and configured tribe leads through Microsoft Graph API.',
        'action': 'run_chatroom_creation',
    },
    {
        'id': 'chatroom-follow-ups',
        'title': 'Chatroom follow-ups',
        'description': 'Based on severity, trigger a follow-up when a CR is inactive for the configured number of hours and ask for the latest status.',
        'action': None,
    },
    {
        'id': 'chatroom-history-to-itrack',
        'title': 'Chatroom History to iTrack',
        'description': 'Summarize daily updates from the CR into iTrack across both IDC and US hours.',
        'action': 'run_chatroom_history_to_itrack',
    },
]
CHATROOM_CREATION_REGISTRY_PATH = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'chatroom_creation_registry.json')
CHATROOM_CREATION_REGISTRY_LOCK = threading.Lock()
CHATROOM_CREATION_DEFAULT_DM_SPOCS = (
    'Ramalingam, Jayalakshmi <jayalakshmi.ramalingam@intl.att.com>; '
    'Amara, Narasimharao <narasimharao.amara@intl.att.com>; '
    'B, Parthiban <parthiban.b@intl.att.com>; '
    
)
CHATROOM_CREATION_EMAIL_ALIASES = {
    'ju1777@att.com': 'jayalakshmi.ramalingam@intl.att.com',
    'bs4405@att.com': 'balachandar.s@intl.att.com',
    'vp9678@att.com': 'vipin.p.k@intl.att.com',
    'nageswara.rao-singu@amdocs.com': 'nageswara.raosingu@amdocs.com',
    'na5741@att.com': 'narasimharao.amara@intl.att.com',
    'pb5741@att.com': 'parthiban.b@intl.att.com'
    
}
CHATROOM_CREATION_DM_SPOCS = os.environ.get('OPERATIONS_CHATROOM_DM_SPOCS', CHATROOM_CREATION_DEFAULT_DM_SPOCS)
CHATROOM_CREATION_TRIBE_LEADS = os.environ.get('OPERATIONS_CHATROOM_TRIBE_LEADS', '')
CHATROOM_CREATION_TRIBE_LEAD_BY_LABEL_JSON = os.environ.get('OPERATIONS_CHATROOM_TRIBE_LEAD_BY_LABEL_JSON', '{}')
CHATROOM_CREATION_MAX_RESULTS = 1000
CHATROOM_CREATION_INITIAL_LOOKBACK_HOURS = 24

OPERATIONS_ENABLED_GROUPS_BY_APPLICATION = {
    'ACC-Prod': {'Trigger Email'},
    'ACES-IST': {'Trigger Email', 'Self Heal iTrack Fields'},
}
OPERATIONS_ENABLED_OPERATION_IDS_BY_APPLICATION = {
    'ACC-Prod': {
        'retest-test-blocked-assigned-to-team-testing-self-heal',
        'return-rejected-assigned-to-team-triage-self-heal',
        'application-fixed-in-root-cause-app-sync-self-heal',
        'assigned-to-team-business-application-fixed-in-self-heal',
        'assigned-to-team-production-support-application-fixed-in-self-heal',
        'assigned-to-team-triage-update-assignee-self-heal',
        'bug-issue-conversion-self-heal',
        'customer-impact-less-update-severity-self-heal',
        'non-monitoring-pilot-sev4-defects-label-addition-self-heal',
        'update-est-retest-date-self-heal',
    },
}
OPERATIONS_VISIBLE_GROUPS_BY_APPLICATION = {
    'ACC-Prod': {'Trigger Email', 'Self Heal iTrack Fields'},
    'ACES-IST': {'Trigger Email', 'Self Heal iTrack Fields'},
}
OPERATIONS_GROUP_DISPLAY_ORDER = {
    'Trigger Email': 0,
    'Self Heal iTrack Fields': 1,
}
ACC_PROD_HIDDEN_OPERATION_IDS = {
    'release-open-defects',
    'release-open-defects-progression-dm-comments',
    'release-open-defects-regression-dm-comments',
    'eta-slipped-defects',
    'not-an-application-requesting-review',
}
ACC_PROD_ONLY_OPERATION_IDS = {
    'pilot-defects-wls',
    'missing-order-impact',
    'new-defects-created',
    'out-of-sla-non-sales',
    'out-of-sla-sales',
    'deferred-defects',
    'retest-test-blocked-assigned-to-team-testing-self-heal',
    'return-rejected-assigned-to-team-triage-self-heal',
    'application-fixed-in-root-cause-app-sync-self-heal',
    'assigned-to-team-business-application-fixed-in-self-heal',
    'assigned-to-team-production-support-application-fixed-in-self-heal',
    'assigned-to-team-triage-update-assignee-self-heal',
    'bug-issue-conversion-self-heal',
    'customer-impact-less-update-severity-self-heal',
    'non-monitoring-pilot-sev4-defects-label-addition-self-heal',
    'update-est-retest-date-self-heal',
}

OPERATIONS = {
    'release-open-defects': {
        'group': 'Trigger Email',
        'title': 'Release Open Defects (Overall)',
        'description': 'Pull current release open defects',
        'action': 'download_release_open_defects',
    },
    'release-open-defects-progression-dm-comments': {
        'group': 'Trigger Email',
        'title': 'Release Open Defects (Progression)',
        'description': 'Pull current release open defects filtered to Progression, include Lastest Defect Status and DM Comments to reflect the progress made over the day along with defect summary view.',
        'action': 'download_progression_open_defects',
    },
    'release-open-defects-regression-dm-comments': {
        'group': 'Trigger Email',
        'title': 'Release Open Defects (Regression)',
        'description': 'Pull current release open defects filtered to Regression, include Lastest Defect Status and DM Comments to reflect the progress made over the day along with defect summary view.',
        'action': 'download_regression_open_defects',
    },
    'eta-slipped-defects': {
        'group': 'Trigger Email',
        'title': 'ETA Slipped Defects',
        'description': 'Identify current release defects where EST Fix Date slipped the committed date, include columns to indicate No. of the times the dates are changed along with history',
        'action': 'download_eta_slipped_defects',
    },
    'blocking-field-empty': {
        'group': 'Trigger Email',
        'title': 'Blocking Field Empty',
        'description': 'Pull current release open defects with a blank Blocking field',
        'action': 'download_blocking_field_empty_defects',
    },
    'retest-defects': {
        'group': 'Trigger Email',
        'title': 'Retest/Test Complete/Dev Complete Defects',
        'description': 'Pull defects in Retest/Test Complete/Dev Complete Defects (with Past Fix version)',
        'action': 'download_retest_defects',
    },
    'return-reject-defects': {
        'group': 'Trigger Email',
        'title': 'Return/Rejected Defects',
        'description': 'Pull defects in returned/rejected status',
        'action': 'download_return_reject_defects',
    },
    'new-defects-created': {
        'group': 'Trigger Email',
        'title': 'New Defects Created',
        'description': 'Pull Prod defects created since the start of the previous day',
        'action': 'download_new_defects_created',
    },
    'missing-order-impact': {
        'group': 'Trigger Email',
        'title': 'Missing Order Impact value (For Shop/Purchase ARTs)',
        'description': 'Pull ACC Prod Shop and Purchase defects where Order Impact is blank',
        'action': 'download_missing_order_impact',
    },
    'pilot-defects-wls': {
        'group': 'Trigger Email',
        'title': 'Pilot Defects (WLS)',
        'description': 'Pull Wireless Pilot defects and enrich them with Director and AVP from the uploaded mapping sheet',
        'action': 'download_pilot_defects_wls',
    },
    'out-of-sla-sales': {
        'group': 'Trigger Email',
        'title': 'Out of SLA (Sales)',
        'description': 'Pull ACC Prod Sales defects that are out of SLA',
        'action': 'download_out_of_sla_sales',
    },
    'out-of-sla-non-sales': {
        'group': 'Trigger Email',
        'title': 'Out of SLA (Non-Sales)',
        'description': 'Pull ACC Prod Non-Sales defects that are out of SLA',
        'action': 'download_out_of_sla_non_sales',
    },
    'not-an-application-requesting-review': {
        'group': 'Trigger Email',
        'title': 'Assigned to Team:Not an Application - Requesting Review',
        'description': 'Pull defects with Application Fixed In as Not an Application that require Root Cause Category/Reason review.',
        'action': 'download_not_an_application_requesting_review',
    },
    'deferred-defects': {
        'group': 'Trigger Email',
        'title': 'Deferred Defects',
        'description': 'Pull ACC Prod defects currently in Deferred status',
        'action': 'download_deferred_defects',
    },
    'tribe-label': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Tribe-Label',
        'description': 'Update the missing "Tribe labels" based on Reporter Vs Tribe mapping for the month',
        'action': 'run_tribe_label_self_heal',
    },
    'progression-regression-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Progression/Regression',
        'description': 'Review the defects with blank value and update the "Progression/Regression" field using User5 and summary-based rules.',
        'action': 'run_progression_regression_self_heal',
    },
    'return-rejected-retest-test-blocked-assigned-to-team-testing-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Status: Return/Rejected or Retest or Test Blocked > Assigned to Team: Update to Testing',
        'description': 'For Return/Rejected, Retest, or Testing Blocked defects, ensure "Assigned to Team" is set to Testing.',
        'action': 'run_assigned_to_team_testing_status_self_heal',
    },
    'retest-test-blocked-assigned-to-team-testing-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Status: Retest or Test Blocked > Assigned to Team: Update to Testing',
        'description': 'For Retest or Testing Blocked defects, ensure "Assigned to Team" is set to Testing.',
        'action': 'run_acc_prod_assigned_to_team_testing_status_self_heal',
    },
    'return-rejected-assigned-to-team-triage-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Status: Return/Rejected > Assigned to Team: Update to Triage',
        'description': 'For Return/Rejected defects, ensure "Assigned to Team" is set to Triage.',
        'action': 'run_acc_prod_assigned_to_team_triage_status_self_heal',
    },
    'application-fixed-in-root-cause-app-sync-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Status: Application Fixed in : Root Cause App in Sync',
        'description': 'For defects in statuses (Resolved/Created in the current year): Accepted/Cancelled/Retest/Dev Complete/Test Blocked/Deferred/Test Failed/Test Complete, ensure Root Cause App is in sync with Application Fixed In.',
        'action': 'run_acc_prod_application_fixed_in_root_cause_app_sync_self_heal',
    },
    'assigned-to-team-business-application-fixed-in-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Assigned to Team: Business > Update Application Fixed In',
        'description': 'If Assigned to Team is Business, update Application Fixed In to Not an Application while the defect is in To Do or In Progress.',
        'action': 'run_acc_prod_assigned_to_team_business_application_fixed_in_self_heal',
    },
    'assigned-to-team-production-support-application-fixed-in-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Assigned to Team: Production Support > Update Application Fixed In',
        'description': 'If Assigned to Team is Production Support, update Application Fixed In to Not an Application while the defect is in To Do or In Progress.',
        'action': 'run_acc_prod_assigned_to_team_production_support_application_fixed_in_self_heal',
    },
    'assigned-to-team-triage-update-assignee-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Assigned to Team: Triage > Update Assignee',
        'description': 'Assigned to Team: Triage --> Populate Assignee based on Alternate Project Identifier.',
        'action': 'run_acc_prod_assigned_to_team_triage_update_assignee_self_heal',
    },
    'bug-issue-conversion-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Bug/Issue Conversion',
        'description': 'When Customer Volume Impact and Customer Facing Defect are none and Severity is Sev4, convert the defect type to Bug/Issue for non-CI, non-pilot, non-sales-impacting defects.',
        'action': 'run_acc_prod_bug_issue_conversion_self_heal',
    },
    'customer-impact-less-update-severity-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Customer Impact Less : Update Severity',
        'description': 'When customer impacted <5, update Severity to Sev4 for non-CI, non-pilot, non-sales-impacting defects.',
        'action': 'run_acc_prod_customer_impact_less_update_severity_self_heal',
    },
    'non-monitoring-pilot-sev4-defects-label-addition-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Non Monitoring/Pilot Sev4 Defects: Label Addition',
        'description': 'Sev-4 defects which are non monitoring and non pilot, add label CQE_PROD_AgentNM.',
        'action': 'run_acc_prod_non_monitoring_pilot_sev4_label_addition_self_heal',
    },
    'update-est-retest-date-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Update EST Retest Date',
        'description': 'Populate EST Retest Date as per Fix Version (window - 2 days).',
        'action': 'run_acc_prod_update_est_retest_date_self_heal',
    },
    'assigned-to-team-testing-vs-assignee-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Assigned To Team: Testing > Assignee: Update to Reporter',
        'description': 'For the defects assigned to the Testing team, update the "Assignee" field to match the Reporter.',
        'action': 'run_assigned_to_team_testing_vs_assignee_self_heal',
    },
    'application-fixed-in-cqe-accepted-cancelled-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Application Fixed in: CQE & Status = Accepted/Cancelled > Update Application Fixed In',
        'description': 'For defects in Accepted or Cancelled status, sync "Application Fixed In" from "Root Cause App" when it has a valid app value; otherwise set both fields to Not An Application.',
        'action': 'run_application_fixed_in_cqe_self_heal',
    },
    'application-fixed-in-cqe-revert-to-previous-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Application Fixed in: CQE & Status != Accepted/Cancelled > Revert Assigned to Team to previous value',
        'description': 'For defects outside Accepted or Cancelled, sync "Application Fixed In" from "Root Cause App" when valid; otherwise revert to the latest prior non-CQE app value and sync both fields.',
        'action': 'run_application_fixed_in_cqe_revert_to_previous_self_heal',
    },
    'root-cause-app-matches-application-fixed-in-self-heal': {
        'group': 'Self Heal iTrack Fields',
        'title': 'Status: Accepted/Cancelled/Retest/Dev Complete/Test Blocked/Deferred/Test Failed/Test Complete > Application Fixed in = Root Cause App',
        'description': 'For defects in the listed statuses, ensure "Root Cause App" matches the current "Application Fixed In" value.',
        'action': 'run_root_cause_app_matches_application_fixed_in_self_heal',
    },
}


class OperationsFeature:
    def download_deferred_defects(self):
        from operations.config import ACC_PROD_DEFERRED_DEFECTS_JQL
        from shared.release_open_defects import (
            ACC_PROD_EMAIL_HEADER_TITLES,
            build_defects_email_preview,
            extract_issue_recipients,
            parse_jira_datetime,
            resolve_issue_assignee_display,
            resolve_issue_severity,
            stringify_field_value,
        )
        credentials = self._credentials()
        from shared.release_open_defects import fetch_open_defects
        jql = ACC_PROD_DEFERRED_DEFECTS_JQL
        issues = fetch_open_defects(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
        )
        header_titles = [title for title in ACC_PROD_EMAIL_HEADER_TITLES if title != 'EST Fix Date']
        now = datetime.now(timezone.utc)
        issue_rows = []
        for issue in issues:
            fields = issue.get('fields', {})
            created_value = stringify_field_value(fields.get('created'))
            age = ''
            created_datetime = parse_jira_datetime(fields.get('created'))
            if created_datetime is not None:
                age = f"{max(0, (now - created_datetime.astimezone(timezone.utc)).days)}d"
            elif len(created_value) >= 10:
                try:
                    created = datetime.strptime(created_value[:10], '%Y-%m-%d')
                    age = f"{(now.replace(tzinfo=None) - created).days}d"
                except ValueError:
                    age = ''
            row = [
                issue.get('key', ''),
                stringify_field_value((fields.get('status') or {}).get('name')),
                resolve_issue_severity(fields),
                stringify_field_value(fields.get('summary')),
                created_value[:10] if created_value else '',
                age,
                resolve_issue_assignee_display(fields),
                stringify_field_value(fields.get('customfield_17001')),  # Application Fixed In
            ]
            issue_rows.append(row)
        filename = 'ACCProd_DeferredDefects.xlsx'
        email_preview = build_defects_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
            subject='ACTION Required: ACC Prod - Deferred Defects',
            summary_text='Below are the ACC Prod defects currently in Deferred status. Please review and take necessary action.',
            empty_state_message='No ACC Prod defects in Deferred status were found.',
            include_summary_section=False,
            header_titles=header_titles,
            to_recipients=extract_issue_recipients(issues),
            cc_recipients=parse_recipient_entries(ACC_PROD_RETURN_REJECT_CC_RECIPIENTS),
            closing_signature_html='Regards,<br/>ACC Prod DM Team',
            from_address='dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com',
        )
        self.cache_last_generated_artifact('Deferred Defects', None, filename, email_preview, jql=jql)
        return self._preview_ready_message('Deferred Defects exported successfully.')
    def __init__(
        self,
        get_session_credentials,
        clear_session_credentials,
        set_home_feedback,
        get_home_feedback,
        format_http_error_message,
    ):
        self.get_session_credentials = get_session_credentials
        self.clear_session_credentials = clear_session_credentials
        self.set_home_feedback = set_home_feedback
        self.get_home_feedback = get_home_feedback
        self.format_http_error_message = format_http_error_message

    @staticmethod
    def reset_operations_history():
        _clear_last_generated_artifact()
        session.pop('home_feedback', None)

    def register(self, app, login_required):
        @app.route('/operations')
        @login_required
        def operations_page():
            if request.args.get('reset_history') == '1':
                self.reset_operations_history()
            credentials = self.get_session_credentials() or {}
            selected_application = self.get_selected_application()
            selected_release = self.get_selected_release()
            selected_application_configured = self.is_configured_application(selected_application)
            selected_application_supports_release_filter = self.application_supports_release_filter(selected_application)
            selected_application_supports_fix_version_filter = self.application_supports_fix_version_filter(selected_application)
            last_generated_artifact_state = _build_last_generated_state(_get_last_generated_artifact())
            # Debug log for JQL
            print(f"[DEBUG] Rendering /operations: last_generated_artifact_state.jql = {last_generated_artifact_state.get('jql')}")
            release_options = []
            fix_version_options = []
            release_error = None
            fix_version_error = None
            selected_fix_version = self.get_selected_fix_version()
            if selected_application_supports_release_filter:
                try:
                    release_options = self.fetch_release_options(
                        application=selected_application,
                        username=credentials.get('username'),
                        password=credentials.get('password'),
                        release_name=selected_release,
                    )
                except requests.RequestException as error:
                    release_error = f'Unable to load {OPERATIONS_RELEASE_FIELD_NAME} values from Jira/iTrack: {error}'
                except ValueError as error:
                    release_error = str(error)
            if selected_application_supports_fix_version_filter:
                try:
                    fix_version_options = self.fetch_fix_version_options(
                        application=selected_application,
                        username=credentials.get('username'),
                        password=credentials.get('password'),
                        fix_version_name=selected_fix_version,
                    )
                except requests.RequestException as error:
                    fix_version_error = f'Unable to load {OPERATIONS_FIX_VERSION_FIELD_NAME} values from Jira/iTrack: {error}'
                except ValueError as error:
                    fix_version_error = str(error)

            tile_groups = self.build_tile_groups(selected_application) if self.application_ready_for_operations(selected_application, selected_release) else []
            chatrooms = self.build_chatrooms(selected_application)
            status, message = self.get_home_feedback()
            return render_template(
                'operations_hub.html',
                page_title='Quality Lens 360 | Operations',
                tile_groups=tile_groups,
                total_operations=sum(len(group['items']) for group in tile_groups),
                application_options=get_operations_application_options(),
                selected_application=selected_application,
                release_options=release_options,
                fix_version_options=fix_version_options,
                selected_release=selected_release,
                selected_fix_version=selected_fix_version,
                release_field_name=OPERATIONS_RELEASE_FIELD_NAME,
                fix_version_field_name=OPERATIONS_FIX_VERSION_FIELD_NAME,
                release_error=release_error,
                fix_version_error=fix_version_error,
                selected_application_configured=selected_application_configured,
                selected_application_supports_release_filter=selected_application_supports_release_filter,
                selected_application_supports_fix_version_filter=selected_application_supports_fix_version_filter,
                wired_application=OPERATIONS_WIRED_APPLICATION,
                chatroom_application=OPERATIONS_CHATROOM_APPLICATION,
                chatrooms=chatrooms,
                jira_user=credentials.get('username', JIRA_USER),
                status=status,
                message=message,
                last_generated_artifact_state=last_generated_artifact_state,
            )

        @app.post('/operations/<operation_id>')
        @login_required
        def trigger_operation(operation_id):
            self.reset_operations_history()
            selected_application = self.get_selected_application()
            selected_release = self.get_selected_release()
            selected_fix_version = self.get_selected_fix_version()

            # Check if this is a custom email config created via the chatbot
            from operations.ops_chat import load_email_config as _load_custom_email_cfg
            custom_email_cfg = _load_custom_email_cfg(operation_id)

            if operation_id not in OPERATIONS and not custom_email_cfg:
                return jsonify(status='error', message='Unknown operation requested.'), 400

            if not self.is_configured_application(selected_application):
                return jsonify(
                    status='error',
                    message='Operations workflows are not configured for the selected application.',
                ), 400

            # Custom email config — run directly
            if custom_email_cfg:
                if self.application_supports_release_filter(selected_application) and not selected_release:
                    return jsonify(
                        status='error',
                        message=f'Select {OPERATIONS_RELEASE_FIELD_NAME} before running Operations workflows.',
                    ), 400

                from home.logic import record_operation_run
                record_operation_run()

                op_title = custom_email_cfg.get('name', operation_id)
                job_id = _create_job()

                @copy_current_request_context
                def _background_custom_run():
                    try:
                        succeeded, result = self.run_custom_email_operation(custom_email_cfg)
                        if succeeded:
                            _complete_job(job_id, 'success', result)
                        else:
                            _complete_job(job_id, 'error', result)
                    except Exception as exc:
                        LOGGER.exception("Custom email operation %s failed.", operation_id)
                        _complete_job(job_id, 'error', f'{op_title} failed: {exc}')

                thread = threading.Thread(target=_background_custom_run, daemon=True)
                thread.start()

                return jsonify(
                    status='running',
                    message=f'{op_title} has been triggered and is running in the background.',
                    job_id=job_id,
                )

            if not self.is_operation_enabled_for_application(operation_id, selected_application):
                return jsonify(
                    status='error',
                    message=f'{OPERATIONS[operation_id]["title"]} is not enabled for {selected_application}.',
                ), 400

            if self.application_supports_release_filter(selected_application) and not selected_release:
                return jsonify(
                    status='error',
                    message=f'Select {OPERATIONS_RELEASE_FIELD_NAME} before running Operations workflows.',
                ), 400
            if selected_application == 'ACC-Prod' and operation_id in {'retest-defects', 'blocking-field-empty'} and not selected_fix_version:
                return jsonify(
                    status='error',
                    message=f'Select {OPERATIONS_FIX_VERSION_FIELD_NAME} before running {self.get_operation_definition(selected_application, operation_id)["title"]} for ACC-Prod.',
                ), 400

            try:
                if operation_id == 'tribe-label':
                    uploaded_tribe_mapping_path = self.cache_uploaded_tribe_mapping_workbook(request.files.get('tribe_mapping_file'))
                    if uploaded_tribe_mapping_path:
                        self.set_home_feedback('success', f'Team-structure workbook uploaded to {uploaded_tribe_mapping_path}.')
                if operation_id == 'pilot-defects-wls':
                    uploaded_pilot_mapping_path = self.cache_uploaded_pilot_wls_mapping_workbook(request.files.get('pilot_wls_mapping_file'))
                    if uploaded_pilot_mapping_path:
                        self.set_home_feedback('success', f'Pilot WLS mapping workbook uploaded to {uploaded_pilot_mapping_path}.')
                    elif not os.path.exists(self.get_cached_pilot_wls_mapping_path()):
                        raise ValueError('Upload the Pilot Defects WLS mapping workbook before running this workflow.')
            except ValueError as error:
                return jsonify(status='error', message=str(error)), 400

            if OPERATIONS[operation_id]['action'] is not None:
                from home.logic import record_operation_run
                record_operation_run()

            operation = self.get_operation_definition(selected_application, operation_id)
            job_id = _create_job()

            @copy_current_request_context
            def _background_run():
                try:
                    succeeded, result = self.run_operation(operation_id)
                    if succeeded:
                        _complete_job(job_id, 'success', result)
                    else:
                        _complete_job(job_id, 'error', result)
                except Exception as exc:
                    LOGGER.exception("Background operation %s failed.", operation_id)
                    _complete_job(job_id, 'error', f'{operation["title"]} failed: {exc}')

            thread = threading.Thread(target=_background_run, daemon=True)
            thread.start()

            return jsonify(
                status='running',
                message=f'{operation["title"]} has been triggered and is running in the background.',
                job_id=job_id,
            )

        @app.route('/operations/job-status/<job_id>')
        @login_required
        def operations_job_status(job_id):
            job = _get_job(job_id)
            if job is None:
                return jsonify(status='error', message='Job not found.'), 404
            return jsonify(**job)

        @app.post('/operations/chatrooms/<chatroom_id>')
        @login_required
        def trigger_chatroom(chatroom_id):
            self.reset_operations_history()
            selected_application = self.get_selected_application()
            selected_release = self.get_selected_release()
            chatroom = self.get_chatroom_definition(chatroom_id)
            if chatroom is None:
                return jsonify(status='error', message='Unknown chatroom workflow requested.'), 400

            if selected_application != OPERATIONS_CHATROOM_APPLICATION:
                return jsonify(status='error', message='Chatroom workflows are currently wired only for ACES-IST.'), 400

            if self.application_supports_release_filter(selected_application) and not selected_release:
                return jsonify(status='error', message=f'Select {OPERATIONS_RELEASE_FIELD_NAME} before running Chatroom workflows.'), 400

            if not self.is_chatroom_enabled(chatroom_id, selected_application):
                return jsonify(status='error', message=f'{chatroom["title"]} is not configured yet.'), 400

            from home.logic import record_operation_run
            record_operation_run()

            job_id = _create_job()

            @copy_current_request_context
            def _background_run():
                try:
                    succeeded, result = self.run_chatroom(chatroom_id)
                    if succeeded:
                        _complete_job(job_id, 'success', result)
                    else:
                        _complete_job(job_id, 'error', result)
                except Exception as exc:
                    LOGGER.exception('Background chatroom workflow %s failed.', chatroom_id)
                    _complete_job(job_id, 'error', f'{chatroom["title"]} failed: {exc}')

            thread = threading.Thread(target=_background_run, daemon=True)
            thread.start()

            return jsonify(
                status='running',
                message=f'{chatroom["title"]} has been triggered and is running in the background.',
                job_id=job_id,
            )

        @app.get('/operations/last-generated-state')
        @login_required
        def operations_last_generated_state():
            return jsonify(_build_last_generated_state(_get_last_generated_artifact()))

        @app.get('/operations/download-last-export')
        @login_required
        def operations_download_last_export():
            artifact = _get_last_generated_artifact()
            if not artifact or not artifact.get('export_bytes'):
                return redirect(url_for('operations_page'))
            return send_file(
                BytesIO(artifact['export_bytes']),
                as_attachment=True,
                download_name=artifact.get('export_filename') or 'operations_export.xlsx',
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            )

        @app.get('/operations/preview-last-email')
        @login_required
        def operations_preview_last_email():
            artifact = _get_last_generated_artifact()
            if not artifact or not artifact.get('email_html'):
                return redirect(url_for('operations_page'))
            return render_template_string(
                """<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>{{ email_subject or 'Email Preview' }}</title>
    <style>
        body{margin:0;font-family:"Plus Jakarta Sans",Segoe UI,Arial,sans-serif;background:#eef4f9;color:#0f172a;}
        .page{max-width:1180px;margin:0 auto;padding:24px;}
        .meta{background:#ffffff;border:1px solid #d7dee7;border-radius:18px;box-shadow:0 18px 44px rgba(15,23,42,0.08);padding:20px 22px;margin-bottom:20px;}
        .eyebrow{font-size:12px;font-weight:800;letter-spacing:0.08em;text-transform:uppercase;color:#0891b2;margin:0 0 10px;}
        .subject{font-size:22px;font-weight:800;margin:0 0 14px;}
        .meta-row{font-size:14px;line-height:1.6;margin:0 0 8px;word-break:break-word;}
        .label{font-weight:800;color:#334155;display:inline-block;min-width:96px;}
        .frame{background:#ffffff;border:1px solid #d7dee7;border-radius:18px;box-shadow:0 18px 44px rgba(15,23,42,0.08);padding:12px;}
        .email-canvas{background:#ffffff;border:1px solid #e2e8f0;border-radius:14px;padding:18px;overflow:auto;}
    </style>
</head>
<body>
    <main class="page">
        <section class="meta">
            <p class="eyebrow">Operations Email Preview</p>
            <h1 class="subject">{{ email_subject or 'Untitled email' }}</h1>
            <p class="meta-row"><span class="label">Workflow</span>{{ operation_title or 'Latest generated workflow' }}</p>
            <p class="meta-row"><span class="label">To</span>{{ to_recipients or 'No recipients resolved' }}</p>
            <p class="meta-row"><span class="label">Cc</span>{{ cc_recipients or 'None' }}</p>
            <p class="meta-row"><span class="label">Attachment</span>{{ export_filename or 'No attachment' }}</p>
        </section>
        <section class="frame">
            <div class="email-canvas">{{ email_html|safe }}</div>
        </section>
    </main>
</body>
</html>""",
                email_subject=artifact.get('email_subject', ''),
                operation_title=artifact.get('operation_title', ''),
                to_recipients='; '.join(artifact.get('to_recipients') or []),
                cc_recipients='; '.join(artifact.get('cc_recipients') or []),
                export_filename=artifact.get('export_filename', ''),
                email_html=artifact.get('email_html', ''),
            )

        @app.post('/operations/send-last-email')
        @login_required
        def operations_send_last_email():
            artifact = _get_last_generated_artifact()
            if not artifact or not artifact.get('email_html'):
                return jsonify(status='error', message='No cached email preview is available to send.'), 400
            if not (GRAPH_TENANT_ID and GRAPH_CLIENT_ID and GRAPH_CLIENT_SECRET):
                return jsonify(status='error', message='Microsoft Graph email delivery is not configured. Set GRAPH_CLIENT_SECRET and retry.'), 400

            to_recipients = list(artifact.get('to_recipients') or [])
            if not to_recipients:
                return jsonify(status='error', message='The cached email preview does not contain any To recipients.'), 400

            try:
                send_email_via_graph(
                    subject=artifact.get('email_subject') or 'Operations Email',
                    html_body=artifact.get('email_html') or '',
                    to_recipients=to_recipients,
                    cc_recipients=list(artifact.get('cc_recipients') or []),
                    from_address=artifact.get('from_address') or None,
                    attachment_bytes=artifact.get('export_bytes'),
                    attachment_filename=artifact.get('export_filename') or None,
                )
            except Exception as error:
                LOGGER.exception('Graph email delivery failed for cached Operations preview.')
                return jsonify(status='error', message=f'Send Email failed: {error}'), 500

            return jsonify(
                status='success',
                message=f"Sent '{artifact.get('email_subject') or 'Operations Email'}' via Microsoft Graph.",
            )

        # In-memory chat state store (avoids cookie size limits)
        _ops_chat_states = {}

        @app.post('/operations/ops-chat')
        @login_required
        def operations_ops_chat():
            from operations.ops_chat import handle_chat_message
            body = request.get_json(silent=True) or {}
            user_message = str(body.get('message', '')).strip()
            chat_key = session.get('credentials_key', 'default')
            chat_state = _ops_chat_states.get(chat_key, {})
            try:
                reply, new_state = handle_chat_message(chat_state, user_message)
            except Exception as exc:
                import logging
                logging.getLogger(__name__).exception('Operations chat error')
                return jsonify({'reply': f'Something went wrong: {exc}'})
            _ops_chat_states[chat_key] = new_state
            return jsonify({'reply': reply})

    def build_tile_groups(self, selected_application):
        visible_groups = OPERATIONS_VISIBLE_GROUPS_BY_APPLICATION.get(
            selected_application,
            OPERATIONS_ENABLED_GROUPS_BY_APPLICATION.get(selected_application, set()),
        )
        # Include groups from custom app configs
        if not visible_groups:
            from operations.ops_chat import load_all_app_configs
            for cfg in load_all_app_configs():
                if cfg.get('name') == selected_application and not cfg.get('disabled'):
                    visible_groups = set(cfg.get('groups', []))
                    break
        groups = {
            group_title: {'title': group_title, 'items': []}
            for group_title in visible_groups
        }
        for operation_id, operation in OPERATIONS.items():
            if not self.is_operation_enabled_for_application(operation_id, selected_application):
                continue
            resolved_operation = self.get_operation_definition(selected_application, operation_id)
            group = groups.setdefault(operation['group'], {'title': operation['group'], 'items': []})
            group['items'].append(
                {
                    'id': operation_id,
                    'title': resolved_operation['title'],
                    'description': resolved_operation['description'],
                    'enabled': resolved_operation['action'] is not None,
                }
            )
        # Include custom email configs created via the chatbot for this application
        from operations.ops_chat import load_all_email_configs
        existing_ids = set()
        for g in groups.values():
            for item in g['items']:
                existing_ids.add(item['id'])
        for cfg in load_all_email_configs():
            if cfg.get('application') != selected_application:
                continue
            if cfg.get('id') in existing_ids:
                continue
            trigger_group = groups.setdefault('Trigger Email', {'title': 'Trigger Email', 'items': []})
            trigger_group['items'].append(
                {
                    'id': cfg['id'],
                    'title': cfg.get('name', cfg['id']),
                    'description': cfg.get('subject', ''),
                    'enabled': True,
                }
            )
        return sorted(
            groups.values(),
            key=lambda group: (OPERATIONS_GROUP_DISPLAY_ORDER.get(group['title'], 99), group['title']),
        )

    def build_chatrooms(self, selected_application):
        built_chatrooms = []
        for chatroom in OPERATIONS_CHATROOMS:
            built_chatroom = dict(chatroom)
            built_chatroom['enabled'] = self.is_chatroom_enabled(chatroom['id'], selected_application)
            built_chatrooms.append(built_chatroom)
        return built_chatrooms

    @staticmethod
    def get_chatroom_definition(chatroom_id):
        for chatroom in OPERATIONS_CHATROOMS:
            if chatroom.get('id') == chatroom_id:
                return dict(chatroom)
        return None

    def is_chatroom_enabled(self, chatroom_id, application):
        chatroom = self.get_chatroom_definition(chatroom_id)
        if chatroom is None or not chatroom.get('action'):
            return False
        return application == OPERATIONS_CHATROOM_APPLICATION and self.is_graph_chat_configured()

    @staticmethod
    def get_operation_definition(application, operation_id):
        operation = dict(OPERATIONS[operation_id])
        if application == 'ACC-Prod' and operation_id == 'blocking-field-empty':
            operation['title'] = ACC_PROD_PAST_DATED_FIX_VERSION_TITLE
            operation['description'] = ACC_PROD_PAST_DATED_FIX_VERSION_DESCRIPTION
        return operation

    @staticmethod
    def is_configured_application(application):
        if application in OPERATIONS_ENABLED_GROUPS_BY_APPLICATION:
            return True
        from operations.ops_chat import load_all_app_configs
        for cfg in load_all_app_configs():
            if cfg.get('name') == application and not cfg.get('disabled'):
                return True
        return False

    @staticmethod
    def application_supports_release_filter(application):
        application_definition = get_ram_application_definition(application)
        if (application_definition or {}).get('supports_release_filter'):
            return True
        # Check custom app config
        from operations.ops_chat import load_all_app_configs
        for cfg in load_all_app_configs():
            if cfg.get('name') == application and not cfg.get('disabled'):
                return bool(cfg.get('release_filter'))
        return False

    @staticmethod
    def application_supports_fix_version_filter(application):
        return application == 'ACC-Prod'

    def application_ready_for_operations(self, application, release_name):
        if not self.is_configured_application(application):
            return False
        if self.application_supports_release_filter(application):
            return bool(release_name)
        return True

    @staticmethod
    def is_operation_enabled_for_application(operation_id, application):
        enabled_groups = OPERATIONS_ENABLED_GROUPS_BY_APPLICATION.get(application, set())
        enabled_operation_ids = OPERATIONS_ENABLED_OPERATION_IDS_BY_APPLICATION.get(application, set())
        return (
            (
                OPERATIONS.get(operation_id, {}).get('group') in enabled_groups
                or operation_id in enabled_operation_ids
            )
            and OperationsFeature.is_operation_visible_for_application(operation_id, application)
        )

    @staticmethod
    def is_operation_visible_for_application(operation_id, application):
        if application == 'ACC-Prod' and operation_id in ACC_PROD_HIDDEN_OPERATION_IDS:
            return False
        if application != 'ACC-Prod' and operation_id in ACC_PROD_ONLY_OPERATION_IDS:
            return False
        return True

    @staticmethod
    def get_selected_application():
        return (request.form.get('application') or request.args.get('application') or '').strip()

    @staticmethod
    def get_selected_release():
        return (request.form.get('release_name') or request.args.get('release_name') or '').strip()

    @staticmethod
    def get_selected_fix_version():
        return (request.form.get('fix_version') or request.args.get('fix_version') or '').strip()

    @staticmethod
    def escape_jql_string(value):
        return str(value).replace('\\', '\\\\').replace('"', '\\"').strip()

    def build_release_clause(self, release_name):
        escaped_release_name = self.escape_jql_string(release_name)
        return f'(cf[18971] in ("{escaped_release_name}") or cf[18972] in ("{escaped_release_name}"))'

    def build_release_scoped_jql(self, base_jql, release_name):
        if not release_name:
            return base_jql
        scoped_jql, replaced_count = OPERATIONS_RELEASE_CLAUSE_PATTERN.subn(self.build_release_clause(release_name), base_jql, count=1)
        if replaced_count:
            return scoped_jql
        order_by_index = base_jql.casefold().find(' order by ')
        if order_by_index == -1:
            return f'({base_jql}) and {self.build_release_clause(release_name)}'
        return f'{base_jql[:order_by_index]} and {self.build_release_clause(release_name)}{base_jql[order_by_index:]}'

    def fetch_release_options(self, application=None, username=None, password=None, release_name=None):
        if application and not self.application_supports_release_filter(application):
            return []
        seed_release_name = (release_name or self.get_selected_release() or OPERATIONS_RELEASE_SEED_FALLBACK).strip()
        seed_jql = self.build_release_scoped_jql(self.get_application_base_release_jql(application), seed_release_name)
        seed_issues = fetch_open_defects(
            jql=seed_jql,
            max_results=1,
            username=username,
            password=password,
            fields=[OPERATIONS_RELEASE_FIELD_KEY],
            expand='names',
        )
        if not seed_issues:
            return []
        issue_key = (seed_issues[0] or {}).get('key')
        if not issue_key:
            return []
        editmeta = fetch_issue_editmeta(issue_key, username=username, password=password)
        field_meta = (editmeta.get('fields') or {}).get(OPERATIONS_RELEASE_FIELD_KEY) or {}
        allowed_values = field_meta.get('allowedValues') or []
        release_options = []
        for allowed_value in allowed_values:
            option_text = self.stringify_select_value(allowed_value.get('value') or allowed_value.get('name'))
            if option_text:
                release_options.append(option_text)
        return sorted(set(release_options), key=str.casefold)

    def fetch_fix_version_options(self, application=None, username=None, password=None, fix_version_name=None):
        if not self.application_supports_fix_version_filter(application):
            return []
        seed_jql = self.get_application_base_release_jql(application)
        seed_issues = fetch_open_defects(
            jql=seed_jql,
            max_results=1,
            username=username,
            password=password,
            fields=['summary'],
            expand='names',
        )
        if not seed_issues:
            return [fix_version_name] if fix_version_name else []
        issue_key = (seed_issues[0] or {}).get('key')
        if not issue_key:
            return [fix_version_name] if fix_version_name else []
        editmeta = fetch_issue_editmeta(issue_key, username=username, password=password)
        field_meta = (editmeta.get('fields') or {}).get(OPERATIONS_FIX_VERSION_FIELD_KEY) or {}
        allowed_values = field_meta.get('allowedValues') or []
        fix_version_options = []
        for allowed_value in allowed_values:
            option_text = self.stringify_select_value(allowed_value.get('name') or allowed_value.get('value'))
            if option_text:
                fix_version_options.append(option_text)
        if fix_version_name and fix_version_name not in fix_version_options:
            fix_version_options.append(fix_version_name)
        return sorted(set(fix_version_options), key=str.casefold)

    @staticmethod
    def build_ordered_jql(base_jql, *clauses, order_by=None):
        normalized_jql = (base_jql or '').strip()
        order_by_index = normalized_jql.casefold().find(' order by ')
        if order_by_index != -1:
            normalized_jql = normalized_jql[:order_by_index].rstrip()
        jql_parts = [f'({normalized_jql})']
        jql_parts.extend(clause for clause in clauses if clause)
        scoped_jql = ' and '.join(jql_parts)
        if order_by:
            return f'{scoped_jql} ORDER BY {order_by}'
        return scoped_jql

    @staticmethod
    def get_application_base_release_jql(application):
        if application == 'ACC-Prod':
            application_definition = get_ram_application_definition(application) or {}
            return application_definition.get('base_jql') or RELEASE_OPEN_DEFECTS_JQL
        return RELEASE_OPEN_DEFECTS_JQL

    def build_acc_prod_jql_overrides(self):
        application_definition = get_ram_application_definition('ACC-Prod') or {}
        acc_base_jql = application_definition.get('base_jql')
        acc_prod_out_of_sla_sales_base_jql = (
            'filter in (self-agent-filter) '
            'and "Defect Type" in ("Tracking Record", "Bug/Issue", Defect, "Production Defect") '
            'and "Phase Found In" in (Production, "Production Validation Testing (PVT)", "Business Validation Testing", '
            '"First Field Availability (FFA)", "Controlled Introduction (CI)", "Production Readiness (PR)", '
            '"User Acceptance Test (UAT)", Pilot) '
            'and Severity in ("Severity 4", "Severity 1", "Severity 3", "Severity 2") '
            'and filter in (Lynn_ask_ACC_app_filter)'
        )
        if not acc_base_jql:
            raise ValueError('ACC-Prod Operations JQL is not configured.')
        selected_fix_version = self.get_selected_fix_version()
        open_status_clause = 'status not in (Accepted, Cancelled)'
        open_order_by = 'Severity ASC, created ASC'
        new_defects_order_by = 'created DESC'
        resolved_order_by = 'Severity ASC, updated DESC'
        past_dated_fix_version_clause = 'fixVersion in unreleasedVersions()'
        retest_fix_version_clause = ''
        if selected_fix_version:
            escaped_fix_version = self.escape_jql_string(selected_fix_version)
            retest_fix_version_clause = f'fixVersion in unreleasedVersions() and fixVersion < "{escaped_fix_version}"'
            past_dated_fix_version_clause = (
                'fixVersion in unreleasedVersions() '
                f'and fixVersion < "{escaped_fix_version}" '
            )
        return {
            'release-open-defects': self.build_ordered_jql(acc_base_jql, open_status_clause, order_by=open_order_by),
            'release-open-defects-progression-dm-comments': self.build_ordered_jql(
                acc_base_jql,
                open_status_clause,
                '"Progression/Regression" = Progression',
                order_by=open_order_by,
            ),
            'release-open-defects-regression-dm-comments': self.build_ordered_jql(
                acc_base_jql,
                open_status_clause,
                '"Progression/Regression" = Regression',
                order_by=open_order_by,
            ),
            'release-open-defects-retest': self.build_ordered_jql(
                acc_base_jql,
                'status in ("Retest", "Dev Complete", "Test Complete")',
                retest_fix_version_clause,
                order_by=open_order_by,
            ),
            'release-open-defects-return-rejected': self.build_ordered_jql(
                acc_base_jql,
                'status in ("Returned/Rejected")',
                order_by=open_order_by,
            ),
            'new-defects-created': self.build_ordered_jql(
                acc_base_jql,
                'created >= startOfDay(-1)',
                order_by=new_defects_order_by,
            ),
            'pilot-defects-wls': 'labels in (Centers_Pilot_UpgradeExpansion_Wireless, Retail_Pilot_UpgradeExpansion_Wireless) AND status not in (accepted, cancelled) ORDER BY created DESC',
            'missing-order-impact': self.build_ordered_jql(
                acc_prod_out_of_sla_sales_base_jql,
                'labels in (CQE_ACC_ProdDM_Shop, CQE_ACC_ProdDM_Purchase)',
                'status not in (Accepted, Cancelled)',
                '"Phase Found In" in (Production)',
                '"User 2" is EMPTY',
                order_by=open_order_by,
            ),
            'out-of-sla-sales': self.build_ordered_jql(
                acc_prod_out_of_sla_sales_base_jql,
                '((Severity = "Severity 1" AND created > -3000d AND created <= -1d) '
                'OR (Severity = "Severity 2" AND created > -3000d AND created <= -10d) '
                'OR (Severity = "Severity 3" AND created > -3000d AND created <= -20d) '
                'OR (Severity = "Severity 4" AND created > -3000d AND created <= -90d))',
                'status not in (accepted, cancelled, deferred, Closed, Retest, "Dev Complete", "Test Complete" )',
                'labels in (CQE_ACC_ProdDM_Shop, CQE_ACC_ProdDM_Purchase, CQE_ACC_ProdDM_RetailTech, CQE_ACC_ProdDM_Leads, CQE_ACC_ProdDM_CustomerCommunications)',
                order_by=open_order_by,
            ),
            'assigned-to-team-testing-status-acc-prod': ACC_PROD_RETEST_TEST_BLOCKED_ASSIGNED_TO_TEAM_TESTING_JQL,
            'assigned-to-team-triage-status-acc-prod': ACC_PROD_RETURN_REJECTED_ASSIGNED_TO_TEAM_TRIAGE_JQL,
            'application-fixed-in-root-cause-app-sync-acc-prod': ACC_PROD_APPLICATION_FIXED_IN_ROOT_CAUSE_APP_SYNC_JQL,
            'assigned-to-team-business-application-fixed-in-acc-prod': ACC_PROD_ASSIGNED_TO_TEAM_BUSINESS_APPLICATION_FIXED_IN_JQL,
            'assigned-to-team-production-support-application-fixed-in-acc-prod': ACC_PROD_ASSIGNED_TO_TEAM_PRODUCTION_SUPPORT_APPLICATION_FIXED_IN_JQL,
            'assigned-to-team-triage-update-assignee-acc-prod': ACC_PROD_ASSIGNED_TO_TRIAGE_UPDATE_ASSIGNEE_JQL,
            'bug-issue-conversion-acc-prod': ACC_PROD_BUG_ISSUE_CONVERSION_JQL,
            'customer-impact-less-update-severity-acc-prod': ACC_PROD_CUSTOMER_IMPACT_LESS_UPDATE_SEVERITY_JQL,
            'non-monitoring-pilot-sev4-label-addition-acc-prod': ACC_PROD_NON_MONITORING_PILOT_SEV4_LABEL_ADDITION_JQL,
            'update-est-retest-date-acc-prod': ACC_PROD_UPDATE_EST_RETEST_DATE_JQL,
            'out-of-sla-non-sales': self.build_ordered_jql(
                acc_prod_out_of_sla_sales_base_jql,
                '((Severity = "Severity 1" AND created > -3000d AND created <= -1d) '
                'OR (Severity = "Severity 2" AND created > -3000d AND created <= -30d) '
                'OR (Severity = "Severity 3" AND created > -3000d AND created <= -60d) '
                'OR (Severity = "Severity 4" AND created > -3000d AND created <= -90d))',
                'status not in (accepted, cancelled, deferred, Closed, Retest, "Dev Complete", "Test Complete")',
                'labels in (CQE_ACC_ProdDM_AccountsAndServices, CQE_ACC_ProdDM_BillingPaymentFrameworks, CQE_ACC_ProdDM_SupportAndNetwork, CQE_ACC_ProdDM_CaBSSharedServices, CQE_ACC_ProdDM_StrataAI)',
                order_by=open_order_by,
            ),
            'eta-slipped-defects': self.build_ordered_jql(acc_base_jql, order_by=open_order_by),
            'blocking-field-empty-defects': self.build_ordered_jql(
                acc_base_jql,
                'status not in (Accepted, Cancelled, "Retest", "Dev Complete", "Test Complete")',
                past_dated_fix_version_clause,
                order_by=open_order_by,
            ),
            'not-an-application-requesting-review': self.build_ordered_jql(
                acc_base_jql,
                '"Application Fixed In" ~ "Not an Application*"',
                order_by=open_order_by,
            ),
            'progression-open-resolved-today': self.build_ordered_jql(
                acc_base_jql,
                'status in (Accepted, Cancelled)',
                'updated >= startOfDay(-1d)',
                '"Progression/Regression" = Progression',
                order_by=resolved_order_by,
            ),
            'regression-open-resolved-today': self.build_ordered_jql(
                acc_base_jql,
                'status in (Accepted, Cancelled)',
                'updated >= startOfDay(-1d)',
                '"Progression/Regression" = Regression',
                order_by=resolved_order_by,
            ),
        }

    def build_jql_overrides(self, selected_application, selected_release):
        if selected_application == 'ACC-Prod':
            return self.build_acc_prod_jql_overrides()
        return {
            'chatroom-creation': self.build_release_scoped_jql(CHATROOM_CREATION_BASE_JQL, selected_release),
            'release-open-defects': self.build_release_scoped_jql(RELEASE_OPEN_DEFECTS_JQL, selected_release),
            'release-open-defects-progression-dm-comments': self.build_release_scoped_jql(PROGRESSION_OPEN_DEFECTS_JQL, selected_release),
            'release-open-defects-regression-dm-comments': self.build_release_scoped_jql(REGRESSION_OPEN_DEFECTS_JQL, selected_release),
            'release-open-defects-retest': self.build_release_scoped_jql(RETEST_DEFECTS_JQL, selected_release),
            'release-open-defects-return-rejected': self.build_release_scoped_jql(RETURN_REJECT_DEFECTS_JQL, selected_release),
            'eta-slipped-defects': self.build_release_scoped_jql(ETA_SLIPPED_DEFECTS_JQL, selected_release),
            'blocking-field-empty-defects': self.build_release_scoped_jql(RELEASE_OPEN_DEFECTS_JQL, selected_release),
            'not-an-application-requesting-review': self.build_release_scoped_jql(NOT_AN_APPLICATION_REQUESTING_REVIEW_JQL, selected_release),
            'progression-regression': self.build_release_scoped_jql(ETA_SLIPPED_DEFECTS_JQL, selected_release),
            'tribe-label': self.build_release_scoped_jql(TRIBE_LABEL_SELF_HEAL_JQL, selected_release),
            'assigned-to-team-testing-vs-assignee': self.build_release_scoped_jql(ASSIGNED_TO_TEAM_TESTING_VS_ASSIGNEE_JQL, selected_release),
            'assigned-to-team-testing-status': self.build_release_scoped_jql(RETURN_REJECTED_RETEST_TEST_BLOCKED_ASSIGNED_TO_TEAM_TESTING_JQL, selected_release),
            'application-fixed-in-cqe': self.build_release_scoped_jql(APPLICATION_FIXED_IN_CQE_ACCEPTED_CANCELLED_JQL, selected_release),
            'application-fixed-in-cqe-revert': self.build_release_scoped_jql(APPLICATION_FIXED_IN_CQE_STATUS_NOT_ACCEPTED_CANCELLED_JQL, selected_release),
            'root-cause-app-matches-application-fixed-in': self.build_release_scoped_jql(ROOT_CAUSE_APP_MATCHES_APPLICATION_FIXED_IN_JQL, selected_release),
            'progression-open-resolved-today': self.build_release_scoped_jql(PROGRESSION_RESOLVED_TODAY_JQL, selected_release),
            'regression-open-resolved-today': self.build_release_scoped_jql(REGRESSION_RESOLVED_TODAY_JQL, selected_release),
        }

    def redirect_to_operations_page(self, selected_application=None):
        application = self.get_selected_application() if selected_application is None else (selected_application or '').strip()
        release_name = self.get_selected_release()
        if application and release_name:
            return redirect(url_for('operations_page', application=application, release_name=release_name))
        if application:
            return redirect(url_for('operations_page', application=application))
        return redirect(url_for('operations_page'))

    @staticmethod
    def get_cached_tribe_mapping_path():
        return build_project_cached_workbook_path(TRIBE_LABEL_MAPPING_SOURCE)

    @staticmethod
    def get_cached_pilot_wls_mapping_path():
        return get_cached_pilot_wls_mapping_path()

    def cache_uploaded_tribe_mapping_workbook(self, uploaded_file):
        if uploaded_file is None or not (uploaded_file.filename or '').strip():
            return None
        uploaded_filename = os.path.basename((uploaded_file.filename or '').strip())
        if not uploaded_filename.lower().endswith('.xlsx'):
            raise ValueError('Only .xlsx tribe mapping workbooks are supported.')
        workbook_bytes = uploaded_file.read()
        if not workbook_bytes:
            raise ValueError('The selected workbook is empty. Choose a valid .xlsx file and retry.')
        cached_path = self.get_cached_tribe_mapping_path()
        os.makedirs(os.path.dirname(cached_path), exist_ok=True)
        with open(cached_path, 'wb') as cached_workbook:
            cached_workbook.write(workbook_bytes)
        return cached_path

    def cache_uploaded_pilot_wls_mapping_workbook(self, uploaded_file):
        if uploaded_file is None or not (uploaded_file.filename or '').strip():
            return None
        uploaded_filename = os.path.basename((uploaded_file.filename or '').strip())
        if not uploaded_filename.lower().endswith('.xlsx'):
            raise ValueError('Only .xlsx Pilot Defects WLS mapping workbooks are supported.')
        workbook_bytes = uploaded_file.read()
        if not workbook_bytes:
            raise ValueError('The selected Pilot Defects WLS mapping workbook is empty. Choose a valid .xlsx file and retry.')
        cached_path = self.get_cached_pilot_wls_mapping_path()
        os.makedirs(os.path.dirname(cached_path), exist_ok=True)
        with open(cached_path, 'wb') as cached_workbook:
            cached_workbook.write(workbook_bytes)
        return cached_path

    def cache_last_generated_artifact(self, operation_title, workbook_bytes, filename, email_preview, jql=None):
        _set_last_generated_artifact(
            {
                'operation_title': operation_title,
                'export_bytes': workbook_bytes,
                'export_filename': filename,
                'email_subject': email_preview.get('subject', ''),
                'email_html': email_preview.get('html_body', ''),
                'to_recipients': list(email_preview.get('to_recipients') or []),
                'cc_recipients': list(email_preview.get('cc_recipients') or []),
                'from_address': email_preview.get('from_address', ''),
                'captured_at': time.time(),
                'jql': jql or '',
            }
        )

    @staticmethod
    def is_graph_chat_configured():
        return bool(GRAPH_TENANT_ID and GRAPH_CLIENT_ID)

    @staticmethod
    def graph_chat_token_cache_path():
        return os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logs', 'graph_chat_delegated_token.json')

    def load_graph_chat_token_cache(self):

        cache_path = self.graph_chat_token_cache_path()
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            return None
        except OSError:
            LOGGER.warning('Unable to load delegated Graph token cache at %s.', cache_path)
            return None

    def save_graph_chat_token_cache(self, payload):
        cache_path = self.graph_chat_token_cache_path()
        try:
            os.makedirs(os.path.dirname(cache_path), exist_ok=True)
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(payload, f, indent=2)
        except OSError:
            LOGGER.warning('Unable to save delegated Graph token cache at %s.', cache_path)

    def clear_graph_chat_token_cache(self):
        cache_path = self.graph_chat_token_cache_path()
        try:
            os.remove(cache_path)
        except FileNotFoundError:
            pass
        except OSError:
            LOGGER.warning('Unable to remove delegated Graph token cache at %s.', cache_path)

    @staticmethod
    def graph_chat_scope_text():
        return ' '.join(GRAPH_CHAT_DELEGATED_SCOPES)

    def persist_graph_chat_token(self, token_payload):
        expires_in = int(token_payload.get('expires_in') or 0)
        cache_payload = {
            'access_token': token_payload.get('access_token') or '',
            'refresh_token': token_payload.get('refresh_token') or '',
            'scope': token_payload.get('scope') or self.graph_chat_scope_text(),
            'expires_at': time.time() + max(expires_in - 60, 0),
        }
        self.save_graph_chat_token_cache(cache_payload)

    def refresh_graph_chat_access_token(self, refresh_token):
        response = get_http_session().post(
            f'https://login.microsoftonline.com/{GRAPH_TENANT_ID}/oauth2/v2.0/token',
            data={
                'grant_type': 'refresh_token',
                'client_id': GRAPH_CLIENT_ID,
                'refresh_token': refresh_token,
                'scope': self.graph_chat_scope_text(),
            },
            timeout=30,
        )
        if response.status_code >= 400:
            LOGGER.warning('Delegated Graph refresh token exchange failed: %s', response.text)
            self.clear_graph_chat_token_cache()
            return None
        token_payload = response.json()
        if not token_payload.get('access_token'):
            self.clear_graph_chat_token_cache()
            return None
        self.persist_graph_chat_token(token_payload)
        return token_payload.get('access_token')

    def start_graph_chat_device_flow(self):
        response = get_http_session().post(
            f'https://login.microsoftonline.com/{GRAPH_TENANT_ID}/oauth2/v2.0/devicecode',
            data={
                'client_id': GRAPH_CLIENT_ID,
                'scope': self.graph_chat_scope_text(),
            },
            timeout=30,
        )
        response.raise_for_status()
        device_payload = response.json()
        self.save_graph_chat_token_cache(
            {
                'pending_device_code': {
                    'device_code': device_payload.get('device_code') or '',
                    'user_code': device_payload.get('user_code') or '',
                    'verification_uri': device_payload.get('verification_uri') or '',
                    'verification_uri_complete': device_payload.get('verification_uri_complete') or '',
                    'expires_at': time.time() + int(device_payload.get('expires_in') or 0),
                    'interval': int(device_payload.get('interval') or 5),
                    'scope': self.graph_chat_scope_text(),
                }
            }
        )
        return device_payload

    def exchange_graph_chat_device_code(self, pending_device_code):
        response = get_http_session().post(
            f'https://login.microsoftonline.com/{GRAPH_TENANT_ID}/oauth2/v2.0/token',
            data={
                'grant_type': 'urn:ietf:params:oauth:grant-type:device_code',
                'client_id': GRAPH_CLIENT_ID,
                'device_code': pending_device_code.get('device_code') or '',
            },
            timeout=30,
        )
        if response.status_code == 400:
            error_payload = response.json()
            error_code = str(error_payload.get('error') or '').strip().casefold()
            verification_target = pending_device_code.get('verification_uri_complete') or pending_device_code.get('verification_uri') or 'https://microsoft.com/devicelogin'
            user_code = pending_device_code.get('user_code') or ''
            if error_code in {'authorization_pending', 'slow_down'}:
                raise ValueError(
                    'Delegated Microsoft Graph sign-in is still pending. Open '
                    f'{verification_target} and complete the sign-in with code {user_code}, then run Chatroom Creation again.'
                )
            if error_code == 'authorization_declined':
                self.clear_graph_chat_token_cache()
                raise ValueError('Delegated Microsoft Graph sign-in was declined. Run Chatroom Creation again to generate a new device code.')
            if error_code in {'expired_token', 'bad_verification_code'}:
                self.clear_graph_chat_token_cache()
                raise ValueError('Delegated Microsoft Graph device code expired. Run Chatroom Creation again to generate a new sign-in prompt.')
        response.raise_for_status()
        token_payload = response.json()
        if not token_payload.get('access_token'):
            raise ValueError('Delegated Microsoft Graph token exchange returned no access token.')
        self.persist_graph_chat_token(token_payload)
        return token_payload.get('access_token')

    @staticmethod
    def parse_recipient_text(recipient_text):
        return [entry.strip() for entry in (recipient_text or '').split(';') if entry.strip()]

    @staticmethod
    def extract_email_addresses(value):
        raw_value = (value or '').strip()
        if not raw_value:
            return []

        extracted_addresses = []
        seen_addresses = set()
        for candidate in re.findall(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}', raw_value):
            normalized_email = CHATROOM_CREATION_EMAIL_ALIASES.get(
                candidate.strip().strip(';,').casefold(),
                candidate.strip().strip(';,')
            )
            normalized_candidate = normalized_email.casefold()
            if normalized_candidate in seen_addresses:
                continue
            seen_addresses.add(normalized_candidate)
            extracted_addresses.append(normalized_email)

        if extracted_addresses:
            return extracted_addresses

        candidate = raw_value.strip(';,')
        if '@' in candidate and ' ' not in candidate:
            return [CHATROOM_CREATION_EMAIL_ALIASES.get(candidate.casefold(), candidate)]
        return []

    @staticmethod
    def extract_email_address(value):
        extracted_addresses = OperationsFeature.extract_email_addresses(value)
        return extracted_addresses[0] if extracted_addresses else ''

    @staticmethod
    def extract_issue_user_email(user_payload):
        if not isinstance(user_payload, dict):
            return ''
        for candidate in (
            user_payload.get('emailAddress'),
            user_payload.get('name'),
            user_payload.get('key'),
        ):
            email_address = OperationsFeature.extract_email_address(str(candidate or ''))
            if email_address:
                return email_address
        return ''

    @staticmethod
    def extract_display_name(value):
        raw_value = str(value or '').strip()
        if not raw_value:
            return ''
        if '<' in raw_value:
            return raw_value.split('<', 1)[0].strip().strip(';,')
        if '@' in raw_value:
            return ''
        return raw_value.strip(';,')

    @staticmethod
    def extract_issue_user_identity(user_payload):
        if not isinstance(user_payload, dict):
            return {'email': '', 'display_name': ''}
        return {
            'email': OperationsFeature.extract_issue_user_email(user_payload),
            'display_name': OperationsFeature.extract_display_name(
                user_payload.get('displayName') or user_payload.get('name') or user_payload.get('key') or ''
            ),
        }

    @staticmethod
    def build_participant_candidate(value):
        return {
            'email': OperationsFeature.extract_email_address(str(value or '')),
            'display_name': OperationsFeature.extract_display_name(value),
        }

    @staticmethod
    def dedupe_participant_candidates(values):
        unique_values = []
        seen_values = set()
        for value in values:
            if not isinstance(value, dict):
                continue
            email = (value.get('email') or '').strip()
            display_name = (value.get('display_name') or '').strip()
            dedupe_key = (email or display_name).casefold()
            if not dedupe_key or dedupe_key in seen_values:
                continue
            unique_values.append({'email': email, 'display_name': display_name})
            seen_values.add(dedupe_key)
        return unique_values

    @staticmethod
    def dedupe_email_addresses(values):
        unique_values = []
        seen_values = set()
        for value in values:
            normalized_value = (value or '').strip()
            if not normalized_value:
                continue
            seen_key = normalized_value.casefold()
            if seen_key in seen_values:
                continue
            unique_values.append(normalized_value)
            seen_values.add(seen_key)
        return unique_values

    @staticmethod
    def load_chatroom_registry():
        os.makedirs(os.path.dirname(CHATROOM_CREATION_REGISTRY_PATH), exist_ok=True)
        with CHATROOM_CREATION_REGISTRY_LOCK:
            if not os.path.exists(CHATROOM_CREATION_REGISTRY_PATH):
                return {}
            try:
                with open(CHATROOM_CREATION_REGISTRY_PATH, 'r', encoding='utf-8') as registry_file:
                    payload = json.load(registry_file)
            except (OSError, ValueError, TypeError):
                return {}
            return payload if isinstance(payload, dict) else {}

    @staticmethod
    def get_chatroom_registry_metadata(registry):
        metadata = (registry or {}).get('_meta') or {}
        return metadata if isinstance(metadata, dict) else {}

    @staticmethod
    def get_chatroom_last_checked_at(registry):
        metadata = OperationsFeature.get_chatroom_registry_metadata(registry)
        raw_value = metadata.get('last_checked_at')
        try:
            return float(raw_value)
        except (TypeError, ValueError):
            return None

    @staticmethod
    def save_chatroom_registry(payload):
        os.makedirs(os.path.dirname(CHATROOM_CREATION_REGISTRY_PATH), exist_ok=True)
        temp_path = f'{CHATROOM_CREATION_REGISTRY_PATH}.tmp'
        with CHATROOM_CREATION_REGISTRY_LOCK:
            with open(temp_path, 'w', encoding='utf-8') as registry_file:
                json.dump(payload, registry_file, indent=2, sort_keys=True)
            os.replace(temp_path, CHATROOM_CREATION_REGISTRY_PATH)

    @staticmethod
    def load_chatroom_tribe_lead_mapping():
        raw_mapping = (CHATROOM_CREATION_TRIBE_LEAD_BY_LABEL_JSON or '').strip()
        if not raw_mapping:
            return {}
        try:
            parsed_mapping = json.loads(raw_mapping)
        except ValueError as error:
            raise ValueError('OPERATIONS_CHATROOM_TRIBE_LEAD_BY_LABEL_JSON must be valid JSON.') from error
        if not isinstance(parsed_mapping, dict):
            raise ValueError('OPERATIONS_CHATROOM_TRIBE_LEAD_BY_LABEL_JSON must be a JSON object.')
        normalized_mapping = {}
        for label_name, configured_value in parsed_mapping.items():
            if isinstance(configured_value, list):
                normalized_mapping[str(label_name)] = [str(entry).strip() for entry in configured_value if str(entry).strip()]
            else:
                normalized_mapping[str(label_name)] = OperationsFeature.parse_recipient_text(str(configured_value))
        return normalized_mapping

    def resolve_chatroom_participants(self, issue, tribe_lead_mapping):
        fields = issue.get('fields') or {}
        labels = fields.get('labels') or []
        configured_entries = self.parse_recipient_text(CHATROOM_CREATION_DM_SPOCS)
        configured_entries.extend(self.parse_recipient_text(CHATROOM_CREATION_TRIBE_LEADS))
        for label_name in labels:
            configured_entries.extend(tribe_lead_mapping.get(str(label_name), []))

        participant_candidates = [
            self.extract_issue_user_identity(fields.get('reporter') or {}),
            self.extract_issue_user_identity(fields.get('assignee') or {}),
        ]
        for entry in configured_entries:
            participant_candidates.append(self.build_participant_candidate(entry))
        participant_candidates = self.dedupe_participant_candidates(participant_candidates)

        missing_roles = []
        reporter_identity = self.extract_issue_user_identity(fields.get('reporter') or {})
        assignee_identity = self.extract_issue_user_identity(fields.get('assignee') or {})
        if not (reporter_identity.get('email') or reporter_identity.get('display_name')):
            missing_roles.append('reporter')
        if not (assignee_identity.get('email') or assignee_identity.get('display_name')):
            missing_roles.append('assignee')
        if not self.parse_recipient_text(CHATROOM_CREATION_TRIBE_LEADS) and not any(tribe_lead_mapping.get(str(label_name)) for label_name in labels):
            missing_roles.append('tribe lead config')

        return participant_candidates, missing_roles

    @staticmethod
    def get_graph_access_token():
        raise NotImplementedError('Use the instance method get_graph_access_token_for_chatroom().')

    def get_graph_access_token_for_chatroom(self):
        cache_payload = self.load_graph_chat_token_cache() or {}
        access_token = str(cache_payload.get('access_token') or '').strip()
        expires_at = float(cache_payload.get('expires_at') or 0)
        if access_token and expires_at > (time.time() + 60):
            return access_token

        refresh_token = str(cache_payload.get('refresh_token') or '').strip()
        if refresh_token:
            refreshed_access_token = self.refresh_graph_chat_access_token(refresh_token)
            if refreshed_access_token:
                return refreshed_access_token

        pending_device_code = cache_payload.get('pending_device_code') or {}
        if pending_device_code:
            if float(pending_device_code.get('expires_at') or 0) > time.time():
                return self.exchange_graph_chat_device_code(pending_device_code)
            self.clear_graph_chat_token_cache()

        device_payload = self.start_graph_chat_device_flow()
        verification_target = device_payload.get('verification_uri_complete') or device_payload.get('verification_uri') or 'https://microsoft.com/devicelogin'
        user_code = device_payload.get('user_code') or ''
        raise ValueError(
            'Delegated Microsoft Graph sign-in is required for Chatroom Creation. Open '
            f'{verification_target} and complete the sign-in with code {user_code}, then run Chatroom Creation again.'
        )

    def lookup_graph_user(self, access_token, participant_candidate):
        email = (participant_candidate.get('email') or '').strip()
        display_name = (participant_candidate.get('display_name') or '').strip()

        def _request(url, params=None, headers=None):
            response = requests.get(
                url,
                params=params,
                headers={
                    'Authorization': f'Bearer {access_token}',
                    **(headers or {}),
                },
                timeout=30,
            )
            response.raise_for_status()
            return response.json() or {}

        if email:
            escaped_email = email.replace("'", "''")
            try:
                direct_user = _request(
                    f'https://graph.microsoft.com/v1.0/users/{quote(email)}',
                    params={'$select': 'id,displayName,mail,userPrincipalName'},
                )
                if direct_user.get('id'):
                    return direct_user
            except requests.HTTPError as error:
                if getattr(error, 'response', None) is None or error.response.status_code != 404:
                    raise

            filter_payload = _request(
                'https://graph.microsoft.com/v1.0/users',
                params={
                    '$select': 'id,displayName,mail,userPrincipalName',
                    '$filter': f"mail eq '{escaped_email}' or userPrincipalName eq '{escaped_email}'",
                    '$top': '2',
                },
            )
            filter_matches = filter_payload.get('value') or []
            if len(filter_matches) == 1 and filter_matches[0].get('id'):
                return filter_matches[0]

        search_terms = []
        if display_name:
            search_terms.append(display_name)
            if ',' in display_name:
                last_name, first_name = [part.strip() for part in display_name.split(',', 1)]
                if first_name and last_name:
                    search_terms.append(f'{first_name} {last_name}')

        for search_term in search_terms:
            search_payload = _request(
                'https://graph.microsoft.com/v1.0/users',
                params={
                    '$select': 'id,displayName,mail,userPrincipalName',
                    '$search': f'"displayName:{search_term}"',
                    '$top': '5',
                    '$count': 'true',
                },
                headers={'ConsistencyLevel': 'eventual'},
            )
            search_matches = search_payload.get('value') or []
            normalized_term = search_term.casefold()
            exact_matches = [
                match for match in search_matches
                if str(match.get('displayName') or '').strip().casefold() == normalized_term
            ]
            if len(exact_matches) == 1 and exact_matches[0].get('id'):
                return exact_matches[0]
            if len(search_matches) == 1 and search_matches[0].get('id'):
                return search_matches[0]

        return None

    def create_graph_chatroom(self, issue_key, issue_severity, issue_summary, member_candidates):
        access_token = self.get_graph_access_token_for_chatroom()
        resolved_members = []
        unresolved_candidates = []
        for participant_candidate in member_candidates:
            resolved_user = self.lookup_graph_user(access_token, participant_candidate)
            if not resolved_user:
                unresolved_candidates.append(participant_candidate)
                continue
            resolved_members.append(
                {
                    'id': resolved_user.get('id') or '',
                    'email': (resolved_user.get('mail') or resolved_user.get('userPrincipalName') or participant_candidate.get('email') or '').strip(),
                    'display_name': (resolved_user.get('displayName') or participant_candidate.get('display_name') or '').strip(),
                }
            )

        chat_type = 'group' if len(resolved_members) > 2 else 'oneOnOne'
        members_payload = []
        for resolved_member in resolved_members:
            if not resolved_member.get('id'):
                continue
            members_payload.append(
                {
                    '@odata.type': '#microsoft.graph.aadUserConversationMember',
                    'roles': ['owner'] if chat_type == 'group' else [],
                    "user@odata.bind": f"https://graph.microsoft.com/v1.0/users('{resolved_member['id']}')",
                }
            )

        if len(members_payload) < 2:
            unresolved_labels = []
            for candidate in unresolved_candidates:
                unresolved_labels.append(candidate.get('email') or candidate.get('display_name') or 'unknown user')
            raise ValueError('insufficient valid participants after Graph directory lookup: ' + ', '.join(unresolved_labels[:3]))

        payload = {
            'chatType': chat_type,
            'members': members_payload,
        }
        if chat_type == 'group':
            normalized_severity = (issue_severity or 'Severity Unknown').strip()
            normalized_summary = (issue_summary or 'No summary').strip()
            payload['topic'] = f'ACES IST | {normalized_severity} | {issue_key} | {normalized_summary}'[:250]

        response = requests.post(
            'https://graph.microsoft.com/v1.0/chats',
            json=payload,
            headers={
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json',
            },
            timeout=60,
        )
        response.raise_for_status()
        return response.json() or {}, resolved_members, unresolved_candidates

    @staticmethod
    def extract_issue_description_text(description_value):
        def _flatten(value):
            if value is None:
                return ''
            if isinstance(value, str):
                return value
            if isinstance(value, list):
                return ''.join(_flatten(entry) for entry in value)
            if not isinstance(value, dict):
                return str(value)

            node_type = (value.get('type') or '').strip()
            if node_type == 'hardBreak':
                return '\n'

            text_value = value.get('text') if isinstance(value.get('text'), str) else ''
            child_text = _flatten(value.get('content') or [])

            if node_type in {'paragraph', 'heading'}:
                combined_text = f'{text_value}{child_text}'.strip()
                return f'{combined_text}\n' if combined_text else ''
            if node_type == 'listItem':
                combined_text = f'{text_value}{child_text}'.strip()
                return f'- {combined_text}\n' if combined_text else ''

            return f'{text_value}{child_text}'

        flattened_text = _flatten(description_value)
        flattened_text = re.sub(r'\n{3,}', '\n\n', flattened_text)
        return flattened_text.strip()

    @staticmethod
    def build_graph_chatroom_message_payload(issue_key, issue_summary, issue_description, resolved_members):
        mentions = []
        mention_markup = []
        for index, member in enumerate(resolved_members):
            member_id = (member.get('id') or '').strip()
            if not member_id:
                continue
            display_name = (member.get('display_name') or member.get('email') or f'Member {index + 1}').strip()
            mention_markup.append(f'<at id="{len(mentions)}">{escape(display_name)}</at>')
            mentions.append(
                {
                    'id': len(mentions),
                    'mentionText': display_name,
                    'mentioned': {
                        'user': {
                            'id': member_id,
                            'displayName': display_name,
                            'userIdentityType': 'aadUser',
                        }
                    },
                }
            )

        normalized_summary = (issue_summary or 'No summary').strip()
        normalized_description = (issue_description or 'No description available in iTrack.').strip()
        description_html = escape(normalized_description).replace('\n', '<br>')

        content_parts = []
        if mention_markup:
            content_parts.append(' '.join(mention_markup))
        content_parts.append(f'New CR created for {escape(issue_key)} Please review')
        content_parts.append(f'<strong>Summary:</strong> {escape(normalized_summary)}')
        content_parts.append(f'<strong>Description:</strong><br>{description_html}')

        return {
            'body': {
                'contentType': 'html',
                'content': '<br><br>'.join(content_parts),
            },
            'mentions': mentions,
        }

    def post_graph_chatroom_message(self, chat_id, issue_key, issue_summary, issue_description, resolved_members):
        payload = self.build_graph_chatroom_message_payload(
            issue_key,
            issue_summary,
            issue_description,
            resolved_members,
        )
        response = requests.post(
            f'https://graph.microsoft.com/v1.0/chats/{quote(chat_id)}/messages',
            json=payload,
            headers={
                'Authorization': f'Bearer {self.get_graph_access_token_for_chatroom()}',
                'Content-Type': 'application/json',
            },
            timeout=60,
        )
        response.raise_for_status()
        return response.json()

    @staticmethod
    def parse_graph_datetime(value):
        normalized_value = str(value or '').strip()
        if not normalized_value:
            return None
        try:
            return datetime.fromisoformat(normalized_value.replace('Z', '+00:00'))
        except ValueError:
            return None

    @staticmethod
    def strip_html_text(value):
        normalized_value = unescape(str(value or ''))
        normalized_value = re.sub(r'<br\s*/?>', '\n', normalized_value, flags=re.IGNORECASE)
        normalized_value = re.sub(r'</p\s*>', '\n', normalized_value, flags=re.IGNORECASE)
        normalized_value = re.sub(r'<[^>]+>', ' ', normalized_value)
        normalized_value = normalized_value.replace('\xa0', ' ')
        normalized_value = re.sub(r'\r\n?', '\n', normalized_value)
        normalized_value = re.sub(r'\n{3,}', '\n\n', normalized_value)
        normalized_value = re.sub(r'[ \t]{2,}', ' ', normalized_value)
        return normalized_value.strip()

    @staticmethod
    def truncate_text(value, max_length=220):
        normalized_value = str(value or '').strip()
        if len(normalized_value) <= max_length:
            return normalized_value
        return normalized_value[: max_length - 3].rstrip() + '...'

    def list_graph_chat_messages(self, chat_id, since_datetime=None):
        access_token = self.get_graph_access_token_for_chatroom()
        request_url = f'https://graph.microsoft.com/v1.0/chats/{quote(chat_id)}/messages?$top=50'
        messages = []

        while request_url:
            response = requests.get(
                request_url,
                headers={'Authorization': f'Bearer {access_token}'},
                timeout=60,
            )
            response.raise_for_status()
            payload = response.json() or {}
            for message in payload.get('value') or []:
                created_at = self.parse_graph_datetime(message.get('createdDateTime'))
                if since_datetime and created_at and created_at < since_datetime:
                    continue
                body_text = self.strip_html_text(((message.get('body') or {}).get('content') or ''))
                if not body_text:
                    continue
                if str(message.get('messageType') or '').strip().casefold() not in {'', 'message', 'unknownfuturevalue'}:
                    continue
                from_user = ((message.get('from') or {}).get('user') or {})
                sender_name = (from_user.get('displayName') or from_user.get('id') or 'Unknown').strip()
                messages.append(
                    {
                        'created_at': created_at,
                        'sender': sender_name,
                        'text': body_text,
                    }
                )

            request_url = payload.get('@odata.nextLink')

        messages.sort(key=lambda item: item.get('created_at') or datetime.min.replace(tzinfo=timezone.utc))
        return messages

    @staticmethod
    def build_chat_history_comment(issue_key, message_entries, window_start, window_end):
        participants = []
        seen_participants = set()
        summarized_lines = []
        for message_entry in message_entries:
            sender_name = str(message_entry.get('sender') or 'Unknown').strip()
            normalized_sender = sender_name.casefold()
            if normalized_sender and normalized_sender not in seen_participants:
                participants.append(sender_name)
                seen_participants.add(normalized_sender)

            created_at = message_entry.get('created_at')
            timestamp_text = created_at.astimezone(timezone.utc).strftime('%Y-%m-%d %H:%M UTC') if created_at else 'Unknown time'
            summarized_lines.append(
                f'- [{timestamp_text}] {sender_name}: {OperationsFeature.truncate_text(message_entry.get("text") or "")}'
            )

        participant_text = ', '.join(participants[:8]) if participants else 'No named participants captured'
        if len(participants) > 8:
            participant_text += ', ...'

        comment_lines = [
            f'ACES IST Chatroom History Summary for {issue_key}',
            f'Window: {window_start.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")} to {window_end.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")}',
            f'Active participants: {participant_text}',
            f'Total messages captured: {len(message_entries)}',
            '',
            'Conversation summary:',
        ]
        comment_lines.extend(summarized_lines[:12])
        if len(summarized_lines) > 12:
            comment_lines.append(f'- Additional messages omitted: {len(summarized_lines) - 12}')
        return '\n'.join(comment_lines).strip()

    @staticmethod
    def extract_bad_graph_member(response_text):
        if not response_text:
            return ''
        match = re.search(r"user principal name '([^']+)'", response_text, re.IGNORECASE)
        if not match:
            return ''
        return match.group(1).strip().strip(';,')

    def run_chatroom(self, chatroom_id):
        chatroom = self.get_chatroom_definition(chatroom_id)
        if chatroom is None or not chatroom.get('action'):
            return False, 'Chatroom workflow is not configured.'
        try:
            return True, getattr(self, chatroom['action'])()
        except ValueError as error:
            return False, str(error)
        except requests.HTTPError as error:
            if getattr(error, 'response', None) is not None:
                response_text = (error.response.text or '').strip()
                if response_text:
                    return False, f'{chatroom["title"]} failed: {response_text[:300]}'
            return False, f'{chatroom["title"]} failed: {error}'

    @staticmethod
    def build_self_heal_email_preview(
        subject,
        intro_text,
        column_labels,
        row_values,
        support_contact_email='dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com',
        to_recipients=None,
        signature_label='ACC Prod DM',
    ):
        if not row_values:
            return None

        linkable_key_columns = {'key', 'cdex#'}
        header_cells = ''.join(
            f'<th style="background-color:#009fdb;color:#ffffff;padding:10px 12px;border:1px solid #cbd5e1;text-align:left;">{escape(label)}</th>'
            for label in column_labels
        )

        def render_cell(column_index, value):
            normalized_value = '' if value is None else str(value)
            cell_content = escape(normalized_value)
            if column_index < len(column_labels):
                normalized_label = str(column_labels[column_index]).strip().casefold()
                if normalized_label in linkable_key_columns and normalized_value.strip():
                    issue_key = normalized_value.strip()
                    issue_url = f'https://itrack.web.att.com/browse/{issue_key}'
                    cell_content = (
                        f'<a href="{escape(issue_url, quote=True)}" '
                        'style="color:#0a66c2;text-decoration:none;font-weight:600;">'
                        f'{escape(issue_key)}</a>'
                    )
            return f'<td style="padding:8px 10px;border:1px solid #cbd5e1;">{cell_content}</td>'

        body_rows = ''.join(
            '<tr>'
            + ''.join(
                render_cell(column_index, value)
                for column_index, value in enumerate(row)
            )
            + '</tr>'
            for row in row_values
        )
        normalized_support_contact_email = (support_contact_email or 'dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com').strip()
        resolved_to_recipients = list(to_recipients or [normalized_support_contact_email])
        bot_note_html = (
            '<div style="margin-top:24px; margin-bottom:8px; color:#0f0202; font-size:14px;">'
            'Note: This is a BOT generated email, kindly reach out to '
            f'<a href="mailto:{escape(normalized_support_contact_email, quote=True)}">{escape(normalized_support_contact_email)}</a> for any questions.</div>'
        )
        return {
            'subject': subject,
            'html_body': (
                '<html><body style="font-family:Segoe UI,Arial,sans-serif;color:#0f172a;">'
                '<p>Hello Team,</p>'
                f'<p>{escape(intro_text)}</p>'
                '<table style="border-collapse:collapse;width:100%;max-width:920px;font-family:Segoe UI,Arial,sans-serif;font-size:13px;">'
                f'<thead><tr>{header_cells}</tr></thead>'
                f'<tbody>{body_rows}</tbody>'
                '</table>'
                f'{bot_note_html}'
                f'<p style="margin-top:16px;">Regards,<br/>{escape(signature_label)}</p>'
                '</body></html>'
            ),
            'to_recipients': resolved_to_recipients,
            'cc_recipients': [],
        }

    @staticmethod
    def stringify_select_value(value):
        if value is None:
            return ''
        if isinstance(value, dict):
            return (value.get('value') or value.get('name') or '').strip()
        return str(value).strip()

    def run_operation(self, operation_id):
        operation = self.get_operation_definition(self.get_selected_application(), operation_id)
        action_name = operation['action']
        if action_name is None:
            return False, f"{operation['title']} is not configured yet."
        try:
            return True, getattr(self, action_name)()
        except ValueError as error:
            return False, str(error)
        except requests.HTTPError as error:
            if getattr(error, 'response', None) is not None and error.response.status_code == 401:
                self.clear_session_credentials()
            return False, self.format_http_error_message(operation['title'], error)
        except requests.RequestException as error:
            return False, f"{operation['title']} failed while pulling data from Jira/iTrack: {error}"
        except Exception as error:
            return False, f"{operation['title']} failed: {error}"

    def run_custom_email_operation(self, email_cfg):
        """Run a custom trigger email configured via the chatbot."""
        from shared.release_open_defects import (
            build_defects_email_preview, export_defects, stringify_field_value,
            parse_severity_level, parse_age_days,
        )
        from operations.ops_chat import AVAILABLE_ITRACK_FIELDS
        title = email_cfg.get('name', 'Custom Email')
        jql = email_cfg.get('jql', '')
        if not jql:
            return False, f"{title}: No JQL query configured."
        credentials = self._credentials()
        table_columns = email_cfg.get('table_columns') or None
        column_fields = email_cfg.get('table_column_fields') or None

        # Merge any persisted custom field mappings into the lookup
        field_lookup = dict(AVAILABLE_ITRACK_FIELDS)
        custom_map = email_cfg.get('custom_field_map') or {}
        field_lookup.update(custom_map)

        # Determine if we have any custom Jira field IDs (non-integer mappings)
        has_custom_jira_fields = False
        if column_fields:
            for fn in column_fields:
                mapping = field_lookup.get(fn)
                if isinstance(mapping, str):
                    has_custom_jira_fields = True
                    break

        # Build a row_transform that picks the right indices based on the
        # configured iTrack field mapping
        row_transform = None
        if column_fields and not has_custom_jira_fields:
            indices = []
            for field_name in column_fields:
                idx = field_lookup.get(field_name)
                if idx is not None:
                    indices.append(idx)
            if indices:
                row_transform = lambda row, _idx=indices: [row[i] for i in _idx]

        workbook_stream, filename, issue_count, issue_rows, issues = export_defects(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            header_titles=table_columns,
            row_transform=row_transform,
        )

        # If custom Jira fields are present, rebuild rows from raw issues
        if has_custom_jira_fields and issues and column_fields:
            custom_rows = []
            for issue, base_row in zip(issues, issue_rows):
                new_row = []
                fields_data = issue.get('fields') or {}
                for fn in column_fields:
                    mapping = field_lookup.get(fn)
                    if isinstance(mapping, int):
                        new_row.append(base_row[mapping] if mapping < len(base_row) else '')
                    elif isinstance(mapping, str):
                        new_row.append(stringify_field_value(fields_data.get(mapping, '')))
                    else:
                        new_row.append('')
                custom_rows.append(new_row)
            issue_rows = custom_rows

        # Sort by severity (ascending: Sev 1 first) then age (descending: oldest first)
        if issues and issue_rows:
            from shared.release_open_defects import resolve_issue_severity as _sev
            paired = list(zip(issue_rows, issues))
            def _sort_key(pair):
                row, issue = pair
                fields_data = issue.get('fields') or {}
                sev = parse_severity_level(_sev(fields_data))
                if sev is None:
                    sev = 999
                created_str = stringify_field_value(fields_data.get('created', ''))
                age = 0
                if len(created_str) >= 10:
                    try:
                        from datetime import datetime as _dt
                        age = (_dt.utcnow() - _dt.strptime(created_str[:10], '%Y-%m-%d')).days
                    except ValueError:
                        pass
                return (sev, -age)
            paired.sort(key=_sort_key)
            issue_rows = [p[0] for p in paired]
            issues = [p[1] for p in paired]

        workbook_bytes = workbook_stream.getvalue()
        to_recipients = email_cfg.get('to', [])
        if to_recipients == ['__dynamic__']:
            to_recipients = None  # let build_defects_email_preview resolve from assignees
        cc_recipients = email_cfg.get('cc', []) or []
        email_preview = build_defects_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
            subject=email_cfg.get('subject', title),
            summary_text=email_cfg.get('body', ''),
            empty_state_message=f"No defects were returned for {title}.",
            include_summary_section=False,
            header_titles=table_columns,
            to_recipients=to_recipients if to_recipients else None,
            cc_recipients=cc_recipients if cc_recipients else None,
            closing_signature_html=email_cfg.get('closing_signature', '') or None,
            from_address=email_cfg.get('from_address') or None,
        )
        self.cache_last_generated_artifact(title, workbook_bytes, filename, email_preview, jql=jql)
        return True, self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def _credentials(self):
        credentials = self.get_session_credentials()
        if credentials is None:
            raise ValueError('Log in with your Jira/iTrack credentials to run this operation.')
        return credentials

    def _jql_overrides(self):
        return self.build_jql_overrides(self.get_selected_application(), self.get_selected_release())

    @staticmethod
    def _preview_ready_message(base_message):
        return f'{base_message} Email preview is ready. Use Send Email to deliver it.'

    def download_release_open_defects(self):
        credentials = self._credentials()
        workbook_stream, filename, issue_count, issue_rows, issues = export_release_open_defects(
            jql=self._jql_overrides()['release-open-defects'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_release_open_defects_email_preview(issue_rows, filename=filename, issues=issues)
        self.cache_last_generated_artifact('Release Open Defects', workbook_bytes, filename, email_preview, jql=self._jql_overrides()['release-open-defects'])
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_progression_open_defects(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues, header_titles = export_progression_open_defects(
            open_jql=jql_overrides['release-open-defects-progression-dm-comments'],
            resolved_today_jql=jql_overrides['progression-open-resolved-today'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_progression_open_defects_email_preview(issue_rows, filename=filename, issues=issues, header_titles=header_titles)
        self.cache_last_generated_artifact('Progression Open Defects', workbook_bytes, filename, email_preview, jql=jql_overrides['release-open-defects-progression-dm-comments'])
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_regression_open_defects(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues, header_titles = export_regression_open_defects(
            open_jql=jql_overrides['release-open-defects-regression-dm-comments'],
            resolved_today_jql=jql_overrides['regression-open-resolved-today'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_regression_open_defects_email_preview(issue_rows, filename=filename, issues=issues, header_titles=header_titles)
        self.cache_last_generated_artifact('Regression Open Defects', workbook_bytes, filename, email_preview, jql=jql_overrides['release-open-defects-regression-dm-comments'])
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_eta_slipped_defects(self):
        credentials = self._credentials()
        workbook_stream, filename, issue_count, issue_rows, issues = export_eta_slipped_defects(
            jql=self._jql_overrides()['eta-slipped-defects'],
            max_results=None,  # Use the new default (200)
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_eta_slipped_defects_email_preview(issue_rows, filename=filename, issues=issues)
        self.cache_last_generated_artifact('ETA Slipped Defects', workbook_bytes, filename, email_preview, jql=self._jql_overrides()['eta-slipped-defects'])
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_blocking_field_empty_defects(self):
        credentials = self._credentials()
        selected_application = self.get_selected_application()
        jql_used = self._jql_overrides()['blocking-field-empty-defects']
        if selected_application == 'ACC-Prod':
            workbook_stream, filename, issue_count, issue_rows, issues = export_past_dated_fix_version_defects(
                jql=jql_used,
                username=credentials['username'],
                password=credentials['password'],
            )
            email_preview = build_past_dated_fix_version_defects_email_preview(issue_rows, filename=filename, issues=issues)
            operation_title = ACC_PROD_PAST_DATED_FIX_VERSION_TITLE
        else:
            workbook_stream, filename, issue_count, issue_rows, issues = export_blocking_field_empty_defects(
                jql=jql_used,
                username=credentials['username'],
                password=credentials['password'],
            )
            email_preview = build_blocking_field_empty_defects_email_preview(issue_rows, filename=filename, issues=issues)
            operation_title = self.get_operation_definition(selected_application, 'blocking-field-empty')['title']
        workbook_bytes = workbook_stream.getvalue()
        self.cache_last_generated_artifact(operation_title, workbook_bytes, filename, email_preview, jql=jql_used)
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_retest_defects(self):
        credentials = self._credentials()
        selected_application = self.get_selected_application()
        jql_overrides = self._jql_overrides()
        if selected_application == 'ACC-Prod':
            workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_retest_defects(
                jql=jql_overrides['release-open-defects-retest'],
                username=credentials['username'],
                password=credentials['password'],
            )
        else:
            workbook_stream, filename, issue_count, issue_rows, issues = export_retest_defects(
                jql=jql_overrides['release-open-defects-retest'],
                username=credentials['username'],
                password=credentials['password'],
            )
        workbook_bytes = workbook_stream.getvalue()
        cc_recipients = None
        if selected_application == 'ACC-Prod':
            cc_recipients = parse_recipient_entries(ACC_PROD_RETURN_REJECT_CC_RECIPIENTS)
        email_preview = build_retest_defects_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
            cc_recipients=cc_recipients,
            is_acc_prod=(selected_application == 'ACC-Prod'),
        )
        self.cache_last_generated_artifact('Retest/Test Complete/Dev Complete Defects', workbook_bytes, filename, email_preview, jql=jql_overrides.get('release-open-defects-retest'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_return_reject_defects(self):
        credentials = self._credentials()
        selected_application = self.get_selected_application()
        jql_overrides = self._jql_overrides()
        if selected_application == 'ACC-Prod':
            workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_return_reject_defects(
                jql=jql_overrides['release-open-defects-return-rejected'],
                username=credentials['username'],
                password=credentials['password'],
            )
        else:
            workbook_stream, filename, issue_count, issue_rows, issues = export_return_reject_defects(
                jql=jql_overrides['release-open-defects-return-rejected'],
                username=credentials['username'],
                password=credentials['password'],
            )
        workbook_bytes = workbook_stream.getvalue()
        cc_recipients = None
        if selected_application == 'ACC-Prod':
            cc_recipients = parse_recipient_entries(ACC_PROD_RETURN_REJECT_CC_RECIPIENTS)
        email_preview = build_return_reject_defects_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
            cc_recipients=cc_recipients,
            is_acc_prod=(selected_application == 'ACC-Prod'),
        )
        self.cache_last_generated_artifact('Return/Reject Defects', workbook_bytes, filename, email_preview, jql=jql_overrides.get('release-open-defects-return-rejected'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_new_defects_created(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_new_defects_created(
            jql=jql_overrides['new-defects-created'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_acc_prod_new_defects_created_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
        )
        self.cache_last_generated_artifact('New Defects Created', workbook_bytes, filename, email_preview, jql=jql_overrides.get('new-defects-created'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_missing_order_impact(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_missing_order_impact(
            jql=jql_overrides['missing-order-impact'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_acc_prod_missing_order_impact_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
        )
        self.cache_last_generated_artifact('Missing Order Impact value (For Shop/Purchase ARTs)', workbook_bytes, filename, email_preview, jql=jql_overrides.get('missing-order-impact'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_pilot_defects_wls(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_pilot_defects_wls(
            jql=jql_overrides['pilot-defects-wls'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_acc_prod_pilot_defects_wls_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
        )
        self.cache_last_generated_artifact('Pilot Defects (WLS)', workbook_bytes, filename, email_preview, jql=jql_overrides.get('pilot-defects-wls'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_out_of_sla_sales(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_out_of_sla_sales(
            jql=jql_overrides['out-of-sla-sales'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_acc_prod_out_of_sla_sales_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
        )
        self.cache_last_generated_artifact('Out of SLA (Sales)', workbook_bytes, filename, email_preview, jql=jql_overrides.get('out-of-sla-sales'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_out_of_sla_non_sales(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues = export_acc_prod_out_of_sla_non_sales(
            jql=jql_overrides['out-of-sla-non-sales'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_acc_prod_out_of_sla_non_sales_email_preview(
            issue_rows,
            filename=filename,
            issues=issues,
        )
        self.cache_last_generated_artifact('Out of SLA (Non-Sales)', workbook_bytes, filename, email_preview, jql=jql_overrides.get('out-of-sla-non-sales'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def download_not_an_application_requesting_review(self):
        credentials = self._credentials()
        jql_overrides = self._jql_overrides()
        workbook_stream, filename, issue_count, issue_rows, issues = export_not_an_application_requesting_review_defects(
            jql=jql_overrides['not-an-application-requesting-review'],
            username=credentials['username'],
            password=credentials['password'],
        )
        workbook_bytes = workbook_stream.getvalue()
        email_preview = build_not_an_application_requesting_review_email_preview(issue_rows, filename=filename, issues=issues)
        self.cache_last_generated_artifact('Not An Application Requesting Review', workbook_bytes, filename, email_preview, jql=jql_overrides.get('not-an-application-requesting-review'))
        return self._preview_ready_message(f'Data exported ({issue_count} defects) successfully.')

    def run_progression_regression_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['progression-regression']
        updated_issues = self_heal_progression_regression_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Progression/Regression Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Progression/Regression Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Progression/Regression.',
                    ['CDEX#', 'Updated Value'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Progression/Regression for {len(updated_issues)} defects successfully.'
            )
        # Always cache the JQL, even if no updates
        self.cache_last_generated_artifact(
            'Progression/Regression Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No defects with blank Progression/Regression required updates.'

    def run_tribe_label_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['tribe-label']
        updated_issues = self_heal_tribe_label_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Tribe-Label Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Tribe-Label Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Tribe-Label.',
                    ['CDEX#', 'Reporter', 'Added Label', 'Mapping Source'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Tribe label for {len(updated_issues)} defects successfully.'
            )
        # Always cache the JQL, even if no updates
        self.cache_last_generated_artifact(
            'Tribe-Label Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No defects required Tribe label updates.'

    def run_assigned_to_team_testing_vs_assignee_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['assigned-to-team-testing-vs-assignee']
        updated_issues = self_heal_assigned_to_team_testing_vs_assignee_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Assigned To Team Testing vs Assignee Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Assigned To Team Testing vs Assignee Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Assigned To Team: Testing > Assignee: Update to Reporter.',
                    ['CDEX#', 'Previous Assignee', 'Reporter / New Assignee'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Assignee from Reporter for {len(updated_issues)} defects successfully.'
            )
        # Always cache the JQL, even if no updates
        self.cache_last_generated_artifact(
            'Assigned To Team Testing vs Assignee Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No Testing-team defects required Assignee updates.'

    def run_assigned_to_team_testing_status_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['assigned-to-team-testing-status']
        updated_issues = self_heal_assigned_to_team_testing_status_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            add_bot_comment=True,
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Assigned To Team Testing Status Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Assigned To Team Testing Status Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Return/Rejected or Retest or Test Blocked Defects > Assigned to Team: Update to Testing.',
                    ['CDEX#', 'Previous Assigned to Team', 'Updated Assigned to Team', 'Status'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Assigned to Team to Testing for {len(updated_issues)} defects successfully.'
            )
        # Always cache the JQL, even if no updates
        self.cache_last_generated_artifact(
            'Assigned To Team Testing Status Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No Return/Rejected, Retest, or Testing Blocked defects required Assigned to Team updates.'

    def run_acc_prod_assigned_to_team_testing_status_self_heal(self):
        credentials = self._credentials()
        updated_issues = self_heal_assigned_to_team_testing_status_fields(
            jql=self._jql_overrides()['assigned-to-team-testing-status-acc-prod'],
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Status: Retest or Test Blocked > Assigned to Team: Update to Testing',
            add_bot_comment=True,
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Assigned To Team Testing Status Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Assigned To Team Testing Status Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Retest or Test Blocked Defects > Assigned to Team: Update to Testing.',
                    ['CDEX#', 'Previous Assigned to Team', 'Updated Assigned to Team', 'Status'],
                    updated_issues,
                ),
                jql=self._jql_overrides()['assigned-to-team-testing-status-acc-prod']
            )
            return self._preview_ready_message(
                f'Updated Assigned to Team to Testing for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Assigned To Team Testing Status Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=self._jql_overrides()['assigned-to-team-testing-status-acc-prod']
        )
        return 'No Retest or Test Blocked ACC-Prod defects required Assigned to Team updates.'

    def run_acc_prod_assigned_to_team_triage_status_self_heal(self):
        credentials = self._credentials()
        updated_issues = self_heal_assigned_to_team_testing_status_fields(
            jql=self._jql_overrides()['assigned-to-team-triage-status-acc-prod'],
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Status: Return/Rejected > Assigned to Team: Update to Triage',
            target_assigned_to_team_value='Triage',
            protected_current_values=('TIER 1', 'Business', 'Production Support'),
            add_bot_comment=True,
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Assigned To Team Triage Status Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Assigned To Team Triage Status Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Return/Rejected Defects > Assigned to Team: Update to Triage.',
                    ['CDEX#', 'Previous Assigned to Team', 'Updated Assigned to Team', 'Status'],
                    updated_issues,
                ),
                jql=self._jql_overrides()['assigned-to-team-triage-status-acc-prod']
            )
            return self._preview_ready_message(
                f'Updated Assigned to Team to Triage for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Assigned To Team Triage Status Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=self._jql_overrides()['assigned-to-team-triage-status-acc-prod']
        )
        return 'No Return/Rejected ACC-Prod defects required Assigned to Team updates.'

    def run_acc_prod_application_fixed_in_root_cause_app_sync_self_heal(self):
        credentials = self._credentials()
        updated_issues = self_heal_application_fixed_in_matches_root_cause_app_fields(
            jql=self._jql_overrides()['application-fixed-in-root-cause-app-sync-acc-prod'],
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Status: Application Fixed in : Root Cause App in Sync',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Application Fixed In Root Cause App Sync Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Application Fixed In Root Cause App Sync Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Application Fixed In matching Root Cause App.',
                    ['CDEX#', 'Previous Application Fixed In', 'Updated Application Fixed In', 'Status'],
                    updated_issues,
                ),
                jql=self._jql_overrides()['application-fixed-in-root-cause-app-sync-acc-prod']
            )
            return self._preview_ready_message(
                f'Updated Application Fixed In from Root Cause App for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Application Fixed In Root Cause App Sync Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=self._jql_overrides()['application-fixed-in-root-cause-app-sync-acc-prod']
        )
        return 'No matching ACC-Prod defects required Application Fixed In updates.'

    def run_acc_prod_assigned_to_team_business_application_fixed_in_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['assigned-to-team-business-application-fixed-in-acc-prod']
        updated_issues = self_heal_application_fixed_in_for_business_team_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Assigned to Team: Business > Update Application Fixed In',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Assigned To Team Business Application Fixed In Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Assigned To Team Business Application Fixed In Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Assigned to Team: Business > Update Application Fixed In.',
                    ['CDEX#', 'Previous Application Fixed In', 'Updated Application Fixed In', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Application Fixed In to Not An Application for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Assigned To Team Business Application Fixed In Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod Business-team defects required Application Fixed In updates.'

    def run_acc_prod_assigned_to_team_production_support_application_fixed_in_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['assigned-to-team-production-support-application-fixed-in-acc-prod']
        updated_issues = self_heal_application_fixed_in_for_business_team_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Assigned to Team: Production Support > Update Application Fixed In',
            target_assigned_to_team_value='Production Support',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Assigned To Team Production Support Application Fixed In Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Assigned To Team Production Support Application Fixed In Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Assigned to Team: Production Support > Update Application Fixed In.',
                    ['CDEX#', 'Previous Application Fixed In', 'Updated Application Fixed In', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Application Fixed In to Not An Application for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Assigned To Team Production Support Application Fixed In Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod Production Support-team defects required Application Fixed In updates.'

    def run_acc_prod_assigned_to_team_triage_update_assignee_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['assigned-to-team-triage-update-assignee-acc-prod']
        updated_issues = self_heal_acc_prod_assigned_to_triage_update_assignee_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Assigned to Team: Triage > Update Assignee',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Assigned To Team Triage Update Assignee Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Assigned To Team Triage Update Assignee Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Assigned to Team: Triage > Update Assignee.',
                    ['CDEX#', 'Previous Assignee', 'Updated Assignee', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Assignee for {len(updated_issues)} ACC-Prod triage defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Assigned To Team Triage Update Assignee Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod triage defects required Assignee updates.'

    def run_acc_prod_bug_issue_conversion_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['bug-issue-conversion-acc-prod']
        updated_issues = self_heal_bug_issue_conversion_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Bug/Issue Conversion',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Bug Issue Conversion Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Bug Issue Conversion Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Bug/Issue Conversion.',
                    ['CDEX#', 'Previous Defect Type', 'Updated Defect Type', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Defect Type to Bug/Issue for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Bug Issue Conversion Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod defects required Bug/Issue conversion updates.'

    def run_acc_prod_customer_impact_less_update_severity_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['customer-impact-less-update-severity-acc-prod']
        updated_issues = self_heal_customer_impact_less_update_severity_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Customer Impact Less : Update Severity',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Customer Impact Less Update Severity Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Customer Impact Less Update Severity Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Customer Impact Less : Update Severity.',
                    ['CDEX#', 'Previous Severity', 'Updated Severity', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Severity to Severity 4 for {len(updated_issues)} ACC-Prod defects successfully.'
            )
        self.cache_last_generated_artifact(
            'ACC Prod Customer Impact Less Update Severity Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod defects required Severity updates for Customer Impact Less.'

    def run_acc_prod_non_monitoring_pilot_sev4_label_addition_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['non-monitoring-pilot-sev4-label-addition-acc-prod']
        issues = fetch_open_defects(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            fields=['labels', 'status'],
            expand='names',
        )

        updated_issues = []
        for issue in issues:
            issue_key = issue.get('key', '')
            fields = issue.get('fields') or {}
            current_labels = fields.get('labels') or []
            normalized_labels = {str(label).strip().casefold() for label in current_labels}
            if 'cqe_prod_agentnm' in normalized_labels:
                continue

            update_issue_labels(
                issue_key,
                current_labels,
                ['CQE_PROD_AgentNM'],
                username=credentials['username'],
                password=credentials['password'],
            )
            add_issue_comment(
                issue_key,
                'Updates Done by BOT: Add Non Monitoring/Pilot Sev4 Defects: Label Addition',
                username=credentials['username'],
                password=credentials['password'],
            )
            updated_issues.append(
                (
                    issue_key,
                    ', '.join(str(label) for label in current_labels) or 'None',
                    'CQE_PROD_AgentNM',
                    ((fields.get('status') or {}).get('name') or ''),
                )
            )

        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Non Monitoring Pilot Sev4 Defects Label Addition Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Non Monitoring/Pilot Sev4 Defects Label Addition Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Non Monitoring/Pilot Sev4 Defects: Label Addition.',
                    ['CDEX#', 'Existing Labels', 'Added Label', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Added CQE_PROD_AgentNM label for {len(updated_issues)} ACC-Prod defects successfully.'
            )

        self.cache_last_generated_artifact(
            'ACC Prod Non Monitoring Pilot Sev4 Defects Label Addition Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod defects required CQE_PROD_AgentNM label updates.'

    def run_acc_prod_update_est_retest_date_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['update-est-retest-date-acc-prod']
        updated_issues = self_heal_update_est_retest_date_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
            operation_label='Update EST Retest Date',
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'ACC Prod Update EST Retest Date Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'ACC Prod Update EST Retest Date Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Update EST Retest Date.',
                    ['CDEX#', 'Previous EST Fix Date', 'Updated EST Fix Date', 'Status'],
                    updated_issues,
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated EST Fix Date for {len(updated_issues)} ACC-Prod defects successfully.'
            )

        self.cache_last_generated_artifact(
            'ACC Prod Update EST Retest Date Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No ACC-Prod defects required EST Retest Date updates.'

    def run_application_fixed_in_cqe_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['application-fixed-in-cqe']
        updated_issues = self_heal_application_fixed_in_cqe_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Application Fixed In CQE Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Application Fixed In CQE Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Application Fixed In: CQE & Status = Accepted/Cancelled.',
                    ['CDEX#', 'Previous Application Fixed In', 'Updated Application Fixed In', 'Status'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Updated Application Fixed In for {len(updated_issues)} defects successfully.'
            )
        # Always cache the JQL, even if no updates
        self.cache_last_generated_artifact(
            'Application Fixed In CQE Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No Accepted or Cancelled CQE defects required Application Fixed In updates.'

    def run_application_fixed_in_cqe_revert_to_previous_self_heal(self):
        credentials = self._credentials()
        jql = self._jql_overrides()['application-fixed-in-cqe-revert']
        updated_issues = self_heal_application_fixed_in_cqe_revert_to_previous_fields(
            jql=jql,
            username=credentials['username'],
            password=credentials['password'],
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Application Fixed In CQE Revert Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Application Fixed In CQE Revert Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Application Fixed In: CQE & Status != Accepted/Cancelled.',
                    ['CDEX#', 'Current Application Fixed In', 'Updated Application Fixed In', 'Status'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
                jql=jql
            )
            return self._preview_ready_message(
                f'Reverted Application Fixed In to the previous value for {len(updated_issues)} defects successfully.'
            )
        # Always cache the JQL, even if no updates
        self.cache_last_generated_artifact(
            'Application Fixed In CQE Revert Self Heal',
            None,
            None,
            {'subject': '', 'html_body': '', 'to_recipients': [], 'cc_recipients': [], 'from_address': ''},
            jql=jql
        )
        return 'No matching CQE defects required Application Fixed In reversion.'

    def run_root_cause_app_matches_application_fixed_in_self_heal(self):
        credentials = self._credentials()
        updated_issues = self_heal_root_cause_app_matches_application_fixed_in_fields(
            jql=self._jql_overrides()['root-cause-app-matches-application-fixed-in'],
            username=credentials['username'],
            password=credentials['password'],
        )
        if updated_issues:
            self.cache_last_generated_artifact(
                'Root Cause App Matches Application Fixed In Self Heal',
                None,
                None,
                self.build_self_heal_email_preview(
                    'Root Cause App Matches Application Fixed In Self Heal Updates',
                    'The following CDEX defects were updated by the Self Heal iTrack Fields workflow for Root Cause App matching Application Fixed In.',
                    ['CDEX#', 'Previous Root Cause App', 'Updated Root Cause App', 'Status'],
                    updated_issues,
                    support_contact_email='dl-ATT_DM_ACES@intl.att.com',
                    to_recipients=['dl-ATT_DM_ACES@intl.att.com'],
                    signature_label='ACES IST',
                ),
            )
            return self._preview_ready_message(
                f'Updated Root Cause App from Application Fixed In for {len(updated_issues)} defects successfully.'
            )
        return 'No matching defects required Root Cause App updates.'

    def run_chatroom_history_to_itrack(self):
        credentials = self._credentials()
        registry = self.load_chatroom_registry()
        selected_release = self.get_selected_release()
        now = datetime.now(timezone.utc)
        default_window_start = now - timedelta(hours=24)
        active_chatroom_count = 0
        updated_issue_count = 0
        skipped_issue_entries = []
        failed_issue_entries = []

        for issue_key, registry_entry in (registry or {}).items():
            if issue_key == '_meta' or not isinstance(registry_entry, dict):
                continue
            if selected_release and (registry_entry.get('release_name') or '').strip() != selected_release:
                continue

            chat_id = (registry_entry.get('chat_id') or '').strip()
            if not chat_id:
                skipped_issue_entries.append(f'{issue_key}: missing chat id')
                continue

            last_synced_at = registry_entry.get('history_synced_at')
            try:
                last_synced_datetime = datetime.fromtimestamp(float(last_synced_at), tz=timezone.utc)
            except (TypeError, ValueError, OSError):
                last_synced_datetime = None
            window_start = max(default_window_start, last_synced_datetime) if last_synced_datetime else default_window_start

            try:
                message_entries = self.list_graph_chat_messages(chat_id, since_datetime=window_start)
            except requests.HTTPError as error:
                response_text = ''
                if getattr(error, 'response', None) is not None:
                    response_text = (error.response.text or '').strip()
                failed_issue_entries.append(f'{issue_key}: {response_text[:160] if response_text else error}')
                continue

            if not message_entries:
                skipped_issue_entries.append(f'{issue_key}: no active conversation in the last 24 hours')
                continue

            active_chatroom_count += 1
            comment_body = self.build_chat_history_comment(issue_key, message_entries, window_start, now)
            try:
                add_issue_comment(
                    issue_key,
                    comment_body,
                    username=credentials.get('username'),
                    password=credentials.get('password'),
                )
            except ValueError as error:
                failed_issue_entries.append(f'{issue_key}: {error}')
                continue

            registry_entry['history_synced_at'] = time.time()
            registry_entry['last_history_message_count'] = len(message_entries)
            updated_issue_count += 1

        registry.setdefault('_meta', {})
        registry['_meta']['last_checked_at'] = time.time()
        self.save_chatroom_registry(registry)

        message_parts = [
            f'Chatroom History to iTrack reviewed {active_chatroom_count} active chatrooms.',
            f'Posted summaries to {updated_issue_count} iTrack issues.',
        ]
        if skipped_issue_entries:
            message_parts.append(f'Skipped {len(skipped_issue_entries)} entries: ' + '; '.join(skipped_issue_entries[:3]))
        if failed_issue_entries:
            message_parts.append(f'Failed for {len(failed_issue_entries)} entries: ' + '; '.join(failed_issue_entries[:3]))
        if not active_chatroom_count and not failed_issue_entries:
            message_parts.append('No active ACES-IST chatroom conversations were found in the last 24 hours.')
        return ' '.join(message_parts)

    def run_chatroom_creation(self):
        if not self.is_graph_chat_configured():
            raise ValueError('Microsoft Graph chat creation is not configured. Set GRAPH_TENANT_ID and GRAPH_CLIENT_ID and retry.')

        credentials = self._credentials()
        registry = self.load_chatroom_registry()
        matching_issues = fetch_open_defects(
            jql=self._jql_overrides()['chatroom-creation'],
            max_results=CHATROOM_CREATION_MAX_RESULTS,
            username=credentials['username'],
            password=credentials['password'],
            fields=['summary', 'description', 'reporter', 'assignee', 'labels', 'created', 'customfield_10552', 'priority'],
            expand='names',
        )
        if not matching_issues:
            return 'Chatroom Creation found no To Do defects without the CR_Created label for the selected release.'

        tribe_lead_mapping = self.load_chatroom_tribe_lead_mapping()
        created_count = 0
        failed_entries = []
        skipped_member_entries = []
        initial_message_failures = []
        initial_message_permission_blocked = False
        abort_reason = ''

        for issue in matching_issues:
            issue_key = (issue or {}).get('key', '').strip()
            if not issue_key:
                continue

            fields = issue.get('fields') or {}
            participant_candidates, missing_roles = self.resolve_chatroom_participants(issue, tribe_lead_mapping)
            if len(participant_candidates) < 2:
                failed_entries.append(f'{issue_key}: insufficient participants')
                continue

            valid_participant_candidates = list(participant_candidates)
            skipped_members_for_issue = []
            try:
                while True:
                    if len(valid_participant_candidates) < 2:
                        failed_entries.append(f'{issue_key}: insufficient valid participants after removing unresolved members')
                        created_chat = None
                        break

                    try:
                        created_chat, resolved_members, unresolved_candidates = self.create_graph_chatroom(
                            issue_key,
                            resolve_issue_severity(fields),
                            fields.get('summary') or '',
                            valid_participant_candidates,
                        )
                        for unresolved_candidate in unresolved_candidates:
                            skipped_label = unresolved_candidate.get('email') or unresolved_candidate.get('display_name') or 'unknown user'
                            if skipped_label not in skipped_members_for_issue:
                                skipped_members_for_issue.append(skipped_label)
                        break
                    except ValueError as error:
                        failed_entries.append(f'{issue_key}: {error}')
                        created_chat = None
                        break
                    except requests.HTTPError as error:
                        response_text = ''
                        status_code = None
                        if getattr(error, 'response', None) is not None:
                            response_text = (error.response.text or '').strip()
                            status_code = error.response.status_code

                        if status_code in {401, 403}:
                            raise

                        bad_member = self.extract_bad_graph_member(response_text)
                        if bad_member and any((candidate.get('email') or '').casefold() == bad_member.casefold() for candidate in valid_participant_candidates):
                            valid_participant_candidates = [
                                candidate for candidate in valid_participant_candidates
                                if (candidate.get('email') or '').casefold() != bad_member.casefold()
                            ]
                            skipped_members_for_issue.append(bad_member)
                            continue

                        raise
            except requests.HTTPError as error:
                response_text = ''
                status_code = None
                if getattr(error, 'response', None) is not None:
                    response_text = (error.response.text or '').strip()
                    status_code = error.response.status_code
                failed_entries.append(f'{issue_key}: {response_text[:120] if response_text else error}')
                if status_code in {401, 403}:
                    abort_reason = 'Microsoft Graph rejected the chatroom creation request. Verify Chat.Create permission and app consent.'
                    break
                continue

            if created_chat is None:
                continue

            if skipped_members_for_issue:
                skipped_member_entries.append(
                    f"{issue_key}: skipped invalid members {', '.join(skipped_members_for_issue)}"
                )

            initial_message_error = ''
            try:
                self.post_graph_chatroom_message(
                    created_chat.get('id', ''),
                    issue_key,
                    fields.get('summary') or '',
                    self.extract_issue_description_text(fields.get('description')),
                    resolved_members,
                )
            except requests.HTTPError as error:
                response_text = ''
                if getattr(error, 'response', None) is not None:
                    response_text = (error.response.text or '').strip()
                initial_message_error = response_text[:180] if response_text else str(error)
                lowered_initial_message_error = initial_message_error.casefold()
                if 'missing role permissions' in lowered_initial_message_error or 'teamwork.migrate.all' in lowered_initial_message_error:
                    initial_message_permission_blocked = True
                initial_message_failures.append(f'{issue_key}: {initial_message_error}')

            registry[issue_key] = {
                'chat_id': created_chat.get('id', ''),
                'web_url': created_chat.get('webUrl', ''),
                'topic': created_chat.get('topic', ''),
                'participants': [member.get('email') or member.get('display_name') or '' for member in resolved_members],
                'skipped_members': list(skipped_members_for_issue),
                'release_name': self.get_selected_release(),
                'created_at': time.time(),
                'summary': fields.get('summary') or '',
                'missing_roles': list(missing_roles),
                'initial_message_error': initial_message_error,
            }

            try:
                update_issue_labels(
                    issue_key,
                    fields.get('labels') or [],
                    ['CR_Created'],
                    username=credentials['username'],
                    password=credentials['password'],
                )
            except ValueError as error:
                failed_entries.append(f'{issue_key}: {error}')
                abort_reason = 'Teams chat was created, but Jira/iTrack label update failed for at least one defect. Resolve the label update issue before rerunning to avoid duplicate chats.'
                break

            created_count += 1

        registry['_meta'] = {
            'last_run_completed_at': time.time(),
            'release_name': self.get_selected_release(),
        }
        self.save_chatroom_registry(registry)

        matched_count = len(matching_issues)
        message_parts = [
            f'Chatroom Creation matched {matched_count} defects.',
            f'Created {created_count} new Teams chatrooms.',
        ]
        message_parts.append('Selection is based on To Do defects that do not already carry the CR_Created label.')
        if skipped_member_entries:
            message_parts.append(
                f'Skipped invalid members for {len(skipped_member_entries)} defects: ' + '; '.join(skipped_member_entries[:3])
            )
        if initial_message_failures:
            message_parts.append(
                f'Initial Teams post failed for {len(initial_message_failures)} defects: ' + '; '.join(initial_message_failures[:3])
            )
        if initial_message_permission_blocked:
            message_parts.append(
                'Summary/Description message was not posted because the current Microsoft Graph app token cannot send regular chat messages. The tenant must grant the required Teams chat message permission model before the initial post can work.'
            )
        if failed_entries:
            message_parts.append(f'Failed for {len(failed_entries)} defects: ' + '; '.join(failed_entries[:3]))
        if abort_reason:
            message_parts.append(abort_reason)
        if not created_count and not failed_entries:
            message_parts.append('No new defects required chatroom creation.')
        return ' '.join(message_parts)
