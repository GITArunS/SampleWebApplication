"""
Operations Hub Configuration Chat

Guided conversational interface for teams to configure Operations Hub
workflows — Trigger Email, Self-Heal iTrack Fields, and Chatrooms —
per application.

Flow:
  Top Level ──► 1. Add a New Application
              ├─► 2. Update Existing Application  ──► pick app ──► 3-section menu
              └─► 3. Remove an Application

Custom overrides are stored as JSON in _email_configs/<id>.json.
Application configs are stored as JSON in _app_configs/<slug>.json.
"""

import json
import os
import re
from datetime import datetime, timezone
from pathlib import Path

# Persistent storage directories
_EMAIL_CONFIG_DIR = Path(__file__).resolve().parent / '_email_configs'
_EMAIL_CONFIG_DIR.mkdir(exist_ok=True)

_APP_CONFIG_DIR = Path(__file__).resolve().parent / '_app_configs'
_APP_CONFIG_DIR.mkdir(exist_ok=True)


# ============================================================================
# LAZY ACCESSORS — avoid circular imports with feature.py
# ============================================================================

def _get_operations():
    from operations.feature import OPERATIONS
    return OPERATIONS


def _get_chatrooms():
    from operations.feature import OPERATIONS_CHATROOMS
    return OPERATIONS_CHATROOMS


def _get_builtin_applications():
    """Return the built-in application list from feature.py."""
    from operations.feature import OPERATIONS_ENABLED_GROUPS_BY_APPLICATION
    return OPERATIONS_ENABLED_GROUPS_BY_APPLICATION


def _get_trigger_email_items(app_name=None):
    """Return list of dicts for Trigger Email operations filtered by app."""
    ops = _get_operations()
    items = []
    if app_name:
        from operations.feature import (
            OPERATIONS_ENABLED_GROUPS_BY_APPLICATION,
            OPERATIONS_ENABLED_OPERATION_IDS_BY_APPLICATION,
            ACC_PROD_HIDDEN_OPERATION_IDS,
            ACC_PROD_ONLY_OPERATION_IDS,
        )
        enabled_groups = OPERATIONS_ENABLED_GROUPS_BY_APPLICATION.get(app_name, set())
        enabled_ids = OPERATIONS_ENABLED_OPERATION_IDS_BY_APPLICATION.get(app_name, set())
        # Only show built-in operations for apps that have them in OPERATIONS_ENABLED_GROUPS
        if enabled_groups:
            for op_id, op in ops.items():
                if op.get('group') != 'Trigger Email':
                    continue
                if op.get('group') not in enabled_groups and op_id not in enabled_ids:
                    continue
                if app_name == 'ACC-Prod' and op_id in ACC_PROD_HIDDEN_OPERATION_IDS:
                    continue
                if app_name != 'ACC-Prod' and op_id in ACC_PROD_ONLY_OPERATION_IDS:
                    continue
                items.append({'id': op_id, 'title': op['title'], 'description': op['description']})
    else:
        for op_id, op in ops.items():
            if op.get('group') == 'Trigger Email':
                items.append({'id': op_id, 'title': op['title'], 'description': op['description']})
    # Also include custom configs for this app
    for cfg in load_all_email_configs():
        if app_name and cfg.get('application') and cfg['application'] != app_name:
            continue
        if not any(item['id'] == cfg.get('id') for item in items):
            items.append({'id': cfg['id'], 'title': cfg.get('name', cfg['id']), 'description': cfg.get('subject', '')})
    return items


def _get_selfheal_items():
    """Return list of dicts for all Self-Heal operations."""
    ops = _get_operations()
    return [
        {'id': op_id, 'title': op['title'], 'description': op['description']}
        for op_id, op in ops.items()
        if op.get('group') == 'Self Heal iTrack Fields'
    ]


def _get_chatroom_items():
    """Return list of dicts for all Chatroom workflows."""
    return [
        {'id': cr['id'], 'title': cr['title'], 'description': cr['description']}
        for cr in _get_chatrooms()
    ]


# ============================================================================
# APPLICATION CONFIG PERSISTENCE
# ============================================================================

def _app_slug(name):
    return re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-') or 'app'


def _app_config_path(app_id):
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', app_id)
    return _APP_CONFIG_DIR / f'{safe_name}.json'


def load_all_app_configs():
    configs = []
    if not _APP_CONFIG_DIR.exists():
        return configs
    for path in sorted(_APP_CONFIG_DIR.glob('*.json')):
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                configs.append(json.load(fh))
        except (json.JSONDecodeError, OSError):
            continue
    return configs


def load_app_config(app_id):
    path = _app_config_path(app_id)
    if path.exists():
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    return None


def save_app_config(config):
    app_id = config.get('id', '')
    if not app_id:
        return
    path = _app_config_path(app_id)
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(config, fh, indent=2, ensure_ascii=False)


def delete_app_config(app_id):
    path = _app_config_path(app_id)
    if path.exists():
        os.remove(path)
        return True
    return False


def get_all_applications():
    """Return combined list of all applications (from options list + custom)."""
    from operations.feature import OPERATIONS_APPLICATION_OPTIONS
    builtin = _get_builtin_applications()
    apps = []
    # Include all applications from the options list
    for name in OPERATIONS_APPLICATION_OPTIONS:
        groups = sorted(builtin.get(name, set()))
        apps.append({
            'id': _app_slug(name),
            'name': name,
            'groups': groups,
            'builtin': True,
        })
    # Add custom apps
    for cfg in load_all_app_configs():
        if cfg.get('disabled'):
            continue
        if not any(a['name'] == cfg.get('name') for a in apps):
            apps.append({
                'id': cfg['id'],
                'name': cfg['name'],
                'groups': cfg.get('groups', []),
                'builtin': False,
            })
    return apps


# ============================================================================
# EMAIL CONFIG PERSISTENCE
# ============================================================================

def _config_path(config_id):
    safe_name = re.sub(r'[^a-zA-Z0-9_-]', '_', config_id)
    return _EMAIL_CONFIG_DIR / f'{safe_name}.json'


def load_all_email_configs():
    configs = []
    if not _EMAIL_CONFIG_DIR.exists():
        return configs
    for path in sorted(_EMAIL_CONFIG_DIR.glob('*.json')):
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                configs.append(json.load(fh))
        except (json.JSONDecodeError, OSError):
            continue
    return configs


def load_email_config(config_id):
    path = _config_path(config_id)
    if path.exists():
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    return None


def save_email_config(config):
    config_id = config.get('id', '')
    if not config_id:
        return
    path = _config_path(config_id)
    with open(path, 'w', encoding='utf-8') as fh:
        json.dump(config, fh, indent=2, ensure_ascii=False)


def delete_email_config(config_id):
    path = _config_path(config_id)
    if path.exists():
        os.remove(path)
        return True
    return False


def _generate_config_id(name):
    slug = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
    return slug or 'email-config'


def _now_iso():
    return datetime.now(timezone.utc).isoformat()


# ============================================================================
# DEFAULT TABLE COLUMNS
# ============================================================================

DEFAULT_TABLE_COLUMNS = [
    'Key', 'Status', 'Severity', 'Summary', 'Created', 'Age', 'Assignee', 'Application Fixed In',
]

# Maps display label → index in the 13-element row produced by issue_to_row()
AVAILABLE_ITRACK_FIELDS = {
    'Key':                      0,
    'Status @ 10 AM IST':       1,
    'Severity':                 2,
    'Summary':                  3,
    'Created':                  4,
    'Age':                      5,
    'Assignee':                 6,
    'EST Fix Date':             7,
    'Application Fixed In':     8,
    'iXP Flag':                 9,
    'Progression/Regression':  10,
    'Status':                  11,
    'Latest Status':           11,
    'DM Comments':             12,
    'Reporter':                13,
}

# Ordered list for display in the chatbot
AVAILABLE_FIELD_LIST = [
    'Key', 'Status', 'Severity', 'Summary', 'Created', 'Age', 'Assignee',
    'EST Fix Date', 'Application Fixed In', 'Reporter', 'iXP Flag',
    'Progression/Regression', 'Status @ 10 AM IST', 'Latest Status', 'DM Comments',
]

DEFAULT_TABLE_COLUMN_FIELDS = [
    'Key', 'Status', 'Severity', 'Summary', 'Created', 'Age', 'Assignee', 'Application Fixed In',
]

ALL_GROUPS = ['Trigger Email', 'Self-Heal iTrack Fields', 'Chatrooms']


# ============================================================================
# MENU TEXTS
# ============================================================================

GREETING = (
    "Hi! I can help you configure **Operations Hub** workflows.\n\n"
    "What would you like to do?\n"
    "1. **Add a New Application**\n"
    "2. **Update Existing Application**\n"
    "3. **Remove an Application**"
)

SECTION_MENU = (
    "Which section would you like to configure?\n"
    "1. **Trigger Email**\n"
    "2. **Self-Heal iTrack Fields**\n"
    "3. **Chatrooms**"
)

TRIGGER_EMAIL_MENU = (
    "**Trigger Email** — What would you like to do?\n\n"
    "1. **Configure a new trigger email**\n"
    "2. **Update an existing trigger email**\n"
    "3. **Delete a custom trigger email**"
)

SELFHEAL_MENU = (
    "**Self-Heal iTrack Fields** — What would you like to do?\n\n"
    "1. **List all self-heal operations**\n"
    "2. **View details of a self-heal operation**"
)

CHATROOM_MENU = (
    "**Chatrooms** — What would you like to do?\n\n"
    "1. **List all chatroom workflows**\n"
    "2. **View details of a chatroom workflow**"
)


# ============================================================================
# HELPERS
# ============================================================================

def _get_field_display_value(config, field_key):
    """Return a human-readable display string for a config field."""
    if not config:
        return ''
    value = config.get(field_key, '')
    if field_key in ('to', 'cc'):
        if isinstance(value, list):
            return '; '.join(value) if value else ''
        return value or ''
    if field_key == 'table_columns':
        if isinstance(value, list):
            return ', '.join(value) if value else ''
        return value or ''
    if field_key == 'table_column_fields':
        if isinstance(value, list):
            return ', '.join(value) if value else ''
        return value or ''
    if isinstance(value, str):
        return _truncate(value, 200)
    return str(value) if value else ''


def _truncate(text, max_len):
    if not text:
        return ''
    text = str(text)
    if len(text) <= max_len:
        return text
    return text[:max_len - 3] + '...'


def _esc_brackets(text):
    """Escape square brackets so they don't break [edit field|value] markers."""
    return str(text).replace('[', '&#91;').replace(']', '&#93;') if text else ''


def _parse_email_list(text):
    if not text:
        return []
    parts = re.split(r'[;,\n]+', text)
    return [p.strip() for p in parts if p.strip()]


def _config_detail_text(cfg):
    lines = [
        f"**Email Configuration: {cfg.get('name', 'Untitled')}**\n",
        f"- **ID:** `{cfg.get('id', '')}`",
        f"- **Subject:** {cfg.get('subject', '—')} [edit subject|{_esc_brackets(cfg.get('subject', ''))}]",
        f"- **Body:** {_truncate(cfg.get('body', '—'), 120)} [edit body|{_esc_brackets(_truncate(cfg.get('body', ''), 120))}]",
        f"- **Note:** {cfg.get('note', '—')} [edit note|{_esc_brackets(cfg.get('note', ''))}]",
        f"- **To:** {'; '.join(cfg.get('to', [])) or '—'} [edit to|{_esc_brackets('; '.join(cfg.get('to', [])))}]",
        f"- **CC:** {'; '.join(cfg.get('cc', [])) or '—'} [edit cc|{_esc_brackets('; '.join(cfg.get('cc', [])))}]",
        f"- **From:** {cfg.get('from_address', '—')} [edit from|{_esc_brackets(cfg.get('from_address', ''))}]",
        f"- **JQL:** `{cfg.get('jql', '—')}` [edit jql|{_esc_brackets(cfg.get('jql', ''))}]",
        f"- **iTrack Fields:** {', '.join(cfg.get('table_column_fields', cfg.get('table_columns', DEFAULT_TABLE_COLUMNS)))} [edit fields|{_esc_brackets(', '.join(cfg.get('table_column_fields', cfg.get('table_columns', DEFAULT_TABLE_COLUMNS))))}]",
        f"- **Column Headers:** {', '.join(cfg.get('table_columns', DEFAULT_TABLE_COLUMNS))} [edit columns|{_esc_brackets(', '.join(cfg.get('table_columns', DEFAULT_TABLE_COLUMNS)))}]",
        f"- **Closing Signature:** {cfg.get('closing_signature', '—')} [edit signature|{_esc_brackets(cfg.get('closing_signature', ''))}]",
    ]
    return "\n".join(lines)


def _builtin_detail_text(item, cfg_override=None):
    cfg = cfg_override or {}
    lines = [
        f"**{item['title']}**\n",
        f"- **ID:** `{item['id']}`",
        f"- **Description:** {item['description']}",
    ]
    if cfg:
        lines.append("")
        lines.append("*Custom overrides saved:*")
        if cfg.get('subject'):
            lines.append(f"- **Subject:** {cfg['subject']}")
        if cfg.get('body'):
            lines.append(f"- **Body:** {_truncate(cfg['body'], 120)}")
        if cfg.get('note'):
            lines.append(f"- **Note:** {cfg['note']}")
        if cfg.get('to'):
            lines.append(f"- **To:** {'; '.join(cfg['to'])}")
        if cfg.get('cc'):
            lines.append(f"- **CC:** {'; '.join(cfg['cc'])}")
        if cfg.get('from_address'):
            lines.append(f"- **From:** {cfg['from_address']}")
        if cfg.get('jql'):
            lines.append(f"- **JQL:** `{_truncate(cfg['jql'], 200)}`")
        if cfg.get('table_column_fields'):
            lines.append(f"- **iTrack Fields:** {', '.join(cfg['table_column_fields'])}")
        if cfg.get('table_columns'):
            lines.append(f"- **Column Headers:** {', '.join(cfg['table_columns'])}")
        if cfg.get('closing_signature'):
            lines.append(f"- **Closing Signature:** {cfg['closing_signature']}")
    else:
        lines.append("\n*No custom overrides. Using built-in defaults.*")
    return "\n".join(lines)


def _match_item(msg, items):
    if not items:
        return None
    try:
        idx = int(msg) - 1
        if 0 <= idx < len(items):
            return items[idx]
        return None
    except ValueError:
        lower_msg = msg.lower()
        for item in items:
            if item.get('title', '').lower() == lower_msg or item.get('id', '').lower() == lower_msg:
                return item
            if item.get('name', '').lower() == lower_msg:
                return item
        return None


def _section_menu_for_app(app_name):
    return f"**Configuring: {app_name}**\n\n" + SECTION_MENU


# ============================================================================
# MAIN ENTRY POINT
# ============================================================================

def handle_chat_message(session_state, user_message):
    """Process a chat message and return (reply_text, updated_session_state)."""
    state = dict(session_state or {})
    step = state.get('step', 'idle')
    msg = (user_message or '').strip()

    if msg.lower() in ('reset', 'start over', 'cancel', 'quit'):
        return GREETING, {'step': 'app_menu'}

    if not msg or step == 'idle':
        return GREETING, {'step': 'app_menu'}

    # ── Top-level application menu ──
    if step == 'app_menu':
        return _handle_app_menu(msg, state)

    # ── Add New Application flow ──
    if step == 'add_app_name':
        return _handle_add_app_name(msg, state)
    if step == 'add_app_groups':
        return _handle_add_app_groups(msg, state)
    if step == 'add_app_release_filter':
        return _handle_add_app_release_filter(msg, state)
    if step == 'add_app_confirm':
        return _handle_add_app_confirm(msg, state)

    # ── Update Existing Application: pick app ──
    if step == 'update_app_pick':
        return _handle_update_app_pick(msg, state)

    # ── Remove Application flow ──
    if step == 'remove_app_pick':
        return _handle_remove_app_pick(msg, state)
    if step == 'remove_app_confirm':
        return _handle_remove_app_confirm(msg, state)

    # ── Section picker (within selected app) ──
    if step == 'pick_section':
        return _handle_pick_section(msg, state)

    # ── Trigger Email sub-menu ──
    if step == 'trigger_menu':
        return _handle_trigger_menu(msg, state)
    if step == 'trigger_pick_existing':
        return _handle_trigger_pick_existing(msg, state)
    if step == 'trigger_pick_view':
        return _handle_trigger_pick_view(msg, state)
    if step == 'trigger_pick_delete':
        return _handle_trigger_pick_delete(msg, state)

    # ── Trigger Email: create flow ──
    if step == 'create_name':
        return _handle_create_name(msg, state)
    if step == 'create_subject':
        return _handle_create_subject(msg, state)
    if step == 'create_body':
        return _handle_create_body(msg, state)
    if step == 'create_note':
        return _handle_create_note(msg, state)
    if step == 'create_to':
        return _handle_create_to(msg, state)
    if step == 'create_cc':
        return _handle_create_cc(msg, state)
    if step == 'create_from':
        return _handle_create_from(msg, state)
    if step == 'create_jql':
        return _handle_create_jql(msg, state)
    if step == 'create_columns':
        return _handle_create_columns(msg, state)
    if step == 'create_signature':
        return _handle_create_signature(msg, state)
    if step == 'create_confirm':
        return _handle_create_confirm(msg, state)

    # ── Trigger Email: update flow ──
    if step == 'update_pick_field':
        return _handle_update_pick_field(msg, state)
    if step == 'update_value':
        return _handle_update_value(msg, state)

    # ── Delete confirm ──
    if step == 'delete_confirm':
        return _handle_delete_confirm(msg, state)

    # ── Self-Heal sub-menu ──
    if step == 'selfheal_menu':
        return _handle_selfheal_menu(msg, state)
    if step == 'selfheal_pick_view':
        return _handle_selfheal_pick_view(msg, state)

    # ── Chatroom sub-menu ──
    if step == 'chatroom_menu':
        return _handle_chatroom_menu(msg, state)
    if step == 'chatroom_pick_view':
        return _handle_chatroom_pick_view(msg, state)

    return GREETING, {'step': 'app_menu'}


# ============================================================================
# TOP-LEVEL APPLICATION MENU
# ============================================================================

def _handle_app_menu(msg, state):
    lower = msg.lower()

    # 1 — Add a New Application
    if lower == '1' or 'add' in lower or ('new' in lower and 'update' not in lower):
        state['step'] = 'add_app_name'
        state['app_draft'] = {}
        return (
            "**Add a New Application**\n\n"
            "Enter the **application name** (e.g. \"MyApp-Prod\", \"Digital-IST\"):"
        ), state

    # 2 — Update Existing Application
    if lower == '2' or 'update' in lower or 'existing' in lower or 'edit' in lower or 'configure' in lower:
        apps = get_all_applications()
        if not apps:
            return "No applications configured yet.\n\n" + GREETING, {'step': 'app_menu'}
        state['step'] = 'update_app_pick'
        lines = ["**Update Existing Application**\n\nWhich application would you like to configure?\n"]
        for i, app in enumerate(apps, 1):
            lines.append(f"{i}. **{app['name']}**")
        return "\n".join(lines), state

    # 3 — Remove an Application
    if lower == '3' or 'remove' in lower or 'delete' in lower:
        custom_apps = load_all_app_configs()
        apps = get_all_applications()
        if not apps:
            return "No applications to remove.\n\n" + GREETING, {'step': 'app_menu'}
        state['step'] = 'remove_app_pick'
        lines = ["**Remove an Application**\n\nWhich application would you like to remove?\n"]
        for i, app in enumerate(apps, 1):
            lines.append(f"{i}. **{app['name']}**")
        return "\n".join(lines), state

    return GREETING, {'step': 'app_menu'}


# ============================================================================
# ADD NEW APPLICATION FLOW
# ============================================================================

def _handle_add_app_name(msg, state):
    name = msg.strip()
    if not name:
        return "Please enter a valid application name:", state

    app_id = _app_slug(name)
    existing = load_app_config(app_id)
    # Also check built-in
    builtin = _get_builtin_applications()
    if existing or name in builtin:
        return (
            f"An application with the name **{name}** (or similar ID `{app_id}`) already exists.\n"
            "Please choose a different name:"
        ), state

    state['app_draft'] = {'id': app_id, 'name': name}
    state['step'] = 'add_app_groups'
    groups_text = "\n".join(f"{i}. **{g}**" for i, g in enumerate(ALL_GROUPS, 1))
    return (
        f"Which groups should be enabled for **{name}**?\n\n"
        f"{groups_text}\n\n"
        "Enter the numbers (comma separated) or type **all** for all groups:\n"
        "Example: `1,2` for Trigger Email and Self-Heal"
    ), state


def _handle_add_app_groups(msg, state):
    lower = msg.lower().strip()
    if lower == 'all':
        selected_groups = list(ALL_GROUPS)
    else:
        nums = [n.strip() for n in msg.split(',') if n.strip()]
        selected_groups = []
        for n in nums:
            try:
                idx = int(n) - 1
                if 0 <= idx < len(ALL_GROUPS):
                    selected_groups.append(ALL_GROUPS[idx])
            except ValueError:
                # Try matching by name
                for g in ALL_GROUPS:
                    if n.lower() in g.lower() and g not in selected_groups:
                        selected_groups.append(g)
        if not selected_groups:
            return "Please select at least one group (enter numbers like `1,2` or type **all**):", state

    state['app_draft']['groups'] = selected_groups
    state['step'] = 'add_app_release_filter'
    return (
        "Does this application need a **Release filter**?\n\n"
        "1. **Yes** — users must select a release before running workflows\n"
        "2. **No** — no release filter needed"
    ), state


def _handle_add_app_release_filter(msg, state):
    lower = msg.lower().strip()
    if lower in ('1', 'yes', 'y'):
        state['app_draft']['release_filter'] = True
    elif lower in ('2', 'no', 'n'):
        state['app_draft']['release_filter'] = False
    else:
        return "Please select **1** (Yes) or **2** (No):", state

    draft = state['app_draft']
    state['step'] = 'add_app_confirm'
    release_text = 'Yes' if draft.get('release_filter') else 'No'
    lines = [
        "Here's a summary of the new application:\n",
        f"- **Name:** {draft['name']}",
        f"- **Groups:** {', '.join(draft.get('groups', []))}",
        f"- **Release Filter:** {release_text}",
        "",
        "Type **yes** to save, or **no** to discard."
    ]
    return "\n".join(lines), state


def _handle_add_app_confirm(msg, state):
    lower = msg.lower()
    if lower in ('yes', 'y', 'save', 'confirm'):
        draft = state.get('app_draft', {})
        now = _now_iso()
        config = {
            'id': draft.get('id', ''),
            'name': draft.get('name', ''),
            'groups': draft.get('groups', []),
            'release_filter': draft.get('release_filter', False),
            'created_at': now,
            'updated_at': now,
        }
        save_app_config(config)
        return (
            f"Application **{config['name']}** has been added successfully!\n\n" + GREETING
        ), {'step': 'app_menu'}
    elif lower in ('no', 'n', 'discard'):
        return "Application creation discarded.\n\n" + GREETING, {'step': 'app_menu'}
    else:
        return "Type **yes** to save or **no** to discard:", state


# ============================================================================
# UPDATE EXISTING APPLICATION — PICK APP
# ============================================================================

def _handle_update_app_pick(msg, state):
    apps = get_all_applications()
    selected = _match_item(msg, apps)
    if selected is None:
        return f"Please enter a number between 1 and {len(apps)}:", state

    state['selected_app'] = selected['name']
    state['selected_app_id'] = selected['id']
    state['step'] = 'pick_section'
    return _section_menu_for_app(selected['name']), state


# ============================================================================
# REMOVE APPLICATION FLOW
# ============================================================================

def _handle_remove_app_pick(msg, state):
    apps = get_all_applications()
    selected = _match_item(msg, apps)
    if selected is None:
        return f"Please enter a number between 1 and {len(apps)}:", state

    state['remove_app_id'] = selected['id']
    state['remove_app_name'] = selected['name']
    state['remove_app_builtin'] = selected.get('builtin', False)
    state['step'] = 'remove_app_confirm'

    if selected.get('builtin'):
        return (
            f"**{selected['name']}** is a built-in application. Removing it will disable it from the chatbot but won't affect the system.\n\n"
            "Type **yes** to confirm or **no** to cancel."
        ), state
    else:
        return (
            f"Are you sure you want to **remove** the application **{selected['name']}**?\n\n"
            "This will delete its configuration. Type **yes** to confirm or **no** to cancel."
        ), state


def _handle_remove_app_confirm(msg, state):
    lower = msg.lower()
    if lower in ('yes', 'y', 'confirm'):
        app_id = state.get('remove_app_id', '')
        app_name = state.get('remove_app_name', app_id)
        is_builtin = state.get('remove_app_builtin', False)

        if is_builtin:
            # Save a "disabled" marker config for the built-in app
            config = {
                'id': app_id,
                'name': app_name,
                'disabled': True,
                'groups': [],
                'updated_at': _now_iso(),
            }
            save_app_config(config)
            reply = f"Application **{app_name}** has been disabled.\n\n" + GREETING
        else:
            deleted = delete_app_config(app_id)
            if deleted:
                reply = f"Application **{app_name}** has been removed.\n\n" + GREETING
            else:
                reply = f"Application `{app_id}` was not found.\n\n" + GREETING
        return reply, {'step': 'app_menu'}
    elif lower in ('no', 'n', 'cancel'):
        return "Removal cancelled.\n\n" + GREETING, {'step': 'app_menu'}
    else:
        return "Type **yes** to confirm or **no** to cancel:", state


# ============================================================================
# SECTION PICKER (within selected application)
# ============================================================================

def _handle_pick_section(msg, state):
    lower = msg.lower()
    app_name = state.get('selected_app', '')

    if lower == '1' or 'trigger' in lower or 'email' in lower:
        state['step'] = 'trigger_menu'
        return TRIGGER_EMAIL_MENU, state

    if lower == '2' or 'self' in lower or 'heal' in lower or 'itrack' in lower:
        state['step'] = 'selfheal_menu'
        return SELFHEAL_MENU, state

    if lower == '3' or 'chatroom' in lower or 'chat room' in lower:
        state['step'] = 'chatroom_menu'
        return CHATROOM_MENU, state

    return _section_menu_for_app(app_name), state


# ============================================================================
# TRIGGER EMAIL SUB-MENU
# ============================================================================

def _handle_trigger_menu(msg, state):
    lower = msg.lower()
    app_name = state.get('selected_app', '')

    # 1 — Configure new
    if lower == '1' or ('new' in lower and 'update' not in lower) or 'create' in lower or 'configure' in lower or ('add' in lower and 'application' not in lower):
        state['step'] = 'create_name'
        state['action'] = 'create'
        state['draft'] = {}
        return "Enter a **name** for this email configuration (e.g. \"Release Open Defects Email\"):", state

    # 2 — Update existing
    if lower == '2' or 'update' in lower or 'edit' in lower or 'modify' in lower:
        items = _get_trigger_email_items(app_name)
        if not items:
            state['step'] = 'trigger_menu'
            return "No trigger email operations found.\n\n" + TRIGGER_EMAIL_MENU, state
        state['action'] = 'update'
        state['step'] = 'trigger_pick_existing'
        lines = ["Which trigger email would you like to update?\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. **{item['title']}**")
        return "\n".join(lines), state

    # 3 — Delete custom
    if lower == '3' or 'delete' in lower or 'remove' in lower:
        custom_configs = load_all_email_configs()
        if not custom_configs:
            state['step'] = 'trigger_menu'
            return "No custom email configurations to delete. Only custom configurations can be deleted.\n\n" + TRIGGER_EMAIL_MENU, state
        state['action'] = 'delete'
        state['step'] = 'trigger_pick_delete'
        lines = ["Which custom email configuration would you like to delete?\n"]
        for i, cfg in enumerate(custom_configs, 1):
            lines.append(f"{i}. **{cfg.get('name', cfg.get('id', 'Untitled'))}**")
        return "\n".join(lines), state

    # 4 — List all
    if lower == '4' or 'list' in lower:
        items = _get_trigger_email_items(app_name)
        if not items:
            reply = "No trigger email operations are configured.\n\n" + TRIGGER_EMAIL_MENU
        else:
            lines = ["**All Trigger Email Operations:**\n"]
            for i, item in enumerate(items, 1):
                lines.append(f"{i}. **{item['title']}**\n   {item['description']}")
            lines.append("\n" + TRIGGER_EMAIL_MENU)
            reply = "\n".join(lines)
        state['step'] = 'trigger_menu'
        return reply, state

    # 5 — View details
    if lower == '5' or 'view' in lower or 'detail' in lower or 'show' in lower:
        items = _get_trigger_email_items(app_name)
        if not items:
            state['step'] = 'trigger_menu'
            return "No trigger email operations found.\n\n" + TRIGGER_EMAIL_MENU, state
        state['action'] = 'view'
        state['step'] = 'trigger_pick_view'
        lines = ["Which trigger email would you like to view?\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. **{item['title']}**")
        return "\n".join(lines), state

    return TRIGGER_EMAIL_MENU, {'step': 'trigger_menu', 'selected_app': state.get('selected_app', ''), 'selected_app_id': state.get('selected_app_id', '')}


def _handle_trigger_pick_existing(msg, state):
    """User selects which existing trigger email to update."""
    app_name = state.get('selected_app', '')
    items = _get_trigger_email_items(app_name)
    selected = _match_item(msg, items)
    if selected is None:
        return f"Please enter a number between 1 and {len(items)}:", state

    config_id = selected['id']
    config = load_email_config(config_id)

    state['selected_config_id'] = config_id
    state['selected_config_name'] = selected['title']
    state['step'] = 'update_pick_field'

    # Show all fields with inline edit buttons
    cfg = config or {}
    lines = [
        f"**{selected['title']}**\n",
        f"- **Subject:** {cfg.get('subject') or '*(not set)*'} [edit subject|{_esc_brackets(cfg.get('subject', ''))}]",
        f"- **Body:** {_truncate(cfg.get('body', ''), 120) or '*(not set)*'} [edit body|{_esc_brackets(_truncate(cfg.get('body', ''), 120))}]",
        f"- **Note:** {cfg.get('note') or '*(not set)*'} [edit note|{_esc_brackets(cfg.get('note', ''))}]",
        f"- **To:** {'; '.join(cfg.get('to', [])) or '*(not set)*'} [edit to|{_esc_brackets('; '.join(cfg.get('to', [])))}]",
        f"- **CC:** {'; '.join(cfg.get('cc', [])) or '*(not set)*'} [edit cc|{_esc_brackets('; '.join(cfg.get('cc', [])))}]",
        f"- **From:** {cfg.get('from_address') or '*(not set)*'} [edit from|{_esc_brackets(cfg.get('from_address', ''))}]",
        f"- **JQL:** `{cfg.get('jql', '') or '*(not set)*'}` [edit jql|{_esc_brackets(cfg.get('jql', ''))}]",
        f"- **iTrack Fields:** {', '.join(cfg.get('table_column_fields', cfg.get('table_columns', []))) or '*(not set)*'} [edit fields|{_esc_brackets(', '.join(cfg.get('table_column_fields', cfg.get('table_columns', []))))}]",
        f"- **Column Headers:** {', '.join(cfg.get('table_columns', [])) or '*(not set)*'} [edit columns|{_esc_brackets(', '.join(cfg.get('table_columns', [])))}]",
        f"- **Closing Signature:** {cfg.get('closing_signature') or '*(not set)*'} [edit signature|{_esc_brackets(cfg.get('closing_signature', ''))}]",
    ]
    return "\n".join(lines), state


def _handle_trigger_pick_view(msg, state):
    """User selects which trigger email to view."""
    app_name = state.get('selected_app', '')
    items = _get_trigger_email_items(app_name)
    selected = _match_item(msg, items)
    if selected is None:
        return f"Please enter a number between 1 and {len(items)}:", state

    config = load_email_config(selected['id'])
    ops = _get_operations()
    if selected['id'] not in ops and config:
        detail = _config_detail_text(config)
    else:
        has_overrides = config and any(v for k, v in config.items() if k not in ('id', 'name', 'created_at', 'updated_at', 'application'))
        detail = _builtin_detail_text(selected, config if has_overrides else None)

    detail += "\n\n" + TRIGGER_EMAIL_MENU
    state['step'] = 'trigger_menu'
    return detail, state


def _handle_trigger_pick_delete(msg, state):
    """User selects which custom config to delete."""
    custom_configs = load_all_email_configs()
    if not custom_configs:
        state['step'] = 'trigger_menu'
        return "No custom configurations to delete.\n\n" + TRIGGER_EMAIL_MENU, state

    try:
        idx = int(msg) - 1
        if 0 <= idx < len(custom_configs):
            selected = custom_configs[idx]
        else:
            return f"Please enter a number between 1 and {len(custom_configs)}:", state
    except ValueError:
        lower_msg = msg.lower()
        selected = None
        for cfg in custom_configs:
            if cfg.get('name', '').lower() == lower_msg or cfg.get('id', '').lower() == lower_msg:
                selected = cfg
                break
        if not selected:
            return f"Not found. Please enter a number (1–{len(custom_configs)}) or exact name:", state

    state['selected_config_id'] = selected['id']
    state['selected_config_name'] = selected.get('name', selected['id'])
    state['step'] = 'delete_confirm'
    return (
        f"Are you sure you want to **delete** the email configuration **{selected.get('name', selected['id'])}**?\n\n"
        "Type **yes** to confirm or **no** to cancel."
    ), state


# ============================================================================
# TRIGGER EMAIL: CREATE FLOW
# ============================================================================

def _handle_create_name(msg, state):
    name = msg.strip()
    if not name:
        return "Please enter a valid name for the email configuration:", state

    app_name = state.get('selected_app', '')
    app_prefix = _app_slug(app_name) + '-' if app_name else ''
    config_id = app_prefix + _generate_config_id(name)
    existing = load_email_config(config_id)
    if existing:
        return (
            f"An email configuration with a similar ID (`{config_id}`) already exists.\n"
            "Please choose a different name:"
        ), state

    state['draft'] = {'id': config_id, 'name': name}
    state['step'] = 'create_subject'
    return "Enter the **email subject** line (e.g. \"ACTION Required: Release Open Defects\"):", state


def _handle_create_subject(msg, state):
    state['draft']['subject'] = msg.strip()
    state['step'] = 'create_body'
    return (
        "Enter the **email body** text. This is the introductory paragraph shown before the defect table.\n\n"
        "Example: *Below are the current release open defects. Please review and take action.*"
    ), state


def _handle_create_body(msg, state):
    state['draft']['body'] = msg.strip()
    state['step'] = 'create_note'
    return (
        "Enter an optional **note** to display above the table (or type **skip** to omit):\n\n"
        "Example: *This is a BOT generated email, kindly reach out to &lt;your team DL&gt; for any questions.*"
    ), state


def _handle_create_note(msg, state):
    if msg.lower() == 'skip':
        state['draft']['note'] = ''
    else:
        state['draft']['note'] = msg.strip()
    state['step'] = 'create_to'
    return (
        "Enter the **To** recipient email addresses (semicolon or comma separated):\n\n"
        "Example: *user1@att.com; user2@att.com*\n\n"
        "Type **dynamic** if recipients should be resolved from defect assignees at runtime."
    ), state


def _handle_create_to(msg, state):
    if msg.lower() == 'dynamic':
        state['draft']['to'] = ['__dynamic__']
    else:
        addrs = _parse_email_list(msg)
        if not addrs:
            return "Please enter at least one recipient email address:", state
        state['draft']['to'] = addrs
    state['step'] = 'create_cc'
    return "Enter the **CC** recipient email addresses (semicolon or comma separated), or type **skip**:", state


def _handle_create_cc(msg, state):
    if msg.lower() == 'skip':
        state['draft']['cc'] = []
    else:
        state['draft']['cc'] = _parse_email_list(msg)
    state['step'] = 'create_from'
    return "Enter the **From** sender address (e.g. `dl-CTX-IDC-CQE-ACC_Prod_DM@intl.att.com`), or type **skip** to use the default:", state


def _handle_create_from(msg, state):
    if msg.lower() == 'skip':
        state['draft']['from_address'] = ''
    else:
        state['draft']['from_address'] = msg.strip()
    state['step'] = 'create_jql'
    return (
        "Enter the **JQL query** to pull defect data for the email table.\n\n"
        "Example:\n"
        "`project = CDEX AND status not in (Accepted, Cancelled) ORDER BY severity ASC`\n\n"
        "You can use `{release}` as a placeholder for the selected release name."
    ), state


def _handle_create_jql(msg, state):
    jql = msg.strip()
    if not jql:
        return "Please enter a valid JQL query:", state
    state['draft']['jql'] = jql
    state['step'] = 'create_columns'
    fields_json = json.dumps(AVAILABLE_FIELD_LIST)
    defaults_json = json.dumps(DEFAULT_TABLE_COLUMN_FIELDS)
    return (
        "Select the **iTrack fields** to include as table columns.\n"
        "Check the fields you want, drag to reorder, and optionally rename column headers.\n\n"
        f"[field_selector|{fields_json}|{defaults_json}]"
    ), state


def _handle_create_columns(msg, state):
    # Accept JSON payload from the field selector widget
    stripped = msg.strip()
    if stripped.startswith('{'):
        try:
            payload = json.loads(stripped)
            selected = payload.get('fields', [])
            labels = payload.get('labels', [])
            custom = payload.get('custom_fields', [])  # list of {name, field_id}
        except (json.JSONDecodeError, AttributeError):
            selected, labels, custom = [], [], []
    elif stripped.lower() == 'default':
        selected = list(DEFAULT_TABLE_COLUMN_FIELDS)
        labels = list(DEFAULT_TABLE_COLUMNS)
        custom = []
    else:
        # Fallback: comma-separated field names
        selected = [c.strip() for c in stripped.split(',') if c.strip()]
        labels = list(selected)
        custom = []

    if not selected:
        selected = list(DEFAULT_TABLE_COLUMN_FIELDS)
        labels = list(DEFAULT_TABLE_COLUMNS)

    # Register any custom fields
    custom_field_map = {}
    for cf in custom:
        cf_name = cf.get('name', '')
        cf_field = cf.get('field_id', '')
        if cf_name and cf_field:
            custom_field_map[cf_name] = cf_field
            if cf_name not in AVAILABLE_ITRACK_FIELDS:
                AVAILABLE_ITRACK_FIELDS[cf_name] = cf_field
            if cf_name not in AVAILABLE_FIELD_LIST:
                AVAILABLE_FIELD_LIST.append(cf_name)

    # Validate known fields
    invalid = [f for f in selected if f not in AVAILABLE_ITRACK_FIELDS]
    if invalid:
        fields_json = json.dumps(AVAILABLE_FIELD_LIST)
        defaults_json = json.dumps(selected)
        return (
            f"Unknown field(s): **{', '.join(invalid)}**. Please re-select.\n\n"
            f"[field_selector|{fields_json}|{defaults_json}]"
        ), state

    state['draft']['table_column_fields'] = selected
    state['draft']['table_columns'] = labels if len(labels) == len(selected) else list(selected)
    if custom_field_map:
        state['draft']['custom_field_map'] = custom_field_map
    state['step'] = 'create_signature'
    return (
        "Enter the **closing signature** for the email, or type **skip**:\n\n"
        "Example: *Regards,<br/>ACC Prod DM Team*"
    ), state


def _handle_create_signature(msg, state):
    if msg.lower() == 'skip':
        state['draft']['closing_signature'] = ''
    else:
        state['draft']['closing_signature'] = msg.strip()

    draft = state['draft']
    state['step'] = 'create_confirm'
    lines = [
        "Great! Here's a summary of the new email configuration:\n",
        f"- **Name:** {draft.get('name', '')}",
        f"- **Subject:** {draft.get('subject', '')}",
        f"- **Body:** {_truncate(draft.get('body', ''), 120)}",
        f"- **Note:** {draft.get('note', '') or '(none)'}",
        f"- **To:** {'; '.join(draft.get('to', [])) or '(none)'}",
        f"- **CC:** {'; '.join(draft.get('cc', [])) or '(none)'}",
        f"- **From:** {draft.get('from_address', '') or '(default)'}",
        f"- **JQL:** `{_truncate(draft.get('jql', ''), 200)}`",
        f"- **iTrack Fields:** {', '.join(draft.get('table_column_fields', []))}",
        f"- **Column Headers:** {', '.join(draft.get('table_columns', []))}",
        f"- **Closing Signature:** {draft.get('closing_signature', '') or '(none)'}",
        "",
        "Type **yes** to save, or **no** to discard."
    ]
    return "\n".join(lines), state


def _handle_create_confirm(msg, state):
    lower = msg.lower()
    if lower in ('yes', 'y', 'save', 'confirm'):
        draft = state.get('draft', {})
        now = _now_iso()
        config = {
            'id': draft.get('id', ''),
            'name': draft.get('name', ''),
            'application': state.get('selected_app', ''),
            'subject': draft.get('subject', ''),
            'body': draft.get('body', ''),
            'note': draft.get('note', ''),
            'to': draft.get('to', []),
            'cc': draft.get('cc', []),
            'from_address': draft.get('from_address', ''),
            'jql': draft.get('jql', ''),
            'table_columns': draft.get('table_columns', list(DEFAULT_TABLE_COLUMNS)),
            'table_column_fields': draft.get('table_column_fields', list(DEFAULT_TABLE_COLUMN_FIELDS)),
            'custom_field_map': draft.get('custom_field_map', {}),
            'closing_signature': draft.get('closing_signature', ''),
            'created_at': now,
            'updated_at': now,
        }
        save_email_config(config)
        return (
            f"Email configuration **{config['name']}** has been saved successfully!\n\n" + TRIGGER_EMAIL_MENU
        ), {**state, 'step': 'trigger_menu', 'draft': None}
    elif lower in ('no', 'n', 'discard'):
        return "Configuration discarded.\n\n" + TRIGGER_EMAIL_MENU, {**state, 'step': 'trigger_menu', 'draft': None}
    else:
        return "Type **yes** to save or **no** to discard:", state


# ============================================================================
# TRIGGER EMAIL: UPDATE FLOW
# ============================================================================

_UPDATE_FIELD_MAP = {
    '1': 'subject', '2': 'body', '3': 'note', '4': 'to', '5': 'cc',
    '6': 'from_address', '7': 'jql', '8': 'table_column_fields', '9': 'table_columns', '10': 'closing_signature',
    'subject': 'subject', 'body': 'body', 'note': 'note', 'to': 'to', 'cc': 'cc',
    'from': 'from_address', 'from_address': 'from_address', 'jql': 'jql',
    'fields': 'table_column_fields', 'table_column_fields': 'table_column_fields', 'itrack fields': 'table_column_fields',
    'columns': 'table_columns', 'table_columns': 'table_columns', 'table columns': 'table_columns',
    'signature': 'closing_signature', 'closing_signature': 'closing_signature', 'closing signature': 'closing_signature',
}

_FIELD_PROMPTS = {
    'subject': "Enter the new **email subject**:",
    'body': "Enter the new **email body** text:",
    'note': "Enter the new **note** (or **skip** to clear):",
    'to': "Enter the new **To** recipients (semicolon or comma separated), or **dynamic**:",
    'cc': "Enter the new **CC** recipients (semicolon or comma separated), or **skip** to clear:",
    'from_address': "Enter the new **From** address, or **skip** to use default:",
    'jql': "Enter the new **JQL query**:",
    'table_column_fields': None,  # handled dynamically in _handle_update_pick_field
    'table_columns': "Enter the new **column headers** (comma separated), or **default**:",
    'closing_signature': "Enter the new **closing signature**, or **skip** to clear:",
}


def _handle_update_pick_field(msg, state):
    lower = msg.lower().strip()

    if lower in ('11', 'done', 'back', 'menu'):
        state['step'] = 'trigger_menu'
        return TRIGGER_EMAIL_MENU, state

    field_key = _UPDATE_FIELD_MAP.get(lower)
    if not field_key:
        return "Please select a field number (1–10) or type **done** to go back:", state

    state['update_field'] = field_key
    state['step'] = 'update_value'

    # Show current value for the selected field
    config_id = state.get('selected_config_id', '')
    config = load_email_config(config_id) or {}

    # Special handling for iTrack fields — render field selector widget
    if field_key == 'table_column_fields':
        current_fields = config.get('table_column_fields', config.get('table_columns', []))
        fields_json = json.dumps(AVAILABLE_FIELD_LIST)
        defaults_json = json.dumps(current_fields)
        current_labels = config.get('table_columns', [])
        labels_json = json.dumps(current_labels)
        return (
            "Update the **iTrack fields** for the email table.\n"
            "Check the fields you want, drag to reorder, and optionally rename column headers.\n\n"
            f"[field_selector|{fields_json}|{defaults_json}|{labels_json}]"
        ), state

    current_value = _get_field_display_value(config, field_key)
    prompt = _FIELD_PROMPTS.get(field_key, f"Enter the new value for **{field_key}**:")

    if current_value:
        return f"**Current value:** {current_value}\n\n{prompt}", state
    else:
        return f"**Current value:** *(not set)*\n\n{prompt}", state


def _handle_update_value(msg, state):
    config_id = state.get('selected_config_id', '')
    config = load_email_config(config_id)
    if not config:
        config = {
            'id': config_id,
            'name': state.get('selected_config_name', config_id),
            'application': state.get('selected_app', ''),
            'subject': '', 'body': '', 'note': '',
            'to': [], 'cc': [], 'from_address': '',
            'jql': '', 'table_columns': [], 'closing_signature': '',
            'created_at': _now_iso(), 'updated_at': _now_iso(),
        }

    field = state.get('update_field', '')
    lower_msg = msg.lower().strip()

    if field == 'to':
        if lower_msg == 'dynamic':
            config['to'] = ['__dynamic__']
        else:
            addrs = _parse_email_list(msg)
            if not addrs:
                return "Please enter at least one recipient email address:", state
            config['to'] = addrs
    elif field == 'cc':
        config['cc'] = [] if lower_msg == 'skip' else _parse_email_list(msg)
    elif field == 'from_address':
        config['from_address'] = '' if lower_msg == 'skip' else msg.strip()
    elif field == 'note':
        config['note'] = '' if lower_msg == 'skip' else msg.strip()
    elif field == 'closing_signature':
        config['closing_signature'] = '' if lower_msg == 'skip' else msg.strip()
    elif field == 'table_column_fields':
        stripped = msg.strip()
        if stripped.startswith('{'):
            try:
                payload = json.loads(stripped)
                selected_fields = payload.get('fields', [])
                labels = payload.get('labels', [])
                custom = payload.get('custom_fields', [])
            except (json.JSONDecodeError, AttributeError):
                selected_fields, labels, custom = [], [], []
            # Register custom fields and persist mapping
            custom_field_map = config.get('custom_field_map', {})
            for cf in custom:
                cf_name = cf.get('name', '')
                cf_field = cf.get('field_id', '')
                if cf_name and cf_field:
                    custom_field_map[cf_name] = cf_field
                    if cf_name not in AVAILABLE_ITRACK_FIELDS:
                        AVAILABLE_ITRACK_FIELDS[cf_name] = cf_field
                    if cf_name not in AVAILABLE_FIELD_LIST:
                        AVAILABLE_FIELD_LIST.append(cf_name)
            if not selected_fields:
                return "Please select at least one field.", state
            config['table_column_fields'] = selected_fields
            config['table_columns'] = labels if len(labels) == len(selected_fields) else list(selected_fields)
            config['custom_field_map'] = custom_field_map
        elif stripped.lower() == 'default':
            config['table_column_fields'] = list(DEFAULT_TABLE_COLUMN_FIELDS)
            config['table_columns'] = list(DEFAULT_TABLE_COLUMNS)
        else:
            selected_fields = []
            for part in msg.split(','):
                part = part.strip()
                if part.isdigit():
                    idx = int(part) - 1
                    if 0 <= idx < len(AVAILABLE_FIELD_LIST):
                        selected_fields.append(AVAILABLE_FIELD_LIST[idx])
                        continue
                matched = next((f for f in AVAILABLE_FIELD_LIST if f.lower() == part.lower()), None)
                if matched:
                    selected_fields.append(matched)
            invalid = [f for f in selected_fields if f not in AVAILABLE_ITRACK_FIELDS]
            if invalid:
                return f"Unknown field(s): {', '.join(invalid)}. Please try again:", state
            if not selected_fields:
                return "Please enter valid field numbers or names:", state
            config['table_column_fields'] = selected_fields
            config['table_columns'] = list(selected_fields)
    elif field == 'table_columns':
        if lower_msg == 'default':
            config['table_columns'] = list(DEFAULT_TABLE_COLUMNS)
        else:
            cols = [c.strip() for c in msg.split(',') if c.strip()]
            config['table_columns'] = cols if cols else list(DEFAULT_TABLE_COLUMNS)
    elif field == 'jql':
        if not msg.strip():
            return "Please enter a valid JQL query:", state
        config['jql'] = msg.strip()
    else:
        config[field] = msg.strip()

    config['updated_at'] = _now_iso()
    save_email_config(config)

    state['step'] = 'update_pick_field'
    cfg = config
    lines = [
        f"**{field.replace('_', ' ').title()}** has been updated!\n",
        f"- **Subject:** {cfg.get('subject') or '*(not set)*'} [edit subject|{_esc_brackets(cfg.get('subject', ''))}]",
        f"- **Body:** {_truncate(cfg.get('body', ''), 120) or '*(not set)*'} [edit body|{_esc_brackets(_truncate(cfg.get('body', ''), 120))}]",
        f"- **Note:** {cfg.get('note') or '*(not set)*'} [edit note|{_esc_brackets(cfg.get('note', ''))}]",
        f"- **To:** {'; '.join(cfg.get('to', [])) or '*(not set)*'} [edit to|{_esc_brackets('; '.join(cfg.get('to', [])))}]",
        f"- **CC:** {'; '.join(cfg.get('cc', [])) or '*(not set)*'} [edit cc|{_esc_brackets('; '.join(cfg.get('cc', [])))}]",
        f"- **From:** {cfg.get('from_address') or '*(not set)*'} [edit from|{_esc_brackets(cfg.get('from_address', ''))}]",
        f"- **JQL:** `{cfg.get('jql', '') or '*(not set)*'}` [edit jql|{_esc_brackets(cfg.get('jql', ''))}]",
        f"- **iTrack Fields:** {', '.join(cfg.get('table_column_fields', cfg.get('table_columns', []))) or '*(not set)*'} [edit fields|{_esc_brackets(', '.join(cfg.get('table_column_fields', cfg.get('table_columns', []))))}]",
        f"- **Column Headers:** {', '.join(cfg.get('table_columns', [])) or '*(not set)*'} [edit columns|{_esc_brackets(', '.join(cfg.get('table_columns', [])))}]",
        f"- **Closing Signature:** {cfg.get('closing_signature') or '*(not set)*'} [edit signature|{_esc_brackets(cfg.get('closing_signature', ''))}]",
    ]
    return "\n".join(lines), state


# ============================================================================
# DELETE CONFIRM
# ============================================================================

def _handle_delete_confirm(msg, state):
    lower = msg.lower()
    if lower in ('yes', 'y', 'confirm'):
        config_id = state.get('selected_config_id', '')
        config_name = state.get('selected_config_name', config_id)
        deleted = delete_email_config(config_id)
        if deleted:
            reply = f"Email configuration **{config_name}** has been deleted.\n\n" + TRIGGER_EMAIL_MENU
        else:
            reply = f"Configuration `{config_id}` was not found.\n\n" + TRIGGER_EMAIL_MENU
        state['step'] = 'trigger_menu'
        return reply, state
    elif lower in ('no', 'n', 'cancel'):
        state['step'] = 'trigger_menu'
        return "Delete cancelled.\n\n" + TRIGGER_EMAIL_MENU, state
    else:
        return "Type **yes** to confirm deletion or **no** to cancel:", state


# ============================================================================
# SELF-HEAL SUB-MENU
# ============================================================================

def _handle_selfheal_menu(msg, state):
    lower = msg.lower()

    if lower == '1' or 'list' in lower:
        items = _get_selfheal_items()
        if not items:
            state['step'] = 'selfheal_menu'
            return "No self-heal operations are configured.\n\n" + SELFHEAL_MENU, state
        lines = ["**All Self-Heal iTrack Fields Operations:**\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. **{item['title']}**\n   {item['description']}")
        lines.append("\n" + SELFHEAL_MENU)
        state['step'] = 'selfheal_menu'
        return "\n".join(lines), state

    if lower == '2' or 'view' in lower or 'detail' in lower or 'show' in lower:
        items = _get_selfheal_items()
        if not items:
            state['step'] = 'selfheal_menu'
            return "No self-heal operations found.\n\n" + SELFHEAL_MENU, state
        state['step'] = 'selfheal_pick_view'
        lines = ["Which self-heal operation would you like to view?\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. **{item['title']}**")
        return "\n".join(lines), state

    return SELFHEAL_MENU, state


def _handle_selfheal_pick_view(msg, state):
    items = _get_selfheal_items()
    selected = _match_item(msg, items)
    if selected is None:
        return f"Please enter a number between 1 and {len(items)}:", state

    lines = [
        f"**{selected['title']}**\n",
        f"- **ID:** `{selected['id']}`",
        f"- **Description:** {selected['description']}",
        "",
        SELFHEAL_MENU,
    ]
    state['step'] = 'selfheal_menu'
    return "\n".join(lines), state


# ============================================================================
# CHATROOM SUB-MENU
# ============================================================================

def _handle_chatroom_menu(msg, state):
    lower = msg.lower()

    if lower == '1' or 'list' in lower:
        items = _get_chatroom_items()
        if not items:
            state['step'] = 'chatroom_menu'
            return "No chatroom workflows are configured.\n\n" + CHATROOM_MENU, state
        lines = ["**All Chatroom Workflows:**\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. **{item['title']}**\n   {item['description']}")
        lines.append("\n" + CHATROOM_MENU)
        state['step'] = 'chatroom_menu'
        return "\n".join(lines), state

    if lower == '2' or 'view' in lower or 'detail' in lower or 'show' in lower:
        items = _get_chatroom_items()
        if not items:
            state['step'] = 'chatroom_menu'
            return "No chatroom workflows found.\n\n" + CHATROOM_MENU, state
        state['step'] = 'chatroom_pick_view'
        lines = ["Which chatroom workflow would you like to view?\n"]
        for i, item in enumerate(items, 1):
            lines.append(f"{i}. **{item['title']}**")
        return "\n".join(lines), state

    return CHATROOM_MENU, state


def _handle_chatroom_pick_view(msg, state):
    items = _get_chatroom_items()
    selected = _match_item(msg, items)
    if selected is None:
        return f"Please enter a number between 1 and {len(items)}:", state

    lines = [
        f"**{selected['title']}**\n",
        f"- **ID:** `{selected['id']}`",
        f"- **Description:** {selected['description']}",
        "",
        CHATROOM_MENU,
    ]
    state['step'] = 'chatroom_menu'
    return "\n".join(lines), state
