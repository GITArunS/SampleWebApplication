from flask import redirect, render_template, request, url_for
import requests


class LoginFeature:
    def __init__(
        self,
        get_session_credentials,
        store_session_credentials,
        clear_session_credentials,
        validate_jira_credentials,
    ):
        self.get_session_credentials = get_session_credentials
        self.store_session_credentials = store_session_credentials
        self.clear_session_credentials = clear_session_credentials
        self.validate_jira_credentials = validate_jira_credentials

    def register(self, app):
        @app.route('/')
        def login_page():
            if self.get_session_credentials() is not None:
                return redirect(url_for('operations_page'))

            return render_template(
                'login.html',
                page_title='Quality Lens 360 | Login',
                status=request.args.get('status'),
                message=request.args.get('message'),
            )

        @app.post('/login')
        def login():
            jira_username = (request.form.get('jira_username') or '').strip()
            jira_password = (request.form.get('jira_password') or '').strip()

            if not jira_username:
                return redirect(
                    url_for(
                        'login_page',
                        status='error',
                        message='Enter your Jira/iTrack ID.',
                    )
                )

            if not jira_password:
                return redirect(
                    url_for(
                        'login_page',
                        status='error',
                        message='Enter your Jira/iTrack password or API token.',
                    )
                )

            try:
                self.validate_jira_credentials(username=jira_username, password=jira_password)
            except requests.RequestException as error:
                if (
                    isinstance(error, requests.HTTPError)
                    and getattr(error, 'response', None) is not None
                    and error.response.status_code == 401
                ):
                    message = 'Jira/iTrack sign-in failed. Enter a valid Jira/iTrack ID and password, then try again.'
                else:
                    message = f'Jira/iTrack sign-in could not be verified: {error}'
                return redirect(
                    url_for('login_page', status='error', message=message)
                )

            self.store_session_credentials(jira_username, jira_password)
            return redirect(url_for('home'))

        @app.post('/logout')
        def logout():
            self.clear_session_credentials()
            return redirect(
                url_for(
                    'login_page',
                    status='success',
                    message='You have been signed out.',
                )
            )
