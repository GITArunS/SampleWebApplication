"""Flask application factory."""

from __future__ import annotations

from flask import Flask
from werkzeug.middleware.proxy_fix import ProxyFix

from defectLens.config import Settings, get_settings
from defectLens.logging_conf import configure_logging
from defectLens.ui.routes.web import web_blueprint
from defectLens.core.services.job_service import AnalysisJobService, JobStore


def create_app(settings: Settings | None = None) -> Flask:
    """Create and configure the Flask application."""

    resolved = settings if settings is not None else get_settings()
    configure_logging(resolved)

    app = Flask(
        __name__,
        template_folder=str(resolved.template_dir),
        static_folder=str(resolved.static_dir),
        static_url_path="/static",
    )
    app.config["MAX_CONTENT_LENGTH"] = resolved.max_content_length
    app.config["SEND_FILE_MAX_AGE_DEFAULT"] = 0
    app.config["PREFERRED_URL_SCHEME"] = resolved.preferred_scheme
    if resolved.external_host:
        app.config["SERVER_NAME"] = resolved.external_host
    app.config["settings"] = resolved
    if resolved.trust_proxy:
        app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1, x_port=1)
    app.extensions["job_store"] = JobStore()
    app.extensions["job_service"] = AnalysisJobService(resolved, app.extensions["job_store"])
    app.register_blueprint(web_blueprint)
    return app
